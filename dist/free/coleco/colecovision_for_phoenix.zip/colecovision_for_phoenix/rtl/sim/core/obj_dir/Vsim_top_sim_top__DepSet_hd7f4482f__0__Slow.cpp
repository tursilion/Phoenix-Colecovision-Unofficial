// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vsim_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vsim_top__Syms.h"
#include "Vsim_top_sim_top.h"

VL_ATTR_COLD void Vsim_top_sim_top___ctor_var_reset(Vsim_top_sim_top* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+      Vsim_top_sim_top___ctor_var_reset\n"); );
    // Body
    vlSelf->clk = VL_RAND_RESET_I(1);
    vlSelf->clk_3m58_en = VL_RAND_RESET_I(1);
    vlSelf->por_n = VL_RAND_RESET_I(1);
    vlSelf->p1 = VL_RAND_RESET_I(2);
    vlSelf->p2 = VL_RAND_RESET_I(2);
    vlSelf->p3 = VL_RAND_RESET_I(2);
    vlSelf->p4 = VL_RAND_RESET_I(2);
    vlSelf->p6 = VL_RAND_RESET_I(2);
    vlSelf->p7 = VL_RAND_RESET_I(2);
    vlSelf->p9 = VL_RAND_RESET_I(2);
    vlSelf->p5 = VL_RAND_RESET_I(1);
    vlSelf->p8 = VL_RAND_RESET_I(1);
    vlSelf->sd_miso = VL_RAND_RESET_I(1);
    vlSelf->sd_mosi = VL_RAND_RESET_I(1);
    vlSelf->sd_sclk = VL_RAND_RESET_I(1);
    vlSelf->sd_cs_n = VL_RAND_RESET_I(1);
    vlSelf->sram_addr = VL_RAND_RESET_I(19);
    vlSelf->sram_wdata = VL_RAND_RESET_I(8);
    vlSelf->sram_rdata = VL_RAND_RESET_I(8);
    vlSelf->sram_we_n = VL_RAND_RESET_I(1);
    vlSelf->sram_ce_n = VL_RAND_RESET_I(1);
    vlSelf->led = VL_RAND_RESET_I(1);
    vlSelf->cpu_a = VL_RAND_RESET_I(15);
    vlSelf->cart_en_n = VL_RAND_RESET_I(1);
    vlSelf->dbg_m1_n = VL_RAND_RESET_I(1);
    vlSelf->dbg_addr = VL_RAND_RESET_I(16);
    vlSelf->dbg_clken = VL_RAND_RESET_I(1);
    vlSelf->dbg_loader = VL_RAND_RESET_I(1);
    vlSelf->dbg_din = VL_RAND_RESET_I(8);
    vlSelf->dbg_iorq_n = VL_RAND_RESET_I(1);
    vlSelf->dbg_wr_n = VL_RAND_RESET_I(1);
    vlSelf->dbg_sdcs_n = VL_RAND_RESET_I(1);
    vlSelf->dbg_dout = VL_RAND_RESET_I(8);
    vlSelf->dbg_ext = VL_RAND_RESET_I(8);
    vlSelf->dbg_mux = VL_RAND_RESET_I(8);
    vlSelf->dbg_mreq_n = VL_RAND_RESET_I(1);
    vlSelf->dbg_ext_en = VL_RAND_RESET_I(1);
    vlSelf->dbg_mc_bank = VL_RAND_RESET_I(6);
    vlSelf->dbg_rd_n = VL_RAND_RESET_I(1);
    vlSelf->dbg_cwait_n = VL_RAND_RESET_I(1);
    vlSelf->dbg_tstate = VL_RAND_RESET_I(3);
    vlSelf->dbg_mcycle = VL_RAND_RESET_I(3);
    vlSelf->dbg_rom_page = VL_RAND_RESET_I(8);
    vlSelf->dbg_mask = VL_RAND_RESET_I(8);
    vlSelf->dbg_c_line = VL_RAND_RESET_I(6);
    vlSelf->dbg_c_hit = VL_RAND_RESET_I(1);
    vlSelf->__PVT__cart_bus = VL_RAND_RESET_I(8);
}
