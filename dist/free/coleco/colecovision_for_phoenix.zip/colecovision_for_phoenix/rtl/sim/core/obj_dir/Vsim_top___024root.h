// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vsim_top.h for the primary calling header

#ifndef VERILATED_VSIM_TOP___024ROOT_H_
#define VERILATED_VSIM_TOP___024ROOT_H_  // guard

#include "verilated.h"
class Vsim_top_sim_top;


class Vsim_top__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vsim_top___024root final : public VerilatedModule {
  public:
    // CELLS
    Vsim_top_sim_top* sim_top;

    // DESIGN SPECIFIC STATE
    VL_IN8(clk,0,0);
    VL_IN8(clk_3m58_en,0,0);
    VL_IN8(por_n,0,0);
    VL_IN8(p1,2,1);
    VL_IN8(p2,2,1);
    VL_IN8(p3,2,1);
    VL_IN8(p4,2,1);
    VL_IN8(p6,2,1);
    VL_IN8(p7,2,1);
    VL_IN8(p9,2,1);
    VL_OUT8(p5,0,0);
    VL_OUT8(p8,0,0);
    VL_IN8(sd_miso,0,0);
    VL_OUT8(sd_mosi,0,0);
    VL_OUT8(sd_sclk,0,0);
    VL_OUT8(sd_cs_n,0,0);
    VL_OUT8(sram_wdata,7,0);
    VL_IN8(sram_rdata,7,0);
    VL_OUT8(sram_we_n,0,0);
    VL_OUT8(sram_ce_n,0,0);
    VL_OUT8(led,0,0);
    VL_OUT8(cart_en_n,0,0);
    VL_OUT8(dbg_m1_n,0,0);
    VL_OUT8(dbg_clken,0,0);
    VL_OUT8(dbg_loader,0,0);
    VL_OUT8(dbg_din,7,0);
    VL_OUT8(dbg_iorq_n,0,0);
    VL_OUT8(dbg_wr_n,0,0);
    VL_OUT8(dbg_sdcs_n,0,0);
    VL_OUT8(dbg_dout,7,0);
    VL_OUT8(dbg_ext,7,0);
    VL_OUT8(dbg_mux,7,0);
    VL_OUT8(dbg_mreq_n,0,0);
    VL_OUT8(dbg_ext_en,0,0);
    VL_OUT8(dbg_mc_bank,5,0);
    VL_OUT8(dbg_rd_n,0,0);
    VL_OUT8(dbg_cwait_n,0,0);
    VL_OUT8(dbg_tstate,2,0);
    VL_OUT8(dbg_mcycle,2,0);
    VL_OUT8(dbg_rom_page,7,0);
    VL_OUT8(dbg_mask,7,0);
    VL_OUT8(dbg_c_line,5,0);
    VL_OUT8(dbg_c_hit,0,0);
    CData/*0:0*/ __Vtrigprevexpr___TOP__clk__0;
    CData/*0:0*/ __Vtrigprevexpr___TOP__sim_top__cv____PVT__inst_t80__DOT__u0__DOT___071___0;
    CData/*0:0*/ __VactContinue;
    VL_OUT16(cpu_a,14,0);
    VL_OUT16(dbg_addr,15,0);
    VL_OUT(sram_addr,18,0);
    IData/*31:0*/ __VstlIterCount;
    IData/*31:0*/ __VicoIterCount;
    IData/*31:0*/ __VactIterCount;
    VlTriggerVec<1> __VstlTriggered;
    VlTriggerVec<1> __VicoTriggered;
    VlTriggerVec<2> __VactTriggered;
    VlTriggerVec<2> __VnbaTriggered;

    // INTERNAL VARIABLES
    Vsim_top__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vsim_top___024root(Vsim_top__Syms* symsp, const char* v__name);
    ~Vsim_top___024root();
    VL_UNCOPYABLE(Vsim_top___024root);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
