// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vsim_top.h for the primary calling header

#ifndef VERILATED_VSIM_TOP_F18A_CORE_H_
#define VERILATED_VSIM_TOP_F18A_CORE_H_  // guard

#include "verilated.h"
class Vsim_top_vdp_spy;


class Vsim_top__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vsim_top_f18a_core final : public VerilatedModule {
  public:
    // CELLS
    Vsim_top_vdp_spy* spy;

    // DESIGN SPECIFIC STATE
    VL_IN8(__PVT__clk_100m0_i,0,0);
    VL_IN8(__PVT__clk_25m0_i,0,0);
    VL_IN8(__PVT__reset_n_i,0,0);
    VL_IN8(__PVT__mode_i,0,0);
    VL_IN8(__PVT__csw_n_i,0,0);
    VL_IN8(__PVT__csr_n_i,0,0);
    VL_IN8(__PVT__cd_i,7,0);
    VL_IN8(__PVT__sprite_max_i,0,0);
    VL_IN8(__PVT__scanlines_i,0,0);
    VL_IN8(__PVT__spi_miso_i,0,0);
    VL_OUT8(__PVT__int_n_o,0,0);
    VL_OUT8(__PVT__cd_o,7,0);
    VL_OUT8(__PVT__blank_o,0,0);
    VL_OUT8(__PVT__hsync_o,0,0);
    VL_OUT8(__PVT__vsync_o,0,0);
    VL_OUT8(__PVT__red_o,3,0);
    VL_OUT8(__PVT__grn_o,3,0);
    VL_OUT8(__PVT__blu_o,3,0);
    VL_OUT8(__PVT__spi_clk_o,0,0);
    VL_OUT8(__PVT__spi_cs_o,0,0);
    VL_OUT8(__PVT__spi_mosi_o,0,0);

    // INTERNAL VARIABLES
    Vsim_top__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vsim_top_f18a_core(Vsim_top__Syms* symsp, const char* v__name);
    ~Vsim_top_f18a_core();
    VL_UNCOPYABLE(Vsim_top_f18a_core);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
