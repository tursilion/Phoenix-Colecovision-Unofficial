// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Model implementation (design independent parts)

#include "Vsim_top.h"
#include "Vsim_top__Syms.h"
#include "verilated_dpi.h"

//============================================================
// Constructors

Vsim_top::Vsim_top(VerilatedContext* _vcontextp__, const char* _vcname__)
    : VerilatedModel{*_vcontextp__}
    , vlSymsp{new Vsim_top__Syms(contextp(), _vcname__, this)}
    , clk{vlSymsp->TOP.clk}
    , clk_3m58_en{vlSymsp->TOP.clk_3m58_en}
    , por_n{vlSymsp->TOP.por_n}
    , p1{vlSymsp->TOP.p1}
    , p2{vlSymsp->TOP.p2}
    , p3{vlSymsp->TOP.p3}
    , p4{vlSymsp->TOP.p4}
    , p6{vlSymsp->TOP.p6}
    , p7{vlSymsp->TOP.p7}
    , p9{vlSymsp->TOP.p9}
    , p5{vlSymsp->TOP.p5}
    , p8{vlSymsp->TOP.p8}
    , sd_miso{vlSymsp->TOP.sd_miso}
    , sd_mosi{vlSymsp->TOP.sd_mosi}
    , sd_sclk{vlSymsp->TOP.sd_sclk}
    , sd_cs_n{vlSymsp->TOP.sd_cs_n}
    , sram_wdata{vlSymsp->TOP.sram_wdata}
    , sram_rdata{vlSymsp->TOP.sram_rdata}
    , sram_we_n{vlSymsp->TOP.sram_we_n}
    , sram_ce_n{vlSymsp->TOP.sram_ce_n}
    , led{vlSymsp->TOP.led}
    , cart_en_n{vlSymsp->TOP.cart_en_n}
    , dbg_m1_n{vlSymsp->TOP.dbg_m1_n}
    , dbg_clken{vlSymsp->TOP.dbg_clken}
    , dbg_loader{vlSymsp->TOP.dbg_loader}
    , dbg_din{vlSymsp->TOP.dbg_din}
    , dbg_iorq_n{vlSymsp->TOP.dbg_iorq_n}
    , dbg_wr_n{vlSymsp->TOP.dbg_wr_n}
    , dbg_sdcs_n{vlSymsp->TOP.dbg_sdcs_n}
    , dbg_dout{vlSymsp->TOP.dbg_dout}
    , dbg_ext{vlSymsp->TOP.dbg_ext}
    , dbg_mux{vlSymsp->TOP.dbg_mux}
    , dbg_mreq_n{vlSymsp->TOP.dbg_mreq_n}
    , dbg_ext_en{vlSymsp->TOP.dbg_ext_en}
    , dbg_mc_bank{vlSymsp->TOP.dbg_mc_bank}
    , dbg_rd_n{vlSymsp->TOP.dbg_rd_n}
    , dbg_cwait_n{vlSymsp->TOP.dbg_cwait_n}
    , dbg_tstate{vlSymsp->TOP.dbg_tstate}
    , dbg_mcycle{vlSymsp->TOP.dbg_mcycle}
    , dbg_rom_page{vlSymsp->TOP.dbg_rom_page}
    , dbg_mask{vlSymsp->TOP.dbg_mask}
    , dbg_c_line{vlSymsp->TOP.dbg_c_line}
    , dbg_c_hit{vlSymsp->TOP.dbg_c_hit}
    , cpu_a{vlSymsp->TOP.cpu_a}
    , dbg_addr{vlSymsp->TOP.dbg_addr}
    , sram_addr{vlSymsp->TOP.sram_addr}
    , sim_top{vlSymsp->TOP.sim_top}
    , rootp{&(vlSymsp->TOP)}
{
    // Register model with the context
    contextp()->addModel(this);
}

Vsim_top::Vsim_top(const char* _vcname__)
    : Vsim_top(Verilated::threadContextp(), _vcname__)
{
}

//============================================================
// Destructor

Vsim_top::~Vsim_top() {
    delete vlSymsp;
}

//============================================================
// Evaluation function

#ifdef VL_DEBUG
void Vsim_top___024root___eval_debug_assertions(Vsim_top___024root* vlSelf);
#endif  // VL_DEBUG
void Vsim_top___024root___eval_static(Vsim_top___024root* vlSelf);
void Vsim_top___024root___eval_initial(Vsim_top___024root* vlSelf);
void Vsim_top___024root___eval_settle(Vsim_top___024root* vlSelf);
void Vsim_top___024root___eval(Vsim_top___024root* vlSelf);

void Vsim_top::eval_step() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate Vsim_top::eval_step\n"); );
#ifdef VL_DEBUG
    // Debug assertions
    Vsim_top___024root___eval_debug_assertions(&(vlSymsp->TOP));
#endif  // VL_DEBUG
    vlSymsp->__Vm_deleter.deleteAll();
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) {
        vlSymsp->__Vm_didInit = true;
        VL_DEBUG_IF(VL_DBG_MSGF("+ Initial\n"););
        Vsim_top___024root___eval_static(&(vlSymsp->TOP));
        Vsim_top___024root___eval_initial(&(vlSymsp->TOP));
        Vsim_top___024root___eval_settle(&(vlSymsp->TOP));
    }
    // MTask 0 start
    VL_DEBUG_IF(VL_DBG_MSGF("MTask0 starting\n"););
    Verilated::mtaskId(0);
    VL_DEBUG_IF(VL_DBG_MSGF("+ Eval\n"););
    Vsim_top___024root___eval(&(vlSymsp->TOP));
    // Evaluate cleanup
    Verilated::endOfThreadMTask(vlSymsp->__Vm_evalMsgQp);
    Verilated::endOfEval(vlSymsp->__Vm_evalMsgQp);
}

//============================================================
// Events and timing
bool Vsim_top::eventsPending() { return false; }

uint64_t Vsim_top::nextTimeSlot() {
    VL_FATAL_MT(__FILE__, __LINE__, "", "%Error: No delays in the design");
    return 0;
}

//============================================================
// Utilities

const char* Vsim_top::name() const {
    return vlSymsp->name();
}

//============================================================
// Invoke final blocks

void Vsim_top___024root___eval_final(Vsim_top___024root* vlSelf);

VL_ATTR_COLD void Vsim_top::final() {
    Vsim_top___024root___eval_final(&(vlSymsp->TOP));
}

//============================================================
// Implementations of abstract methods from VerilatedModel

const char* Vsim_top::hierName() const { return vlSymsp->name(); }
const char* Vsim_top::modelName() const { return "Vsim_top"; }
unsigned Vsim_top::threads() const { return 1; }
void Vsim_top::prepareClone() const { contextp()->prepareClone(); }
void Vsim_top::atClone() const {
    contextp()->threadPoolpOnClone();
}

//============================================================
// Trace configuration

VL_ATTR_COLD void Vsim_top::trace(VerilatedVcdC* tfp, int levels, int options) {
    vl_fatal(__FILE__, __LINE__, __FILE__,"'Vsim_top::trace()' called on model that was Verilated without --trace option");
}
