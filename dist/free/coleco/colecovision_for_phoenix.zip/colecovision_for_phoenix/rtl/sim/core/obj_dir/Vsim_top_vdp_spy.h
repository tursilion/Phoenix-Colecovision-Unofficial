// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vsim_top.h for the primary calling header

#ifndef VERILATED_VSIM_TOP_VDP_SPY_H_
#define VERILATED_VSIM_TOP_VDP_SPY_H_  // guard

#include "verilated.h"


class Vsim_top__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vsim_top_vdp_spy final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    VL_IN8(__PVT__clk,0,0);
    VL_IN8(__PVT__mode,0,0);
    VL_IN8(__PVT__csw_n,0,0);
    VL_IN8(__PVT__csr_n,0,0);
    VL_IN8(__PVT__din,7,0);
    VL_OUT8(__PVT__dout,7,0);
    VL_OUT8(__PVT__int_n,0,0);
    CData/*0:0*/ __PVT__latch_first;
    CData/*7:0*/ __PVT__latch;
    CData/*7:0*/ __PVT__rd_buf;
    CData/*0:0*/ __PVT__f_flag;
    CData/*0:0*/ __PVT__csw_d;
    CData/*0:0*/ __PVT__csr_d;
    SData/*13:0*/ __PVT__addr;
    IData/*18:0*/ __PVT__fcnt;
    VlUnpacked<CData/*7:0*/, 16384> vram;
    VlUnpacked<CData/*7:0*/, 8> regs;

    // INTERNAL VARIABLES
    Vsim_top__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vsim_top_vdp_spy(Vsim_top__Syms* symsp, const char* v__name);
    ~Vsim_top_vdp_spy();
    VL_UNCOPYABLE(Vsim_top_vdp_spy);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
