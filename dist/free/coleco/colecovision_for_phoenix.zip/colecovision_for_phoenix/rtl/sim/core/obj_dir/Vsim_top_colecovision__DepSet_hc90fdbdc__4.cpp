// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vsim_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vsim_top__Syms.h"
#include "Vsim_top_colecovision.h"

VL_INLINE_OPT void Vsim_top_colecovision___nba_sequent__TOP__sim_top__cv__5(Vsim_top_colecovision* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vsim_top_colecovision___nba_sequent__TOP__sim_top__cv__5\n"); );
    // Init
    CData/*1:0*/ __PVT__inst_t80__DOT__u0__DOT___176_;
    __PVT__inst_t80__DOT__u0__DOT___176_ = 0;
    CData/*7:0*/ __PVT__inst_t80__DOT__u0__DOT___223_;
    __PVT__inst_t80__DOT__u0__DOT___223_ = 0;
    CData/*7:0*/ __PVT__inst_t80__DOT__u0__DOT___253_;
    __PVT__inst_t80__DOT__u0__DOT___253_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT___255_;
    __PVT__inst_t80__DOT__u0__DOT___255_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT___256_;
    __PVT__inst_t80__DOT__u0__DOT___256_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT___258_;
    __PVT__inst_t80__DOT__u0__DOT___258_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT___259_;
    __PVT__inst_t80__DOT__u0__DOT___259_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT___264_;
    __PVT__inst_t80__DOT__u0__DOT___264_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT___267_;
    __PVT__inst_t80__DOT__u0__DOT___267_ = 0;
    CData/*1:0*/ __PVT__inst_t80__DOT__u0__DOT___284_;
    __PVT__inst_t80__DOT__u0__DOT___284_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT___467_;
    __PVT__inst_t80__DOT__u0__DOT___467_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT___483_;
    __PVT__inst_t80__DOT__u0__DOT___483_ = 0;
    CData/*0:0*/ inst_t80__DOT__u0__DOT____VdfgTmp_h2a6c92f6__0;
    inst_t80__DOT__u0__DOT____VdfgTmp_h2a6c92f6__0 = 0;
    CData/*2:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2282_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2282_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2285_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2285_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2291_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2291_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2292_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2292_ = 0;
    CData/*1:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2293_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2293_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2294_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2294_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2306_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2306_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2311_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2311_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2316_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2316_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2317_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2317_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2318_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2318_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2326_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2326_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2327_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2327_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2330_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2330_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2331_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2331_ = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033409__68__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033409__68__Vfuncout = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033409__68__a;
    __Vfunc_inst_t80__DOT__u0__DOT____033409__68__a = 0;
    IData/*23:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033409__68__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033409__68__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033409__68__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033409__68__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033415__69__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033415__69__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033415__69__a;
    __Vfunc_inst_t80__DOT__u0__DOT____033415__69__a = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033415__69__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033415__69__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033415__69__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033415__69__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033421__70__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033421__70__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033421__70__a;
    __Vfunc_inst_t80__DOT__u0__DOT____033421__70__a = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033421__70__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033421__70__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033421__70__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033421__70__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033427__71__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033427__71__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033427__71__a;
    __Vfunc_inst_t80__DOT__u0__DOT____033427__71__a = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033427__71__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033427__71__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033427__71__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033427__71__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033433__72__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033433__72__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033433__72__a;
    __Vfunc_inst_t80__DOT__u0__DOT____033433__72__a = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033433__72__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033433__72__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033433__72__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033433__72__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033439__73__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033439__73__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033439__73__a;
    __Vfunc_inst_t80__DOT__u0__DOT____033439__73__a = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033439__73__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033439__73__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033439__73__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033439__73__s = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033440__74__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033440__74__Vfuncout = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033440__74__a;
    __Vfunc_inst_t80__DOT__u0__DOT____033440__74__a = 0;
    IData/*23:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033440__74__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033440__74__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033440__74__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033440__74__s = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033443__75__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033443__75__Vfuncout = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033443__75__a;
    __Vfunc_inst_t80__DOT__u0__DOT____033443__75__a = 0;
    IData/*23:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033443__75__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033443__75__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033443__75__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033443__75__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____034002__83__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____034002__83__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____034002__83__a;
    __Vfunc_inst_t80__DOT__u0__DOT____034002__83__a = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____034002__83__s;
    __Vfunc_inst_t80__DOT__u0__DOT____034002__83__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____034004__84__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____034004__84__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____034004__84__a;
    __Vfunc_inst_t80__DOT__u0__DOT____034004__84__a = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____034004__84__s;
    __Vfunc_inst_t80__DOT__u0__DOT____034004__84__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__a = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__a = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__a = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__a = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__s = 0;
    // Body
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0865_ 
        = vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036718__323__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___341_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2320_) 
         | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2321_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___334_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2320_) 
         & (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)));
    __Vfunc_inst_t80__DOT__u0__DOT____033440__74__s 
        = (((2U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
            << 2U) | (((1U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
                       << 1U) | (0U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_)))));
    __Vfunc_inst_t80__DOT__u0__DOT____033440__74__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_) 
            << 0x10U) | (0xffffU & (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___724_) 
                                     << 8U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___724_))));
    __Vfunc_inst_t80__DOT__u0__DOT____033440__74__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___724_;
    __Vfunc_inst_t80__DOT__u0__DOT____033440__74__Vfuncout 
        = (0xffU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033440__74__s)))
                     ? __Vfunc_inst_t80__DOT__u0__DOT____033440__74__b
                     : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033440__74__s)))
                         ? (__Vfunc_inst_t80__DOT__u0__DOT____033440__74__b 
                            >> 8U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033440__74__s)))
                                       ? (__Vfunc_inst_t80__DOT__u0__DOT____033440__74__b 
                                          >> 0x10U)
                                       : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033440__74__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___269_ = __Vfunc_inst_t80__DOT__u0__DOT____033440__74__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033443__75__s 
        = (((2U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
            << 2U) | (((1U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
                       << 1U) | (0U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_)))));
    __Vfunc_inst_t80__DOT__u0__DOT____033443__75__b 
        = ((0x800000U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___726_) 
                         << 0x10U)) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___119_) 
                                        << 0x10U) | 
                                       ((0x8000U & 
                                         ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___726_) 
                                          << 8U)) | 
                                        (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___119_) 
                                          << 8U) | 
                                         ((0x80U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___726_)) 
                                          | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___119_))))));
    __Vfunc_inst_t80__DOT__u0__DOT____033443__75__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_;
    __Vfunc_inst_t80__DOT__u0__DOT____033443__75__Vfuncout 
        = (0xffU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033443__75__s)))
                     ? __Vfunc_inst_t80__DOT__u0__DOT____033443__75__b
                     : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033443__75__s)))
                         ? (__Vfunc_inst_t80__DOT__u0__DOT____033443__75__b 
                            >> 8U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033443__75__s)))
                                       ? (__Vfunc_inst_t80__DOT__u0__DOT____033443__75__b 
                                          >> 0x10U)
                                       : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033443__75__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___270_ = __Vfunc_inst_t80__DOT__u0__DOT____033443__75__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___298_ = 
        ((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_) 
            >> 2U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__b 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1547_) 
           << 1U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2332_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0895_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2314_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0881_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2299_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0880_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2264_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2298_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0872_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2255_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2289_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1539_) 
            << 3U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0864_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2249_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2281_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1544_) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0879_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2263_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2297_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0890_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2269_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2308_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1543_) 
            << 4U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0878_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2261_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__b) 
                           >> 4U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2295_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1541_) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0871_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2254_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2288_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0885_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2303_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0902_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2329_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0889_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2268_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2307_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0900_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__b)) 
                             >> 1U))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2326_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0883_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2266_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2301_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0903_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2279_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__a))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2330_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0867_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2251_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2284_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0886_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2304_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0877_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2260_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__a))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2294_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__b 
        = ((2U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1542_) 
                  << 1U)) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0875_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2258_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__a))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2292_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__b 
        = ((0xcU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1542_) 
                    << 1U)) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0876_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2259_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__Vfuncout 
        = (3U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__b) 
                         >> 2U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__a))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2293_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0888_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__b)) 
                             >> 1U))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2306_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0887_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2305_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0884_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2267_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2302_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0901_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__b)) 
                             >> 1U))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2327_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0868_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2252_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__a))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2285_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1546_) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0904_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2280_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__a))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2331_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0891_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2309_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0874_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2257_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__a))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2291_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0866_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__Vfuncout 
        = (3U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__b) 
                         >> 2U) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2283_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0893_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2312_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__b 
        = ((0x38U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                     << 3U)) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0873_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2256_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2290_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0869_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__a 
        = (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2253_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__Vfuncout 
        = (3U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__b) 
                         >> 2U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2286_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1545_) 
            << 3U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0882_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2265_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2300_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0870_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__a 
        = (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2253_) 
                 >> 2U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__Vfuncout 
        = (3U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__b) 
                         >> 2U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2287_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0896_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2315_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0892_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__b)) 
                             >> 1U))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2311_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0898_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__b)) 
                             >> 1U))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2317_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0899_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__b)) 
                             >> 1U))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2318_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0897_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__b)) 
                             >> 1U))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2316_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0894_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2313_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1540_) 
            << 3U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0865_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2250_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__a))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2282_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__Vfuncout;
    inst_t80__DOT__u0__DOT____VdfgTmp_h2a6c92f6__0 
        = (1U & (~ ((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
                    & (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2326_))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___009_ = 
        ((7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
          ? (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))
          : (((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2294_) 
              << 3U) | (((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2293_) 
                         << 1U) | (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2292_))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___197_ = 
        ((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
         & (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2306_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___133_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2305_) 
         | (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2306_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___149_ = 
        (0xffffU & ((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2285_)
                     ? ((IData)(1U) + (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___740_))
                     : (IData)(vlSelf->inst_t80__DOT__u0__DOT____VdfgTmp_hbde73ddd__0)));
    vlSelf->__PVT__inst_t80__DOT___42_ = ((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2331_) 
                                          & (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)));
    vlSelf->__PVT__inst_t80__DOT___40_ = (1U & (~ (
                                                   (~ (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2331_)) 
                                                   & ((~ 
                                                       ((7U 
                                                         == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                         ? 
                                                        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2345_)) 
                                                         | (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2330_))
                                                         : (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2330_))) 
                                                      & (1U 
                                                         == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___391_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2304_) 
         | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2309_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___636_ = 
        ((~ (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2327_)) 
         & ((0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2283_)) 
            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___752_) 
               & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___764_))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___640_ = 
        ((0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2283_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___762_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_ = 
        (((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2291_) 
          << 3U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2290_));
    __PVT__inst_t80__DOT__u0__DOT___483_ = ((0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2286_)) 
                                            | ((1U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2286_)) 
                                               | (2U 
                                                  == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2286_))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___015_ = 
        ((IData)(vlSelf->__VdfgTmp_h7bf8ddc8__0) ? 2U
          : ((IData)(vlSelf->__VdfgTmp_h426b99eb__0)
              ? 7U : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2300_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___503_ = 
        ((((1U != (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
           & (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_))) 
          | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___501_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2287_));
    vlSelf->inst_t80__DOT__u0__DOT____VdfgTmp_h548e9c6f__0 
        = ((4U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2287_) 
                  << 2U)) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2286_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___424_ = 
        ((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
         | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2287_) 
            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___501_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___304_ = 
        (((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2315_)) 
          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___798_)) 
         | (9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)));
    __PVT__inst_t80__DOT__u0__DOT___467_ = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
                                             | (4U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_))) 
                                            & (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2311_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___493_ = 
        ((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
         & (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2311_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___489_ = 
        ((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
         & (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2311_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__t_res = 
        (((7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
           ? 5U : (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2282_)) 
         == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___600_ = 
        ((IData)(inst_t80__DOT__u0__DOT____VdfgTmp_h2a6c92f6__0) 
         & (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
             & (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2327_)) 
            | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___754_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___599_ = 
        ((IData)(inst_t80__DOT__u0__DOT____VdfgTmp_h2a6c92f6__0) 
         & ((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_))
             ? ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2319_)
                 ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___754_)
                 : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___752_) 
                    | (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2327_)))
             : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___752_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___546_ = 
        ((0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_)) 
         | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_)) 
            | ((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_)) 
               | ((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_)) 
                  | ((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_)) 
                     | (5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__nextis_xy_fetch 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___015_)) 
            | (((0xcbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                | (0x36U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))) 
               & (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))) 
           & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___379_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___215_ = 
        (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
          | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
             & (4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)))) 
         & (7U == (IData)(vlSelf->inst_t80__DOT__u0__DOT____VdfgTmp_h548e9c6f__0)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___468_ = 
        ((IData)(__PVT__inst_t80__DOT__u0__DOT___467_) 
         | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___447_) 
            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___460_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___469_ = 
        ((IData)(__PVT__inst_t80__DOT__u0__DOT___467_) 
         | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___447_) 
            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___461_)));
    __Vfunc_inst_t80__DOT__u0__DOT____033433__72__s 
        = (((2U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
            << 2U) | (((1U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
                       << 1U) | (0U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_)))));
    if (vlSelf->__PVT__inst_t80__DOT__u0__DOT___082_) {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___290_ 
            = (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                     >> 6U));
        __PVT__inst_t80__DOT__u0__DOT___264_ = (1U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                   >> 6U));
    } else if (vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2313_) {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___290_ 
            = (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___722_) 
                     >> 6U));
        __PVT__inst_t80__DOT__u0__DOT___264_ = (1U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___722_) 
                                                   >> 6U));
    } else {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___290_ 
            = (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                     >> 6U));
        __PVT__inst_t80__DOT__u0__DOT___264_ = (1U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                   >> 6U));
    }
    __Vfunc_inst_t80__DOT__u0__DOT____033433__72__b 
        = ((6U & ((- (IData)((IData)(__PVT__inst_t80__DOT__u0__DOT___264_))) 
                  << 1U)) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___724_)));
    __Vfunc_inst_t80__DOT__u0__DOT____033433__72__a 
        = __PVT__inst_t80__DOT__u0__DOT___264_;
    __Vfunc_inst_t80__DOT__u0__DOT____033433__72__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033433__72__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033433__72__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033433__72__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033433__72__b) 
                         >> 1U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033433__72__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033433__72__b) 
                                       >> 2U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033433__72__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___265_ = __Vfunc_inst_t80__DOT__u0__DOT____033433__72__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033439__73__s 
        = (((2U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
            << 2U) | (((1U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
                       << 1U) | (0U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_)))));
    __PVT__inst_t80__DOT__u0__DOT___267_ = (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___082_)
                                                   ? 
                                                  ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                   >> 7U)
                                                   : 
                                                  ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2313_)
                                                    ? 
                                                   ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___722_) 
                                                    >> 7U)
                                                    : 
                                                   ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                    >> 7U))));
    __Vfunc_inst_t80__DOT__u0__DOT____033439__73__b 
        = ((6U & ((- (IData)((IData)(__PVT__inst_t80__DOT__u0__DOT___267_))) 
                  << 1U)) | (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___724_) 
                                   >> 7U)));
    __Vfunc_inst_t80__DOT__u0__DOT____033439__73__a 
        = __PVT__inst_t80__DOT__u0__DOT___267_;
    __Vfunc_inst_t80__DOT__u0__DOT____033439__73__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033439__73__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033439__73__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033439__73__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033439__73__b) 
                         >> 1U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033439__73__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033439__73__b) 
                                       >> 2U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033439__73__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___268_ = __Vfunc_inst_t80__DOT__u0__DOT____033439__73__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033421__70__s 
        = (((2U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
            << 2U) | (((1U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
                       << 1U) | (0U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_)))));
    __PVT__inst_t80__DOT__u0__DOT___258_ = (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___082_)
                                                   ? 
                                                  ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                   >> 2U)
                                                   : 
                                                  ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2313_)
                                                    ? 
                                                   ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___722_) 
                                                    >> 2U)
                                                    : 
                                                   ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                    >> 2U))));
    __Vfunc_inst_t80__DOT__u0__DOT____033421__70__b 
        = (((IData)(__PVT__inst_t80__DOT__u0__DOT___258_) 
            << 2U) | (3U & (- (IData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___754_)))));
    __Vfunc_inst_t80__DOT__u0__DOT____033421__70__a 
        = __PVT__inst_t80__DOT__u0__DOT___258_;
    __Vfunc_inst_t80__DOT__u0__DOT____033421__70__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033421__70__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033421__70__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033421__70__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033421__70__b) 
                         >> 1U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033421__70__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033421__70__b) 
                                       >> 2U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033421__70__a)))));
    __PVT__inst_t80__DOT__u0__DOT___259_ = __Vfunc_inst_t80__DOT__u0__DOT____033421__70__Vfuncout;
    if (vlSelf->__PVT__inst_t80__DOT__u0__DOT__t_res) {
        if (__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2318_) {
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___177_ 
                = (7U & ((4U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_) 
                                >> 3U)) | (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_) 
                                                 >> 3U))));
            __PVT__inst_t80__DOT__u0__DOT___176_ = 
                (3U & 1U);
        } else if (__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2317_) {
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___177_ 
                = (7U & ((4U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_) 
                                >> 3U)) | ((2U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                  << 1U)) 
                                           | (1U & 
                                              ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_) 
                                               >> 3U)))));
            __PVT__inst_t80__DOT__u0__DOT___176_ = 
                (3U & (1U & (~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_))));
        } else {
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___177_ 
                = (7U & ((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2316_)
                          ? (2U | ((4U & ((~ ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_) 
                                              >> 5U)) 
                                          << 2U)) | 
                                   (1U & (~ ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_) 
                                             >> 3U)))))
                          : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                             >> 3U)));
            __PVT__inst_t80__DOT__u0__DOT___176_ = 
                (3U & ((2U & (((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2316_) 
                               << 1U) | (0xfffffffeU 
                                         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)))) 
                       | (1U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_))));
        }
    } else {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___177_ 
            = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                     >> 3U));
        __PVT__inst_t80__DOT__u0__DOT___176_ = (3U 
                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_));
    }
    if (vlSelf->__PVT__inst_t80__DOT__u0__DOT___082_) {
        __PVT__inst_t80__DOT__u0__DOT___223_ = (0xffU 
                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___261_ 
            = (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                     >> 4U));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___293_ 
            = (1U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_));
        __PVT__inst_t80__DOT__u0__DOT___284_ = (3U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                   >> 1U));
        __PVT__inst_t80__DOT__u0__DOT___255_ = (1U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                   >> 1U));
    } else if (vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2313_) {
        __PVT__inst_t80__DOT__u0__DOT___223_ = (0xffU 
                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___720_));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___261_ 
            = (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___722_) 
                     >> 4U));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___293_ 
            = (1U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___722_));
        __PVT__inst_t80__DOT__u0__DOT___284_ = (3U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___722_) 
                                                   >> 1U));
        __PVT__inst_t80__DOT__u0__DOT___255_ = (1U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___722_) 
                                                   >> 1U));
    } else {
        __PVT__inst_t80__DOT__u0__DOT___223_ = (0xffU 
                                                & (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__t_res) 
                                                    & (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2316_))
                                                    ? 
                                                   (~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_))
                                                    : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_)));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___261_ 
            = (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___177_) 
                     >> 1U));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___293_ 
            = (1U & (IData)(__PVT__inst_t80__DOT__u0__DOT___176_));
        __PVT__inst_t80__DOT__u0__DOT___284_ = (3U 
                                                & ((2U 
                                                    & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & ((IData)(__PVT__inst_t80__DOT__u0__DOT___176_) 
                                                         >> 1U))));
        __PVT__inst_t80__DOT__u0__DOT___255_ = (1U 
                                                & ((IData)(__PVT__inst_t80__DOT__u0__DOT___176_) 
                                                   >> 1U));
    }
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___307_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2325_) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__t_res));
    __Vfunc_inst_t80__DOT__u0__DOT____034002__83__s 
        = __PVT__inst_t80__DOT__u0__DOT___483_;
    __Vfunc_inst_t80__DOT__u0__DOT____034002__83__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___468_;
    __Vfunc_inst_t80__DOT__u0__DOT____034002__83__Vfuncout 
        = ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____034002__83__s) 
           | (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034002__83__a));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___484_ = __Vfunc_inst_t80__DOT__u0__DOT____034002__83__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____034004__84__s 
        = __PVT__inst_t80__DOT__u0__DOT___483_;
    __Vfunc_inst_t80__DOT__u0__DOT____034004__84__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___469_;
    __Vfunc_inst_t80__DOT__u0__DOT____034004__84__Vfuncout 
        = ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____034004__84__s) 
           | (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034004__84__a));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___485_ = __Vfunc_inst_t80__DOT__u0__DOT____034004__84__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033409__68__s 
        = (((2U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
            << 2U) | (((1U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
                       << 1U) | (0U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_)))));
    __Vfunc_inst_t80__DOT__u0__DOT____033409__68__b 
        = (((IData)(__PVT__inst_t80__DOT__u0__DOT___223_) 
            << 0x10U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___726_) 
                          << 8U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___724_)));
    __Vfunc_inst_t80__DOT__u0__DOT____033409__68__a 
        = __PVT__inst_t80__DOT__u0__DOT___223_;
    __Vfunc_inst_t80__DOT__u0__DOT____033409__68__Vfuncout 
        = (0xffU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033409__68__s)))
                     ? __Vfunc_inst_t80__DOT__u0__DOT____033409__68__b
                     : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033409__68__s)))
                         ? (__Vfunc_inst_t80__DOT__u0__DOT____033409__68__b 
                            >> 8U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033409__68__s)))
                                       ? (__Vfunc_inst_t80__DOT__u0__DOT____033409__68__b 
                                          >> 0x10U)
                                       : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033409__68__a)))));
    __PVT__inst_t80__DOT__u0__DOT___253_ = __Vfunc_inst_t80__DOT__u0__DOT____033409__68__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___271_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___298_)
          ? (IData)(__PVT__inst_t80__DOT__u0__DOT___253_)
          : (IData)(__PVT__inst_t80__DOT__u0__DOT___223_));
    __Vfunc_inst_t80__DOT__u0__DOT____033427__71__s 
        = (((2U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
            << 2U) | (((1U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
                       << 1U) | (0U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_)))));
    __Vfunc_inst_t80__DOT__u0__DOT____033427__71__b 
        = (6U & ((- (IData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___261_))) 
                 << 1U));
    __Vfunc_inst_t80__DOT__u0__DOT____033427__71__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___261_;
    __Vfunc_inst_t80__DOT__u0__DOT____033427__71__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033427__71__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033427__71__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033427__71__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033427__71__b) 
                         >> 1U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033427__71__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033427__71__b) 
                                       >> 2U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033427__71__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___262_ = __Vfunc_inst_t80__DOT__u0__DOT____033427__71__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033415__69__s 
        = (((2U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
            << 2U) | (((1U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
                       << 1U) | (0U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_)))));
    __Vfunc_inst_t80__DOT__u0__DOT____033415__69__b 
        = (6U & ((- (IData)((IData)(__PVT__inst_t80__DOT__u0__DOT___255_))) 
                 << 1U));
    __Vfunc_inst_t80__DOT__u0__DOT____033415__69__a 
        = __PVT__inst_t80__DOT__u0__DOT___255_;
    __Vfunc_inst_t80__DOT__u0__DOT____033415__69__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033415__69__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033415__69__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033415__69__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033415__69__b) 
                         >> 1U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033415__69__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033415__69__b) 
                                       >> 2U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033415__69__a)))));
    __PVT__inst_t80__DOT__u0__DOT___256_ = __Vfunc_inst_t80__DOT__u0__DOT____033415__69__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___285_ = 
        ((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_))
          ? ((4U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))
              ? (((IData)(__PVT__inst_t80__DOT__u0__DOT___259_) 
                  << 1U) | (IData)(__PVT__inst_t80__DOT__u0__DOT___256_))
              : (IData)(__PVT__inst_t80__DOT__u0__DOT___284_))
          : (IData)(__PVT__inst_t80__DOT__u0__DOT___284_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___337_ = 
        (1U & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___334_)) 
               & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___307_)) 
                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___304_)
                      ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___177_)
                      : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___285_)))));
}
