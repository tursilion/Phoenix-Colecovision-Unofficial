// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vsim_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vsim_top__Syms.h"
#include "Vsim_top__Syms.h"
#include "Vsim_top_colecovision.h"

VL_ATTR_COLD void Vsim_top_colecovision___stl_sequent__TOP__sim_top__cv__2(Vsim_top_colecovision* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vsim_top_colecovision___stl_sequent__TOP__sim_top__cv__2\n"); );
    // Init
    CData/*0:0*/ __PVT___110_;
    __PVT___110_ = 0;
    CData/*7:0*/ __PVT___164_;
    __PVT___164_ = 0;
    CData/*2:0*/ __PVT__inst_t80__DOT__u0__DOT__alu__DOT___020_;
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___020_ = 0;
    CData/*0:0*/ __Vfunc___03389__5__Vfuncout;
    __Vfunc___03389__5__Vfuncout = 0;
    CData/*7:0*/ __Vfunc___03389__5__b;
    __Vfunc___03389__5__b = 0;
    CData/*7:0*/ __Vfunc___03389__5__s;
    __Vfunc___03389__5__s = 0;
    CData/*7:0*/ __Vfunc___03510__20__Vfuncout;
    __Vfunc___03510__20__Vfuncout = 0;
    CData/*7:0*/ __Vfunc___03510__20__a;
    __Vfunc___03510__20__a = 0;
    QData/*47:0*/ __Vfunc___03510__20__b;
    __Vfunc___03510__20__b = 0;
    CData/*5:0*/ __Vfunc___03510__20__s;
    __Vfunc___03510__20__s = 0;
    CData/*7:0*/ __Vfunc___03701__39__Vfuncout;
    __Vfunc___03701__39__Vfuncout = 0;
    CData/*7:0*/ __Vfunc___03701__39__a;
    __Vfunc___03701__39__a = 0;
    VlWide<4>/*103:0*/ __Vfunc___03701__39__b;
    VL_ZERO_W(104, __Vfunc___03701__39__b);
    SData/*12:0*/ __Vfunc___03701__39__s;
    __Vfunc___03701__39__s = 0;
    CData/*7:0*/ __Vfunc___03702__40__Vfuncout;
    __Vfunc___03702__40__Vfuncout = 0;
    CData/*7:0*/ __Vfunc___03702__40__a;
    __Vfunc___03702__40__a = 0;
    VlWide<4>/*103:0*/ __Vfunc___03702__40__b;
    VL_ZERO_W(104, __Vfunc___03702__40__b);
    SData/*12:0*/ __Vfunc___03702__40__s;
    __Vfunc___03702__40__s = 0;
    CData/*7:0*/ __Vfunc___03703__41__Vfuncout;
    __Vfunc___03703__41__Vfuncout = 0;
    CData/*7:0*/ __Vfunc___03703__41__a;
    __Vfunc___03703__41__a = 0;
    VlWide<4>/*103:0*/ __Vfunc___03703__41__b;
    VL_ZERO_W(104, __Vfunc___03703__41__b);
    SData/*12:0*/ __Vfunc___03703__41__s;
    __Vfunc___03703__41__s = 0;
    CData/*0:0*/ __Vfunc___03736__56__Vfuncout;
    __Vfunc___03736__56__Vfuncout = 0;
    CData/*0:0*/ __Vfunc___03736__56__a;
    __Vfunc___03736__56__a = 0;
    CData/*1:0*/ __Vfunc___03736__56__b;
    __Vfunc___03736__56__b = 0;
    CData/*1:0*/ __Vfunc___03736__56__s;
    __Vfunc___03736__56__s = 0;
    CData/*0:0*/ __Vfunc___03737__57__Vfuncout;
    __Vfunc___03737__57__Vfuncout = 0;
    CData/*0:0*/ __Vfunc___03737__57__a;
    __Vfunc___03737__57__a = 0;
    CData/*1:0*/ __Vfunc___03737__57__b;
    __Vfunc___03737__57__b = 0;
    CData/*1:0*/ __Vfunc___03737__57__s;
    __Vfunc___03737__57__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__a;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__a = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__a;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__a = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__b;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__a;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__a = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__b;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__s = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__Vfuncout = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__a;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__a = 0;
    IData/*31:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__b;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037196__373__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037196__373__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037196__373__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037196__373__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037246__377__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037246__377__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037246__377__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037246__377__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037440__380__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037440__380__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037440__380__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037440__380__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037500__385__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037500__385__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037500__385__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037500__385__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037709__391__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037709__391__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037709__391__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037709__391__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037772__397__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037772__397__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037772__397__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037772__397__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037981__403__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037981__403__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037981__403__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037981__403__s = 0;
    IData/*23:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__b = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__Vfuncout = 0;
    VlWide<3>/*91:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b;
    VL_ZERO_W(92, __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b);
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__Vfuncout = 0;
    VlWide<3>/*68:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b;
    VL_ZERO_W(69, __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b);
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__Vfuncout = 0;
    QData/*45:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__Vfuncout = 0;
    VlWide<3>/*91:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b;
    VL_ZERO_W(92, __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b);
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__Vfuncout = 0;
    VlWide<3>/*68:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b;
    VL_ZERO_W(69, __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b);
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039579__586__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039579__586__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039579__586__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039579__586__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039579__586__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039579__586__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039619__600__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039619__600__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039619__600__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039619__600__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039619__600__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039619__600__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039646__609__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039646__609__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039646__609__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039646__609__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039646__609__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039646__609__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039649__610__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039649__610__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039649__610__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039649__610__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039649__610__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039649__610__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039652__611__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039652__611__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039652__611__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039652__611__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039652__611__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039652__611__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039655__612__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039655__612__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039655__612__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039655__612__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039655__612__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039655__612__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039658__613__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039658__613__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039658__613__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039658__613__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039658__613__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039658__613__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039661__614__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039661__614__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039661__614__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039661__614__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039661__614__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039661__614__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039664__615__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039664__615__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039664__615__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039664__615__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039664__615__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039664__615__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039673__618__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039673__618__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039673__618__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039673__618__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039673__618__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039673__618__s = 0;
    CData/*1:0*/ __Vfunc_sdcard__DOT____032676__623__Vfuncout;
    __Vfunc_sdcard__DOT____032676__623__Vfuncout = 0;
    CData/*7:0*/ __Vfunc_sdcard__DOT____032676__623__b;
    __Vfunc_sdcard__DOT____032676__623__b = 0;
    CData/*3:0*/ __Vfunc_sdcard__DOT____032676__623__s;
    __Vfunc_sdcard__DOT____032676__623__s = 0;
    CData/*7:0*/ __Vfunc_sdcard__DOT____032678__624__Vfuncout;
    __Vfunc_sdcard__DOT____032678__624__Vfuncout = 0;
    IData/*31:0*/ __Vfunc_sdcard__DOT____032678__624__b;
    __Vfunc_sdcard__DOT____032678__624__b = 0;
    CData/*3:0*/ __Vfunc_sdcard__DOT____032678__624__s;
    __Vfunc_sdcard__DOT____032678__624__s = 0;
    CData/*2:0*/ __Vfunc_sdcard__DOT____032680__625__Vfuncout;
    __Vfunc_sdcard__DOT____032680__625__Vfuncout = 0;
    SData/*11:0*/ __Vfunc_sdcard__DOT____032680__625__b;
    __Vfunc_sdcard__DOT____032680__625__b = 0;
    CData/*3:0*/ __Vfunc_sdcard__DOT____032680__625__s;
    __Vfunc_sdcard__DOT____032680__625__s = 0;
    CData/*0:0*/ __Vfunc_sdcard__DOT____032687__627__Vfuncout;
    __Vfunc_sdcard__DOT____032687__627__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_sdcard__DOT____032687__627__b;
    __Vfunc_sdcard__DOT____032687__627__b = 0;
    CData/*3:0*/ __Vfunc_sdcard__DOT____032687__627__s;
    __Vfunc_sdcard__DOT____032687__627__s = 0;
    CData/*0:0*/ __Vfunc_sdcard__DOT____032698__629__Vfuncout;
    __Vfunc_sdcard__DOT____032698__629__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_sdcard__DOT____032698__629__b;
    __Vfunc_sdcard__DOT____032698__629__b = 0;
    CData/*3:0*/ __Vfunc_sdcard__DOT____032698__629__s;
    __Vfunc_sdcard__DOT____032698__629__s = 0;
    VlWide<3>/*95:0*/ __Vtemp_1;
    VlWide<3>/*95:0*/ __Vtemp_4;
    VlWide<4>/*127:0*/ __Vtemp_8;
    VlWide<3>/*95:0*/ __Vtemp_12;
    VlWide<3>/*95:0*/ __Vtemp_21;
    VlWide<4>/*127:0*/ __Vtemp_24;
    VlWide<4>/*127:0*/ __Vtemp_26;
    VlWide<4>/*127:0*/ __Vtemp_28;
    // Body
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0920_ 
        = vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036987__367__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037196__373__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037196__373__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037196__373__s)))
            ? 2U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037196__373__s)))
                     ? 2U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1050_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037196__373__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037246__377__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037246__377__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037246__377__s)))
            ? 2U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1077_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037246__377__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037440__380__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037440__380__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037440__380__s)))
            ? 2U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1201_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037440__380__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037500__385__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037500__385__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037500__385__s)))
            ? 2U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037500__385__s)))
                     ? 2U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1231_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037500__385__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037709__391__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037709__391__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037709__391__s)))
            ? 2U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037709__391__s)))
                     ? 2U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1361_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037709__391__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037772__397__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037772__397__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037772__397__s)))
            ? 2U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037772__397__s)))
                     ? 2U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1392_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037772__397__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037981__403__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037981__403__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037981__403__s)))
            ? 2U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037981__403__s)))
                     ? 2U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1522_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037981__403__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__b 
        = (0x20U | ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 6U) | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                             ? 4U : 3U)));
    if ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))) {
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__a = 4U;
    } else {
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__a = 3U;
    }
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0916_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__b 
        = (0x20U | ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 6U) | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                             ? 4U : 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1046_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__b 
        = (0x20U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                     ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1075_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__b 
        = (0x20U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                     ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1199_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__b 
        = (0x20U | ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 6U) | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                             ? 4U : 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1227_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__b 
        = (0x20U | ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 6U) | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                             ? 4U : 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1357_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__b 
        = (0x20U | ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 6U) | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                             ? 4U : 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1388_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__b 
        = (0x20U | ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 6U) | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                             ? 4U : 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1518_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_ 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2019_) 
           | (IData)(vlSelf->__VdfgTmp_hc027efeb__0));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1212_ 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2019_) 
           | ((0x56U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x5eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (IData)(vlSelf->__VdfgTmp_hc027efeb__0))));
    vlSelf->__PVT__cache__DOT__ci_rev = ((4U <= (IData)(vlSelf->__PVT__cache__DOT__c_init_i)) 
                                         & (0x40U <= (IData)(vlSelf->cache__DOT____VdfgTmp_h64dfa0ff__0)));
    vlSelf->__PVT__cache__DOT__ci_map = (((IData)(vlSelf->__PVT__cache__DOT__c_init_i) 
                                          < (IData)(vlSelf->__PVT__cache_n_pages_s)) 
                                         & ((4U <= (IData)(vlSelf->__PVT__cache__DOT__ci_sram)) 
                                            & (0x40U 
                                               > (IData)(vlSelf->__PVT__cache__DOT__ci_sram))));
    vlSelf->__PVT__cache__DOT__c_map_q = vlSelf->__PVT__cache__DOT__c_map
        [vlSelf->__PVT__rom_page_s];
    __Vtemp_1[0U] = (IData)((((QData)((IData)((0xffU 
                                               & (((IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___114_) 
                                                   & ((IData)(1U) 
                                                      - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                                                   ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                                                   : 
                                                  ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U] 
                                                    << 8U) 
                                                   | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U] 
                                                      >> 0x18U)))))) 
                              << 0x38U) | (((QData)((IData)(
                                                            (0xffU 
                                                             & (((~ 
                                                                  ((IData)(1U) 
                                                                   - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_))) 
                                                                 & (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___114_))
                                                                 ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                                                                 : 
                                                                ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U] 
                                                                  << 0x10U) 
                                                                 | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U] 
                                                                    >> 0x10U)))))) 
                                            << 0x30U) 
                                           | (((QData)((IData)(
                                                               (0xffU 
                                                                & (((IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___113_) 
                                                                    & ((IData)(1U) 
                                                                       - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                                                                    ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                                                                    : 
                                                                   ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U] 
                                                                     << 0x18U) 
                                                                    | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U] 
                                                                       >> 8U)))))) 
                                               << 0x28U) 
                                              | (((QData)((IData)(
                                                                  (0xffU 
                                                                   & (((~ 
                                                                        ((IData)(1U) 
                                                                         - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_))) 
                                                                       & (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___113_))
                                                                       ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                                                                       : 
                                                                      vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U])))) 
                                                  << 0x20U) 
                                                 | (QData)((IData)(
                                                                   (((((IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___112_) 
                                                                       & ((IData)(1U) 
                                                                          - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                                                                       ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                                                                       : 
                                                                      ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U] 
                                                                        << 8U) 
                                                                       | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U] 
                                                                          >> 0x18U))) 
                                                                     << 0x18U) 
                                                                    | ((0xff0000U 
                                                                        & ((((~ 
                                                                              ((IData)(1U) 
                                                                               - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_))) 
                                                                             & (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___112_))
                                                                             ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                                                                             : 
                                                                            ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U] 
                                                                              << 0x10U) 
                                                                             | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U] 
                                                                                >> 0x10U))) 
                                                                           << 0x10U)) 
                                                                       | ((0xff00U 
                                                                           & ((((IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___111_) 
                                                                                & ((IData)(1U) 
                                                                                - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                                                                                ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                                                                                : 
                                                                               ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U] 
                                                                                << 0x18U) 
                                                                                | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U] 
                                                                                >> 8U))) 
                                                                              << 8U)) 
                                                                          | (0xffU 
                                                                             & (((~ 
                                                                                ((IData)(1U) 
                                                                                - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_))) 
                                                                                & (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___111_))
                                                                                 ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                                                                                 : 
                                                                                vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U]))))))))))));
    __Vtemp_1[1U] = (IData)(((((QData)((IData)((0xffU 
                                                & (((IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___114_) 
                                                    & ((IData)(1U) 
                                                       - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                                                    ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                                                    : 
                                                   ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U] 
                                                     << 8U) 
                                                    | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U] 
                                                       >> 0x18U)))))) 
                               << 0x38U) | (((QData)((IData)(
                                                             (0xffU 
                                                              & (((~ 
                                                                   ((IData)(1U) 
                                                                    - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_))) 
                                                                  & (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___114_))
                                                                  ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                                                                  : 
                                                                 ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U] 
                                                                   << 0x10U) 
                                                                  | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U] 
                                                                     >> 0x10U)))))) 
                                             << 0x30U) 
                                            | (((QData)((IData)(
                                                                (0xffU 
                                                                 & (((IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___113_) 
                                                                     & ((IData)(1U) 
                                                                        - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                                                                     ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                                                                     : 
                                                                    ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U] 
                                                                      << 0x18U) 
                                                                     | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U] 
                                                                        >> 8U)))))) 
                                                << 0x28U) 
                                               | (((QData)((IData)(
                                                                   (0xffU 
                                                                    & (((~ 
                                                                         ((IData)(1U) 
                                                                          - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_))) 
                                                                        & (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___113_))
                                                                        ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                                                                        : 
                                                                       vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U])))) 
                                                   << 0x20U) 
                                                  | (QData)((IData)(
                                                                    (((((IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___112_) 
                                                                        & ((IData)(1U) 
                                                                           - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                                                                        ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                                                                        : 
                                                                       ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U] 
                                                                         << 8U) 
                                                                        | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U] 
                                                                           >> 0x18U))) 
                                                                      << 0x18U) 
                                                                     | ((0xff0000U 
                                                                         & ((((~ 
                                                                               ((IData)(1U) 
                                                                                - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_))) 
                                                                              & (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___112_))
                                                                              ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                                                                              : 
                                                                             ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U] 
                                                                               << 0x10U) 
                                                                              | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U] 
                                                                                >> 0x10U))) 
                                                                            << 0x10U)) 
                                                                        | ((0xff00U 
                                                                            & ((((IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___111_) 
                                                                                & ((IData)(1U) 
                                                                                - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                                                                                 ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                                                                                 : 
                                                                                ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U] 
                                                                                << 0x18U) 
                                                                                | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U] 
                                                                                >> 8U))) 
                                                                               << 8U)) 
                                                                           | (0xffU 
                                                                              & (((~ 
                                                                                ((IData)(1U) 
                                                                                - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_))) 
                                                                                & (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___111_))
                                                                                 ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                                                                                 : 
                                                                                vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U]))))))))))) 
                             >> 0x20U));
    __Vtemp_4[2U] = (((((IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___116_) 
                        & ((IData)(1U) - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                        ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                        : ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[2U] 
                            << 8U) | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[2U] 
                                      >> 0x18U))) << 0x18U) 
                     | ((0xff0000U & ((((~ ((IData)(1U) 
                                            - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_))) 
                                        & (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___116_))
                                        ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                                        : ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[2U] 
                                            << 0x10U) 
                                           | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[2U] 
                                              >> 0x10U))) 
                                      << 0x10U)) | 
                        ((0xff00U & ((((IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___115_) 
                                       & ((IData)(1U) 
                                          - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                                       ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                                       : ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[2U] 
                                           << 0x18U) 
                                          | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[2U] 
                                             >> 8U))) 
                                     << 8U)) | (0xffU 
                                                & (((~ 
                                                     ((IData)(1U) 
                                                      - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_))) 
                                                    & (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___115_))
                                                    ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                                                    : 
                                                   vlSelf->__PVT__ym2149_audio_inst__DOT___057_[2U])))));
    __Vtemp_8[3U] = (((((IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___118_) 
                        & ((IData)(1U) - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                        ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                        : ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[3U] 
                            << 8U) | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[3U] 
                                      >> 0x18U))) << 0x18U) 
                     | ((0xff0000U & ((((~ ((IData)(1U) 
                                            - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_))) 
                                        & (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___118_))
                                        ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                                        : ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[3U] 
                                            << 0x10U) 
                                           | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[3U] 
                                              >> 0x10U))) 
                                      << 0x10U)) | 
                        ((0xff00U & ((((IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___117_) 
                                       & ((IData)(1U) 
                                          - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                                       ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                                       : ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[3U] 
                                           << 0x18U) 
                                          | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[3U] 
                                             >> 8U))) 
                                     << 8U)) | (0xffU 
                                                & (((~ 
                                                     ((IData)(1U) 
                                                      - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_))) 
                                                    & (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___117_))
                                                    ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                                                    : 
                                                   vlSelf->__PVT__ym2149_audio_inst__DOT___057_[3U])))));
    __Vfunc___03736__56__s = (((3U == (0xfU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 4U))) 
                               << 1U) | (5U == (0xfU 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                   >> 4U))));
    __Vfunc___03736__56__b = (((IData)(vlSelf->__PVT___432_) 
                               << 1U) | (IData)(vlSelf->__PVT___276_));
    __Vfunc___03736__56__a = vlSelf->__PVT___432_;
    __Vfunc___03736__56__Vfuncout = (1U & ((1U == (1U 
                                                   & (IData)(__Vfunc___03736__56__s)))
                                            ? (IData)(__Vfunc___03736__56__b)
                                            : ((2U 
                                                == 
                                                (2U 
                                                 & (IData)(__Vfunc___03736__56__s)))
                                                ? ((IData)(__Vfunc___03736__56__b) 
                                                   >> 1U)
                                                : (IData)(__Vfunc___03736__56__a))));
    vlSelf->__PVT___303_ = __Vfunc___03736__56__Vfuncout;
    __Vfunc___03737__57__s = (((3U == (0xfU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 4U))) 
                               << 1U) | (5U == (0xfU 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                   >> 4U))));
    __Vfunc___03737__57__b = (((IData)(vlSelf->__PVT___434_) 
                               << 1U) | (IData)(vlSelf->__PVT___277_));
    __Vfunc___03737__57__a = vlSelf->__PVT___434_;
    __Vfunc___03737__57__Vfuncout = (1U & ((1U == (1U 
                                                   & (IData)(__Vfunc___03737__57__s)))
                                            ? (IData)(__Vfunc___03737__57__b)
                                            : ((2U 
                                                == 
                                                (2U 
                                                 & (IData)(__Vfunc___03737__57__s)))
                                                ? ((IData)(__Vfunc___03737__57__b) 
                                                   >> 1U)
                                                : (IData)(__Vfunc___03737__57__a))));
    vlSelf->__PVT___304_ = __Vfunc___03737__57__Vfuncout;
    vlSelf->__PVT__ctrl_b__DOT__p2_ifc_load_s = ((IData)(vlSelf->__PVT__ctrl_b__DOT__p2_edge_s) 
                                                 & (0U 
                                                    == (IData)(vlSelf->__PVT__ctrl_b__DOT___83_)));
    vlSelf->__PVT__ctrl_b__DOT___31_ = ((IData)(vlSelf->__PVT__ctrl_b__DOT__p1_edge_s) 
                                        | (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_edge_s));
    vlSelf->__PVT__ctrl_b__DOT__p1_ifc_load_s = ((IData)(vlSelf->__PVT__ctrl_b__DOT__p1_edge_s) 
                                                 & (0U 
                                                    == (IData)(vlSelf->__PVT__ctrl_b__DOT___79_)));
    __Vfunc___03510__20__s = (((6U == (IData)(vlSelf->__PVT__io_decode_s)) 
                               << 5U) | (((4U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                          << 4U) | 
                                         (((3U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                           << 3U) | 
                                          (((2U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                            << 2U) 
                                           | (((1U 
                                                == (IData)(vlSelf->__PVT__io_decode_s)) 
                                               << 1U) 
                                              | (0U 
                                                 == (IData)(vlSelf->__PVT__io_decode_s)))))));
    __Vfunc___03510__20__b = (((QData)((IData)(((0xffff0000U 
                                                 & (((IData)(vlSelf->__PVT___447_) 
                                                     << 0x18U) 
                                                    | ((IData)(vlSelf->__PVT___447_) 
                                                       << 0x10U))) 
                                                | (((IData)(vlSymsp->TOP__sim_top__cv__inst_f18a__spy.__PVT__dout) 
                                                    << 8U) 
                                                   | (IData)(vlSelf->__PVT___447_))))) 
                               << 0x10U) | (QData)((IData)(
                                                           ((((IData)(vlSelf->__PVT___427_)
                                                               ? (IData)(vlSelf->__PVT___425_)
                                                               : (IData)(vlSelf->__PVT___447_)) 
                                                             << 8U) 
                                                            | (IData)(vlSelf->__PVT___447_)))));
    __Vfunc___03510__20__a = vlSelf->__PVT___447_;
    __Vfunc___03510__20__Vfuncout = (0xffU & ((0x20U 
                                               & (IData)(__Vfunc___03510__20__s))
                                               ? ((0x10U 
                                                   & (IData)(__Vfunc___03510__20__s))
                                                   ? 
                                                  ((8U 
                                                    & (IData)(__Vfunc___03510__20__s))
                                                    ? 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03510__20__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03510__20__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 8U)))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 0x10U))))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03510__20__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 8U)))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 0x18U)))))
                                                    : 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03510__20__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03510__20__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 8U)))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 0x10U))))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03510__20__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 8U)))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 0x20U))))))
                                                   : 
                                                  ((8U 
                                                    & (IData)(__Vfunc___03510__20__s))
                                                    ? 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03510__20__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03510__20__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 8U)))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 0x10U))))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03510__20__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 8U)))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 0x18U)))))
                                                    : 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03510__20__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03510__20__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 8U)))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 0x10U))))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03510__20__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 8U)))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 0x28U)))))))
                                               : ((0x10U 
                                                   & (IData)(__Vfunc___03510__20__s))
                                                   ? 
                                                  ((8U 
                                                    & (IData)(__Vfunc___03510__20__s))
                                                    ? 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03510__20__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03510__20__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 8U)))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 0x10U))))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03510__20__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 8U)))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 0x18U)))))
                                                    : 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03510__20__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03510__20__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 8U)))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 0x10U))))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03510__20__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 8U)))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 0x20U))))))
                                                   : 
                                                  ((8U 
                                                    & (IData)(__Vfunc___03510__20__s))
                                                    ? 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03510__20__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03510__20__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 8U)))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 0x10U))))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03510__20__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 8U)))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 0x18U)))))
                                                    : 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03510__20__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03510__20__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 8U)))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 0x10U))))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03510__20__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(
                                                                 (__Vfunc___03510__20__b 
                                                                  >> 8U)))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03510__20__s))
                                                       ? (IData)(__Vfunc___03510__20__b)
                                                       : (IData)(__Vfunc___03510__20__a))))))));
    __PVT___164_ = __Vfunc___03510__20__Vfuncout;
    vlSelf->__PVT__sd_cs_n_s = (1U & ((~ (IData)(vlSelf->__PVT___181_)) 
                                      | (IData)(vlSelf->__PVT___295_)));
    vlSelf->__PVT__cv_ram1k_en_s = ((IData)(vlSelf->__PVT___043_) 
                                    & (IData)(vlSelf->__PVT___108_));
    __Vfunc___03389__5__s = (((7U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                            >> 0xdU))) 
                              << 7U) | (((6U == (7U 
                                                 & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                    >> 0xdU))) 
                                         << 6U) | (
                                                   ((5U 
                                                     == 
                                                     (7U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                         >> 0xdU))) 
                                                    << 5U) 
                                                   | (((4U 
                                                        == 
                                                        (7U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                            >> 0xdU))) 
                                                       << 4U) 
                                                      | (((3U 
                                                           == 
                                                           (7U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                               >> 0xdU))) 
                                                          << 3U) 
                                                         | (((2U 
                                                              == 
                                                              (7U 
                                                               & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                  >> 0xdU))) 
                                                             << 2U) 
                                                            | (((1U 
                                                                 == 
                                                                 (7U 
                                                                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                     >> 0xdU))) 
                                                                << 1U) 
                                                               | (0U 
                                                                  == 
                                                                  (7U 
                                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                      >> 0xdU))))))))));
    __Vfunc___03389__5__b = (((IData)(vlSelf->__PVT___077_) 
                              << 7U) | (((IData)(vlSelf->__PVT___077_) 
                                         << 6U) | (
                                                   ((IData)(vlSelf->__PVT___077_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->__PVT___077_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->__PVT___072_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->__PVT___058_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->__PVT___058_) 
                                                                << 1U) 
                                                               | ((IData)(vlSelf->__PVT___415_) 
                                                                  | ((IData)(vlSelf->__PVT___049_) 
                                                                     | (IData)(vlSelf->__PVT__inst_t80__DOT___63_))))))))));
    __Vfunc___03389__5__Vfuncout = (1U & ((~ ((((((
                                                   ((1U 
                                                     == 
                                                     (1U 
                                                      & (IData)(__Vfunc___03389__5__s))) 
                                                    | (2U 
                                                       == 
                                                       (2U 
                                                        & (IData)(__Vfunc___03389__5__s)))) 
                                                   | (4U 
                                                      == 
                                                      (4U 
                                                       & (IData)(__Vfunc___03389__5__s)))) 
                                                  | (8U 
                                                     == 
                                                     (8U 
                                                      & (IData)(__Vfunc___03389__5__s)))) 
                                                 | (0x10U 
                                                    == 
                                                    (0x10U 
                                                     & (IData)(__Vfunc___03389__5__s)))) 
                                                | (0x20U 
                                                   == 
                                                   (0x20U 
                                                    & (IData)(__Vfunc___03389__5__s)))) 
                                               | (0x40U 
                                                  == 
                                                  (0x40U 
                                                   & (IData)(__Vfunc___03389__5__s)))) 
                                              | (0x80U 
                                                 == 
                                                 (0x80U 
                                                  & (IData)(__Vfunc___03389__5__s))))) 
                                          | ((1U == 
                                              (1U & (IData)(__Vfunc___03389__5__s)))
                                              ? (IData)(__Vfunc___03389__5__b)
                                              : ((2U 
                                                  == 
                                                  (2U 
                                                   & (IData)(__Vfunc___03389__5__s)))
                                                  ? 
                                                 ((IData)(__Vfunc___03389__5__b) 
                                                  >> 1U)
                                                  : 
                                                 ((4U 
                                                   == 
                                                   (4U 
                                                    & (IData)(__Vfunc___03389__5__s)))
                                                   ? 
                                                  ((IData)(__Vfunc___03389__5__b) 
                                                   >> 2U)
                                                   : 
                                                  ((8U 
                                                    == 
                                                    (8U 
                                                     & (IData)(__Vfunc___03389__5__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03389__5__b) 
                                                    >> 3U)
                                                    : 
                                                   ((0x10U 
                                                     == 
                                                     (0x10U 
                                                      & (IData)(__Vfunc___03389__5__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03389__5__b) 
                                                     >> 4U)
                                                     : 
                                                    ((0x20U 
                                                      == 
                                                      (0x20U 
                                                       & (IData)(__Vfunc___03389__5__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03389__5__b) 
                                                      >> 5U)
                                                      : 
                                                     ((0x40U 
                                                       == 
                                                       (0x40U 
                                                        & (IData)(__Vfunc___03389__5__s)))
                                                       ? 
                                                      ((IData)(__Vfunc___03389__5__b) 
                                                       >> 6U)
                                                       : 
                                                      ((IData)(__Vfunc___03389__5__b) 
                                                       >> 7U))))))))));
    __PVT___110_ = __Vfunc___03389__5__Vfuncout;
    if (vlSelf->__PVT___043_) {
        vlSelf->__PVT__cpu_data_mux_s = vlSelf->__PVT___113_;
        vlSelf->__PVT__d_to_cpu_s = vlSelf->__PVT__cpu_data_mux_s;
        vlSelf->__PVT__ext_ram_en_s = vlSelf->__PVT___109_;
    } else {
        vlSelf->__PVT__cpu_data_mux_s = vlSymsp->TOP__sim_top.__PVT__cart_bus;
        vlSelf->__PVT__d_to_cpu_s = ((0x80U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))
                                      ? ((IData)(vlSelf->__PVT___150_)
                                          ? (IData)(__PVT___164_)
                                          : (IData)(vlSelf->__PVT___447_))
                                      : ((IData)(vlSelf->__PVT___181_)
                                          ? (IData)(vlSelf->__PVT___293_)
                                          : 0U));
        vlSelf->__PVT__ext_ram_en_s = 0U;
    }
    vlSelf->__PVT___176_ = (((IData)(vlSelf->__PVT___043_) 
                             & (IData)(vlSelf->__PVT___120_))
                             ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_)
                             : (IData)(vlSelf->__PVT___435_));
    vlSelf->__PVT___177_ = (((IData)(vlSelf->__PVT___043_) 
                             & (IData)(vlSelf->__PVT___121_))
                             ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_)
                             : (IData)(vlSelf->__PVT___436_));
    vlSelf->__PVT___179_ = (((IData)(vlSelf->__PVT___043_) 
                             & (IData)(vlSelf->__PVT___122_))
                             ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_)
                             : (IData)(vlSelf->__PVT___437_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___202_ = 
        (0xffffU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__regbusc) 
                    + (IData)(vlSelf->inst_t80__DOT__u0__DOT____VdfgTmp_h8fd225ae__0)));
    vlSelf->__PVT___010_ = ((~ (IData)(vlSelf->__PVT___440_)) 
                            & (IData)(vlSelf->__PVT__io_wr_s));
    vlSelf->__PVT__vdp_r_n_s = (1U & ((~ (IData)(vlSelf->__PVT___150_)) 
                                      | (IData)(vlSelf->__PVT___161_)));
    vlSelf->__PVT__vdp_w_n_s = (1U & ((~ (IData)(vlSelf->__PVT___150_)) 
                                      | (IData)(vlSelf->__PVT___162_)));
    vlSelf->__PVT__sn489_we_n_s = (1U & ((~ (IData)(vlSelf->__PVT___150_)) 
                                         | (IData)(vlSelf->__PVT___163_)));
    vlSelf->__PVT__ctrl_en_joy_n_s = (1U & ((~ (IData)(vlSelf->__PVT___150_)) 
                                            | (IData)(vlSelf->__PVT___166_)));
    vlSelf->__PVT__ctrl_en_key_n_s = (1U & ((~ (IData)(vlSelf->__PVT___150_)) 
                                            | (IData)(vlSelf->__PVT___165_)));
    if (vlSymsp->TOP.clk_3m58_en) {
        if (vlSelf->__PVT___181_) {
            vlSelf->__PVT___359_ = vlSelf->__PVT___294_;
            vlSelf->__PVT___355_ = vlSelf->__PVT___291_;
            vlSelf->__PVT___361_ = vlSelf->__PVT___296_;
            vlSelf->__PVT___362_ = vlSelf->__PVT___297_;
            vlSelf->__PVT___363_ = vlSelf->__PVT___298_;
            vlSelf->__PVT___364_ = vlSelf->__PVT___299_;
            vlSelf->__PVT___365_ = vlSelf->__PVT___301_;
            vlSelf->__PVT___366_ = vlSelf->__PVT___302_;
            vlSelf->__PVT___358_ = vlSelf->__PVT___292_;
            vlSelf->__PVT___369_ = vlSelf->__PVT___303_;
            vlSelf->__PVT___370_ = vlSelf->__PVT___304_;
        } else {
            vlSelf->__PVT___359_ = vlSelf->__PVT___415_;
            vlSelf->__PVT___355_ = vlSelf->__PVT___412_;
            vlSelf->__PVT___361_ = vlSelf->__PVT___417_;
            vlSelf->__PVT___362_ = vlSelf->__PVT___418_;
            vlSelf->__PVT___363_ = vlSelf->__PVT___427_;
            vlSelf->__PVT___364_ = vlSelf->__PVT___428_;
            vlSelf->__PVT___365_ = vlSelf->__PVT___429_;
            vlSelf->__PVT___366_ = vlSelf->__PVT___430_;
            vlSelf->__PVT___358_ = vlSelf->__PVT___414_;
            vlSelf->__PVT___369_ = vlSelf->__PVT___432_;
            vlSelf->__PVT___370_ = vlSelf->__PVT___434_;
        }
        if (vlSelf->__PVT__ym2149_audio_inst__DOT___158_) {
            vlSelf->__PVT__ym2149_audio_inst__DOT___192_[0U] 
                = vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U];
            vlSelf->__PVT__ym2149_audio_inst__DOT___192_[1U] 
                = vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U];
            vlSelf->__PVT__ym2149_audio_inst__DOT___192_[2U] 
                = vlSelf->__PVT__ym2149_audio_inst__DOT___057_[2U];
            vlSelf->__PVT__ym2149_audio_inst__DOT___192_[3U] 
                = vlSelf->__PVT__ym2149_audio_inst__DOT___057_[3U];
        } else if (vlSelf->__PVT__ym2149_audio_inst__DOT___159_) {
            vlSelf->__PVT__ym2149_audio_inst__DOT___192_[0U] 
                = __Vtemp_1[0U];
            vlSelf->__PVT__ym2149_audio_inst__DOT___192_[1U] 
                = __Vtemp_1[1U];
            vlSelf->__PVT__ym2149_audio_inst__DOT___192_[2U] 
                = __Vtemp_4[2U];
            vlSelf->__PVT__ym2149_audio_inst__DOT___192_[3U] 
                = __Vtemp_8[3U];
        } else {
            vlSelf->__PVT__ym2149_audio_inst__DOT___192_[0U] 
                = vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U];
            vlSelf->__PVT__ym2149_audio_inst__DOT___192_[1U] 
                = vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U];
            vlSelf->__PVT__ym2149_audio_inst__DOT___192_[2U] 
                = vlSelf->__PVT__ym2149_audio_inst__DOT___057_[2U];
            vlSelf->__PVT__ym2149_audio_inst__DOT___192_[3U] 
                = vlSelf->__PVT__ym2149_audio_inst__DOT___057_[3U];
        }
        vlSelf->__PVT__sn76489_audio_inst__DOT___160_ 
            = vlSelf->__PVT__sn76489_audio_inst__DOT___018_;
        vlSelf->__PVT__sn76489_audio_inst__DOT___158_ 
            = vlSelf->__PVT__sn76489_audio_inst__DOT___017_;
        vlSelf->__PVT__ctrl_b__DOT___82_ = (0x7ffU 
                                            & (((0U 
                                                 != (IData)(vlSelf->__PVT__ctrl_b__DOT___83_)) 
                                                | (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_ifc_load_s))
                                                ? ((IData)(vlSelf->__PVT__ctrl_b__DOT__p2_ifc_load_s)
                                                    ? 0x700U
                                                    : 
                                                   ((IData)(vlSelf->__PVT__ctrl_b__DOT___83_) 
                                                    - (IData)(1U)))
                                                : (IData)(vlSelf->__PVT__ctrl_b__DOT___83_)));
        vlSelf->__PVT__ctrl_b__DOT___72_ = (0x7fU & 
                                            (((~ (IData)(vlSelf->__PVT__ctrl_b__DOT___31_)) 
                                              & (0U 
                                                 == (IData)(vlSelf->__PVT__ctrl_b__DOT___73_)))
                                              ? (IData)(vlSelf->__PVT__ctrl_b__DOT___73_)
                                              : (((IData)(vlSelf->__PVT__ctrl_b__DOT___31_) 
                                                  & (0U 
                                                     == (IData)(vlSelf->__PVT__ctrl_b__DOT___73_)))
                                                  ? 0x48U
                                                  : 
                                                 ((IData)(vlSelf->__PVT__ctrl_b__DOT___73_) 
                                                  - (IData)(1U)))));
        vlSelf->__PVT__ctrl_b__DOT___78_ = (0x7ffU 
                                            & (((0U 
                                                 != (IData)(vlSelf->__PVT__ctrl_b__DOT___79_)) 
                                                | (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_ifc_load_s))
                                                ? ((IData)(vlSelf->__PVT__ctrl_b__DOT__p1_ifc_load_s)
                                                    ? 0x700U
                                                    : 
                                                   ((IData)(vlSelf->__PVT__ctrl_b__DOT___79_) 
                                                    - (IData)(1U)))
                                                : (IData)(vlSelf->__PVT__ctrl_b__DOT___79_)));
        vlSelf->__PVT__ctrl_b__DOT___66_ = ((~ ((~ (IData)(vlSelf->__PVT__ctrl_en_key_n_s)) 
                                                & (IData)(vlSelf->__PVT__ctrl_en_joy_n_s))) 
                                            & (((~ (IData)(vlSelf->__PVT__ctrl_en_joy_n_s)) 
                                                & (IData)(vlSelf->__PVT__ctrl_en_key_n_s)) 
                                               | (IData)(vlSelf->__PVT__ctrl_b__DOT___67_)));
    } else {
        vlSelf->__PVT___359_ = vlSelf->__PVT___415_;
        vlSelf->__PVT___355_ = vlSelf->__PVT___412_;
        vlSelf->__PVT___361_ = vlSelf->__PVT___417_;
        vlSelf->__PVT___362_ = vlSelf->__PVT___418_;
        vlSelf->__PVT___363_ = vlSelf->__PVT___427_;
        vlSelf->__PVT___364_ = vlSelf->__PVT___428_;
        vlSelf->__PVT___365_ = vlSelf->__PVT___429_;
        vlSelf->__PVT___366_ = vlSelf->__PVT___430_;
        vlSelf->__PVT___358_ = vlSelf->__PVT___414_;
        vlSelf->__PVT__ym2149_audio_inst__DOT___192_[0U] 
            = vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U];
        vlSelf->__PVT__ym2149_audio_inst__DOT___192_[1U] 
            = vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U];
        vlSelf->__PVT__ym2149_audio_inst__DOT___192_[2U] 
            = vlSelf->__PVT__ym2149_audio_inst__DOT___057_[2U];
        vlSelf->__PVT__ym2149_audio_inst__DOT___192_[3U] 
            = vlSelf->__PVT__ym2149_audio_inst__DOT___057_[3U];
        vlSelf->__PVT__sn76489_audio_inst__DOT___160_ 
            = vlSelf->__PVT__sn76489_audio_inst__DOT___161_;
        vlSelf->__PVT__sn76489_audio_inst__DOT___158_ 
            = vlSelf->__PVT__sn76489_audio_inst__DOT___159_;
        vlSelf->__PVT___369_ = vlSelf->__PVT___432_;
        vlSelf->__PVT___370_ = vlSelf->__PVT___434_;
        vlSelf->__PVT__ctrl_b__DOT___82_ = (0x7ffU 
                                            & (IData)(vlSelf->__PVT__ctrl_b__DOT___83_));
        vlSelf->__PVT__ctrl_b__DOT___72_ = (0x7fU & (IData)(vlSelf->__PVT__ctrl_b__DOT___73_));
        vlSelf->__PVT__ctrl_b__DOT___78_ = (0x7ffU 
                                            & (IData)(vlSelf->__PVT__ctrl_b__DOT___79_));
        vlSelf->__PVT__ctrl_b__DOT___66_ = vlSelf->__PVT__ctrl_b__DOT___67_;
    }
    vlSelf->__PVT__kbd_rd_s = ((IData)(vlSelf->__PVT___150_) 
                               & (IData)(vlSelf->__PVT___168_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___119_ = 
        (0x7fU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___726_) 
                  + (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___233_)));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s 
        = (((8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
            << 6U) | (((0xbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                       << 5U) | (((0xaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                  << 4U) | (((9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                             << 3U) 
                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___137_) 
                                                << 2U) 
                                               | (((0xcU 
                                                    == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___086_)))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b 
        = ((0x20U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                     << 4U)) | ((0x10U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                          << 3U)) | 
                                ((2U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)) 
                                 | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___040_))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__a 
        = (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                 >> 1U));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__Vfuncout 
        = (1U & ((0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                  ? ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 6U)))))))
                  : ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__a)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___177_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2046_) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2037_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2053_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2080_) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2071_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2087_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2044_) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2035_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2051_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2078_) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2069_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2085_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2045_) 
            << 2U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2036_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__Vfuncout 
        = (3U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__b) 
                         >> 2U) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2052_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2079_) 
            << 2U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2070_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__Vfuncout 
        = (3U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__b) 
                         >> 2U) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2086_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0569_) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0560_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0576_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0567_) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0558_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0574_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0568_) 
            << 2U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0559_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__Vfuncout 
        = (3U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__b) 
                         >> 2U) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0575_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___111_ 
        = (0x1ffU & ((2U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_))
                      ? ((1U & ((0x99U < (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_)) 
                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)))
                          ? ((IData)(vlSelf->inst_t80__DOT__u0__DOT__alu__DOT____VdfgTmp_h27faa2e2__0) 
                             - (IData)(0x160U)) : (IData)(vlSelf->inst_t80__DOT__u0__DOT__alu__DOT____VdfgTmp_h27faa2e2__0))
                      : ((1U & ((9U < (0x1fU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___094_) 
                                                >> 4U))) 
                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)))
                          ? ((IData)(0x60U) + (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___094_))
                          : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___094_))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s 
        = (((8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
            << 6U) | (((0xbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                       << 5U) | (((0xaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                  << 4U) | (((9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                             << 3U) 
                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___137_) 
                                                << 2U) 
                                               | (((0xcU 
                                                    == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___086_)))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b 
        = (8U | ((0x20U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                           << 1U)) | ((0x10U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)) 
                                      | ((2U & (((2U 
                                                  & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_))
                                                  ? 
                                                 ((~ 
                                                   ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___089_) 
                                                    & (5U 
                                                       < 
                                                       (0xfU 
                                                        & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_))))) 
                                                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                     >> 4U))
                                                  : 
                                                 ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___089_)
                                                   ? 
                                                  (9U 
                                                   < 
                                                   (0xfU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_)))
                                                   : 
                                                  ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                   >> 4U))) 
                                                << 1U)) 
                                         | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___042_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__a 
        = (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                 >> 4U));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__Vfuncout 
        = (1U & ((0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                  ? ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 6U)))))))
                  : ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__b)
                                          : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__a)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___180_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310262__96__Vfuncout;
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___020_ 
        = (7U & (((2U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                         >> 6U)) | (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___017_) 
                                          >> 4U))) 
                 + (1U | (2U & (((2U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))
                                  ? (~ ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_) 
                                        >> 7U)) : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_) 
                                                   >> 7U)) 
                                << 1U)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__Vfuncout 
        = (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s)) 
                  | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
                 | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
                | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
               | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
              | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
             | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
            | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s)))
            ? 3U : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s)) 
                           | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
                          | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
                         | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
                        | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
                       | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
                      | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
                     | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s)))
                     ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                         ? 3U : ((0x200U == (0x200U 
                                             & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                                  ? 3U : ((0x400U == 
                                           (0x400U 
                                            & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                                           ? 3U : (
                                                   (0x800U 
                                                    == 
                                                    (0x800U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                                                    ? 0U
                                                    : 
                                                   ((0x1000U 
                                                     == 
                                                     (0x1000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                                                     ? 1U
                                                     : 
                                                    ((0x2000U 
                                                      == 
                                                      (0x2000U 
                                                       & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                                                      ? 2U
                                                      : 3U))))))
                     : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                         ? 3U : ((0x20000U == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                                  ? 3U : ((0x40000U 
                                           == (0x40000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                                           ? 3U : (
                                                   (0x80000U 
                                                    == 
                                                    (0x80000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                                                    ? 3U
                                                    : 
                                                   ((0x100000U 
                                                     == 
                                                     (0x100000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                                                     ? 3U
                                                     : 
                                                    ((0x200000U 
                                                      == 
                                                      (0x200000U 
                                                       & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                                                      ? 3U
                                                      : 
                                                     ((0x400000U 
                                                       == 
                                                       (0x400000U 
                                                        & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                                                       ? 3U
                                                       : 0U)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2278_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__Vfuncout 
        = (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s)) 
                  | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
                 | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
                | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
               | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
              | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
             | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
            | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s)))
            ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                ? 1U : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                         ? 1U : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                  ? 1U : ((8U == (8U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                           ? 1U : (
                                                   (0x10U 
                                                    == 
                                                    (0x10U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                                    ? 1U
                                                    : 
                                                   ((0x20U 
                                                     == 
                                                     (0x20U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                                     ? 1U
                                                     : 5U))))))
            : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s)) 
                      | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
                     | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
                    | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
                   | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
                  | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
                 | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
                | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s)))
                ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                    ? 4U : ((0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                             ? 4U : ((0x400U == (0x400U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                      ? 1U : ((0x800U 
                                               == (0x800U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                               ? 1U
                                               : ((0x1000U 
                                                   == 
                                                   (0x1000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                                   ? 1U
                                                   : 
                                                  ((0x2000U 
                                                    == 
                                                    (0x2000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                                    ? 1U
                                                    : 3U))))))
                : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                    ? 4U : ((0x20000U == (0x20000U 
                                          & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                             ? 4U : ((0x40000U == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                      ? 3U : ((0x80000U 
                                               == (0x80000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                               ? 2U
                                               : ((0x100000U 
                                                   == 
                                                   (0x100000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                                   ? 2U
                                                   : 
                                                  ((0x200000U 
                                                    == 
                                                    (0x200000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                                    ? 4U
                                                    : 
                                                   ((0x400000U 
                                                     == 
                                                     (0x400000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                                     ? 4U
                                                     : 0U)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2249_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1989_) 
           << 9U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2262_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__Vfuncout 
        = ((~ ((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s)) 
                     | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
                    | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
                   | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
                  | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
                 | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
                | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
               | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s)))) 
           & (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s)) 
                     | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
                    | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
                   | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
                  | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
                 | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
                | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
               | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
              & ((0x100U != (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s)) 
                 & (IData)(((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s 
                             >> 0xaU) & (0x200U != 
                                         (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2255_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1991_) 
           << 9U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2264_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
        = (0x400U | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2236_) 
                      << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2211_) 
                                    << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2120_) 
                                                  << 0x11U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2106_) 
                                                     << 0x10U) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2089_) 
                                                        << 0xfU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2055_) 
                                                           << 0xeU) 
                                                          | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1990_) 
                                                             << 9U))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2263_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1945_) 
            << 7U) | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1924_) 
                      << 6U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2269_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2131_) 
            << 0x12U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1944_) 
                          << 7U) | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1923_) 
                                    << 6U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2268_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2232_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2207_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2154_) 
                                        << 0x13U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2116_) 
                                         << 0x11U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2102_) 
                                            << 0x10U) 
                                           | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2083_) 
                                               << 0xfU) 
                                              | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2049_) 
                                                  << 0xeU) 
                                                 | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1919_) 
                                                    << 6U))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2254_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2239_) 
            << 0x16U) | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2214_) 
                         << 0x15U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2274_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2132_) 
           << 0x12U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2271_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1940_) 
            << 7U) | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1917_) 
                      << 6U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2251_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vtemp_12[0U] = (((IData)((((QData)((IData)((((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2235_) 
                                                   << 0x1cU) 
                                                  | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2210_) 
                                                      << 0x18U) 
                                                     | ((0x700000U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                            << 0x11U)) 
                                                        | ((0x70000U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                               << 0xdU)) 
                                                           | ((0x7000U 
                                                               & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                  << 9U)) 
                                                              | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2119_) 
                                                                  << 8U) 
                                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2105_) 
                                                                     << 4U) 
                                                                    | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2088_)))))))))) 
                                 << 0x20U) | (QData)((IData)(
                                                             (0x2000U 
                                                              | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2054_) 
                                                                  << 0x1cU) 
                                                                 | ((0x7000000U 
                                                                     & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                        << 0x15U)) 
                                                                    | ((0x700000U 
                                                                        & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                           << 0x11U)) 
                                                                       | ((0x70000U 
                                                                           & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                              << 0xdU)) 
                                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1988_) 
                                                                              << 8U) 
                                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1966_) 
                                                                                << 4U) 
                                                                                | (7U 
                                                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                                >> 3U))))))))))))) 
                       << 0x1cU) | ((0x7000000U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                   << 0x15U)) 
                                    | ((0x700000U & 
                                        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                         << 0x11U)) 
                                       | ((0x70000U 
                                           & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                              << 0xdU)) 
                                          | ((0x7000U 
                                              & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                 << 9U)) 
                                             | ((0x700U 
                                                 & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                    << 5U)) 
                                                | ((0x70U 
                                                    & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                       << 1U)) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                         >> 3U)))))))));
    __Vtemp_12[1U] = (((IData)((((QData)((IData)((((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2235_) 
                                                   << 0x1cU) 
                                                  | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2210_) 
                                                      << 0x18U) 
                                                     | ((0x700000U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                            << 0x11U)) 
                                                        | ((0x70000U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                               << 0xdU)) 
                                                           | ((0x7000U 
                                                               & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                  << 9U)) 
                                                              | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2119_) 
                                                                  << 8U) 
                                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2105_) 
                                                                     << 4U) 
                                                                    | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2088_)))))))))) 
                                 << 0x20U) | (QData)((IData)(
                                                             (0x2000U 
                                                              | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2054_) 
                                                                  << 0x1cU) 
                                                                 | ((0x7000000U 
                                                                     & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                        << 0x15U)) 
                                                                    | ((0x700000U 
                                                                        & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                           << 0x11U)) 
                                                                       | ((0x70000U 
                                                                           & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                              << 0xdU)) 
                                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1988_) 
                                                                              << 8U) 
                                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1966_) 
                                                                                << 4U) 
                                                                                | (7U 
                                                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                                >> 3U))))))))))))) 
                       >> 4U) | ((IData)(((((QData)((IData)(
                                                            (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2235_) 
                                                              << 0x1cU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2210_) 
                                                                 << 0x18U) 
                                                                | ((0x700000U 
                                                                    & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                       << 0x11U)) 
                                                                   | ((0x70000U 
                                                                       & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                          << 0xdU)) 
                                                                      | ((0x7000U 
                                                                          & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                             << 9U)) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2119_) 
                                                                             << 8U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2105_) 
                                                                                << 4U) 
                                                                               | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2088_)))))))))) 
                                            << 0x20U) 
                                           | (QData)((IData)(
                                                             (0x2000U 
                                                              | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2054_) 
                                                                  << 0x1cU) 
                                                                 | ((0x7000000U 
                                                                     & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                        << 0x15U)) 
                                                                    | ((0x700000U 
                                                                        & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                           << 0x11U)) 
                                                                       | ((0x70000U 
                                                                           & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                              << 0xdU)) 
                                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1988_) 
                                                                              << 8U) 
                                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1966_) 
                                                                                << 4U) 
                                                                                | (7U 
                                                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                                >> 3U)))))))))))) 
                                          >> 0x20U)) 
                                 << 0x1cU));
    __Vtemp_12[2U] = ((IData)(((((QData)((IData)((((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2235_) 
                                                   << 0x1cU) 
                                                  | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2210_) 
                                                      << 0x18U) 
                                                     | ((0x700000U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                            << 0x11U)) 
                                                        | ((0x70000U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                               << 0xdU)) 
                                                           | ((0x7000U 
                                                               & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                  << 9U)) 
                                                              | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2119_) 
                                                                  << 8U) 
                                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2105_) 
                                                                     << 4U) 
                                                                    | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2088_)))))))))) 
                                 << 0x20U) | (QData)((IData)(
                                                             (0x2000U 
                                                              | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2054_) 
                                                                  << 0x1cU) 
                                                                 | ((0x7000000U 
                                                                     & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                        << 0x15U)) 
                                                                    | ((0x700000U 
                                                                        & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                           << 0x11U)) 
                                                                       | ((0x70000U 
                                                                           & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                              << 0xdU)) 
                                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1988_) 
                                                                              << 8U) 
                                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1966_) 
                                                                                << 4U) 
                                                                                | (7U 
                                                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                                >> 3U)))))))))))) 
                               >> 0x20U)) >> 4U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
        = __Vtemp_12[0U];
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
        = __Vtemp_12[1U];
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
        = __Vtemp_12[2U];
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__Vfuncout 
        = (0xfU & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s)) 
                          | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                         | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                        | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                       | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                      | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                     | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                    | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s)))
                    ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                        ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U]
                        : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                            ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                << 0x1cU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                             >> 4U))
                            : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                    << 0x18U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                                 >> 8U))
                                : ((8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                    ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                        << 0x14U) | 
                                       (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                        >> 0xcU)) : 
                                   ((0x10U == (0x10U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                     ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                         << 0x10U) 
                                        | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                           >> 0x10U))
                                     : ((0x20U == (0x20U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                         ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                             << 0xcU) 
                                            | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                               >> 0x14U))
                                         : ((0x40U 
                                             == (0x40U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                             ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                                 << 8U) 
                                                | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                                   >> 0x18U))
                                             : ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                                 << 4U) 
                                                | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                                   >> 0x1cU)))))))))
                    : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s)) 
                              | (0x200U == (0x200U 
                                            & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                             | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                            | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                           | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                          | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                         | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                        | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s)))
                        ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                            ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U]
                            : ((0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                    << 0x1cU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                                 >> 4U))
                                : ((0x400U == (0x400U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                    ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                        << 0x18U) | 
                                       (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                        >> 8U)) : (
                                                   (0x800U 
                                                    == 
                                                    (0x800U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                                    ? 
                                                   ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                                     << 0x14U) 
                                                    | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                                       >> 0xcU))
                                                    : 
                                                   ((0x1000U 
                                                     == 
                                                     (0x1000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                                     ? 
                                                    ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                                      << 0x10U) 
                                                     | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                                        >> 0x10U))
                                                     : 
                                                    ((0x2000U 
                                                      == 
                                                      (0x2000U 
                                                       & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                                      ? 
                                                     ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                                       << 0xcU) 
                                                      | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                                         >> 0x14U))
                                                      : 
                                                     ((0x4000U 
                                                       == 
                                                       (0x4000U 
                                                        & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                                       ? 
                                                      ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                                        << 8U) 
                                                       | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                                          >> 0x18U))
                                                       : 
                                                      ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                                        << 4U) 
                                                       | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                                          >> 0x1cU)))))))))
                        : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                            ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U]
                            : ((0x20000U == (0x20000U 
                                             & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                    << 0x1cU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                                 >> 4U))
                                : ((0x40000U == (0x40000U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                    ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                        << 0x18U) | 
                                       (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                        >> 8U)) : (
                                                   (0x80000U 
                                                    == 
                                                    (0x80000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                                    ? 
                                                   ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                                     << 0x14U) 
                                                    | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                                       >> 0xcU))
                                                    : 
                                                   ((0x100000U 
                                                     == 
                                                     (0x100000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                                     ? 
                                                    ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                                      << 0x10U) 
                                                     | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                                        >> 0x10U))
                                                     : 
                                                    ((0x200000U 
                                                      == 
                                                      (0x200000U 
                                                       & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                                      ? 
                                                     ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                                       << 0xcU) 
                                                      | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                                         >> 0x14U))
                                                      : 
                                                     ((0x400000U 
                                                       == 
                                                       (0x400000U 
                                                        & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                                       ? 
                                                      ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                                        << 8U) 
                                                       | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                                          >> 0x18U))
                                                       : 0U))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2261_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2108_) 
           << 0x10U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2275_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2122_) 
           << 0x11U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2276_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2240_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2215_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2109_) 
                                        << 0x10U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2090_) 
                                         << 0xfU) | 
                                        (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2056_) 
                                          << 0xeU) 
                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1994_) 
                                             << 9U) 
                                            | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1969_) 
                                               << 8U)))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2279_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2238_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2213_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2182_) 
                                        << 0x14U) | 
                                       ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2157_) 
                                        << 0x13U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2266_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1993_) 
           << 9U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2273_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2130_) 
           << 0x12U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2267_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2241_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2216_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2183_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2123_) 
                                         << 0x11U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2110_) 
                                            << 0x10U) 
                                           | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1970_) 
                                               << 8U) 
                                              | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1946_) 
                                                 << 7U)))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2280_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1941_) 
            << 7U) | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1918_) 
                      << 6U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2252_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
        = (0x400U | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1921_) 
                     << 6U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2257_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
        = (IData)((0x80000000ULL | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2155_)) 
                                     << 0x39U) | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2117_)) 
                                                   << 0x33U) 
                                                  | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2103_)) 
                                                      << 0x30U) 
                                                     | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2084_)) 
                                                         << 0x2dU) 
                                                        | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2050_)) 
                                                            << 0x2aU) 
                                                           | (QData)((IData)(
                                                                             (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1986_) 
                                                                               << 0x1bU) 
                                                                              | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1964_) 
                                                                                << 0x18U) 
                                                                                | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1920_) 
                                                                                << 0x12U))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
        = (IData)(((0x80000000ULL | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2155_)) 
                                      << 0x39U) | (
                                                   ((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2117_)) 
                                                    << 0x33U) 
                                                   | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2103_)) 
                                                       << 0x30U) 
                                                      | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2084_)) 
                                                          << 0x2dU) 
                                                         | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2050_)) 
                                                             << 0x2aU) 
                                                            | (QData)((IData)(
                                                                              (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1986_) 
                                                                                << 0x1bU) 
                                                                               | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1964_) 
                                                                                << 0x18U) 
                                                                                | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1920_) 
                                                                                << 0x12U))))))))))) 
                   >> 0x20U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[2U] = 0U;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__Vfuncout 
        = (7U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U]
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                          ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                              << 0x1dU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                           >> 3U)) : 
                         ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                           ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                               << 0x1aU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                            >> 6U))
                           : ((8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                               ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                   << 0x17U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                                >> 9U))
                               : ((0x10U == (0x10U 
                                             & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                   ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                       << 0x14U) | 
                                      (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                       >> 0xcU)) : 
                                  ((0x20U == (0x20U 
                                              & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                    ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                        << 0x11U) | 
                                       (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                        >> 0xfU)) : 
                                   ((0x40U == (0x40U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                     ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                         << 0xeU) | 
                                        (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                         >> 0x12U))
                                     : ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                         << 0xbU) | 
                                        (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                         >> 0x15U)))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                          ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                              << 8U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                        >> 0x18U)) : 
                         ((0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                           ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                               << 5U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                         >> 0x1bU))
                           : ((0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                               ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                   << 2U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                             >> 0x1eU))
                               : ((0x800U == (0x800U 
                                              & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                   ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                       << 0x1fU) | 
                                      (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                       >> 1U)) : ((0x1000U 
                                                   == 
                                                   (0x1000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                                   ? 
                                                  ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                                    << 0x1cU) 
                                                   | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                                      >> 4U))
                                                   : 
                                                  ((0x2000U 
                                                    == 
                                                    (0x2000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                                    ? 
                                                   ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                                     << 0x19U) 
                                                    | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                                       >> 7U))
                                                    : 
                                                   ((0x4000U 
                                                     == 
                                                     (0x4000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                                     ? 
                                                    ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                                      << 0x16U) 
                                                     | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                                        >> 0xaU))
                                                     : 
                                                    ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                                      << 0x13U) 
                                                     | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                                        >> 0xdU)))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                          ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                              << 0x10U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                           >> 0x10U))
                          : ((0x20000U == (0x20000U 
                                           & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                              ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                  << 0xdU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                              >> 0x13U))
                              : ((0x40000U == (0x40000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                  ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                      << 0xaU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                                  >> 0x16U))
                                  : ((0x80000U == (0x80000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                      ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                          << 7U) | 
                                         (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                          >> 0x19U))
                                      : ((0x100000U 
                                          == (0x100000U 
                                              & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                          ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                              << 4U) 
                                             | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                                >> 0x1cU))
                                          : ((0x200000U 
                                              == (0x200000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                              ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[2U] 
                                                  << 1U) 
                                                 | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                                    >> 0x1fU))
                                              : ((0x400000U 
                                                  == 
                                                  (0x400000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                                  ? 
                                                 ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[2U] 
                                                   << 0x1eU) 
                                                  | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[2U] 
                                                     >> 2U))
                                                  : 0U))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2256_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1968_) 
           << 8U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2272_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2158_) 
           << 0x13U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2277_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
        = (IData)((0xffffc0000000ULL | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2181_)) 
                                         << 0x3cU) 
                                        | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2156_)) 
                                            << 0x39U) 
                                           | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2129_)) 
                                               << 0x36U) 
                                              | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2121_)) 
                                                  << 0x33U) 
                                                 | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2107_)) 
                                                     << 0x30U) 
                                                    | (QData)((IData)(
                                                                      (0x3ffffU 
                                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1992_) 
                                                                           << 0x1bU) 
                                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1967_) 
                                                                              << 0x18U) 
                                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1943_) 
                                                                                << 0x15U) 
                                                                                | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1922_) 
                                                                                << 0x12U))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2212_) 
            << 0x1fU) | (IData)(((0xffffc0000000ULL 
                                  | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2181_)) 
                                      << 0x3cU) | (
                                                   ((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2156_)) 
                                                    << 0x39U) 
                                                   | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2129_)) 
                                                       << 0x36U) 
                                                      | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2121_)) 
                                                          << 0x33U) 
                                                         | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2107_)) 
                                                             << 0x30U) 
                                                            | (QData)((IData)(
                                                                              (0x3ffffU 
                                                                               | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1992_) 
                                                                                << 0x1bU) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1967_) 
                                                                                << 0x18U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1943_) 
                                                                                << 0x15U) 
                                                                                | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1922_) 
                                                                                << 0x12U))))))))))))) 
                                 >> 0x20U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[2U] 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2237_) 
            << 2U) | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2212_) 
                      >> 1U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__Vfuncout 
        = (7U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U]
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                          ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                              << 0x1dU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                           >> 3U)) : 
                         ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                           ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                               << 0x1aU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                            >> 6U))
                           : ((8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                               ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                   << 0x17U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                                >> 9U))
                               : ((0x10U == (0x10U 
                                             & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                   ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                       << 0x14U) | 
                                      (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                       >> 0xcU)) : 
                                  ((0x20U == (0x20U 
                                              & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                    ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                        << 0x11U) | 
                                       (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                        >> 0xfU)) : 
                                   ((0x40U == (0x40U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                     ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                         << 0xeU) | 
                                        (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                         >> 0x12U))
                                     : ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                         << 0xbU) | 
                                        (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                         >> 0x15U)))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                          ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                              << 8U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                        >> 0x18U)) : 
                         ((0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                           ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                               << 5U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                         >> 0x1bU))
                           : ((0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                               ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                   << 2U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                             >> 0x1eU))
                               : ((0x800U == (0x800U 
                                              & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                   ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                       << 0x1fU) | 
                                      (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                       >> 1U)) : ((0x1000U 
                                                   == 
                                                   (0x1000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                                   ? 
                                                  ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                                    << 0x1cU) 
                                                   | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                                      >> 4U))
                                                   : 
                                                  ((0x2000U 
                                                    == 
                                                    (0x2000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                                    ? 
                                                   ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                                     << 0x19U) 
                                                    | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                                       >> 7U))
                                                    : 
                                                   ((0x4000U 
                                                     == 
                                                     (0x4000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                                     ? 
                                                    ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                                      << 0x16U) 
                                                     | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                                        >> 0xaU))
                                                     : 
                                                    ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                                      << 0x13U) 
                                                     | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                                        >> 0xdU)))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                          ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                              << 0x10U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                           >> 0x10U))
                          : ((0x20000U == (0x20000U 
                                           & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                              ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                  << 0xdU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                              >> 0x13U))
                              : ((0x40000U == (0x40000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                  ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                      << 0xaU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                                  >> 0x16U))
                                  : ((0x80000U == (0x80000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                      ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                          << 7U) | 
                                         (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                          >> 0x19U))
                                      : ((0x100000U 
                                          == (0x100000U 
                                              & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                          ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                              << 4U) 
                                             | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                                >> 0x1cU))
                                          : ((0x200000U 
                                              == (0x200000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                              ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[2U] 
                                                  << 1U) 
                                                 | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                                    >> 0x1fU))
                                              : ((0x400000U 
                                                  == 
                                                  (0x400000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                                  ? 
                                                 ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[2U] 
                                                   << 0x1eU) 
                                                  | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[2U] 
                                                     >> 2U))
                                                  : 0U))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2265_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
        = (IData)((((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1985_)) 
                    << 0x24U) | ((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1963_)) 
                                 << 0x20U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
        = (IData)(((((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1985_)) 
                     << 0x24U) | ((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1963_)) 
                                  << 0x20U)) >> 0x20U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2231_) 
            << 0x18U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2206_) 
                          << 0x14U) | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2128_) 
                                       << 8U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__Vfuncout 
        = (0xfU & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s)) 
                          | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                         | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                        | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                       | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                      | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                     | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                    | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s)))
                    ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                        ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U]
                        : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                            ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                << 0x1cU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                             >> 4U))
                            : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                    << 0x18U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                                 >> 8U))
                                : ((8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                    ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                        << 0x14U) | 
                                       (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                        >> 0xcU)) : 
                                   ((0x10U == (0x10U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                     ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                         << 0x10U) 
                                        | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                           >> 0x10U))
                                     : ((0x20U == (0x20U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                         ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                             << 0xcU) 
                                            | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                               >> 0x14U))
                                         : ((0x40U 
                                             == (0x40U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                             ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                                 << 8U) 
                                                | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                                   >> 0x18U))
                                             : ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                                 << 4U) 
                                                | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                                   >> 0x1cU)))))))))
                    : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s)) 
                              | (0x200U == (0x200U 
                                            & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                             | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                            | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                           | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                          | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                         | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                        | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s)))
                        ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                            ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U]
                            : ((0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                    << 0x1cU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                                 >> 4U))
                                : ((0x400U == (0x400U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                    ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                        << 0x18U) | 
                                       (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                        >> 8U)) : (
                                                   (0x800U 
                                                    == 
                                                    (0x800U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                                    ? 
                                                   ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                                     << 0x14U) 
                                                    | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                                       >> 0xcU))
                                                    : 
                                                   ((0x1000U 
                                                     == 
                                                     (0x1000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                                     ? 
                                                    ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                                      << 0x10U) 
                                                     | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                                        >> 0x10U))
                                                     : 
                                                    ((0x2000U 
                                                      == 
                                                      (0x2000U 
                                                       & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                                      ? 
                                                     ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                                       << 0xcU) 
                                                      | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                                         >> 0x14U))
                                                      : 
                                                     ((0x4000U 
                                                       == 
                                                       (0x4000U 
                                                        & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                                       ? 
                                                      ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                                        << 8U) 
                                                       | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                                          >> 0x18U))
                                                       : 
                                                      ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                                        << 4U) 
                                                       | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                                          >> 0x1cU)))))))))
                        : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                            ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U]
                            : ((0x20000U == (0x20000U 
                                             & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                    << 0x1cU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                                 >> 4U))
                                : ((0x40000U == (0x40000U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                    ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                        << 0x18U) | 
                                       (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                        >> 8U)) : (
                                                   (0x80000U 
                                                    == 
                                                    (0x80000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                                    ? 
                                                   ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                                     << 0x14U) 
                                                    | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                                       >> 0xcU))
                                                    : 
                                                   ((0x100000U 
                                                     == 
                                                     (0x100000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                                     ? 
                                                    ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                                      << 0x10U) 
                                                     | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                                        >> 0x10U))
                                                     : 
                                                    ((0x200000U 
                                                      == 
                                                      (0x200000U 
                                                       & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                                      ? 
                                                     ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                                       << 0xcU) 
                                                      | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                                         >> 0x14U))
                                                      : 
                                                     ((0x400000U 
                                                       == 
                                                       (0x400000U 
                                                        & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                                       ? 
                                                      ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                                        << 8U) 
                                                       | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                                          >> 0x18U))
                                                       : 0U))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2253_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__Vfuncout 
        = (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s)) 
                  | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))) 
                 | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))) 
                | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))) 
               | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))) 
              | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))) 
             | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))) 
            | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s)))
            ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))
                ? 0U : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))
                         ? 0U : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))
                                  ? 4U : ((8U == (8U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))
                                           ? 5U : (
                                                   (0x10U 
                                                    == 
                                                    (0x10U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))
                                                    ? 6U
                                                    : 
                                                   ((0x20U 
                                                     == 
                                                     (0x20U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))
                                                     ? 7U
                                                     : 0U))))))
            : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2270_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__Vfuncout;
    vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vtemp_21[0U] = (IData)((((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2178_)) 
                               << 0x3cU) | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2153_)) 
                                             << 0x39U) 
                                            | (((QData)((IData)(
                                                                ((1U 
                                                                  == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                  ? 4U
                                                                  : 3U))) 
                                                << 0x36U) 
                                               | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2115_)) 
                                                   << 0x33U) 
                                                  | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2101_)) 
                                                      << 0x30U) 
                                                     | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2082_)) 
                                                         << 0x2dU) 
                                                        | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2048_)) 
                                                            << 0x2aU) 
                                                           | (((QData)((IData)(
                                                                               ((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U))) 
                                                               << 0x27U) 
                                                              | (((QData)((IData)(
                                                                                ((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U))) 
                                                                  << 0x24U) 
                                                                 | (((QData)((IData)(
                                                                                ((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U))) 
                                                                     << 0x21U) 
                                                                    | (((QData)((IData)(
                                                                                ((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U))) 
                                                                        << 0x1eU) 
                                                                       | (QData)((IData)(
                                                                                (0x2db40U 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1984_) 
                                                                                << 0x1bU) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1962_) 
                                                                                << 0x18U) 
                                                                                | ((((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U) 
                                                                                << 0x15U) 
                                                                                | ((((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U) 
                                                                                << 0x12U) 
                                                                                | (0x3fU 
                                                                                & ((((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U) 
                                                                                << 3U) 
                                                                                | ((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U))))))))))))))))))))));
    __Vtemp_21[1U] = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2205_) 
                       << 0x1fU) | (IData)(((((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2178_)) 
                                              << 0x3cU) 
                                             | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2153_)) 
                                                 << 0x39U) 
                                                | (((QData)((IData)(
                                                                    ((1U 
                                                                      == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                      ? 4U
                                                                      : 3U))) 
                                                    << 0x36U) 
                                                   | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2115_)) 
                                                       << 0x33U) 
                                                      | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2101_)) 
                                                          << 0x30U) 
                                                         | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2082_)) 
                                                             << 0x2dU) 
                                                            | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2048_)) 
                                                                << 0x2aU) 
                                                               | (((QData)((IData)(
                                                                                ((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U))) 
                                                                   << 0x27U) 
                                                                  | (((QData)((IData)(
                                                                                ((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U))) 
                                                                      << 0x24U) 
                                                                     | (((QData)((IData)(
                                                                                ((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U))) 
                                                                         << 0x21U) 
                                                                        | (((QData)((IData)(
                                                                                ((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U))) 
                                                                            << 0x1eU) 
                                                                           | (QData)((IData)(
                                                                                (0x2db40U 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1984_) 
                                                                                << 0x1bU) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1962_) 
                                                                                << 0x18U) 
                                                                                | ((((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U) 
                                                                                << 0x15U) 
                                                                                | ((((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U) 
                                                                                << 0x12U) 
                                                                                | (0x3fU 
                                                                                & ((((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U) 
                                                                                << 3U) 
                                                                                | ((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U))))))))))))))))))))) 
                                            >> 0x20U)));
    vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[0U] 
        = __Vtemp_21[0U];
    vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
        = __Vtemp_21[1U];
    vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[2U] 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2230_) 
            << 2U) | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2205_) 
                      >> 1U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__Vfuncout 
        = (7U & (((((((((1U == (1U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s)) 
                        | (2U == (2U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))) 
                       | (4U == (4U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))) 
                      | (8U == (8U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))) 
                     | (0x10U == (0x10U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))) 
                    | (0x20U == (0x20U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))) 
                   | (0x40U == (0x40U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))) 
                  | (0x80U == (0x80U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s)))
                  ? ((1U == (1U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))
                      ? vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[0U]
                      : ((2U == (2U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))
                          ? ((vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[0U] 
                              << 0x1dU) | (vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[0U] 
                                           >> 3U)) : 
                         ((4U == (4U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))
                           ? ((vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[0U] 
                               << 0x1aU) | (vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[0U] 
                                            >> 6U))
                           : ((8U == (8U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))
                               ? ((vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[0U] 
                                   << 0x17U) | (vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[0U] 
                                                >> 9U))
                               : ((0x10U == (0x10U 
                                             & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))
                                   ? ((vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[0U] 
                                       << 0x14U) | 
                                      (vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[0U] 
                                       >> 0xcU)) : 
                                  ((0x20U == (0x20U 
                                              & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))
                                    ? ((vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[0U] 
                                        << 0x11U) | 
                                       (vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[0U] 
                                        >> 0xfU)) : 
                                   ((0x40U == (0x40U 
                                               & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))
                                     ? ((vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[0U] 
                                         << 0xeU) | 
                                        (vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[0U] 
                                         >> 0x12U))
                                     : ((vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[0U] 
                                         << 0xbU) | 
                                        (vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[0U] 
                                         >> 0x15U)))))))))
                  : (((((((((0x100U == (0x100U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s)) 
                            | (0x200U == (0x200U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))) 
                           | (0x400U == (0x400U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))) 
                          | (0x800U == (0x800U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))) 
                         | (0x1000U == (0x1000U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))) 
                        | (0x2000U == (0x2000U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))) 
                       | (0x4000U == (0x4000U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))) 
                      | (0x8000U == (0x8000U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s)))
                      ? ((0x100U == (0x100U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))
                          ? ((vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[0U] 
                              << 8U) | (vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[0U] 
                                        >> 0x18U)) : 
                         ((0x200U == (0x200U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))
                           ? ((vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[0U] 
                               << 5U) | (vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[0U] 
                                         >> 0x1bU))
                           : ((0x400U == (0x400U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))
                               ? ((vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
                                   << 2U) | (vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[0U] 
                                             >> 0x1eU))
                               : ((0x800U == (0x800U 
                                              & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))
                                   ? ((vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
                                       << 0x1fU) | 
                                      (vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
                                       >> 1U)) : ((0x1000U 
                                                   == 
                                                   (0x1000U 
                                                    & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))
                                                   ? 
                                                  ((vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
                                                    << 0x1cU) 
                                                   | (vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
                                                      >> 4U))
                                                   : 
                                                  ((0x2000U 
                                                    == 
                                                    (0x2000U 
                                                     & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))
                                                    ? 
                                                   ((vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
                                                     << 0x19U) 
                                                    | (vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
                                                       >> 7U))
                                                    : 
                                                   ((0x4000U 
                                                     == 
                                                     (0x4000U 
                                                      & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))
                                                     ? 
                                                    ((vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
                                                      << 0x16U) 
                                                     | (vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
                                                        >> 0xaU))
                                                     : 
                                                    ((vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
                                                      << 0x13U) 
                                                     | (vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
                                                        >> 0xdU)))))))))
                      : ((0x10000U == (0x10000U & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))
                          ? ((vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
                              << 0x10U) | (vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
                                           >> 0x10U))
                          : ((0x20000U == (0x20000U 
                                           & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))
                              ? ((vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
                                  << 0xdU) | (vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
                                              >> 0x13U))
                              : ((0x40000U == (0x40000U 
                                               & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))
                                  ? ((vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
                                      << 0xaU) | (vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
                                                  >> 0x16U))
                                  : ((0x80000U == (0x80000U 
                                                   & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))
                                      ? ((vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
                                          << 7U) | 
                                         (vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
                                          >> 0x19U))
                                      : ((0x100000U 
                                          == (0x100000U 
                                              & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))
                                          ? ((vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
                                              << 4U) 
                                             | (vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
                                                >> 0x1cU))
                                          : ((0x200000U 
                                              == (0x200000U 
                                                  & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))
                                              ? ((vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[2U] 
                                                  << 1U) 
                                                 | (vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
                                                    >> 0x1fU))
                                              : ((0x400000U 
                                                  == 
                                                  (0x400000U 
                                                   & vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s))
                                                  ? 
                                                 ((vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[2U] 
                                                   << 0x1eU) 
                                                  | (vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[2U] 
                                                     >> 2U))
                                                  : 0U))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2250_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1216_ 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1212_) 
           | ((0x76U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | (0x7eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0133_ 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1212_) 
           | (0x7eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)));
    __Vfunc_sdcard__DOT____032687__627__s = (((3U == (IData)(vlSelf->__PVT__sdcard__DOT___45_)) 
                                              << 3U) 
                                             | (((2U 
                                                  == (IData)(vlSelf->__PVT__sdcard__DOT___45_)) 
                                                 << 2U) 
                                                | (((1U 
                                                     == (IData)(vlSelf->__PVT__sdcard__DOT___45_)) 
                                                    << 1U) 
                                                   | (0U 
                                                      == (IData)(vlSelf->__PVT__sdcard__DOT___45_)))));
    __Vfunc_sdcard__DOT____032687__627__b = (8U | (IData)(vlSelf->__PVT__sd_cs_n_s));
    __Vfunc_sdcard__DOT____032687__627__Vfuncout = 
        (1U & ((8U & (IData)(__Vfunc_sdcard__DOT____032687__627__s))
                ? ((4U & (IData)(__Vfunc_sdcard__DOT____032687__627__s))
                    ? ((2U & (IData)(__Vfunc_sdcard__DOT____032687__627__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032687__627__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032687__627__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032687__627__b) 
                               >> 1U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032687__627__s))
                                           ? (IData)(__Vfunc_sdcard__DOT____032687__627__b)
                                           : ((IData)(__Vfunc_sdcard__DOT____032687__627__b) 
                                              >> 2U)))
                    : ((2U & (IData)(__Vfunc_sdcard__DOT____032687__627__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032687__627__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032687__627__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032687__627__b) 
                               >> 1U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032687__627__s))
                                           ? (IData)(__Vfunc_sdcard__DOT____032687__627__b)
                                           : ((IData)(__Vfunc_sdcard__DOT____032687__627__b) 
                                              >> 3U))))
                : ((4U & (IData)(__Vfunc_sdcard__DOT____032687__627__s))
                    ? ((2U & (IData)(__Vfunc_sdcard__DOT____032687__627__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032687__627__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032687__627__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032687__627__b) 
                               >> 1U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032687__627__s))
                                           ? (IData)(__Vfunc_sdcard__DOT____032687__627__b)
                                           : ((IData)(__Vfunc_sdcard__DOT____032687__627__b) 
                                              >> 2U)))
                    : ((2U & (IData)(__Vfunc_sdcard__DOT____032687__627__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032687__627__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032687__627__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032687__627__b) 
                               >> 1U)) : ((IData)(__Vfunc_sdcard__DOT____032687__627__s) 
                                          & (IData)(__Vfunc_sdcard__DOT____032687__627__b))))));
    vlSelf->__PVT__sdcard__DOT___20_ = __Vfunc_sdcard__DOT____032687__627__Vfuncout;
    __Vfunc_sdcard__DOT____032676__623__s = (((3U == (IData)(vlSelf->__PVT__sdcard__DOT___45_)) 
                                              << 3U) 
                                             | (((2U 
                                                  == (IData)(vlSelf->__PVT__sdcard__DOT___45_)) 
                                                 << 2U) 
                                                | (((1U 
                                                     == (IData)(vlSelf->__PVT__sdcard__DOT___45_)) 
                                                    << 1U) 
                                                   | (0U 
                                                      == (IData)(vlSelf->__PVT__sdcard__DOT___45_)))));
    __Vfunc_sdcard__DOT____032676__623__b = (8U | (
                                                   (((IData)(vlSelf->__PVT__sd_cs_n_s)
                                                      ? 0U
                                                      : (IData)(vlSelf->__PVT__sdcard__DOT___45_)) 
                                                    << 6U) 
                                                   | ((((0U 
                                                         == (IData)(vlSelf->__PVT__sdcard__DOT___47_))
                                                         ? 3U
                                                         : 1U) 
                                                       << 4U) 
                                                      | ((IData)(vlSelf->__PVT__sd_cs_n_s)
                                                          ? (IData)(vlSelf->__PVT__sdcard__DOT___45_)
                                                          : 1U))));
    __Vfunc_sdcard__DOT____032676__623__Vfuncout = 
        (3U & ((8U & (IData)(__Vfunc_sdcard__DOT____032676__623__s))
                ? ((4U & (IData)(__Vfunc_sdcard__DOT____032676__623__s))
                    ? ((2U & (IData)(__Vfunc_sdcard__DOT____032676__623__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032676__623__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032676__623__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032676__623__b) 
                               >> 2U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032676__623__s))
                                           ? (IData)(__Vfunc_sdcard__DOT____032676__623__b)
                                           : ((IData)(__Vfunc_sdcard__DOT____032676__623__b) 
                                              >> 4U)))
                    : ((2U & (IData)(__Vfunc_sdcard__DOT____032676__623__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032676__623__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032676__623__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032676__623__b) 
                               >> 2U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032676__623__s))
                                           ? (IData)(__Vfunc_sdcard__DOT____032676__623__b)
                                           : ((IData)(__Vfunc_sdcard__DOT____032676__623__b) 
                                              >> 6U))))
                : ((4U & (IData)(__Vfunc_sdcard__DOT____032676__623__s))
                    ? ((2U & (IData)(__Vfunc_sdcard__DOT____032676__623__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032676__623__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032676__623__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032676__623__b) 
                               >> 2U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032676__623__s))
                                           ? (IData)(__Vfunc_sdcard__DOT____032676__623__b)
                                           : ((IData)(__Vfunc_sdcard__DOT____032676__623__b) 
                                              >> 4U)))
                    : ((2U & (IData)(__Vfunc_sdcard__DOT____032676__623__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032676__623__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032676__623__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032676__623__b) 
                               >> 2U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032676__623__s))
                                           ? (IData)(__Vfunc_sdcard__DOT____032676__623__b)
                                           : 0U)))));
    vlSelf->__PVT__sdcard__DOT___16_ = __Vfunc_sdcard__DOT____032676__623__Vfuncout;
    __Vfunc_sdcard__DOT____032680__625__s = (((3U == (IData)(vlSelf->__PVT__sdcard__DOT___45_)) 
                                              << 3U) 
                                             | (((2U 
                                                  == (IData)(vlSelf->__PVT__sdcard__DOT___45_)) 
                                                 << 2U) 
                                                | (((1U 
                                                     == (IData)(vlSelf->__PVT__sdcard__DOT___45_)) 
                                                    << 1U) 
                                                   | (0U 
                                                      == (IData)(vlSelf->__PVT__sdcard__DOT___45_)))));
    __Vfunc_sdcard__DOT____032680__625__b = (((IData)(vlSelf->__PVT__sdcard__DOT___47_) 
                                              << 9U) 
                                             | ((0x1c0U 
                                                 & (((IData)(vlSelf->__PVT__sdcard__DOT___47_) 
                                                     - (IData)(1U)) 
                                                    << 6U)) 
                                                | (((IData)(vlSelf->__PVT__sdcard__DOT___47_) 
                                                    << 3U) 
                                                   | ((IData)(vlSelf->__PVT__sd_cs_n_s)
                                                       ? (IData)(vlSelf->__PVT__sdcard__DOT___47_)
                                                       : 7U))));
    __Vfunc_sdcard__DOT____032680__625__Vfuncout = 
        (7U & ((8U & (IData)(__Vfunc_sdcard__DOT____032680__625__s))
                ? ((4U & (IData)(__Vfunc_sdcard__DOT____032680__625__s))
                    ? ((2U & (IData)(__Vfunc_sdcard__DOT____032680__625__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032680__625__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032680__625__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032680__625__b) 
                               >> 3U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032680__625__s))
                                           ? (IData)(__Vfunc_sdcard__DOT____032680__625__b)
                                           : ((IData)(__Vfunc_sdcard__DOT____032680__625__b) 
                                              >> 6U)))
                    : ((2U & (IData)(__Vfunc_sdcard__DOT____032680__625__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032680__625__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032680__625__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032680__625__b) 
                               >> 3U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032680__625__s))
                                           ? (IData)(__Vfunc_sdcard__DOT____032680__625__b)
                                           : ((IData)(__Vfunc_sdcard__DOT____032680__625__b) 
                                              >> 9U))))
                : ((4U & (IData)(__Vfunc_sdcard__DOT____032680__625__s))
                    ? ((2U & (IData)(__Vfunc_sdcard__DOT____032680__625__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032680__625__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032680__625__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032680__625__b) 
                               >> 3U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032680__625__s))
                                           ? (IData)(__Vfunc_sdcard__DOT____032680__625__b)
                                           : ((IData)(__Vfunc_sdcard__DOT____032680__625__b) 
                                              >> 6U)))
                    : ((2U & (IData)(__Vfunc_sdcard__DOT____032680__625__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032680__625__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032680__625__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032680__625__b) 
                               >> 3U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032680__625__s))
                                           ? (IData)(__Vfunc_sdcard__DOT____032680__625__b)
                                           : 0U)))));
    vlSelf->__PVT__sdcard__DOT___18_ = __Vfunc_sdcard__DOT____032680__625__Vfuncout;
    __Vfunc_sdcard__DOT____032678__624__s = (((3U == (IData)(vlSelf->__PVT__sdcard__DOT___45_)) 
                                              << 3U) 
                                             | (((2U 
                                                  == (IData)(vlSelf->__PVT__sdcard__DOT___45_)) 
                                                 << 2U) 
                                                | (((1U 
                                                     == (IData)(vlSelf->__PVT__sdcard__DOT___45_)) 
                                                    << 1U) 
                                                   | (0U 
                                                      == (IData)(vlSelf->__PVT__sdcard__DOT___45_)))));
    __Vfunc_sdcard__DOT____032678__624__b = (((IData)(vlSelf->__PVT__sdcard__DOT___46_) 
                                              << 0x18U) 
                                             | ((0xfe0000U 
                                                 & ((IData)(vlSelf->__PVT__sdcard__DOT___46_) 
                                                    << 0x11U)) 
                                                | (((IData)(vlSelf->__PVT__sdcard__DOT___48_) 
                                                    << 0x10U) 
                                                   | (((IData)(vlSelf->__PVT__sdcard__DOT___46_) 
                                                       << 8U) 
                                                      | ((IData)(vlSelf->__PVT__sd_cs_n_s)
                                                          ? (IData)(vlSelf->__PVT__sdcard__DOT___46_)
                                                          : 
                                                         ((IData)(vlSelf->__PVT__inst_t80__DOT___63_)
                                                           ? 0xffU
                                                           : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_)))))));
    __Vfunc_sdcard__DOT____032678__624__Vfuncout = 
        (0xffU & ((8U & (IData)(__Vfunc_sdcard__DOT____032678__624__s))
                   ? ((4U & (IData)(__Vfunc_sdcard__DOT____032678__624__s))
                       ? ((2U & (IData)(__Vfunc_sdcard__DOT____032678__624__s))
                           ? ((1U & (IData)(__Vfunc_sdcard__DOT____032678__624__s))
                               ? __Vfunc_sdcard__DOT____032678__624__b
                               : (__Vfunc_sdcard__DOT____032678__624__b 
                                  >> 8U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032678__624__s))
                                              ? __Vfunc_sdcard__DOT____032678__624__b
                                              : (__Vfunc_sdcard__DOT____032678__624__b 
                                                 >> 0x10U)))
                       : ((2U & (IData)(__Vfunc_sdcard__DOT____032678__624__s))
                           ? ((1U & (IData)(__Vfunc_sdcard__DOT____032678__624__s))
                               ? __Vfunc_sdcard__DOT____032678__624__b
                               : (__Vfunc_sdcard__DOT____032678__624__b 
                                  >> 8U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032678__624__s))
                                              ? __Vfunc_sdcard__DOT____032678__624__b
                                              : (__Vfunc_sdcard__DOT____032678__624__b 
                                                 >> 0x18U))))
                   : ((4U & (IData)(__Vfunc_sdcard__DOT____032678__624__s))
                       ? ((2U & (IData)(__Vfunc_sdcard__DOT____032678__624__s))
                           ? ((1U & (IData)(__Vfunc_sdcard__DOT____032678__624__s))
                               ? __Vfunc_sdcard__DOT____032678__624__b
                               : (__Vfunc_sdcard__DOT____032678__624__b 
                                  >> 8U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032678__624__s))
                                              ? __Vfunc_sdcard__DOT____032678__624__b
                                              : (__Vfunc_sdcard__DOT____032678__624__b 
                                                 >> 0x10U)))
                       : ((2U & (IData)(__Vfunc_sdcard__DOT____032678__624__s))
                           ? ((1U & (IData)(__Vfunc_sdcard__DOT____032678__624__s))
                               ? __Vfunc_sdcard__DOT____032678__624__b
                               : (__Vfunc_sdcard__DOT____032678__624__b 
                                  >> 8U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032678__624__s))
                                              ? __Vfunc_sdcard__DOT____032678__624__b
                                              : 0U)))));
    vlSelf->__PVT__sdcard__DOT___17_ = __Vfunc_sdcard__DOT____032678__624__Vfuncout;
    __Vfunc_sdcard__DOT____032698__629__s = (((3U == (IData)(vlSelf->__PVT__sdcard__DOT___45_)) 
                                              << 3U) 
                                             | (((2U 
                                                  == (IData)(vlSelf->__PVT__sdcard__DOT___45_)) 
                                                 << 2U) 
                                                | (((1U 
                                                     == (IData)(vlSelf->__PVT__sdcard__DOT___45_)) 
                                                    << 1U) 
                                                   | (0U 
                                                      == (IData)(vlSelf->__PVT__sdcard__DOT___45_)))));
    __Vfunc_sdcard__DOT____032698__629__b = (6U | (1U 
                                                   & (~ (IData)(vlSelf->__PVT__sd_cs_n_s))));
    __Vfunc_sdcard__DOT____032698__629__Vfuncout = 
        (1U & ((8U & (IData)(__Vfunc_sdcard__DOT____032698__629__s))
                ? ((4U & (IData)(__Vfunc_sdcard__DOT____032698__629__s))
                    ? ((2U & (IData)(__Vfunc_sdcard__DOT____032698__629__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032698__629__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032698__629__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032698__629__b) 
                               >> 1U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032698__629__s))
                                           ? (IData)(__Vfunc_sdcard__DOT____032698__629__b)
                                           : ((IData)(__Vfunc_sdcard__DOT____032698__629__b) 
                                              >> 2U)))
                    : ((2U & (IData)(__Vfunc_sdcard__DOT____032698__629__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032698__629__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032698__629__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032698__629__b) 
                               >> 1U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032698__629__s))
                                           ? (IData)(__Vfunc_sdcard__DOT____032698__629__b)
                                           : ((IData)(__Vfunc_sdcard__DOT____032698__629__b) 
                                              >> 3U))))
                : ((4U & (IData)(__Vfunc_sdcard__DOT____032698__629__s))
                    ? ((2U & (IData)(__Vfunc_sdcard__DOT____032698__629__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032698__629__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032698__629__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032698__629__b) 
                               >> 1U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032698__629__s))
                                           ? (IData)(__Vfunc_sdcard__DOT____032698__629__b)
                                           : ((IData)(__Vfunc_sdcard__DOT____032698__629__b) 
                                              >> 2U)))
                    : ((2U & (IData)(__Vfunc_sdcard__DOT____032698__629__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032698__629__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032698__629__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032698__629__b) 
                               >> 1U)) : ((IData)(__Vfunc_sdcard__DOT____032698__629__s) 
                                          & (IData)(__Vfunc_sdcard__DOT____032698__629__b))))));
    vlSelf->__PVT__sdcard__DOT___22_ = __Vfunc_sdcard__DOT____032698__629__Vfuncout;
    if (vlSelf->__PVT__cache__DOT__fill_on) {
        vlSelf->__PVT__ext512_we_n_s = (1U & (IData)(vlSelf->__PVT___024_));
        vlSelf->__PVT__ext512_en_s = vlSelf->__PVT___022_;
    } else {
        vlSelf->__PVT__ext512_we_n_s = (1U & ((~ (IData)(vlSelf->__PVT___043_)) 
                                              | (IData)(__PVT___110_)));
        vlSelf->__PVT__ext512_en_s = vlSelf->__PVT__ext_ram_en_s;
    }
    __Vfunc___03701__39__s = (((0xeU == (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                               << 0xcU) | (((0xbU == 
                                             (0xfU 
                                              & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                            << 0xbU) 
                                           | (((0xaU 
                                                == 
                                                (0xfU 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                               << 0xaU) 
                                              | (((9U 
                                                   == 
                                                   (0xfU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                  << 9U) 
                                                 | (((8U 
                                                      == 
                                                      (0xfU 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                     << 8U) 
                                                    | (((7U 
                                                         == 
                                                         (0xfU 
                                                          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                        << 7U) 
                                                       | (((6U 
                                                            == 
                                                            (0xfU 
                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                           << 6U) 
                                                          | (((5U 
                                                               == 
                                                               (0xfU 
                                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                              << 5U) 
                                                             | (((4U 
                                                                  == 
                                                                  (0xfU 
                                                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                 << 4U) 
                                                                | (((3U 
                                                                     == 
                                                                     (0xfU 
                                                                      & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                    << 3U) 
                                                                   | (((2U 
                                                                        == 
                                                                        (0xfU 
                                                                         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                       << 2U) 
                                                                      | (((1U 
                                                                           == 
                                                                           (0xfU 
                                                                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                          << 1U) 
                                                                         | (0U 
                                                                            == 
                                                                            (0xfU 
                                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))))))))))))));
    __Vtemp_24[1U] = ((0xffU & ((IData)(vlSelf->__PVT___212_)
                                 ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_)
                                 : (IData)(vlSelf->__PVT___176_))) 
                      | ((IData)((((QData)((IData)(vlSelf->__PVT___176_)) 
                                   << 0x38U) | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                                 << 0x30U) 
                                                | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                                    << 0x28U) 
                                                   | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                                       << 0x20U) 
                                                      | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                                          << 0x18U) 
                                                         | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                                             << 0x10U) 
                                                            | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                                                << 8U) 
                                                               | (QData)((IData)(vlSelf->__PVT___176_)))))))))) 
                         << 8U));
    __Vtemp_24[2U] = (((IData)((((QData)((IData)(vlSelf->__PVT___176_)) 
                                 << 0x38U) | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                               << 0x30U) 
                                              | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                                  << 0x28U) 
                                                 | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                                     << 0x20U) 
                                                    | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                                        << 0x18U) 
                                                       | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                                           << 0x10U) 
                                                          | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                                              << 8U) 
                                                             | (QData)((IData)(vlSelf->__PVT___176_)))))))))) 
                       >> 0x18U) | ((IData)(((((QData)((IData)(vlSelf->__PVT___176_)) 
                                               << 0x38U) 
                                              | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                                  << 0x30U) 
                                                 | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                                     << 0x28U) 
                                                    | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                                        << 0x20U) 
                                                       | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                                           << 0x18U) 
                                                          | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                                              << 0x10U) 
                                                             | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                                                 << 8U) 
                                                                | (QData)((IData)(vlSelf->__PVT___176_))))))))) 
                                             >> 0x20U)) 
                                    << 8U));
    __Vfunc___03701__39__b[0U] = ((0xffffff00U & (((IData)(vlSelf->__PVT___176_) 
                                                   << 0x18U) 
                                                  | (((IData)(vlSelf->__PVT___176_) 
                                                      << 0x10U) 
                                                     | ((IData)(vlSelf->__PVT___176_) 
                                                        << 8U)))) 
                                  | (IData)(vlSelf->__PVT___176_));
    __Vfunc___03701__39__b[1U] = __Vtemp_24[1U];
    __Vfunc___03701__39__b[2U] = __Vtemp_24[2U];
    __Vfunc___03701__39__b[3U] = ((IData)(((((QData)((IData)(vlSelf->__PVT___176_)) 
                                             << 0x38U) 
                                            | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                                << 0x30U) 
                                               | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                                   << 0x28U) 
                                                  | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                                      << 0x20U) 
                                                     | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                                         << 0x18U) 
                                                        | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                                            << 0x10U) 
                                                           | (((QData)((IData)(vlSelf->__PVT___176_)) 
                                                               << 8U) 
                                                              | (QData)((IData)(vlSelf->__PVT___176_))))))))) 
                                           >> 0x20U)) 
                                  >> 0x18U);
    __Vfunc___03701__39__a = vlSelf->__PVT___176_;
    __Vfunc___03701__39__Vfuncout = (0xffU & ((((((
                                                   (((1U 
                                                      == 
                                                      (1U 
                                                       & (IData)(__Vfunc___03701__39__s))) 
                                                     | (2U 
                                                        == 
                                                        (2U 
                                                         & (IData)(__Vfunc___03701__39__s)))) 
                                                    | (4U 
                                                       == 
                                                       (4U 
                                                        & (IData)(__Vfunc___03701__39__s)))) 
                                                   | (8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03701__39__s)))) 
                                                  | (0x10U 
                                                     == 
                                                     (0x10U 
                                                      & (IData)(__Vfunc___03701__39__s)))) 
                                                 | (0x20U 
                                                    == 
                                                    (0x20U 
                                                     & (IData)(__Vfunc___03701__39__s)))) 
                                                | (0x40U 
                                                   == 
                                                   (0x40U 
                                                    & (IData)(__Vfunc___03701__39__s)))) 
                                               | (0x80U 
                                                  == 
                                                  (0x80U 
                                                   & (IData)(__Vfunc___03701__39__s))))
                                               ? ((1U 
                                                   == 
                                                   (1U 
                                                    & (IData)(__Vfunc___03701__39__s)))
                                                   ? 
                                                  __Vfunc___03701__39__b[0U]
                                                   : 
                                                  ((2U 
                                                    == 
                                                    (2U 
                                                     & (IData)(__Vfunc___03701__39__s)))
                                                    ? 
                                                   ((__Vfunc___03701__39__b[0U] 
                                                     << 0x18U) 
                                                    | (__Vfunc___03701__39__b[0U] 
                                                       >> 8U))
                                                    : 
                                                   ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03701__39__s)))
                                                     ? 
                                                    ((__Vfunc___03701__39__b[0U] 
                                                      << 0x10U) 
                                                     | (__Vfunc___03701__39__b[0U] 
                                                        >> 0x10U))
                                                     : 
                                                    ((8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03701__39__s)))
                                                      ? 
                                                     ((__Vfunc___03701__39__b[0U] 
                                                       << 8U) 
                                                      | (__Vfunc___03701__39__b[0U] 
                                                         >> 0x18U))
                                                      : 
                                                     ((0x10U 
                                                       == 
                                                       (0x10U 
                                                        & (IData)(__Vfunc___03701__39__s)))
                                                       ? 
                                                      __Vfunc___03701__39__b[1U]
                                                       : 
                                                      ((0x20U 
                                                        == 
                                                        (0x20U 
                                                         & (IData)(__Vfunc___03701__39__s)))
                                                        ? 
                                                       ((__Vfunc___03701__39__b[1U] 
                                                         << 0x18U) 
                                                        | (__Vfunc___03701__39__b[1U] 
                                                           >> 8U))
                                                        : 
                                                       ((0x40U 
                                                         == 
                                                         (0x40U 
                                                          & (IData)(__Vfunc___03701__39__s)))
                                                         ? 
                                                        ((__Vfunc___03701__39__b[1U] 
                                                          << 0x10U) 
                                                         | (__Vfunc___03701__39__b[1U] 
                                                            >> 0x10U))
                                                         : 
                                                        ((__Vfunc___03701__39__b[1U] 
                                                          << 8U) 
                                                         | (__Vfunc___03701__39__b[1U] 
                                                            >> 0x18U)))))))))
                                               : ((0x100U 
                                                   == 
                                                   (0x100U 
                                                    & (IData)(__Vfunc___03701__39__s)))
                                                   ? 
                                                  __Vfunc___03701__39__b[2U]
                                                   : 
                                                  ((0x200U 
                                                    == 
                                                    (0x200U 
                                                     & (IData)(__Vfunc___03701__39__s)))
                                                    ? 
                                                   ((__Vfunc___03701__39__b[2U] 
                                                     << 0x18U) 
                                                    | (__Vfunc___03701__39__b[2U] 
                                                       >> 8U))
                                                    : 
                                                   ((0x400U 
                                                     == 
                                                     (0x400U 
                                                      & (IData)(__Vfunc___03701__39__s)))
                                                     ? 
                                                    ((__Vfunc___03701__39__b[2U] 
                                                      << 0x10U) 
                                                     | (__Vfunc___03701__39__b[2U] 
                                                        >> 0x10U))
                                                     : 
                                                    ((0x800U 
                                                      == 
                                                      (0x800U 
                                                       & (IData)(__Vfunc___03701__39__s)))
                                                      ? 
                                                     ((__Vfunc___03701__39__b[2U] 
                                                       << 8U) 
                                                      | (__Vfunc___03701__39__b[2U] 
                                                         >> 0x18U))
                                                      : 
                                                     ((0x1000U 
                                                       == 
                                                       (0x1000U 
                                                        & (IData)(__Vfunc___03701__39__s)))
                                                       ? 
                                                      __Vfunc___03701__39__b[3U]
                                                       : (IData)(__Vfunc___03701__39__a))))))));
    vlSelf->__PVT___279_ = __Vfunc___03701__39__Vfuncout;
    __Vfunc___03702__40__s = (((0xeU == (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                               << 0xcU) | (((0xbU == 
                                             (0xfU 
                                              & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                            << 0xbU) 
                                           | (((0xaU 
                                                == 
                                                (0xfU 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                               << 0xaU) 
                                              | (((9U 
                                                   == 
                                                   (0xfU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                  << 9U) 
                                                 | (((8U 
                                                      == 
                                                      (0xfU 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                     << 8U) 
                                                    | (((7U 
                                                         == 
                                                         (0xfU 
                                                          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                        << 7U) 
                                                       | (((6U 
                                                            == 
                                                            (0xfU 
                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                           << 6U) 
                                                          | (((5U 
                                                               == 
                                                               (0xfU 
                                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                              << 5U) 
                                                             | (((4U 
                                                                  == 
                                                                  (0xfU 
                                                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                 << 4U) 
                                                                | (((3U 
                                                                     == 
                                                                     (0xfU 
                                                                      & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                    << 3U) 
                                                                   | (((2U 
                                                                        == 
                                                                        (0xfU 
                                                                         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                       << 2U) 
                                                                      | (((1U 
                                                                           == 
                                                                           (0xfU 
                                                                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                          << 1U) 
                                                                         | (0U 
                                                                            == 
                                                                            (0xfU 
                                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))))))))))))));
    __Vtemp_26[2U] = (((IData)((((QData)((IData)(((0xffff0000U 
                                                   & (((IData)(vlSelf->__PVT___177_) 
                                                       << 0x18U) 
                                                      | ((IData)(vlSelf->__PVT___177_) 
                                                         << 0x10U))) 
                                                  | ((((IData)(vlSelf->__PVT__inst_t80__DOT___63_)
                                                        ? (IData)(vlSelf->__PVT___177_)
                                                        : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_)) 
                                                      << 8U) 
                                                     | (IData)(vlSelf->__PVT___177_))))) 
                                 << 0x20U) | (QData)((IData)(
                                                             (((IData)(vlSelf->__PVT___177_) 
                                                               << 0x18U) 
                                                              | (((IData)(vlSelf->__PVT___177_) 
                                                                  << 0x10U) 
                                                                 | (((IData)(vlSelf->__PVT___177_) 
                                                                     << 8U) 
                                                                    | (IData)(vlSelf->__PVT___177_)))))))) 
                       >> 0x18U) | ((IData)(((((QData)((IData)(
                                                               ((0xffff0000U 
                                                                 & (((IData)(vlSelf->__PVT___177_) 
                                                                     << 0x18U) 
                                                                    | ((IData)(vlSelf->__PVT___177_) 
                                                                       << 0x10U))) 
                                                                | ((((IData)(vlSelf->__PVT__inst_t80__DOT___63_)
                                                                      ? (IData)(vlSelf->__PVT___177_)
                                                                      : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_)) 
                                                                    << 8U) 
                                                                   | (IData)(vlSelf->__PVT___177_))))) 
                                               << 0x20U) 
                                              | (QData)((IData)(
                                                                (((IData)(vlSelf->__PVT___177_) 
                                                                  << 0x18U) 
                                                                 | (((IData)(vlSelf->__PVT___177_) 
                                                                     << 0x10U) 
                                                                    | (((IData)(vlSelf->__PVT___177_) 
                                                                        << 8U) 
                                                                       | (IData)(vlSelf->__PVT___177_))))))) 
                                             >> 0x20U)) 
                                    << 8U));
    __Vfunc___03702__40__b[0U] = ((((IData)(vlSelf->__PVT___177_) 
                                    << 0x18U) | (((IData)(vlSelf->__PVT___177_) 
                                                  << 0x10U) 
                                                 | ((IData)(vlSelf->__PVT___177_) 
                                                    << 8U))) 
                                  | (IData)(vlSelf->__PVT___177_));
    __Vfunc___03702__40__b[1U] = (((0xffU & (IData)(vlSelf->__PVT___177_)) 
                                   | ((0xffU & ((IData)(vlSelf->__PVT___177_) 
                                                >> 8U)) 
                                      | ((0xffU & ((IData)(vlSelf->__PVT___177_) 
                                                   >> 0x10U)) 
                                         | ((IData)(vlSelf->__PVT___177_) 
                                            >> 0x18U)))) 
                                  | ((IData)((((QData)((IData)(
                                                               ((0xffff0000U 
                                                                 & (((IData)(vlSelf->__PVT___177_) 
                                                                     << 0x18U) 
                                                                    | ((IData)(vlSelf->__PVT___177_) 
                                                                       << 0x10U))) 
                                                                | ((((IData)(vlSelf->__PVT__inst_t80__DOT___63_)
                                                                      ? (IData)(vlSelf->__PVT___177_)
                                                                      : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_)) 
                                                                    << 8U) 
                                                                   | (IData)(vlSelf->__PVT___177_))))) 
                                               << 0x20U) 
                                              | (QData)((IData)(
                                                                (((IData)(vlSelf->__PVT___177_) 
                                                                  << 0x18U) 
                                                                 | (((IData)(vlSelf->__PVT___177_) 
                                                                     << 0x10U) 
                                                                    | (((IData)(vlSelf->__PVT___177_) 
                                                                        << 8U) 
                                                                       | (IData)(vlSelf->__PVT___177_)))))))) 
                                     << 8U));
    __Vfunc___03702__40__b[2U] = __Vtemp_26[2U];
    __Vfunc___03702__40__b[3U] = ((IData)(((((QData)((IData)(
                                                             ((0xffff0000U 
                                                               & (((IData)(vlSelf->__PVT___177_) 
                                                                   << 0x18U) 
                                                                  | ((IData)(vlSelf->__PVT___177_) 
                                                                     << 0x10U))) 
                                                              | ((((IData)(vlSelf->__PVT__inst_t80__DOT___63_)
                                                                    ? (IData)(vlSelf->__PVT___177_)
                                                                    : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_)) 
                                                                  << 8U) 
                                                                 | (IData)(vlSelf->__PVT___177_))))) 
                                             << 0x20U) 
                                            | (QData)((IData)(
                                                              (((IData)(vlSelf->__PVT___177_) 
                                                                << 0x18U) 
                                                               | (((IData)(vlSelf->__PVT___177_) 
                                                                   << 0x10U) 
                                                                  | (((IData)(vlSelf->__PVT___177_) 
                                                                      << 8U) 
                                                                     | (IData)(vlSelf->__PVT___177_))))))) 
                                           >> 0x20U)) 
                                  >> 0x18U);
    __Vfunc___03702__40__a = vlSelf->__PVT___177_;
    __Vfunc___03702__40__Vfuncout = (0xffU & ((((((
                                                   (((1U 
                                                      == 
                                                      (1U 
                                                       & (IData)(__Vfunc___03702__40__s))) 
                                                     | (2U 
                                                        == 
                                                        (2U 
                                                         & (IData)(__Vfunc___03702__40__s)))) 
                                                    | (4U 
                                                       == 
                                                       (4U 
                                                        & (IData)(__Vfunc___03702__40__s)))) 
                                                   | (8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03702__40__s)))) 
                                                  | (0x10U 
                                                     == 
                                                     (0x10U 
                                                      & (IData)(__Vfunc___03702__40__s)))) 
                                                 | (0x20U 
                                                    == 
                                                    (0x20U 
                                                     & (IData)(__Vfunc___03702__40__s)))) 
                                                | (0x40U 
                                                   == 
                                                   (0x40U 
                                                    & (IData)(__Vfunc___03702__40__s)))) 
                                               | (0x80U 
                                                  == 
                                                  (0x80U 
                                                   & (IData)(__Vfunc___03702__40__s))))
                                               ? ((1U 
                                                   == 
                                                   (1U 
                                                    & (IData)(__Vfunc___03702__40__s)))
                                                   ? 
                                                  __Vfunc___03702__40__b[0U]
                                                   : 
                                                  ((2U 
                                                    == 
                                                    (2U 
                                                     & (IData)(__Vfunc___03702__40__s)))
                                                    ? 
                                                   ((__Vfunc___03702__40__b[0U] 
                                                     << 0x18U) 
                                                    | (__Vfunc___03702__40__b[0U] 
                                                       >> 8U))
                                                    : 
                                                   ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03702__40__s)))
                                                     ? 
                                                    ((__Vfunc___03702__40__b[0U] 
                                                      << 0x10U) 
                                                     | (__Vfunc___03702__40__b[0U] 
                                                        >> 0x10U))
                                                     : 
                                                    ((8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03702__40__s)))
                                                      ? 
                                                     ((__Vfunc___03702__40__b[0U] 
                                                       << 8U) 
                                                      | (__Vfunc___03702__40__b[0U] 
                                                         >> 0x18U))
                                                      : 
                                                     ((0x10U 
                                                       == 
                                                       (0x10U 
                                                        & (IData)(__Vfunc___03702__40__s)))
                                                       ? 
                                                      __Vfunc___03702__40__b[1U]
                                                       : 
                                                      ((0x20U 
                                                        == 
                                                        (0x20U 
                                                         & (IData)(__Vfunc___03702__40__s)))
                                                        ? 
                                                       ((__Vfunc___03702__40__b[1U] 
                                                         << 0x18U) 
                                                        | (__Vfunc___03702__40__b[1U] 
                                                           >> 8U))
                                                        : 
                                                       ((0x40U 
                                                         == 
                                                         (0x40U 
                                                          & (IData)(__Vfunc___03702__40__s)))
                                                         ? 
                                                        ((__Vfunc___03702__40__b[1U] 
                                                          << 0x10U) 
                                                         | (__Vfunc___03702__40__b[1U] 
                                                            >> 0x10U))
                                                         : 
                                                        ((__Vfunc___03702__40__b[1U] 
                                                          << 8U) 
                                                         | (__Vfunc___03702__40__b[1U] 
                                                            >> 0x18U)))))))))
                                               : ((0x100U 
                                                   == 
                                                   (0x100U 
                                                    & (IData)(__Vfunc___03702__40__s)))
                                                   ? 
                                                  __Vfunc___03702__40__b[2U]
                                                   : 
                                                  ((0x200U 
                                                    == 
                                                    (0x200U 
                                                     & (IData)(__Vfunc___03702__40__s)))
                                                    ? 
                                                   ((__Vfunc___03702__40__b[2U] 
                                                     << 0x18U) 
                                                    | (__Vfunc___03702__40__b[2U] 
                                                       >> 8U))
                                                    : 
                                                   ((0x400U 
                                                     == 
                                                     (0x400U 
                                                      & (IData)(__Vfunc___03702__40__s)))
                                                     ? 
                                                    ((__Vfunc___03702__40__b[2U] 
                                                      << 0x10U) 
                                                     | (__Vfunc___03702__40__b[2U] 
                                                        >> 0x10U))
                                                     : 
                                                    ((0x800U 
                                                      == 
                                                      (0x800U 
                                                       & (IData)(__Vfunc___03702__40__s)))
                                                      ? 
                                                     ((__Vfunc___03702__40__b[2U] 
                                                       << 8U) 
                                                      | (__Vfunc___03702__40__b[2U] 
                                                         >> 0x18U))
                                                      : 
                                                     ((0x1000U 
                                                       == 
                                                       (0x1000U 
                                                        & (IData)(__Vfunc___03702__40__s)))
                                                       ? 
                                                      __Vfunc___03702__40__b[3U]
                                                       : (IData)(__Vfunc___03702__40__a))))))));
    vlSelf->__PVT___280_ = __Vfunc___03702__40__Vfuncout;
    __Vfunc___03703__41__s = (((0xeU == (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                               << 0xcU) | (((0xbU == 
                                             (0xfU 
                                              & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                            << 0xbU) 
                                           | (((0xaU 
                                                == 
                                                (0xfU 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                               << 0xaU) 
                                              | (((9U 
                                                   == 
                                                   (0xfU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                  << 9U) 
                                                 | (((8U 
                                                      == 
                                                      (0xfU 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                     << 8U) 
                                                    | (((7U 
                                                         == 
                                                         (0xfU 
                                                          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                        << 7U) 
                                                       | (((6U 
                                                            == 
                                                            (0xfU 
                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                           << 6U) 
                                                          | (((5U 
                                                               == 
                                                               (0xfU 
                                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                              << 5U) 
                                                             | (((4U 
                                                                  == 
                                                                  (0xfU 
                                                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                 << 4U) 
                                                                | (((3U 
                                                                     == 
                                                                     (0xfU 
                                                                      & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                    << 3U) 
                                                                   | (((2U 
                                                                        == 
                                                                        (0xfU 
                                                                         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                       << 2U) 
                                                                      | (((1U 
                                                                           == 
                                                                           (0xfU 
                                                                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                          << 1U) 
                                                                         | (0U 
                                                                            == 
                                                                            (0xfU 
                                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))))))))))))));
    __Vtemp_28[2U] = (((IData)((((QData)((IData)((((IData)(vlSelf->__PVT___179_) 
                                                   << 0x18U) 
                                                  | ((((IData)(vlSelf->__PVT__inst_t80__DOT___63_)
                                                        ? (IData)(vlSelf->__PVT___179_)
                                                        : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_)) 
                                                      << 0x10U) 
                                                     | (0xffffU 
                                                        & (((IData)(vlSelf->__PVT___179_) 
                                                            << 8U) 
                                                           | (IData)(vlSelf->__PVT___179_))))))) 
                                 << 0x20U) | (QData)((IData)(
                                                             (((IData)(vlSelf->__PVT___179_) 
                                                               << 0x18U) 
                                                              | (((IData)(vlSelf->__PVT___179_) 
                                                                  << 0x10U) 
                                                                 | (((IData)(vlSelf->__PVT___179_) 
                                                                     << 8U) 
                                                                    | (IData)(vlSelf->__PVT___179_)))))))) 
                       >> 0x18U) | ((IData)(((((QData)((IData)(
                                                               (((IData)(vlSelf->__PVT___179_) 
                                                                 << 0x18U) 
                                                                | ((((IData)(vlSelf->__PVT__inst_t80__DOT___63_)
                                                                      ? (IData)(vlSelf->__PVT___179_)
                                                                      : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_)) 
                                                                    << 0x10U) 
                                                                   | (0xffffU 
                                                                      & (((IData)(vlSelf->__PVT___179_) 
                                                                          << 8U) 
                                                                         | (IData)(vlSelf->__PVT___179_))))))) 
                                               << 0x20U) 
                                              | (QData)((IData)(
                                                                (((IData)(vlSelf->__PVT___179_) 
                                                                  << 0x18U) 
                                                                 | (((IData)(vlSelf->__PVT___179_) 
                                                                     << 0x10U) 
                                                                    | (((IData)(vlSelf->__PVT___179_) 
                                                                        << 8U) 
                                                                       | (IData)(vlSelf->__PVT___179_))))))) 
                                             >> 0x20U)) 
                                    << 8U));
    __Vfunc___03703__41__b[0U] = ((((IData)(vlSelf->__PVT___179_) 
                                    << 0x18U) | (((IData)(vlSelf->__PVT___179_) 
                                                  << 0x10U) 
                                                 | ((IData)(vlSelf->__PVT___179_) 
                                                    << 8U))) 
                                  | (IData)(vlSelf->__PVT___179_));
    __Vfunc___03703__41__b[1U] = (((0xffU & (IData)(vlSelf->__PVT___179_)) 
                                   | ((0xffU & ((IData)(vlSelf->__PVT___179_) 
                                                >> 8U)) 
                                      | ((0xffU & ((IData)(vlSelf->__PVT___179_) 
                                                   >> 0x10U)) 
                                         | ((IData)(vlSelf->__PVT___179_) 
                                            >> 0x18U)))) 
                                  | ((IData)((((QData)((IData)(
                                                               (((IData)(vlSelf->__PVT___179_) 
                                                                 << 0x18U) 
                                                                | ((((IData)(vlSelf->__PVT__inst_t80__DOT___63_)
                                                                      ? (IData)(vlSelf->__PVT___179_)
                                                                      : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_)) 
                                                                    << 0x10U) 
                                                                   | (0xffffU 
                                                                      & (((IData)(vlSelf->__PVT___179_) 
                                                                          << 8U) 
                                                                         | (IData)(vlSelf->__PVT___179_))))))) 
                                               << 0x20U) 
                                              | (QData)((IData)(
                                                                (((IData)(vlSelf->__PVT___179_) 
                                                                  << 0x18U) 
                                                                 | (((IData)(vlSelf->__PVT___179_) 
                                                                     << 0x10U) 
                                                                    | (((IData)(vlSelf->__PVT___179_) 
                                                                        << 8U) 
                                                                       | (IData)(vlSelf->__PVT___179_)))))))) 
                                     << 8U));
    __Vfunc___03703__41__b[2U] = __Vtemp_28[2U];
    __Vfunc___03703__41__b[3U] = ((IData)(((((QData)((IData)(
                                                             (((IData)(vlSelf->__PVT___179_) 
                                                               << 0x18U) 
                                                              | ((((IData)(vlSelf->__PVT__inst_t80__DOT___63_)
                                                                    ? (IData)(vlSelf->__PVT___179_)
                                                                    : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_)) 
                                                                  << 0x10U) 
                                                                 | (0xffffU 
                                                                    & (((IData)(vlSelf->__PVT___179_) 
                                                                        << 8U) 
                                                                       | (IData)(vlSelf->__PVT___179_))))))) 
                                             << 0x20U) 
                                            | (QData)((IData)(
                                                              (((IData)(vlSelf->__PVT___179_) 
                                                                << 0x18U) 
                                                               | (((IData)(vlSelf->__PVT___179_) 
                                                                   << 0x10U) 
                                                                  | (((IData)(vlSelf->__PVT___179_) 
                                                                      << 8U) 
                                                                     | (IData)(vlSelf->__PVT___179_))))))) 
                                           >> 0x20U)) 
                                  >> 0x18U);
    __Vfunc___03703__41__a = vlSelf->__PVT___179_;
    __Vfunc___03703__41__Vfuncout = (0xffU & ((((((
                                                   (((1U 
                                                      == 
                                                      (1U 
                                                       & (IData)(__Vfunc___03703__41__s))) 
                                                     | (2U 
                                                        == 
                                                        (2U 
                                                         & (IData)(__Vfunc___03703__41__s)))) 
                                                    | (4U 
                                                       == 
                                                       (4U 
                                                        & (IData)(__Vfunc___03703__41__s)))) 
                                                   | (8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03703__41__s)))) 
                                                  | (0x10U 
                                                     == 
                                                     (0x10U 
                                                      & (IData)(__Vfunc___03703__41__s)))) 
                                                 | (0x20U 
                                                    == 
                                                    (0x20U 
                                                     & (IData)(__Vfunc___03703__41__s)))) 
                                                | (0x40U 
                                                   == 
                                                   (0x40U 
                                                    & (IData)(__Vfunc___03703__41__s)))) 
                                               | (0x80U 
                                                  == 
                                                  (0x80U 
                                                   & (IData)(__Vfunc___03703__41__s))))
                                               ? ((1U 
                                                   == 
                                                   (1U 
                                                    & (IData)(__Vfunc___03703__41__s)))
                                                   ? 
                                                  __Vfunc___03703__41__b[0U]
                                                   : 
                                                  ((2U 
                                                    == 
                                                    (2U 
                                                     & (IData)(__Vfunc___03703__41__s)))
                                                    ? 
                                                   ((__Vfunc___03703__41__b[0U] 
                                                     << 0x18U) 
                                                    | (__Vfunc___03703__41__b[0U] 
                                                       >> 8U))
                                                    : 
                                                   ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03703__41__s)))
                                                     ? 
                                                    ((__Vfunc___03703__41__b[0U] 
                                                      << 0x10U) 
                                                     | (__Vfunc___03703__41__b[0U] 
                                                        >> 0x10U))
                                                     : 
                                                    ((8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03703__41__s)))
                                                      ? 
                                                     ((__Vfunc___03703__41__b[0U] 
                                                       << 8U) 
                                                      | (__Vfunc___03703__41__b[0U] 
                                                         >> 0x18U))
                                                      : 
                                                     ((0x10U 
                                                       == 
                                                       (0x10U 
                                                        & (IData)(__Vfunc___03703__41__s)))
                                                       ? 
                                                      __Vfunc___03703__41__b[1U]
                                                       : 
                                                      ((0x20U 
                                                        == 
                                                        (0x20U 
                                                         & (IData)(__Vfunc___03703__41__s)))
                                                        ? 
                                                       ((__Vfunc___03703__41__b[1U] 
                                                         << 0x18U) 
                                                        | (__Vfunc___03703__41__b[1U] 
                                                           >> 8U))
                                                        : 
                                                       ((0x40U 
                                                         == 
                                                         (0x40U 
                                                          & (IData)(__Vfunc___03703__41__s)))
                                                         ? 
                                                        ((__Vfunc___03703__41__b[1U] 
                                                          << 0x10U) 
                                                         | (__Vfunc___03703__41__b[1U] 
                                                            >> 0x10U))
                                                         : 
                                                        ((__Vfunc___03703__41__b[1U] 
                                                          << 8U) 
                                                         | (__Vfunc___03703__41__b[1U] 
                                                            >> 0x18U)))))))))
                                               : ((0x100U 
                                                   == 
                                                   (0x100U 
                                                    & (IData)(__Vfunc___03703__41__s)))
                                                   ? 
                                                  __Vfunc___03703__41__b[2U]
                                                   : 
                                                  ((0x200U 
                                                    == 
                                                    (0x200U 
                                                     & (IData)(__Vfunc___03703__41__s)))
                                                    ? 
                                                   ((__Vfunc___03703__41__b[2U] 
                                                     << 0x18U) 
                                                    | (__Vfunc___03703__41__b[2U] 
                                                       >> 8U))
                                                    : 
                                                   ((0x400U 
                                                     == 
                                                     (0x400U 
                                                      & (IData)(__Vfunc___03703__41__s)))
                                                     ? 
                                                    ((__Vfunc___03703__41__b[2U] 
                                                      << 0x10U) 
                                                     | (__Vfunc___03703__41__b[2U] 
                                                        >> 0x10U))
                                                     : 
                                                    ((0x800U 
                                                      == 
                                                      (0x800U 
                                                       & (IData)(__Vfunc___03703__41__s)))
                                                      ? 
                                                     ((__Vfunc___03703__41__b[2U] 
                                                       << 8U) 
                                                      | (__Vfunc___03703__41__b[2U] 
                                                         >> 0x18U))
                                                      : 
                                                     ((0x1000U 
                                                       == 
                                                       (0x1000U 
                                                        & (IData)(__Vfunc___03703__41__s)))
                                                       ? 
                                                      __Vfunc___03703__41__b[3U]
                                                       : (IData)(__Vfunc___03703__41__a))))))));
    vlSelf->__PVT___281_ = __Vfunc___03703__41__Vfuncout;
    vlSelf->__PVT__cap_wr_p_s = ((0x5cU == (0xffU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                 & (IData)(vlSelf->__PVT___010_));
    vlSelf->__PVT__chk_wr_p_s = ((0x5dU == (0xffU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                 & (IData)(vlSelf->__PVT___010_));
    vlSelf->__PVT__end_wr_p_s = ((0x5eU == (0xffU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                 & (IData)(vlSelf->__PVT___010_));
    vlSelf->__PVT___384_ = ((~ (IData)(vlSelf->__PVT___426_)) 
                            & (IData)(vlSelf->__PVT__kbd_rd_s));
    vlSelf->inst_t80__DOT__u0__DOT____VdfgTmp_he66cde70__0 
        = ((0x80U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___726_)) 
           | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___119_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b 
        = ((0x400000U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2234_) 
                         << 0x13U)) | ((0x200000U & 
                                        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2209_) 
                                         << 0x12U)) 
                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2180_) 
                                           << 0x14U) 
                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2087_) 
                                              << 0xfU) 
                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2053_) 
                                                 << 0xeU) 
                                                | ((0x200U 
                                                    & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1987_) 
                                                       << 6U)) 
                                                   | ((0x100U 
                                                       & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1965_) 
                                                          << 5U)) 
                                                      | (0x80U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1942_) 
                                                            << 4U)))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2260_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039468__550__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b 
        = (0x400U | ((0x400000U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2234_) 
                                   << 0x16U)) | ((0x200000U 
                                                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2209_) 
                                                     << 0x15U)) 
                                                 | ((0x100000U 
                                                     & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2179_) 
                                                        << 0x14U)) 
                                                    | ((0x20000U 
                                                        & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2118_) 
                                                           << 0x11U)) 
                                                       | ((0x10000U 
                                                           & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2104_) 
                                                              << 0x10U)) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2085_) 
                                                              << 0xfU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2051_) 
                                                                 << 0xeU) 
                                                                | ((0x200U 
                                                                    & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1987_) 
                                                                       << 9U)) 
                                                                   | ((0x100U 
                                                                       & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1965_) 
                                                                          << 8U)) 
                                                                      | (0x80U 
                                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1942_) 
                                                                            << 7U))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2258_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039447__548__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b 
        = ((QData)((IData)((0xc0U | ((0xc0000000U & 
                                      ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2234_) 
                                       << 0x1dU)) | 
                                     ((0x30000000U 
                                       & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2209_) 
                                          << 0x1bU)) 
                                      | ((0xc000000U 
                                          & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2179_) 
                                             << 0x19U)) 
                                         | ((0x300000U 
                                             & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2118_) 
                                                << 0x13U)) 
                                            | ((0xc0000U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2104_) 
                                                   << 0x11U)) 
                                               | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2086_) 
                                                   << 0x10U) 
                                                  | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2052_) 
                                                      << 0xeU) 
                                                     | ((0x30U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1987_) 
                                                            << 3U)) 
                                                        | ((0xcU 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1965_) 
                                                               << 1U)) 
                                                           | (3U 
                                                              & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1942_) 
                                                                 >> 1U)))))))))))))) 
           << 0xeU);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__Vfuncout 
        = (3U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))
                      ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b)
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))
                          ? (IData)((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b 
                                     >> 2U)) : ((4U 
                                                 == 
                                                 (4U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))
                                                 ? (IData)(
                                                           (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b 
                                                            >> 4U))
                                                 : 
                                                ((8U 
                                                  == 
                                                  (8U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))
                                                  ? (IData)(
                                                            (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b 
                                                             >> 6U))
                                                  : 
                                                 ((0x10U 
                                                   == 
                                                   (0x10U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))
                                                   ? (IData)(
                                                             (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b 
                                                              >> 8U))
                                                   : 
                                                  ((0x20U 
                                                    == 
                                                    (0x20U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))
                                                    ? (IData)(
                                                              (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b 
                                                               >> 0xaU))
                                                    : 
                                                   ((0x40U 
                                                     == 
                                                     (0x40U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))
                                                     ? (IData)(
                                                               (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b 
                                                                >> 0xcU))
                                                     : (IData)(
                                                               (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b 
                                                                >> 0xeU)))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))
                          ? (IData)((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b 
                                     >> 0x10U)) : (
                                                   (0x200U 
                                                    == 
                                                    (0x200U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))
                                                    ? (IData)(
                                                              (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b 
                                                               >> 0x12U))
                                                    : 
                                                   ((0x400U 
                                                     == 
                                                     (0x400U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))
                                                     ? (IData)(
                                                               (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b 
                                                                >> 0x14U))
                                                     : 
                                                    ((0x800U 
                                                      == 
                                                      (0x800U 
                                                       & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))
                                                      ? (IData)(
                                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b 
                                                                 >> 0x16U))
                                                      : 
                                                     ((0x1000U 
                                                       == 
                                                       (0x1000U 
                                                        & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))
                                                       ? (IData)(
                                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b 
                                                                  >> 0x18U))
                                                       : 
                                                      ((0x2000U 
                                                        == 
                                                        (0x2000U 
                                                         & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))
                                                        ? (IData)(
                                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b 
                                                                   >> 0x1aU))
                                                        : 
                                                       ((0x4000U 
                                                         == 
                                                         (0x4000U 
                                                          & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))
                                                         ? (IData)(
                                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b 
                                                                    >> 0x1cU))
                                                         : (IData)(
                                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b 
                                                                    >> 0x1eU)))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))
                          ? (IData)((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b 
                                     >> 0x20U)) : (
                                                   (0x20000U 
                                                    == 
                                                    (0x20000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))
                                                    ? (IData)(
                                                              (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b 
                                                               >> 0x22U))
                                                    : 
                                                   ((0x40000U 
                                                     == 
                                                     (0x40000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))
                                                     ? (IData)(
                                                               (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b 
                                                                >> 0x24U))
                                                     : 
                                                    ((0x80000U 
                                                      == 
                                                      (0x80000U 
                                                       & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))
                                                      ? (IData)(
                                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b 
                                                                 >> 0x26U))
                                                      : 
                                                     ((0x100000U 
                                                       == 
                                                       (0x100000U 
                                                        & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))
                                                       ? (IData)(
                                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b 
                                                                  >> 0x28U))
                                                       : 
                                                      ((0x200000U 
                                                        == 
                                                        (0x200000U 
                                                         & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))
                                                        ? (IData)(
                                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b 
                                                                   >> 0x2aU))
                                                        : 
                                                       ((0x400000U 
                                                         == 
                                                         (0x400000U 
                                                          & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__s))
                                                         ? (IData)(
                                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__b 
                                                                    >> 0x2cU))
                                                         : 0U))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2259_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039459__549__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__s 
        = (((5U == (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))) 
            << 3U) | (((4U == (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))) 
                       << 2U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___033_) 
                                  << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___026_))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__b 
        = ((2U & ((~ ((IData)(__PVT__inst_t80__DOT__u0__DOT__alu__DOT___020_) 
                      >> 2U)) << 1U)) | (1U & ((IData)(__PVT__inst_t80__DOT__u0__DOT__alu__DOT___020_) 
                                               >> 2U)));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__b) 
                                 >> 1U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__b) 
                                                >> 2U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__b) 
                                 >> 1U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__b) 
                                                >> 3U))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__b) 
                                 >> 1U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__b) 
                                                >> 2U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__b) 
                                 >> 1U)) : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__s) 
                                            & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__b))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___039_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039884__105__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__s 
        = (((5U == (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))) 
            << 3U) | (((4U == (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))) 
                       << 2U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___033_) 
                                  << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___026_))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__b 
        = ((8U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                  << 1U)) | ((4U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)) 
                             | (3U & (- (IData)((IData)(
                                                        (((IData)(__PVT__inst_t80__DOT__u0__DOT__alu__DOT___020_) 
                                                          >> 2U) 
                                                         ^ 
                                                         ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___017_) 
                                                          >> 4U))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__a 
        = (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                 >> 2U));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__b) 
                                 >> 1U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__b) 
                                                >> 2U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__b) 
                                 >> 1U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__b) 
                                                >> 3U))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__b) 
                                 >> 1U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__b) 
                                                >> 2U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__b) 
                                 >> 1U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__b)
                                             : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__a))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___041_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039887__107__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__s 
        = (((5U == (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))) 
            << 3U) | (((4U == (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))) 
                       << 2U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___033_) 
                                  << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___026_))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__b 
        = ((((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_) 
             ^ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_)) 
            << 0x18U) | ((((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_) 
                           & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_)) 
                          << 0x10U) | (0xffffU & ((
                                                   (0x8000U 
                                                    & ((IData)(__PVT__inst_t80__DOT__u0__DOT__alu__DOT___020_) 
                                                       << 0xeU)) 
                                                   | ((0x7000U 
                                                       & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___017_) 
                                                          << 0xbU)) 
                                                      | (0xf00U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___014_) 
                                                            << 7U)))) 
                                                  | ((0x80U 
                                                      & ((IData)(__PVT__inst_t80__DOT__u0__DOT__alu__DOT___020_) 
                                                         << 6U)) 
                                                     | ((0x70U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___017_) 
                                                            << 3U)) 
                                                        | (0xfU 
                                                           & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___014_) 
                                                              >> 1U))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__a 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_) 
           | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__Vfuncout 
        = (0xffU & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__s))
                     ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__s))
                         ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__s))
                             ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__s))
                                 ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__b
                                 : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__b 
                                    >> 8U)) : ((1U 
                                                & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__s))
                                                ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__b
                                                : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__b 
                                                   >> 0x10U)))
                         : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__s))
                             ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__s))
                                 ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__b
                                 : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__b 
                                    >> 8U)) : ((1U 
                                                & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__s))
                                                ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__b
                                                : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__b 
                                                   >> 0x18U))))
                     : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__s))
                         ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__s))
                             ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__s))
                                 ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__b
                                 : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__b 
                                    >> 8U)) : ((1U 
                                                & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__s))
                                                ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__b
                                                : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__b 
                                                   >> 0x10U)))
                         : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__s))
                             ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__s))
                                 ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__b
                                 : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__b 
                                    >> 8U)) : ((1U 
                                                & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__s))
                                                ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__b
                                                : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__a))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___043_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039889__109__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039673__618__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039673__618__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2278_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039673__618__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039673__618__s)))
            ? 3U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039673__618__s)))
                     ? 3U : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039673__618__a)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2328_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039673__618__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039579__586__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039579__586__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2262_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039579__586__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039579__586__s))) 
           & ((2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039579__586__s))) 
              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039579__586__a)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2296_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039579__586__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039655__612__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039655__612__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2274_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039655__612__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039655__612__s))) 
           & ((2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039655__612__s))) 
              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039655__612__a)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2322_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039655__612__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039646__609__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039646__609__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2271_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039646__609__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039646__609__s))) 
           & ((2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039646__609__s))) 
              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039646__609__a)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2319_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039646__609__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039658__613__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039658__613__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2275_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039658__613__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039658__613__s))) 
           & ((2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039658__613__s))) 
              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039658__613__a)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2323_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039658__613__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039661__614__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039661__614__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2276_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039661__614__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039661__614__s))) 
           & ((2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039661__614__s))) 
              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039661__614__a)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2324_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039661__614__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039652__611__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039652__611__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2273_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039652__611__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039652__611__s))) 
           & ((2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039652__611__s))) 
              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039652__611__a)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2321_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039652__611__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039649__610__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039649__610__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2272_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039649__610__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039649__610__s))) 
           & ((2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039649__610__s))) 
              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039649__610__a)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2320_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039649__610__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039664__615__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039664__615__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2277_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039664__615__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039664__615__s))) 
           & ((2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039664__615__s))) 
              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039664__615__a)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2325_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039664__615__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039619__600__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039619__600__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2270_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039619__600__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039619__600__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039619__600__s)))
                     ? 0U : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039619__600__a)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039619__600__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0432_) 
            << 7U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0410_) 
                       << 6U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0453_) 
                                  << 5U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1351_) 
                                             << 4U) 
                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1216_) 
                                                << 3U) 
                                               | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1194_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1066_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1040_))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__b 
        = (0x618418U | ((((0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___768_))
                           ? 1U : 3U) << 0x12U) | (
                                                   (((0U 
                                                      == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___768_))
                                                      ? 1U
                                                      : 3U) 
                                                    << 0xcU) 
                                                   | ((((0U 
                                                         == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___768_))
                                                         ? 1U
                                                         : 2U) 
                                                       << 6U) 
                                                      | ((0U 
                                                          == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___768_))
                                                          ? 1U
                                                          : 3U)))));
    vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__Vfuncout 
        = (((((((((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__s))) 
                  | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__s)))) 
                 | (4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__s)))) 
                | (8U == (8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__s)))) 
               | (0x10U == (0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__s)))) 
              | (0x20U == (0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__s)))) 
             | (0x40U == (0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__s)))) 
            | (0x80U == (0x80U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__s))))
            ? (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__s)))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__b
                      : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__s)))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__b 
                             >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__s)))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__b 
                                           >> 6U) : 
                                       ((8U == (8U 
                                                & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__s)))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__b 
                                            >> 9U) : 
                                        ((0x10U == 
                                          (0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__s)))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__b 
                                             >> 0xcU)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__s)))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__b 
                                                 >> 0xfU)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__s)))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__b 
                                                  >> 0x12U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038014__405__b 
                                                  >> 0x15U)))))))))
            : 0U);
}
