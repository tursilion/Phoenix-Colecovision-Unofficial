// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vsim_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vsim_top__Syms.h"
#include "Vsim_top_vdp_spy.h"

VL_ATTR_COLD void Vsim_top_vdp_spy___eval_static__TOP__sim_top__cv__inst_f18a__spy(Vsim_top_vdp_spy* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+            Vsim_top_vdp_spy___eval_static__TOP__sim_top__cv__inst_f18a__spy\n"); );
    // Body
    vlSelf->__PVT__addr = 0U;
    vlSelf->__PVT__latch_first = 1U;
    vlSelf->__PVT__rd_buf = 0U;
    vlSelf->__PVT__f_flag = 0U;
    vlSelf->__PVT__fcnt = 0U;
    vlSelf->__PVT__csw_d = 1U;
    vlSelf->__PVT__csr_d = 1U;
}

VL_ATTR_COLD void Vsim_top_vdp_spy___eval_initial__TOP__sim_top__cv__inst_f18a__spy(Vsim_top_vdp_spy* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+            Vsim_top_vdp_spy___eval_initial__TOP__sim_top__cv__inst_f18a__spy\n"); );
    // Body
    vlSelf->regs[0U] = 0U;
    vlSelf->regs[1U] = 0U;
    vlSelf->regs[2U] = 0U;
    vlSelf->regs[3U] = 0U;
    vlSelf->regs[4U] = 0U;
    vlSelf->regs[5U] = 0U;
    vlSelf->regs[6U] = 0U;
    vlSelf->regs[7U] = 0U;
}

VL_ATTR_COLD void Vsim_top_vdp_spy___ctor_var_reset(Vsim_top_vdp_spy* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+            Vsim_top_vdp_spy___ctor_var_reset\n"); );
    // Body
    vlSelf->__PVT__clk = VL_RAND_RESET_I(1);
    vlSelf->__PVT__mode = VL_RAND_RESET_I(1);
    vlSelf->__PVT__csw_n = VL_RAND_RESET_I(1);
    vlSelf->__PVT__csr_n = VL_RAND_RESET_I(1);
    vlSelf->__PVT__din = VL_RAND_RESET_I(8);
    vlSelf->__PVT__dout = VL_RAND_RESET_I(8);
    vlSelf->__PVT__int_n = VL_RAND_RESET_I(1);
    for (int __Vi0 = 0; __Vi0 < 16384; ++__Vi0) {
        vlSelf->vram[__Vi0] = VL_RAND_RESET_I(8);
    }
    for (int __Vi0 = 0; __Vi0 < 8; ++__Vi0) {
        vlSelf->regs[__Vi0] = VL_RAND_RESET_I(8);
    }
    vlSelf->__PVT__addr = VL_RAND_RESET_I(14);
    vlSelf->__PVT__latch_first = VL_RAND_RESET_I(1);
    vlSelf->__PVT__latch = VL_RAND_RESET_I(8);
    vlSelf->__PVT__rd_buf = VL_RAND_RESET_I(8);
    vlSelf->__PVT__f_flag = VL_RAND_RESET_I(1);
    vlSelf->__PVT__fcnt = VL_RAND_RESET_I(19);
    vlSelf->__PVT__csw_d = VL_RAND_RESET_I(1);
    vlSelf->__PVT__csr_d = VL_RAND_RESET_I(1);
}
