// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vsim_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vsim_top__Syms.h"
#include "Vsim_top__Syms.h"
#include "Vsim_top_sim_top.h"

VL_INLINE_OPT void Vsim_top_sim_top___nba_sequent__TOP__sim_top__0(Vsim_top_sim_top* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+      Vsim_top_sim_top___nba_sequent__TOP__sim_top__0\n"); );
    // Body
    vlSelf->__PVT__cart_bus = ((((IData)(vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT___61_)
                                  ? (IData)(vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT__u0__DOT___814_)
                                  : 0U) & ((IData)(vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT___61_)
                                            ? 0xffU
                                            : 0U)) 
                               & ((IData)(vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT___61_)
                                   ? 0xffU : 0U));
}
