// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vsim_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vsim_top__Syms.h"
#include "Vsim_top__Syms.h"
#include "Vsim_top_vdp_spy.h"

VL_INLINE_OPT void Vsim_top_vdp_spy___nba_sequent__TOP__sim_top__cv__inst_f18a__spy__0(Vsim_top_vdp_spy* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+            Vsim_top_vdp_spy___nba_sequent__TOP__sim_top__cv__inst_f18a__spy__0\n"); );
    // Init
    IData/*18:0*/ __Vdly__fcnt;
    __Vdly__fcnt = 0;
    CData/*0:0*/ __Vdly__f_flag;
    __Vdly__f_flag = 0;
    CData/*7:0*/ __Vdly__latch;
    __Vdly__latch = 0;
    CData/*2:0*/ __Vdlyvdim0__regs__v0;
    __Vdlyvdim0__regs__v0 = 0;
    CData/*7:0*/ __Vdlyvval__regs__v0;
    __Vdlyvval__regs__v0 = 0;
    CData/*0:0*/ __Vdlyvset__regs__v0;
    __Vdlyvset__regs__v0 = 0;
    SData/*13:0*/ __Vdly__addr;
    __Vdly__addr = 0;
    CData/*7:0*/ __Vdly__rd_buf;
    __Vdly__rd_buf = 0;
    SData/*13:0*/ __Vdlyvdim0__vram__v0;
    __Vdlyvdim0__vram__v0 = 0;
    CData/*7:0*/ __Vdlyvval__vram__v0;
    __Vdlyvval__vram__v0 = 0;
    CData/*0:0*/ __Vdlyvset__vram__v0;
    __Vdlyvset__vram__v0 = 0;
    // Body
    __Vdly__rd_buf = vlSelf->__PVT__rd_buf;
    __Vdly__addr = vlSelf->__PVT__addr;
    __Vdly__latch = vlSelf->__PVT__latch;
    __Vdly__fcnt = vlSelf->__PVT__fcnt;
    __Vdlyvset__vram__v0 = 0U;
    __Vdly__f_flag = vlSelf->__PVT__f_flag;
    __Vdlyvset__regs__v0 = 0U;
    if ((0x65b9aU == vlSelf->__PVT__fcnt)) {
        __Vdly__fcnt = 0U;
        __Vdly__f_flag = 1U;
    } else {
        __Vdly__fcnt = (0x7ffffU & ((IData)(1U) + vlSelf->__PVT__fcnt));
    }
    if (((~ (IData)(vlSymsp->TOP__sim_top__cv.__PVT__vdp_w_n_s)) 
         & (IData)(vlSelf->__PVT__csw_d))) {
        if ((1U & (IData)(vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT__u0__DOT___812_))) {
            if (vlSelf->__PVT__latch_first) {
                __Vdly__latch = vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT__u0__DOT___814_;
                vlSelf->__PVT__latch_first = 0U;
            } else {
                vlSelf->__PVT__latch_first = 1U;
                if ((0x80U & (IData)(vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT__u0__DOT___814_))) {
                    __Vdlyvval__regs__v0 = vlSelf->__PVT__latch;
                    __Vdlyvset__regs__v0 = 1U;
                    __Vdlyvdim0__regs__v0 = (7U & (IData)(vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT__u0__DOT___814_));
                } else {
                    __Vdly__addr = ((0x3f00U & ((IData)(vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT__u0__DOT___814_) 
                                                << 8U)) 
                                    | (IData)(vlSelf->__PVT__latch));
                    if ((1U & (~ ((IData)(vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT__u0__DOT___814_) 
                                  >> 6U)))) {
                        __Vdly__rd_buf = vlSelf->vram
                            [((0x3f00U & ((IData)(vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT__u0__DOT___814_) 
                                          << 8U)) | (IData)(vlSelf->__PVT__latch))];
                        __Vdly__addr = (0x3fffU & ((IData)(1U) 
                                                   + 
                                                   ((0x3f00U 
                                                     & ((IData)(vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT__u0__DOT___814_) 
                                                        << 8U)) 
                                                    | (IData)(vlSelf->__PVT__latch))));
                    }
                }
            }
        } else {
            __Vdlyvval__vram__v0 = vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT__u0__DOT___814_;
            __Vdlyvset__vram__v0 = 1U;
            __Vdlyvdim0__vram__v0 = vlSelf->__PVT__addr;
            __Vdly__rd_buf = vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT__u0__DOT___814_;
            vlSelf->__PVT__latch_first = 1U;
            __Vdly__addr = (0x3fffU & ((IData)(1U) 
                                       + (IData)(vlSelf->__PVT__addr)));
        }
    }
    if (((~ (IData)(vlSymsp->TOP__sim_top__cv.__PVT__vdp_r_n_s)) 
         & (IData)(vlSelf->__PVT__csr_d))) {
        if ((1U & (IData)(vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT__u0__DOT___812_))) {
            vlSelf->__PVT__dout = (0x1fU | ((IData)(vlSelf->__PVT__f_flag) 
                                            << 7U));
            vlSelf->__PVT__latch_first = 1U;
            __Vdly__f_flag = 0U;
        } else {
            vlSelf->__PVT__dout = vlSelf->__PVT__rd_buf;
            vlSelf->__PVT__latch_first = 1U;
            __Vdly__rd_buf = vlSelf->vram[vlSelf->__PVT__addr];
            __Vdly__addr = (0x3fffU & ((IData)(1U) 
                                       + (IData)(vlSelf->__PVT__addr)));
        }
    }
    vlSelf->__PVT__fcnt = __Vdly__fcnt;
    vlSelf->__PVT__latch = __Vdly__latch;
    vlSelf->__PVT__addr = __Vdly__addr;
    vlSelf->__PVT__rd_buf = __Vdly__rd_buf;
    if (__Vdlyvset__vram__v0) {
        vlSelf->vram[__Vdlyvdim0__vram__v0] = __Vdlyvval__vram__v0;
    }
    vlSelf->__PVT__f_flag = __Vdly__f_flag;
    if (__Vdlyvset__regs__v0) {
        vlSelf->regs[__Vdlyvdim0__regs__v0] = __Vdlyvval__regs__v0;
    }
    vlSelf->__PVT__csw_d = vlSymsp->TOP__sim_top__cv.__PVT__vdp_w_n_s;
    vlSelf->__PVT__csr_d = vlSymsp->TOP__sim_top__cv.__PVT__vdp_r_n_s;
    vlSelf->__PVT__int_n = (1U & (~ ((IData)(vlSelf->__PVT__f_flag) 
                                     & (vlSelf->regs
                                        [1U] >> 5U))));
}
