// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vsim_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vsim_top__Syms.h"
#include "Vsim_top_colecovision.h"

VL_INLINE_OPT void Vsim_top_colecovision___nba_sequent__TOP__sim_top__cv__2(Vsim_top_colecovision* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vsim_top_colecovision___nba_sequent__TOP__sim_top__cv__2\n"); );
    // Init
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0736_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0736_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1166_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1166_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1559_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1559_ = 0;
    CData/*0:0*/ __VdfgTmp_h8a4cccd7__0;
    __VdfgTmp_h8a4cccd7__0 = 0;
    CData/*0:0*/ __Vfunc___03369__0__Vfuncout;
    __Vfunc___03369__0__Vfuncout = 0;
    CData/*2:0*/ __Vfunc___03369__0__s;
    __Vfunc___03369__0__s = 0;
    CData/*0:0*/ __Vfunc___03372__1__Vfuncout;
    __Vfunc___03372__1__Vfuncout = 0;
    CData/*2:0*/ __Vfunc___03372__1__s;
    __Vfunc___03372__1__s = 0;
    CData/*0:0*/ __Vfunc___03375__2__Vfuncout;
    __Vfunc___03375__2__Vfuncout = 0;
    CData/*2:0*/ __Vfunc___03375__2__s;
    __Vfunc___03375__2__s = 0;
    CData/*0:0*/ __Vfunc___03395__8__Vfuncout;
    __Vfunc___03395__8__Vfuncout = 0;
    CData/*7:0*/ __Vfunc___03395__8__s;
    __Vfunc___03395__8__s = 0;
    CData/*0:0*/ __Vfunc___03398__9__Vfuncout;
    __Vfunc___03398__9__Vfuncout = 0;
    CData/*7:0*/ __Vfunc___03398__9__s;
    __Vfunc___03398__9__s = 0;
    CData/*0:0*/ __Vfunc___03401__10__Vfuncout;
    __Vfunc___03401__10__Vfuncout = 0;
    CData/*7:0*/ __Vfunc___03401__10__s;
    __Vfunc___03401__10__s = 0;
    CData/*0:0*/ __Vfunc___03404__11__Vfuncout;
    __Vfunc___03404__11__Vfuncout = 0;
    CData/*7:0*/ __Vfunc___03404__11__s;
    __Vfunc___03404__11__s = 0;
    CData/*0:0*/ __Vfunc___03503__17__Vfuncout;
    __Vfunc___03503__17__Vfuncout = 0;
    CData/*5:0*/ __Vfunc___03503__17__s;
    __Vfunc___03503__17__s = 0;
    CData/*0:0*/ __Vfunc___03506__18__Vfuncout;
    __Vfunc___03506__18__Vfuncout = 0;
    CData/*5:0*/ __Vfunc___03506__18__s;
    __Vfunc___03506__18__s = 0;
    CData/*0:0*/ __Vfunc___03509__19__Vfuncout;
    __Vfunc___03509__19__Vfuncout = 0;
    CData/*5:0*/ __Vfunc___03509__19__s;
    __Vfunc___03509__19__s = 0;
    CData/*0:0*/ __Vfunc___03513__21__Vfuncout;
    __Vfunc___03513__21__Vfuncout = 0;
    CData/*5:0*/ __Vfunc___03513__21__s;
    __Vfunc___03513__21__s = 0;
    CData/*0:0*/ __Vfunc___03516__22__Vfuncout;
    __Vfunc___03516__22__Vfuncout = 0;
    CData/*5:0*/ __Vfunc___03516__22__s;
    __Vfunc___03516__22__s = 0;
    CData/*0:0*/ __Vfunc___03681__24__Vfuncout;
    __Vfunc___03681__24__Vfuncout = 0;
    SData/*12:0*/ __Vfunc___03681__24__b;
    __Vfunc___03681__24__b = 0;
    SData/*12:0*/ __Vfunc___03681__24__s;
    __Vfunc___03681__24__s = 0;
    CData/*0:0*/ __Vfunc___03683__25__Vfuncout;
    __Vfunc___03683__25__Vfuncout = 0;
    SData/*12:0*/ __Vfunc___03683__25__b;
    __Vfunc___03683__25__b = 0;
    SData/*12:0*/ __Vfunc___03683__25__s;
    __Vfunc___03683__25__s = 0;
    CData/*0:0*/ __Vfunc___03691__30__Vfuncout;
    __Vfunc___03691__30__Vfuncout = 0;
    SData/*12:0*/ __Vfunc___03691__30__s;
    __Vfunc___03691__30__s = 0;
    CData/*7:0*/ __Vfunc___03714__42__Vfuncout;
    __Vfunc___03714__42__Vfuncout = 0;
    CData/*7:0*/ __Vfunc___03714__42__b;
    __Vfunc___03714__42__b = 0;
    CData/*0:0*/ __Vfunc___03714__42__s;
    __Vfunc___03714__42__s = 0;
    CData/*0:0*/ __Vfunc___03719__43__Vfuncout;
    __Vfunc___03719__43__Vfuncout = 0;
    CData/*1:0*/ __Vfunc___03719__43__b;
    __Vfunc___03719__43__b = 0;
    CData/*1:0*/ __Vfunc___03719__43__s;
    __Vfunc___03719__43__s = 0;
    CData/*0:0*/ __Vfunc___03721__44__Vfuncout;
    __Vfunc___03721__44__Vfuncout = 0;
    CData/*1:0*/ __Vfunc___03721__44__b;
    __Vfunc___03721__44__b = 0;
    CData/*1:0*/ __Vfunc___03721__44__s;
    __Vfunc___03721__44__s = 0;
    CData/*0:0*/ __Vfunc___03728__49__Vfuncout;
    __Vfunc___03728__49__Vfuncout = 0;
    CData/*1:0*/ __Vfunc___03728__49__b;
    __Vfunc___03728__49__b = 0;
    CData/*1:0*/ __Vfunc___03728__49__s;
    __Vfunc___03728__49__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033959__81__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033959__81__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033959__81__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033959__81__b = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033959__81__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033959__81__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033961__82__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033961__82__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033961__82__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033961__82__b = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033961__82__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033961__82__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__a;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__a = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035923__216__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035923__216__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035923__216__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035923__216__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__b = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035928__218__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035928__218__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035928__218__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035928__218__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035945__219__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035945__219__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035945__219__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035945__219__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__b = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035950__221__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035950__221__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035950__221__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035950__221__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__Vfuncout = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__Vfuncout = 0;
    SData/*15:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__Vfuncout = 0;
    SData/*15:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__Vfuncout = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__Vfuncout = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__Vfuncout = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036978__364__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036978__364__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036978__364__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036978__364__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036983__366__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036983__366__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036983__366__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036983__366__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036987__367__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036987__367__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036990__368__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036990__368__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036990__368__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036990__368__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037187__370__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037187__370__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037187__370__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037187__370__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037192__372__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037192__372__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037192__372__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037192__372__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037196__373__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037196__373__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037196__373__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037196__373__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037199__374__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037199__374__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037199__374__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037199__374__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__a = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037246__377__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037246__377__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037246__377__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037246__377__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__a = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037440__380__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037440__380__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037440__380__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037440__380__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037491__382__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037491__382__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037491__382__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037491__382__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037496__384__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037496__384__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037496__384__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037496__384__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037500__385__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037500__385__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037500__385__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037500__385__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037503__386__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037503__386__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037503__386__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037503__386__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037700__388__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037700__388__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037700__388__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037700__388__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037705__390__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037705__390__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037705__390__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037705__390__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037709__391__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037709__391__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037709__391__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037709__391__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037712__392__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037712__392__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037712__392__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037712__392__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037763__394__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037763__394__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037763__394__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037763__394__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037768__396__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037768__396__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037768__396__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037768__396__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037772__397__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037772__397__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037772__397__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037772__397__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037775__398__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037775__398__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037775__398__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037775__398__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037972__400__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037972__400__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037972__400__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037972__400__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037977__402__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037977__402__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037977__402__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037977__402__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037981__403__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037981__403__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037981__403__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037981__403__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037984__404__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037984__404__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037984__404__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037984__404__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__Vfuncout = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038883__449__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038883__449__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038883__449__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038883__449__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__b = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038888__451__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038888__451__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038888__451__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038888__451__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038905__452__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038905__452__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038905__452__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038905__452__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__b = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038910__454__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038910__454__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038910__454__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038910__454__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038965__464__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038965__464__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038965__464__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038965__464__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__b = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038970__466__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038970__466__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038970__466__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038970__466__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038987__467__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038987__467__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038987__467__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038987__467__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__b = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038992__469__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038992__469__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038992__469__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038992__469__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__Vfuncout = 0;
    VlWide<3>/*91:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b;
    VL_ZERO_W(92, __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b);
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__Vfuncout = 0;
    VlWide<3>/*68:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b;
    VL_ZERO_W(69, __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b);
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__Vfuncout = 0;
    VlWide<3>/*91:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b;
    VL_ZERO_W(92, __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b);
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__Vfuncout = 0;
    VlWide<3>/*68:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b;
    VL_ZERO_W(69, __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b);
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__Vfuncout = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b = 0;
    IData/*22:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s = 0;
    VlWide<3>/*95:0*/ __Vtemp_1;
    VlWide<3>/*95:0*/ __Vtemp_10;
    CData/*31:0*/ __Vdeeptemp_hed498a0d__0;
    // Body
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0736_ 
        = vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_ 
        = ((0xa3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xabU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xb3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0xbbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_ 
        = ((0xa2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xaaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xb2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0xbaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_ 
        = ((0x41U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x49U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x51U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x59U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x61U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x69U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0x71U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | (0x79U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_ 
        = ((0x40U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x48U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x50U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x58U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x60U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x68U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0x70U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | (0x78U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_ 
        = ((0x45U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x4dU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x55U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x5dU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x65U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x6dU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0x75U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | (0x7dU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_ 
        = ((0x42U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x52U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x62U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0x72U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_ 
        = ((0x4aU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x5aU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x6aU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0x7aU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_ 
        = ((0x5eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | (0x77U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_ 
        = ((0x56U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | (0x76U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_ 
        = ((0x44U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x4cU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x54U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x5cU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x64U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x6cU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0x74U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | (0x7cU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_ 
        = ((0xa1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xa9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xb1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0xb9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_ 
        = ((0xa0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xa8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xb0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0xb8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_ 
        = ((0x43U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x53U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x63U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0x73U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_ 
        = ((0x4bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x5bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x6bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0x7bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_ 
        = ((0x7eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | (0x7fU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1559_ 
        = ((0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | (5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0863_ 
        = ((0xddU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | (0xfdU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0841_ 
        = ((0xc7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xcfU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xd7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0xdfU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0xe7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0xefU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0xf7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | (0xffU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0817_ 
        = ((0xc0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xc8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xd0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0xd8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0xe0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0xe8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0xf0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | (0xf8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0769_ 
        = ((0xc4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xccU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xd4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0xdcU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0xe4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0xecU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0xf4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | (0xfcU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0648_ 
        = ((0xc2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xcaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xd2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0xdaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0xe2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0xeaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0xf2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | (0xfaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0608_ 
        = ((7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x17U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xfU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0x1fU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0601_ 
        = ((0xbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x1bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x2bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0x3bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0594_ 
        = ((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x13U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x23U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0x33U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0587_ 
        = ((9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x19U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x29U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0x39U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0492_ 
        = ((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xdU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x15U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x1dU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x25U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x2dU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | (0x3dU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0466_ 
        = ((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xcU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x14U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x1cU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x24U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x2cU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | (0x3cU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0283_ 
        = ((0xc1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xd1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xe1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0xf1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0262_ 
        = ((0xc5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xd5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xe5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0xf5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0218_ 
        = ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x11U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x21U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0x31U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0152_ 
        = ((0x70U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x71U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x72U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x73U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x74U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x75U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | (0x77U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0115_ 
        = ((6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xeU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x16U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x1eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x26U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x2eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | (0x3eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0453_ 
        = ((0xc6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xceU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xd6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0xdeU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0xe6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0xeeU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0xf6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | (0xfeU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0432_ 
        = ((0x86U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x8eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x96U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x9eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0xa6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0xaeU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0xb6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | (0xbeU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0410_ 
        = ((0x80U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x81U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x82U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x83U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x84U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x85U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0x87U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | ((0x88U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                | ((0x89U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                   | ((0x8aU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                      | ((0x8bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                         | ((0x8cU 
                                             == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                            | ((0x8dU 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               | ((0x8fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  | ((0x90U 
                                                      == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                     | ((0x91U 
                                                         == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                        | ((0x92U 
                                                            == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                           | ((0x93U 
                                                               == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                              | ((0x94U 
                                                                  == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                 | ((0x95U 
                                                                     == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                    | ((0x97U 
                                                                        == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                       | ((0x98U 
                                                                           == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                          | ((0x99U 
                                                                              == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                             | ((0x9aU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x9bU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x9cU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x9dU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x9fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa0U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa2U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa3U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa4U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa5U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa7U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa8U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa9U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xaaU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xabU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xacU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xadU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xafU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb0U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb2U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb3U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb4U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb5U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb7U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb8U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb9U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xbaU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xbbU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xbcU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xbdU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | (0xbfU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))))))))))))))))))))))))))))))))))))))))))))))))))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1166_ 
        = ((0x40U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x41U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x42U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x43U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x44U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x45U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0x47U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | ((0x48U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                | ((0x49U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                   | ((0x4aU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                      | ((0x4bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                         | ((0x4cU 
                                             == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                            | ((0x4dU 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               | ((0x4fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  | ((0x50U 
                                                      == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                     | ((0x51U 
                                                         == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                        | ((0x52U 
                                                            == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                           | ((0x53U 
                                                               == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                              | ((0x54U 
                                                                  == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                 | ((0x55U 
                                                                     == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                    | ((0x57U 
                                                                        == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                       | ((0x58U 
                                                                           == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                          | ((0x59U 
                                                                              == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                             | ((0x5aU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x5bU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x5cU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x5dU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x60U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x61U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x62U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x63U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x64U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x65U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x67U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x68U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x69U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x6aU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x6bU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x6cU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x6dU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | (0x6fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))))))))))))))))))))))))))))))))))))));
    __VdfgTmp_h8a4cccd7__0 = ((0x78U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                              | ((0x79U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                 | ((0x7aU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                    | ((0x7bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                       | ((0x7cU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                          | ((0x7dU 
                                              == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                             | (0x7fU 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2019_ 
        = ((0x46U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | (0x4eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)));
    vlSelf->__VdfgTmp_hc027efeb__0 = ((0x66U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                      | (0x6eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___609_ = 
        (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
          & (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))) 
         | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___808_));
    vlSelf->__PVT___181_ = ((~ (IData)(vlSelf->__PVT__inst_t80__DOT___59_)) 
                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___808_));
    __Vfunc___03395__8__s = (((7U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                            >> 0xdU))) 
                              << 7U) | (((6U == (7U 
                                                 & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                    >> 0xdU))) 
                                         << 6U) | (
                                                   ((5U 
                                                     == 
                                                     (7U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                         >> 0xdU))) 
                                                    << 5U) 
                                                   | (((4U 
                                                        == 
                                                        (7U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                            >> 0xdU))) 
                                                       << 4U) 
                                                      | (((3U 
                                                           == 
                                                           (7U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                               >> 0xdU))) 
                                                          << 3U) 
                                                         | (((2U 
                                                              == 
                                                              (7U 
                                                               & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                  >> 0xdU))) 
                                                             << 2U) 
                                                            | (((1U 
                                                                 == 
                                                                 (7U 
                                                                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                     >> 0xdU))) 
                                                                << 1U) 
                                                               | (0U 
                                                                  == 
                                                                  (7U 
                                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                      >> 0xdU))))))))));
    __Vfunc___03395__8__Vfuncout = (1U & ((~ ((((((
                                                   ((1U 
                                                     == 
                                                     (1U 
                                                      & (IData)(__Vfunc___03395__8__s))) 
                                                    | (2U 
                                                       == 
                                                       (2U 
                                                        & (IData)(__Vfunc___03395__8__s)))) 
                                                   | (4U 
                                                      == 
                                                      (4U 
                                                       & (IData)(__Vfunc___03395__8__s)))) 
                                                  | (8U 
                                                     == 
                                                     (8U 
                                                      & (IData)(__Vfunc___03395__8__s)))) 
                                                 | (0x10U 
                                                    == 
                                                    (0x10U 
                                                     & (IData)(__Vfunc___03395__8__s)))) 
                                                | (0x20U 
                                                   == 
                                                   (0x20U 
                                                    & (IData)(__Vfunc___03395__8__s)))) 
                                               | (0x40U 
                                                  == 
                                                  (0x40U 
                                                   & (IData)(__Vfunc___03395__8__s)))) 
                                              | (0x80U 
                                                 == 
                                                 (0x80U 
                                                  & (IData)(__Vfunc___03395__8__s))))) 
                                          | ((1U == 
                                              (1U & (IData)(__Vfunc___03395__8__s))) 
                                             | ((2U 
                                                 == 
                                                 (2U 
                                                  & (IData)(__Vfunc___03395__8__s))) 
                                                | ((4U 
                                                    == 
                                                    (4U 
                                                     & (IData)(__Vfunc___03395__8__s))) 
                                                   | ((8U 
                                                       == 
                                                       (8U 
                                                        & (IData)(__Vfunc___03395__8__s))) 
                                                      | (0x10U 
                                                         != 
                                                         (0x10U 
                                                          & (IData)(__Vfunc___03395__8__s)))))))));
    vlSelf->__PVT___115_ = __Vfunc___03395__8__Vfuncout;
    __Vfunc___03398__9__s = (((7U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                            >> 0xdU))) 
                              << 7U) | (((6U == (7U 
                                                 & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                    >> 0xdU))) 
                                         << 6U) | (
                                                   ((5U 
                                                     == 
                                                     (7U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                         >> 0xdU))) 
                                                    << 5U) 
                                                   | (((4U 
                                                        == 
                                                        (7U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                            >> 0xdU))) 
                                                       << 4U) 
                                                      | (((3U 
                                                           == 
                                                           (7U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                               >> 0xdU))) 
                                                          << 3U) 
                                                         | (((2U 
                                                              == 
                                                              (7U 
                                                               & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                  >> 0xdU))) 
                                                             << 2U) 
                                                            | (((1U 
                                                                 == 
                                                                 (7U 
                                                                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                     >> 0xdU))) 
                                                                << 1U) 
                                                               | (0U 
                                                                  == 
                                                                  (7U 
                                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                      >> 0xdU))))))))));
    __Vfunc___03398__9__Vfuncout = (1U & ((~ ((((((
                                                   ((1U 
                                                     == 
                                                     (1U 
                                                      & (IData)(__Vfunc___03398__9__s))) 
                                                    | (2U 
                                                       == 
                                                       (2U 
                                                        & (IData)(__Vfunc___03398__9__s)))) 
                                                   | (4U 
                                                      == 
                                                      (4U 
                                                       & (IData)(__Vfunc___03398__9__s)))) 
                                                  | (8U 
                                                     == 
                                                     (8U 
                                                      & (IData)(__Vfunc___03398__9__s)))) 
                                                 | (0x10U 
                                                    == 
                                                    (0x10U 
                                                     & (IData)(__Vfunc___03398__9__s)))) 
                                                | (0x20U 
                                                   == 
                                                   (0x20U 
                                                    & (IData)(__Vfunc___03398__9__s)))) 
                                               | (0x40U 
                                                  == 
                                                  (0x40U 
                                                   & (IData)(__Vfunc___03398__9__s)))) 
                                              | (0x80U 
                                                 == 
                                                 (0x80U 
                                                  & (IData)(__Vfunc___03398__9__s))))) 
                                          | ((1U == 
                                              (1U & (IData)(__Vfunc___03398__9__s))) 
                                             | ((2U 
                                                 == 
                                                 (2U 
                                                  & (IData)(__Vfunc___03398__9__s))) 
                                                | ((4U 
                                                    == 
                                                    (4U 
                                                     & (IData)(__Vfunc___03398__9__s))) 
                                                   | ((8U 
                                                       == 
                                                       (8U 
                                                        & (IData)(__Vfunc___03398__9__s))) 
                                                      | ((0x10U 
                                                          == 
                                                          (0x10U 
                                                           & (IData)(__Vfunc___03398__9__s))) 
                                                         | (0x20U 
                                                            != 
                                                            (0x20U 
                                                             & (IData)(__Vfunc___03398__9__s))))))))));
    vlSelf->__PVT___116_ = __Vfunc___03398__9__Vfuncout;
    __Vfunc___03401__10__s = (((7U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                             >> 0xdU))) 
                               << 7U) | (((6U == (7U 
                                                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                     >> 0xdU))) 
                                          << 6U) | 
                                         (((5U == (7U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                      >> 0xdU))) 
                                           << 5U) | 
                                          (((4U == 
                                             (7U & 
                                              ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 0xdU))) 
                                            << 4U) 
                                           | (((3U 
                                                == 
                                                (7U 
                                                 & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                    >> 0xdU))) 
                                               << 3U) 
                                              | (((2U 
                                                   == 
                                                   (7U 
                                                    & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                       >> 0xdU))) 
                                                  << 2U) 
                                                 | (((1U 
                                                      == 
                                                      (7U 
                                                       & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                          >> 0xdU))) 
                                                     << 1U) 
                                                    | (0U 
                                                       == 
                                                       (7U 
                                                        & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                           >> 0xdU))))))))));
    __Vfunc___03401__10__Vfuncout = (1U & ((~ (((((
                                                   (((1U 
                                                      == 
                                                      (1U 
                                                       & (IData)(__Vfunc___03401__10__s))) 
                                                     | (2U 
                                                        == 
                                                        (2U 
                                                         & (IData)(__Vfunc___03401__10__s)))) 
                                                    | (4U 
                                                       == 
                                                       (4U 
                                                        & (IData)(__Vfunc___03401__10__s)))) 
                                                   | (8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03401__10__s)))) 
                                                  | (0x10U 
                                                     == 
                                                     (0x10U 
                                                      & (IData)(__Vfunc___03401__10__s)))) 
                                                 | (0x20U 
                                                    == 
                                                    (0x20U 
                                                     & (IData)(__Vfunc___03401__10__s)))) 
                                                | (0x40U 
                                                   == 
                                                   (0x40U 
                                                    & (IData)(__Vfunc___03401__10__s)))) 
                                               | (0x80U 
                                                  == 
                                                  (0x80U 
                                                   & (IData)(__Vfunc___03401__10__s))))) 
                                           | ((1U == 
                                               (1U 
                                                & (IData)(__Vfunc___03401__10__s))) 
                                              | ((2U 
                                                  == 
                                                  (2U 
                                                   & (IData)(__Vfunc___03401__10__s))) 
                                                 | ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03401__10__s))) 
                                                    | ((8U 
                                                        == 
                                                        (8U 
                                                         & (IData)(__Vfunc___03401__10__s))) 
                                                       | ((0x10U 
                                                           == 
                                                           (0x10U 
                                                            & (IData)(__Vfunc___03401__10__s))) 
                                                          | ((0x20U 
                                                              == 
                                                              (0x20U 
                                                               & (IData)(__Vfunc___03401__10__s))) 
                                                             | (0x40U 
                                                                != 
                                                                (0x40U 
                                                                 & (IData)(__Vfunc___03401__10__s)))))))))));
    vlSelf->__PVT___117_ = __Vfunc___03401__10__Vfuncout;
    __Vfunc___03404__11__s = (((7U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                             >> 0xdU))) 
                               << 7U) | (((6U == (7U 
                                                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                     >> 0xdU))) 
                                          << 6U) | 
                                         (((5U == (7U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                      >> 0xdU))) 
                                           << 5U) | 
                                          (((4U == 
                                             (7U & 
                                              ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 0xdU))) 
                                            << 4U) 
                                           | (((3U 
                                                == 
                                                (7U 
                                                 & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                    >> 0xdU))) 
                                               << 3U) 
                                              | (((2U 
                                                   == 
                                                   (7U 
                                                    & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                       >> 0xdU))) 
                                                  << 2U) 
                                                 | (((1U 
                                                      == 
                                                      (7U 
                                                       & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                          >> 0xdU))) 
                                                     << 1U) 
                                                    | (0U 
                                                       == 
                                                       (7U 
                                                        & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                           >> 0xdU))))))))));
    __Vfunc___03404__11__Vfuncout = (1U & ((~ (((((
                                                   (((1U 
                                                      == 
                                                      (1U 
                                                       & (IData)(__Vfunc___03404__11__s))) 
                                                     | (2U 
                                                        == 
                                                        (2U 
                                                         & (IData)(__Vfunc___03404__11__s)))) 
                                                    | (4U 
                                                       == 
                                                       (4U 
                                                        & (IData)(__Vfunc___03404__11__s)))) 
                                                   | (8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03404__11__s)))) 
                                                  | (0x10U 
                                                     == 
                                                     (0x10U 
                                                      & (IData)(__Vfunc___03404__11__s)))) 
                                                 | (0x20U 
                                                    == 
                                                    (0x20U 
                                                     & (IData)(__Vfunc___03404__11__s)))) 
                                                | (0x40U 
                                                   == 
                                                   (0x40U 
                                                    & (IData)(__Vfunc___03404__11__s)))) 
                                               | (0x80U 
                                                  == 
                                                  (0x80U 
                                                   & (IData)(__Vfunc___03404__11__s))))) 
                                           | ((1U == 
                                               (1U 
                                                & (IData)(__Vfunc___03404__11__s))) 
                                              | ((2U 
                                                  == 
                                                  (2U 
                                                   & (IData)(__Vfunc___03404__11__s))) 
                                                 | ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03404__11__s))) 
                                                    | ((8U 
                                                        == 
                                                        (8U 
                                                         & (IData)(__Vfunc___03404__11__s))) 
                                                       | ((0x10U 
                                                           == 
                                                           (0x10U 
                                                            & (IData)(__Vfunc___03404__11__s))) 
                                                          | ((0x20U 
                                                              == 
                                                              (0x20U 
                                                               & (IData)(__Vfunc___03404__11__s))) 
                                                             | (0x40U 
                                                                == 
                                                                (0x40U 
                                                                 & (IData)(__Vfunc___03404__11__s)))))))))));
    vlSelf->__PVT___118_ = __Vfunc___03404__11__Vfuncout;
    __Vfunc___03681__24__s = (((0xeU == (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                               << 0xcU) | (((0xbU == 
                                             (0xfU 
                                              & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                            << 0xbU) 
                                           | (((0xaU 
                                                == 
                                                (0xfU 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                               << 0xaU) 
                                              | (((9U 
                                                   == 
                                                   (0xfU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                  << 9U) 
                                                 | (((8U 
                                                      == 
                                                      (0xfU 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                     << 8U) 
                                                    | (((7U 
                                                         == 
                                                         (0xfU 
                                                          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                        << 7U) 
                                                       | (((6U 
                                                            == 
                                                            (0xfU 
                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                           << 6U) 
                                                          | (((5U 
                                                               == 
                                                               (0xfU 
                                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                              << 5U) 
                                                             | (((4U 
                                                                  == 
                                                                  (0xfU 
                                                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                 << 4U) 
                                                                | (((3U 
                                                                     == 
                                                                     (0xfU 
                                                                      & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                    << 3U) 
                                                                   | (((2U 
                                                                        == 
                                                                        (0xfU 
                                                                         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                       << 2U) 
                                                                      | (((1U 
                                                                           == 
                                                                           (0xfU 
                                                                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                          << 1U) 
                                                                         | (0U 
                                                                            == 
                                                                            (0xfU 
                                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))))))))))))));
    __Vfunc___03681__24__b = ((2U & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT___63_)) 
                                     << 1U)) | (1U 
                                                & (~ (IData)(vlSelf->__PVT__inst_t80__DOT___63_))));
    __Vfunc___03681__24__Vfuncout = (1U & (((((((((1U 
                                                   == 
                                                   (1U 
                                                    & (IData)(__Vfunc___03681__24__s))) 
                                                  | (2U 
                                                     == 
                                                     (2U 
                                                      & (IData)(__Vfunc___03681__24__s)))) 
                                                 | (4U 
                                                    == 
                                                    (4U 
                                                     & (IData)(__Vfunc___03681__24__s)))) 
                                                | (8U 
                                                   == 
                                                   (8U 
                                                    & (IData)(__Vfunc___03681__24__s)))) 
                                               | (0x10U 
                                                  == 
                                                  (0x10U 
                                                   & (IData)(__Vfunc___03681__24__s)))) 
                                              | (0x20U 
                                                 == 
                                                 (0x20U 
                                                  & (IData)(__Vfunc___03681__24__s)))) 
                                             | (0x40U 
                                                == 
                                                (0x40U 
                                                 & (IData)(__Vfunc___03681__24__s)))) 
                                            | (0x80U 
                                               == (0x80U 
                                                   & (IData)(__Vfunc___03681__24__s))))
                                            ? ((1U 
                                                == 
                                                (1U 
                                                 & (IData)(__Vfunc___03681__24__s)))
                                                ? (IData)(__Vfunc___03681__24__b)
                                                : (
                                                   (2U 
                                                    == 
                                                    (2U 
                                                     & (IData)(__Vfunc___03681__24__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03681__24__b) 
                                                    >> 1U)
                                                    : 
                                                   ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03681__24__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03681__24__b) 
                                                     >> 2U)
                                                     : 
                                                    ((8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03681__24__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03681__24__b) 
                                                      >> 3U)
                                                      : 
                                                     ((0x10U 
                                                       == 
                                                       (0x10U 
                                                        & (IData)(__Vfunc___03681__24__s)))
                                                       ? 
                                                      ((IData)(__Vfunc___03681__24__b) 
                                                       >> 4U)
                                                       : 
                                                      ((0x20U 
                                                        == 
                                                        (0x20U 
                                                         & (IData)(__Vfunc___03681__24__s)))
                                                        ? 
                                                       ((IData)(__Vfunc___03681__24__b) 
                                                        >> 5U)
                                                        : 
                                                       ((0x40U 
                                                         == 
                                                         (0x40U 
                                                          & (IData)(__Vfunc___03681__24__s)))
                                                         ? 
                                                        ((IData)(__Vfunc___03681__24__b) 
                                                         >> 6U)
                                                         : 
                                                        ((IData)(__Vfunc___03681__24__b) 
                                                         >> 7U))))))))
                                            : ((0x100U 
                                                == 
                                                (0x100U 
                                                 & (IData)(__Vfunc___03681__24__s)))
                                                ? ((IData)(__Vfunc___03681__24__b) 
                                                   >> 8U)
                                                : (
                                                   (0x200U 
                                                    == 
                                                    (0x200U 
                                                     & (IData)(__Vfunc___03681__24__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03681__24__b) 
                                                    >> 9U)
                                                    : 
                                                   ((0x400U 
                                                     == 
                                                     (0x400U 
                                                      & (IData)(__Vfunc___03681__24__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03681__24__b) 
                                                     >> 0xaU)
                                                     : 
                                                    ((0x800U 
                                                      == 
                                                      (0x800U 
                                                       & (IData)(__Vfunc___03681__24__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03681__24__b) 
                                                      >> 0xbU)
                                                      : (IData)(
                                                                (((IData)(__Vfunc___03681__24__s) 
                                                                  & (IData)(__Vfunc___03681__24__b)) 
                                                                 >> 0xcU))))))));
    vlSelf->__PVT___262_ = __Vfunc___03681__24__Vfuncout;
    __Vfunc___03683__25__s = (((0xeU == (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                               << 0xcU) | (((0xbU == 
                                             (0xfU 
                                              & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                            << 0xbU) 
                                           | (((0xaU 
                                                == 
                                                (0xfU 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                               << 0xaU) 
                                              | (((9U 
                                                   == 
                                                   (0xfU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                  << 9U) 
                                                 | (((8U 
                                                      == 
                                                      (0xfU 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                     << 8U) 
                                                    | (((7U 
                                                         == 
                                                         (0xfU 
                                                          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                        << 7U) 
                                                       | (((6U 
                                                            == 
                                                            (0xfU 
                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                           << 6U) 
                                                          | (((5U 
                                                               == 
                                                               (0xfU 
                                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                              << 5U) 
                                                             | (((4U 
                                                                  == 
                                                                  (0xfU 
                                                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                 << 4U) 
                                                                | (((3U 
                                                                     == 
                                                                     (0xfU 
                                                                      & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                    << 3U) 
                                                                   | (((2U 
                                                                        == 
                                                                        (0xfU 
                                                                         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                       << 2U) 
                                                                      | (((1U 
                                                                           == 
                                                                           (0xfU 
                                                                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                          << 1U) 
                                                                         | (0U 
                                                                            == 
                                                                            (0xfU 
                                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))))))))))))));
    __Vfunc___03683__25__b = ((4U & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT___61_)) 
                                     << 2U)) | (1U 
                                                & (~ (IData)(vlSelf->__PVT__inst_t80__DOT___63_))));
    __Vfunc___03683__25__Vfuncout = (1U & (((((((((1U 
                                                   == 
                                                   (1U 
                                                    & (IData)(__Vfunc___03683__25__s))) 
                                                  | (2U 
                                                     == 
                                                     (2U 
                                                      & (IData)(__Vfunc___03683__25__s)))) 
                                                 | (4U 
                                                    == 
                                                    (4U 
                                                     & (IData)(__Vfunc___03683__25__s)))) 
                                                | (8U 
                                                   == 
                                                   (8U 
                                                    & (IData)(__Vfunc___03683__25__s)))) 
                                               | (0x10U 
                                                  == 
                                                  (0x10U 
                                                   & (IData)(__Vfunc___03683__25__s)))) 
                                              | (0x20U 
                                                 == 
                                                 (0x20U 
                                                  & (IData)(__Vfunc___03683__25__s)))) 
                                             | (0x40U 
                                                == 
                                                (0x40U 
                                                 & (IData)(__Vfunc___03683__25__s)))) 
                                            | (0x80U 
                                               == (0x80U 
                                                   & (IData)(__Vfunc___03683__25__s))))
                                            ? ((1U 
                                                == 
                                                (1U 
                                                 & (IData)(__Vfunc___03683__25__s)))
                                                ? (IData)(__Vfunc___03683__25__b)
                                                : (
                                                   (2U 
                                                    == 
                                                    (2U 
                                                     & (IData)(__Vfunc___03683__25__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03683__25__b) 
                                                    >> 1U)
                                                    : 
                                                   ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03683__25__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03683__25__b) 
                                                     >> 2U)
                                                     : 
                                                    ((8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03683__25__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03683__25__b) 
                                                      >> 3U)
                                                      : 
                                                     ((0x10U 
                                                       == 
                                                       (0x10U 
                                                        & (IData)(__Vfunc___03683__25__s)))
                                                       ? 
                                                      ((IData)(__Vfunc___03683__25__b) 
                                                       >> 4U)
                                                       : 
                                                      ((0x20U 
                                                        == 
                                                        (0x20U 
                                                         & (IData)(__Vfunc___03683__25__s)))
                                                        ? 
                                                       ((IData)(__Vfunc___03683__25__b) 
                                                        >> 5U)
                                                        : 
                                                       ((0x40U 
                                                         == 
                                                         (0x40U 
                                                          & (IData)(__Vfunc___03683__25__s)))
                                                         ? 
                                                        ((IData)(__Vfunc___03683__25__b) 
                                                         >> 6U)
                                                         : 
                                                        ((IData)(__Vfunc___03683__25__b) 
                                                         >> 7U))))))))
                                            : ((0x100U 
                                                == 
                                                (0x100U 
                                                 & (IData)(__Vfunc___03683__25__s)))
                                                ? ((IData)(__Vfunc___03683__25__b) 
                                                   >> 8U)
                                                : (
                                                   (0x200U 
                                                    == 
                                                    (0x200U 
                                                     & (IData)(__Vfunc___03683__25__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03683__25__b) 
                                                    >> 9U)
                                                    : 
                                                   ((0x400U 
                                                     == 
                                                     (0x400U 
                                                      & (IData)(__Vfunc___03683__25__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03683__25__b) 
                                                     >> 0xaU)
                                                     : 
                                                    ((0x800U 
                                                      == 
                                                      (0x800U 
                                                       & (IData)(__Vfunc___03683__25__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03683__25__b) 
                                                      >> 0xbU)
                                                      : (IData)(
                                                                (((IData)(__Vfunc___03683__25__s) 
                                                                  & (IData)(__Vfunc___03683__25__b)) 
                                                                 >> 0xcU))))))));
    vlSelf->__PVT___263_ = __Vfunc___03683__25__Vfuncout;
    __Vfunc___03714__42__s = (1U == (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)));
    __Vfunc___03714__42__b = ((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                               ? 0U : (0xffU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)));
    __Vfunc___03714__42__Vfuncout = ((IData)(__Vfunc___03714__42__s)
                                      ? (IData)(__Vfunc___03714__42__b)
                                      : 0U);
    vlSelf->__PVT___286_ = __Vfunc___03714__42__Vfuncout;
    __Vfunc___03369__0__s = (((0x1ffeU == (0x1fffU 
                                           & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                              << 2U) | (((0x1ffdU == 
                                          (0x1fffU 
                                           & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                         << 1U) | (0x1ffcU 
                                                   == 
                                                   (0x1fffU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))));
    __Vfunc___03369__0__Vfuncout = (1U == (1U & (IData)(__Vfunc___03369__0__s)));
    vlSelf->__PVT___101_ = __Vfunc___03369__0__Vfuncout;
    __Vfunc___03372__1__s = (((0x1ffeU == (0x1fffU 
                                           & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                              << 2U) | (((0x1ffdU == 
                                          (0x1fffU 
                                           & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                         << 1U) | (0x1ffcU 
                                                   == 
                                                   (0x1fffU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))));
    __Vfunc___03372__1__Vfuncout = (IData)((((IData)(__Vfunc___03372__1__s) 
                                             >> 1U) 
                                            & (1U != 
                                               (1U 
                                                & (IData)(__Vfunc___03372__1__s)))));
    vlSelf->__PVT___102_ = __Vfunc___03372__1__Vfuncout;
    __Vfunc___03375__2__s = (((0x1ffeU == (0x1fffU 
                                           & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                              << 2U) | (((0x1ffdU == 
                                          (0x1fffU 
                                           & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                         << 1U) | (0x1ffcU 
                                                   == 
                                                   (0x1fffU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))));
    __Vfunc___03375__2__Vfuncout = ((1U != (1U & (IData)(__Vfunc___03375__2__s))) 
                                    & (IData)((((IData)(__Vfunc___03375__2__s) 
                                                >> 2U) 
                                               & (2U 
                                                  != 
                                                  (2U 
                                                   & (IData)(__Vfunc___03375__2__s))))));
    vlSelf->__PVT___103_ = __Vfunc___03375__2__Vfuncout;
    __Vfunc___03691__30__s = (((0xeU == (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                               << 0xcU) | (((0xbU == 
                                             (0xfU 
                                              & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                            << 0xbU) 
                                           | (((0xaU 
                                                == 
                                                (0xfU 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                               << 0xaU) 
                                              | (((9U 
                                                   == 
                                                   (0xfU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                  << 9U) 
                                                 | (((8U 
                                                      == 
                                                      (0xfU 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                     << 8U) 
                                                    | (((7U 
                                                         == 
                                                         (0xfU 
                                                          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                        << 7U) 
                                                       | (((6U 
                                                            == 
                                                            (0xfU 
                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                           << 6U) 
                                                          | (((5U 
                                                               == 
                                                               (0xfU 
                                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                              << 5U) 
                                                             | (((4U 
                                                                  == 
                                                                  (0xfU 
                                                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                 << 4U) 
                                                                | (((3U 
                                                                     == 
                                                                     (0xfU 
                                                                      & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                    << 3U) 
                                                                   | (((2U 
                                                                        == 
                                                                        (0xfU 
                                                                         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                       << 2U) 
                                                                      | (((1U 
                                                                           == 
                                                                           (0xfU 
                                                                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                          << 1U) 
                                                                         | (0U 
                                                                            == 
                                                                            (0xfU 
                                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))))))))))))));
    __Vfunc___03691__30__Vfuncout = (1U & ((~ (((((
                                                   (((1U 
                                                      == 
                                                      (1U 
                                                       & (IData)(__Vfunc___03691__30__s))) 
                                                     | (2U 
                                                        == 
                                                        (2U 
                                                         & (IData)(__Vfunc___03691__30__s)))) 
                                                    | (4U 
                                                       == 
                                                       (4U 
                                                        & (IData)(__Vfunc___03691__30__s)))) 
                                                   | (8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03691__30__s)))) 
                                                  | (0x10U 
                                                     == 
                                                     (0x10U 
                                                      & (IData)(__Vfunc___03691__30__s)))) 
                                                 | (0x20U 
                                                    == 
                                                    (0x20U 
                                                     & (IData)(__Vfunc___03691__30__s)))) 
                                                | (0x40U 
                                                   == 
                                                   (0x40U 
                                                    & (IData)(__Vfunc___03691__30__s)))) 
                                               | (0x80U 
                                                  == 
                                                  (0x80U 
                                                   & (IData)(__Vfunc___03691__30__s))))) 
                                           | ((1U == 
                                               (1U 
                                                & (IData)(__Vfunc___03691__30__s))) 
                                              | ((2U 
                                                  == 
                                                  (2U 
                                                   & (IData)(__Vfunc___03691__30__s))) 
                                                 | ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03691__30__s))) 
                                                    | ((8U 
                                                        == 
                                                        (8U 
                                                         & (IData)(__Vfunc___03691__30__s))) 
                                                       | ((0x10U 
                                                           == 
                                                           (0x10U 
                                                            & (IData)(__Vfunc___03691__30__s))) 
                                                          | ((0x20U 
                                                              == 
                                                              (0x20U 
                                                               & (IData)(__Vfunc___03691__30__s))) 
                                                             | (0x40U 
                                                                == 
                                                                (0x40U 
                                                                 & (IData)(__Vfunc___03691__30__s)))))))))));
    vlSelf->__PVT___269_ = __Vfunc___03691__30__Vfuncout;
    vlSelf->__PVT__io_decode_s = ((6U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                         >> 4U)) | (IData)(vlSelf->__PVT__inst_t80__DOT___63_));
    vlSelf->__PVT___226_ = (1U & VL_REDXOR_8((0x30U 
                                              & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_))));
    __Vfunc_inst_t80__DOT__u0__DOT____033959__81__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___459_;
    __Vfunc_inst_t80__DOT__u0__DOT____033959__81__b 
        = (1U & (~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)));
    __Vfunc_inst_t80__DOT__u0__DOT____033959__81__Vfuncout 
        = ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033959__81__s) 
           & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033959__81__b));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___460_ = __Vfunc_inst_t80__DOT__u0__DOT____033959__81__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033961__82__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___459_;
    __Vfunc_inst_t80__DOT__u0__DOT____033961__82__b 
        = (1U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_));
    __Vfunc_inst_t80__DOT__u0__DOT____033961__82__Vfuncout 
        = ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033961__82__s) 
           & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033961__82__b));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___461_ = __Vfunc_inst_t80__DOT__u0__DOT____033961__82__Vfuncout;
    vlSelf->__PVT__cache_rom_rd_s = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                      >> 0xfU) & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT___61_)) 
                                                  & (IData)(vlSelf->__PVT___043_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___604_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___711_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___756_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__auto_wait 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___711_) 
           & (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__s 
        = (((5U == (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))) 
            << 3U) | (((4U == (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))) 
                       << 2U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___033_) 
                                  << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___026_))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__s)))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___040_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__Vfuncout;
    if (vlSelf->__PVT__inst_t80__DOT__u0__DOT___806_) {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___135_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___621_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0544_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0515_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0543_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0514_;
    } else {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___135_ = 0U;
        if (vlSelf->__PVT__inst_t80__DOT__u0__DOT___804_) {
            vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0544_ 
                = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0526_;
            vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0543_ 
                = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0525_;
        } else {
            vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0544_ = 0U;
            vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0543_ = 0U;
        }
    }
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___233_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___082_) 
         & (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036983__366__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036983__366__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036983__366__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036983__366__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0919_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036983__366__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037192__372__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037192__372__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037192__372__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037192__372__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1049_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037192__372__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037496__384__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037496__384__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037496__384__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037496__384__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1230_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037496__384__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037705__390__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037705__390__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037705__390__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037705__390__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1360_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037705__390__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037768__396__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037768__396__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037768__396__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037768__396__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1391_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037768__396__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037977__402__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037977__402__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037977__402__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037977__402__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1521_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037977__402__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036978__364__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036978__364__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036978__364__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036978__364__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0917_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036978__364__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037187__370__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037187__370__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037187__370__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037187__370__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1047_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037187__370__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037491__382__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037491__382__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037491__382__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037491__382__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1228_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037491__382__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037700__388__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037700__388__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037700__388__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037700__388__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1358_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037700__388__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037763__394__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037763__394__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037763__394__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037763__394__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1389_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037763__394__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037972__400__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037972__400__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037972__400__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037972__400__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1519_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037972__400__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__b 
        = (0x80U | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                               << 5U)) | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__b) 
                                         >> 8U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0918_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__b 
        = (0x80U | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                               << 5U)) | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__b) 
                                         >> 8U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1048_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__b 
        = (0x90U | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                          >> 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__b) 
                           >> 4U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1076_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__b 
        = (0x90U | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                          >> 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__b) 
                           >> 4U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1200_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__b 
        = (0xa0U | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                               << 5U)) | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__b) 
                                         >> 8U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1229_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__b 
        = (0xa0U | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                               << 5U)) | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__b) 
                                         >> 8U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1359_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__b 
        = (0xb0U | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                               << 5U)) | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__b) 
                                         >> 8U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1390_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__b 
        = (0xb0U | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                               << 5U)) | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__b) 
                                         >> 8U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1520_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036990__368__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036990__368__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036990__368__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036990__368__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036990__368__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0921_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036990__368__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037199__374__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037199__374__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037199__374__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037199__374__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037199__374__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1051_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037199__374__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037503__386__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037503__386__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037503__386__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037503__386__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037503__386__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1232_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037503__386__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037712__392__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037712__392__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037712__392__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037712__392__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037712__392__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1362_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037712__392__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037775__398__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037775__398__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037775__398__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037775__398__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037775__398__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1393_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037775__398__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037984__404__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037984__404__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037984__404__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037984__404__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037984__404__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1523_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037984__404__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036987__367__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036987__367__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036987__367__s)))
            ? 2U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036987__367__s)))
                     ? 2U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0920_ 
        = vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036987__367__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037196__373__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037196__373__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037196__373__s)))
            ? 2U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037196__373__s)))
                     ? 2U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1050_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037196__373__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037246__377__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037246__377__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037246__377__s)))
            ? 2U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1077_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037246__377__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037440__380__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037440__380__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037440__380__s)))
            ? 2U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1201_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037440__380__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037500__385__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037500__385__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037500__385__s)))
            ? 2U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037500__385__s)))
                     ? 2U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1231_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037500__385__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037709__391__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037709__391__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037709__391__s)))
            ? 2U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037709__391__s)))
                     ? 2U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1361_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037709__391__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037772__397__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037772__397__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037772__397__s)))
            ? 2U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037772__397__s)))
                     ? 2U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1392_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037772__397__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037981__403__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037981__403__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037981__403__s)))
            ? 2U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037981__403__s)))
                     ? 2U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1522_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037981__403__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__b 
        = (0x20U | ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 6U) | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                             ? 4U : 3U)));
    if ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))) {
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__a = 4U;
    } else {
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__a = 3U;
    }
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0916_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036975__363__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__b 
        = (0x20U | ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 6U) | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                             ? 4U : 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1046_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037184__369__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__b 
        = (0x20U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                     ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1075_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037241__375__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__b 
        = (0x20U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                     ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1199_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037435__378__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__b 
        = (0x20U | ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 6U) | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                             ? 4U : 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1227_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037488__381__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__b 
        = (0x20U | ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 6U) | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                             ? 4U : 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1357_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037697__387__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__b 
        = (0x20U | ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 6U) | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                             ? 4U : 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1388_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037760__393__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__b 
        = (0x20U | ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 6U) | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                             ? 4U : 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1518_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037969__399__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__b 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0628_) 
           << 1U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0632_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0205_) 
            << 9U) | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0201_) 
                      << 6U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__Vfuncout 
        = (7U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b) 
                                                >> 9U))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b)
                                             : 0U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1920_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0205_) 
            << 3U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0201_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__b) 
                         >> 3U) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0210_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__b 
        = (0xd8U | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0791_)
                     ? 3U : 1U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__b) 
                                       >> 6U) : 3U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0797_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__b 
        = (0x1e8U | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0791_)
                      ? 5U : 7U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__b) 
                                       >> 6U) : 7U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0800_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038888__451__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038888__451__Vfuncout 
        = (1U & (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038888__451__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2037_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038888__451__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038910__454__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038910__454__Vfuncout 
        = (1U & (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038910__454__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2046_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038910__454__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038970__466__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038970__466__Vfuncout 
        = (1U & (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038970__466__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2071_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038970__466__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038992__469__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038992__469__Vfuncout 
        = (1U & (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038992__469__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2080_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038992__469__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038883__449__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038883__449__Vfuncout 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038883__449__s;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2035_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038883__449__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038905__452__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038905__452__Vfuncout 
        = (1U & (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038905__452__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2044_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038905__452__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038965__464__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038965__464__Vfuncout 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038965__464__s;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2069_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038965__464__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038987__467__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038987__467__Vfuncout 
        = (1U & (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038987__467__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2078_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038987__467__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__b 
        = (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 4U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__Vfuncout 
        = ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__s)
            ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__b)
            : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2036_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__b 
        = (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 4U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__Vfuncout 
        = ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__s)
            ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__b)
            : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2045_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__b 
        = (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 4U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__Vfuncout 
        = ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__s)
            ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__b)
            : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2070_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__b 
        = (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 4U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__Vfuncout 
        = ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__s)
            ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__b)
            : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2079_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035928__218__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035928__218__Vfuncout 
        = (1U & (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035928__218__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0560_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035928__218__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035950__221__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035950__221__Vfuncout 
        = (1U & (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035950__221__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0569_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035950__221__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035923__216__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035923__216__Vfuncout 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035923__216__s;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0558_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035923__216__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035945__219__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035945__219__Vfuncout 
        = (1U & (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035945__219__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0567_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035945__219__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__b 
        = (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 4U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__Vfuncout 
        = ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__s)
            ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__b)
            : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0559_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__b 
        = (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 4U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__Vfuncout 
        = ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__s)
            ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__b)
            : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0568_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b 
        = (0xb45U | (((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0736_)
                       ? 5U : 3U) << 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__Vfuncout 
        = (7U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b) 
                                                >> 9U))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b)
                                             : 5U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0745_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b 
        = (0xf47U | (((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0736_)
                       ? 5U : 7U) << 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__Vfuncout 
        = (7U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b) 
                                                >> 9U))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b)
                                             : 7U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0750_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b 
        = (0xc00U | (((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0736_)
                       ? 0xdU : 0U) << 4U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__Vfuncout 
        = (0xfU & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                    ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b) 
                                                  >> 0xcU))))
                    : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b)
                                               : 0U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0749_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b 
        = (0xf00U | (((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0736_)
                       ? 0xfU : 0U) << 4U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__Vfuncout 
        = (0xfU & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                    ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b) 
                                                  >> 0xcU))))
                    : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b)
                                               : 0U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0748_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b 
        = ((0xfc0U & ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                         ? 4U : 3U) << 9U) | (((1U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                ? 4U
                                                : 3U) 
                                              << 6U))) 
           | ((((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0736_)
                 ? 4U : ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                          ? 4U : 3U)) << 3U) | ((1U 
                                                 == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                 ? 4U
                                                 : 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__Vfuncout 
        = (7U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b) 
                                                >> 9U))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b)
                                             : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__a))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0746_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1040_ 
        = ((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1559_) 
           | ((7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x10U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x11U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x12U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x13U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0x14U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | ((0x15U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                | ((0x17U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                   | ((8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                      | ((9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                         | ((0xaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                            | ((0xbU 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               | ((0xcU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  | ((0xdU 
                                                      == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                     | ((0xfU 
                                                         == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                        | ((0x18U 
                                                            == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                           | ((0x19U 
                                                               == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                              | ((0x1aU 
                                                                  == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                 | ((0x1bU 
                                                                     == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                    | ((0x1cU 
                                                                        == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                       | ((0x1dU 
                                                                           == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                          | ((0x1fU 
                                                                              == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                             | ((0x20U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x21U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x22U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x23U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x24U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x25U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x27U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x28U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x29U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x2aU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x2bU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x2cU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x2dU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x2fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x30U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x31U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x32U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x33U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x34U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x35U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x37U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x38U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x39U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x3aU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x3bU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x3cU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x3dU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | (0x3fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))))))))))))))))))))))))))))))))))))))))))))))))))));
    __Vdeeptemp_hed498a0d__0 = ((0x38U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                | ((0x39U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                   | ((0x3aU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                      | ((0x3bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                         | ((0x3cU 
                                             == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                            | ((0x3dU 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               | ((0x3eU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  | ((0x3fU 
                                                      == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                     | ((0x80U 
                                                         == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                        | ((0x81U 
                                                            == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                           | ((0x82U 
                                                               == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                              | ((0x83U 
                                                                  == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                 | ((0x84U 
                                                                     == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                    | ((0x85U 
                                                                        == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                       | ((0x86U 
                                                                           == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                          | ((0x87U 
                                                                              == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                             | ((0x88U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x89U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x8aU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x8bU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x8cU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x8dU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x8eU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x8fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x90U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x91U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x92U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x93U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x94U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x95U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x96U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x97U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x98U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x99U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x9aU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x9bU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x9cU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x9dU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x9eU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x9fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa4U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa5U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa6U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa7U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xacU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xadU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xaeU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xafU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb4U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb5U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb6U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb7U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xbcU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xbdU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xbeU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xbfU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xc0U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xc1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xc2U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xc3U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xc4U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xc5U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xc6U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xc7U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xc8U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xc9U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xcaU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xcbU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xccU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xcdU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xceU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xcfU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xd0U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xd1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xd2U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xd3U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xd4U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xd5U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xd6U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xd7U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xd8U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xd9U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xdaU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xdbU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xdcU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xddU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xdeU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xdfU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe0U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe2U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe3U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe4U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe5U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe6U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe7U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe8U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe9U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xeaU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xebU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xecU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xedU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xeeU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xefU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf0U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf2U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf3U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf4U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf5U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf6U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf7U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf8U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf9U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xfaU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xfbU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xfcU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xfdU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xfeU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | (0xffU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_ 
        = ((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1559_) 
           | ((6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0xaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0xbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | ((0xcU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                | ((0xdU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                   | ((0xeU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                      | ((0xfU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                         | ((0x10U 
                                             == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                            | ((0x11U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               | ((0x12U 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  | ((0x13U 
                                                      == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                     | ((0x14U 
                                                         == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                        | ((0x15U 
                                                            == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                           | ((0x16U 
                                                               == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                              | ((0x17U 
                                                                  == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                 | ((0x18U 
                                                                     == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                    | ((0x19U 
                                                                        == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                       | ((0x1aU 
                                                                           == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                          | ((0x1bU 
                                                                              == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                             | ((0x1cU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x1dU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x1eU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x1fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x20U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x21U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x22U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x23U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x24U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x25U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x26U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x27U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x28U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x29U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x2aU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x2bU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x2cU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x2dU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x2eU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x2fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x30U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x31U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x32U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x33U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x34U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x35U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x36U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x37U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | __Vdeeptemp_hed498a0d__0)))))))))))))))))))))))))))))))))))))))))))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1194_ 
        = ((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1166_) 
           | ((0x70U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x71U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x72U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x73U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x74U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0x75U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | ((0x77U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                | (IData)(__VdfgTmp_h8a4cccd7__0)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0098_ 
        = ((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1166_) 
           | (IData)(__VdfgTmp_h8a4cccd7__0));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_ 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2019_) 
           | (IData)(vlSelf->__VdfgTmp_hc027efeb__0));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1212_ 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2019_) 
           | ((0x56U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x5eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (IData)(vlSelf->__VdfgTmp_hc027efeb__0))));
    vlSelf->__PVT__io_wr_s = ((~ (IData)(vlSelf->__PVT__inst_t80__DOT___63_)) 
                              & (IData)(vlSelf->__PVT___181_));
    vlSelf->__PVT___150_ = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                             >> 7U) & (IData)(vlSelf->__PVT___181_));
    __Vfunc___03719__43__s = (((3U == (0xfU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 4U))) 
                               << 1U) | (5U == (0xfU 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                   >> 4U))));
    __Vfunc___03719__43__b = vlSelf->__PVT___262_;
    __Vfunc___03719__43__Vfuncout = (1U & ((1U == (1U 
                                                   & (IData)(__Vfunc___03719__43__s)))
                                            ? (IData)(__Vfunc___03719__43__b)
                                            : (IData)(
                                                      (((IData)(__Vfunc___03719__43__s) 
                                                        & (IData)(__Vfunc___03719__43__b)) 
                                                       >> 1U))));
    vlSelf->__PVT___288_ = __Vfunc___03719__43__Vfuncout;
    __Vfunc___03721__44__s = (((3U == (0xfU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 4U))) 
                               << 1U) | (5U == (0xfU 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                   >> 4U))));
    __Vfunc___03721__44__b = vlSelf->__PVT___263_;
    __Vfunc___03721__44__Vfuncout = (1U & ((1U == (1U 
                                                   & (IData)(__Vfunc___03721__44__s)))
                                            ? (IData)(__Vfunc___03721__44__b)
                                            : (IData)(
                                                      (((IData)(__Vfunc___03721__44__s) 
                                                        & (IData)(__Vfunc___03721__44__b)) 
                                                       >> 1U))));
    vlSelf->__PVT___290_ = __Vfunc___03721__44__Vfuncout;
    __Vfunc___03728__49__s = (((3U == (0xfU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 4U))) 
                               << 1U) | (5U == (0xfU 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                   >> 4U))));
    __Vfunc___03728__49__b = (2U | (IData)(vlSelf->__PVT___269_));
    __Vfunc___03728__49__Vfuncout = (1U & ((1U == (1U 
                                                   & (IData)(__Vfunc___03728__49__s)))
                                            ? (IData)(__Vfunc___03728__49__b)
                                            : ((2U 
                                                != 
                                                (2U 
                                                 & (IData)(__Vfunc___03728__49__s))) 
                                               | ((IData)(__Vfunc___03728__49__b) 
                                                  >> 1U))));
    vlSelf->__PVT___295_ = __Vfunc___03728__49__Vfuncout;
    __Vfunc___03503__17__s = (((6U == (IData)(vlSelf->__PVT__io_decode_s)) 
                               << 5U) | (((4U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                          << 4U) | 
                                         (((3U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                           << 3U) | 
                                          (((2U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                            << 2U) 
                                           | (((1U 
                                                == (IData)(vlSelf->__PVT__io_decode_s)) 
                                               << 1U) 
                                              | (0U 
                                                 == (IData)(vlSelf->__PVT__io_decode_s)))))));
    __Vfunc___03503__17__Vfuncout = (1U & ((0x20U & (IData)(__Vfunc___03503__17__s))
                                            ? ((0x10U 
                                                & (IData)(__Vfunc___03503__17__s))
                                                ? (IData)(
                                                          (8U 
                                                           != 
                                                           (0xfU 
                                                            & (IData)(__Vfunc___03503__17__s))))
                                                : (IData)(
                                                          (8U 
                                                           != 
                                                           (0xfU 
                                                            & (IData)(__Vfunc___03503__17__s)))))
                                            : ((0x10U 
                                                & (IData)(__Vfunc___03503__17__s))
                                                ? (IData)(
                                                          (8U 
                                                           != 
                                                           (0xfU 
                                                            & (IData)(__Vfunc___03503__17__s))))
                                                : (IData)(
                                                          (8U 
                                                           != 
                                                           (0xfU 
                                                            & (IData)(__Vfunc___03503__17__s)))))));
    vlSelf->__PVT___161_ = __Vfunc___03503__17__Vfuncout;
    __Vfunc___03506__18__s = (((6U == (IData)(vlSelf->__PVT__io_decode_s)) 
                               << 5U) | (((4U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                          << 4U) | 
                                         (((3U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                           << 3U) | 
                                          (((2U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                            << 2U) 
                                           | (((1U 
                                                == (IData)(vlSelf->__PVT__io_decode_s)) 
                                               << 1U) 
                                              | (0U 
                                                 == (IData)(vlSelf->__PVT__io_decode_s)))))));
    __Vfunc___03506__18__Vfuncout = (1U & ((0x20U & (IData)(__Vfunc___03506__18__s))
                                            ? ((0x10U 
                                                & (IData)(__Vfunc___03506__18__s))
                                                ? (
                                                   (8U 
                                                    & (IData)(__Vfunc___03506__18__s))
                                                    ? (IData)(
                                                              (4U 
                                                               != 
                                                               (7U 
                                                                & (IData)(__Vfunc___03506__18__s))))
                                                    : (IData)(
                                                              (4U 
                                                               != 
                                                               (7U 
                                                                & (IData)(__Vfunc___03506__18__s)))))
                                                : (
                                                   (8U 
                                                    & (IData)(__Vfunc___03506__18__s))
                                                    ? (IData)(
                                                              (4U 
                                                               != 
                                                               (7U 
                                                                & (IData)(__Vfunc___03506__18__s))))
                                                    : (IData)(
                                                              (4U 
                                                               != 
                                                               (7U 
                                                                & (IData)(__Vfunc___03506__18__s))))))
                                            : ((0x10U 
                                                & (IData)(__Vfunc___03506__18__s))
                                                ? (
                                                   (8U 
                                                    & (IData)(__Vfunc___03506__18__s))
                                                    ? (IData)(
                                                              (4U 
                                                               != 
                                                               (7U 
                                                                & (IData)(__Vfunc___03506__18__s))))
                                                    : (IData)(
                                                              (4U 
                                                               != 
                                                               (7U 
                                                                & (IData)(__Vfunc___03506__18__s)))))
                                                : (
                                                   (8U 
                                                    & (IData)(__Vfunc___03506__18__s))
                                                    ? (IData)(
                                                              (4U 
                                                               != 
                                                               (7U 
                                                                & (IData)(__Vfunc___03506__18__s))))
                                                    : (IData)(
                                                              (4U 
                                                               != 
                                                               (7U 
                                                                & (IData)(__Vfunc___03506__18__s))))))));
    vlSelf->__PVT___162_ = __Vfunc___03506__18__Vfuncout;
    __Vfunc___03509__19__s = (((6U == (IData)(vlSelf->__PVT__io_decode_s)) 
                               << 5U) | (((4U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                          << 4U) | 
                                         (((3U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                           << 3U) | 
                                          (((2U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                            << 2U) 
                                           | (((1U 
                                                == (IData)(vlSelf->__PVT__io_decode_s)) 
                                               << 1U) 
                                              | (0U 
                                                 == (IData)(vlSelf->__PVT__io_decode_s)))))));
    __Vfunc___03509__19__Vfuncout = (IData)((0x20U 
                                             != (IData)(__Vfunc___03509__19__s)));
    vlSelf->__PVT___163_ = __Vfunc___03509__19__Vfuncout;
    __Vfunc___03513__21__s = (((6U == (IData)(vlSelf->__PVT__io_decode_s)) 
                               << 5U) | (((4U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                          << 4U) | 
                                         (((3U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                           << 3U) | 
                                          (((2U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                            << 2U) 
                                           | (((1U 
                                                == (IData)(vlSelf->__PVT__io_decode_s)) 
                                               << 1U) 
                                              | (0U 
                                                 == (IData)(vlSelf->__PVT__io_decode_s)))))));
    __Vfunc___03513__21__Vfuncout = (1U & ((0x20U & (IData)(__Vfunc___03513__21__s))
                                            ? ((0x10U 
                                                & (IData)(__Vfunc___03513__21__s))
                                                ? (
                                                   (8U 
                                                    & (IData)(__Vfunc___03513__21__s))
                                                    ? 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03513__21__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s))))
                                                    : 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03513__21__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s)))))
                                                : (
                                                   (8U 
                                                    & (IData)(__Vfunc___03513__21__s))
                                                    ? 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03513__21__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s))))
                                                    : 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03513__21__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s))))))
                                            : ((0x10U 
                                                & (IData)(__Vfunc___03513__21__s))
                                                ? (
                                                   (8U 
                                                    & (IData)(__Vfunc___03513__21__s))
                                                    ? 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03513__21__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s))))
                                                    : 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03513__21__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s)))))
                                                : (
                                                   (8U 
                                                    & (IData)(__Vfunc___03513__21__s))
                                                    ? 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03513__21__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s))))
                                                    : 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03513__21__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s))))))));
    vlSelf->__PVT___165_ = __Vfunc___03513__21__Vfuncout;
    __Vfunc___03516__22__s = (((6U == (IData)(vlSelf->__PVT__io_decode_s)) 
                               << 5U) | (((4U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                          << 4U) | 
                                         (((3U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                           << 3U) | 
                                          (((2U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                            << 2U) 
                                           | (((1U 
                                                == (IData)(vlSelf->__PVT__io_decode_s)) 
                                               << 1U) 
                                              | (0U 
                                                 == (IData)(vlSelf->__PVT__io_decode_s)))))));
    __Vfunc___03516__22__Vfuncout = (1U & ((0x20U & (IData)(__Vfunc___03516__22__s))
                                            ? (IData)(
                                                      (0x10U 
                                                       != 
                                                       (0x1fU 
                                                        & (IData)(__Vfunc___03516__22__s))))
                                            : (IData)(
                                                      (0x10U 
                                                       != 
                                                       (0x1fU 
                                                        & (IData)(__Vfunc___03516__22__s))))));
    vlSelf->__PVT___166_ = __Vfunc___03516__22__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s 
        = (((8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
            << 6U) | (((0xbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                       << 5U) | (((0xaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                  << 4U) | (((9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                             << 3U) 
                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___137_) 
                                                << 2U) 
                                               | (((0xcU 
                                                    == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___086_)))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b 
        = ((0x20U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                     << 4U)) | ((0x10U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                          << 3U)) | 
                                ((2U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)) 
                                 | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___040_))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__a 
        = (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                 >> 1U));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__Vfuncout 
        = (1U & ((0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                  ? ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 6U)))))))
                  : ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__b)
                                          : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__a)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___177_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310256__93__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___119_ = 
        (0x7fU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___726_) 
                  + (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___233_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2046_) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2037_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2053_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038927__460__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2080_) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2071_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2087_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039009__475__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2044_) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2035_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2051_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038923__458__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2078_) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2069_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2085_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039005__473__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2045_) 
            << 2U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2036_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__Vfuncout 
        = (3U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__b) 
                         >> 2U) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2052_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038925__459__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2079_) 
            << 2U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2070_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__Vfuncout 
        = (3U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__b) 
                         >> 2U) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2086_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039007__474__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0569_) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0560_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0576_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035967__227__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0567_) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0558_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0574_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035963__225__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0568_) 
            << 2U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0559_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__Vfuncout 
        = (3U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__b) 
                         >> 2U) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0575_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035965__226__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__Vfuncout 
        = (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s)) 
                  | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
                 | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
                | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
               | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
              | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
             | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
            | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s)))
            ? 3U : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s)) 
                           | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
                          | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
                         | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
                        | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
                       | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
                      | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))) 
                     | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s)))
                     ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                         ? 3U : ((0x200U == (0x200U 
                                             & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                                  ? 3U : ((0x400U == 
                                           (0x400U 
                                            & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                                           ? 3U : (
                                                   (0x800U 
                                                    == 
                                                    (0x800U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                                                    ? 0U
                                                    : 
                                                   ((0x1000U 
                                                     == 
                                                     (0x1000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                                                     ? 1U
                                                     : 
                                                    ((0x2000U 
                                                      == 
                                                      (0x2000U 
                                                       & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                                                      ? 2U
                                                      : 3U))))))
                     : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                         ? 3U : ((0x20000U == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                                  ? 3U : ((0x40000U 
                                           == (0x40000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                                           ? 3U : (
                                                   (0x80000U 
                                                    == 
                                                    (0x80000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                                                    ? 3U
                                                    : 
                                                   ((0x100000U 
                                                     == 
                                                     (0x100000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                                                     ? 3U
                                                     : 
                                                    ((0x200000U 
                                                      == 
                                                      (0x200000U 
                                                       & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                                                      ? 3U
                                                      : 
                                                     ((0x400000U 
                                                       == 
                                                       (0x400000U 
                                                        & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__s))
                                                       ? 3U
                                                       : 0U)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2278_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039530__568__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__Vfuncout 
        = (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s)) 
                  | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
                 | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
                | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
               | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
              | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
             | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
            | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s)))
            ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                ? 1U : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                         ? 1U : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                  ? 1U : ((8U == (8U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                           ? 1U : (
                                                   (0x10U 
                                                    == 
                                                    (0x10U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                                    ? 1U
                                                    : 
                                                   ((0x20U 
                                                     == 
                                                     (0x20U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                                     ? 1U
                                                     : 5U))))))
            : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s)) 
                      | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
                     | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
                    | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
                   | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
                  | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
                 | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))) 
                | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s)))
                ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                    ? 4U : ((0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                             ? 4U : ((0x400U == (0x400U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                      ? 1U : ((0x800U 
                                               == (0x800U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                               ? 1U
                                               : ((0x1000U 
                                                   == 
                                                   (0x1000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                                   ? 1U
                                                   : 
                                                  ((0x2000U 
                                                    == 
                                                    (0x2000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                                    ? 1U
                                                    : 3U))))))
                : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                    ? 4U : ((0x20000U == (0x20000U 
                                          & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                             ? 4U : ((0x40000U == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                      ? 3U : ((0x80000U 
                                               == (0x80000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                               ? 2U
                                               : ((0x100000U 
                                                   == 
                                                   (0x100000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                                   ? 2U
                                                   : 
                                                  ((0x200000U 
                                                    == 
                                                    (0x200000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                                    ? 4U
                                                    : 
                                                   ((0x400000U 
                                                     == 
                                                     (0x400000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__s))
                                                     ? 4U
                                                     : 0U)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2249_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039401__539__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1989_) 
           << 9U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2262_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039474__552__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__Vfuncout 
        = ((~ ((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s)) 
                     | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
                    | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
                   | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
                  | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
                 | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
                | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
               | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s)))) 
           & (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s)) 
                     | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
                    | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
                   | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
                  | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
                 | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
                | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
               | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s))) 
              & ((0x100U != (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s)) 
                 & (IData)(((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s 
                             >> 0xaU) & (0x200U != 
                                         (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2255_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039423__545__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1991_) 
           << 9U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2264_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039481__554__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
        = (0x400U | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2236_) 
                      << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2211_) 
                                    << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2120_) 
                                                  << 0x11U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2106_) 
                                                     << 0x10U) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2089_) 
                                                        << 0xfU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2055_) 
                                                           << 0xeU) 
                                                          | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1990_) 
                                                             << 9U))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2263_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039478__553__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1945_) 
            << 7U) | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1924_) 
                      << 6U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2269_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039496__559__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2131_) 
            << 0x12U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1944_) 
                          << 7U) | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1923_) 
                                    << 6U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2268_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039493__558__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2232_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2207_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2154_) 
                                        << 0x13U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2116_) 
                                         << 0x11U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2102_) 
                                            << 0x10U) 
                                           | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2083_) 
                                               << 0xfU) 
                                              | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2049_) 
                                                  << 0xeU) 
                                                 | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1919_) 
                                                    << 6U))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2254_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039419__544__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2239_) 
            << 0x16U) | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2214_) 
                         << 0x15U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2274_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039515__564__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2132_) 
           << 0x12U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2271_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039506__561__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1940_) 
            << 7U) | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1917_) 
                      << 6U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2251_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039410__541__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vtemp_1[0U] = (((IData)((((QData)((IData)((((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2235_) 
                                                  << 0x1cU) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2210_) 
                                                     << 0x18U) 
                                                    | ((0x700000U 
                                                        & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                           << 0x11U)) 
                                                       | ((0x70000U 
                                                           & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                              << 0xdU)) 
                                                          | ((0x7000U 
                                                              & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                 << 9U)) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2119_) 
                                                                 << 8U) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2105_) 
                                                                    << 4U) 
                                                                   | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2088_)))))))))) 
                                << 0x20U) | (QData)((IData)(
                                                            (0x2000U 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2054_) 
                                                                 << 0x1cU) 
                                                                | ((0x7000000U 
                                                                    & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                       << 0x15U)) 
                                                                   | ((0x700000U 
                                                                       & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                          << 0x11U)) 
                                                                      | ((0x70000U 
                                                                          & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                             << 0xdU)) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1988_) 
                                                                             << 8U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1966_) 
                                                                                << 4U) 
                                                                               | (7U 
                                                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                                >> 3U))))))))))))) 
                      << 0x1cU) | ((0x7000000U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                  << 0x15U)) 
                                   | ((0x700000U & 
                                       ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                        << 0x11U)) 
                                      | ((0x70000U 
                                          & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                             << 0xdU)) 
                                         | ((0x7000U 
                                             & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                << 9U)) 
                                            | ((0x700U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                   << 5U)) 
                                               | ((0x70U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                      << 1U)) 
                                                  | (7U 
                                                     & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                        >> 3U)))))))));
    __Vtemp_1[1U] = (((IData)((((QData)((IData)((((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2235_) 
                                                  << 0x1cU) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2210_) 
                                                     << 0x18U) 
                                                    | ((0x700000U 
                                                        & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                           << 0x11U)) 
                                                       | ((0x70000U 
                                                           & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                              << 0xdU)) 
                                                          | ((0x7000U 
                                                              & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                 << 9U)) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2119_) 
                                                                 << 8U) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2105_) 
                                                                    << 4U) 
                                                                   | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2088_)))))))))) 
                                << 0x20U) | (QData)((IData)(
                                                            (0x2000U 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2054_) 
                                                                 << 0x1cU) 
                                                                | ((0x7000000U 
                                                                    & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                       << 0x15U)) 
                                                                   | ((0x700000U 
                                                                       & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                          << 0x11U)) 
                                                                      | ((0x70000U 
                                                                          & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                             << 0xdU)) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1988_) 
                                                                             << 8U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1966_) 
                                                                                << 4U) 
                                                                               | (7U 
                                                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                                >> 3U))))))))))))) 
                      >> 4U) | ((IData)(((((QData)((IData)(
                                                           (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2235_) 
                                                             << 0x1cU) 
                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2210_) 
                                                                << 0x18U) 
                                                               | ((0x700000U 
                                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                      << 0x11U)) 
                                                                  | ((0x70000U 
                                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                         << 0xdU)) 
                                                                     | ((0x7000U 
                                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                            << 9U)) 
                                                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2119_) 
                                                                            << 8U) 
                                                                           | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2105_) 
                                                                               << 4U) 
                                                                              | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2088_)))))))))) 
                                           << 0x20U) 
                                          | (QData)((IData)(
                                                            (0x2000U 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2054_) 
                                                                 << 0x1cU) 
                                                                | ((0x7000000U 
                                                                    & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                       << 0x15U)) 
                                                                   | ((0x700000U 
                                                                       & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                          << 0x11U)) 
                                                                      | ((0x70000U 
                                                                          & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                             << 0xdU)) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1988_) 
                                                                             << 8U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1966_) 
                                                                                << 4U) 
                                                                               | (7U 
                                                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                                >> 3U)))))))))))) 
                                         >> 0x20U)) 
                                << 0x1cU));
    __Vtemp_1[2U] = ((IData)(((((QData)((IData)((((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2235_) 
                                                  << 0x1cU) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2210_) 
                                                     << 0x18U) 
                                                    | ((0x700000U 
                                                        & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                           << 0x11U)) 
                                                       | ((0x70000U 
                                                           & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                              << 0xdU)) 
                                                          | ((0x7000U 
                                                              & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                 << 9U)) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2119_) 
                                                                 << 8U) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2105_) 
                                                                    << 4U) 
                                                                   | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2088_)))))))))) 
                                << 0x20U) | (QData)((IData)(
                                                            (0x2000U 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2054_) 
                                                                 << 0x1cU) 
                                                                | ((0x7000000U 
                                                                    & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                       << 0x15U)) 
                                                                   | ((0x700000U 
                                                                       & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                          << 0x11U)) 
                                                                      | ((0x70000U 
                                                                          & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                             << 0xdU)) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1988_) 
                                                                             << 8U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1966_) 
                                                                                << 4U) 
                                                                               | (7U 
                                                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                                >> 3U)))))))))))) 
                              >> 0x20U)) >> 4U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
        = __Vtemp_1[0U];
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
        = __Vtemp_1[1U];
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
        = __Vtemp_1[2U];
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__Vfuncout 
        = (0xfU & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s)) 
                          | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                         | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                        | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                       | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                      | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                     | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                    | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s)))
                    ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                        ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U]
                        : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                            ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                << 0x1cU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                             >> 4U))
                            : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                    << 0x18U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                                 >> 8U))
                                : ((8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                    ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                        << 0x14U) | 
                                       (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                        >> 0xcU)) : 
                                   ((0x10U == (0x10U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                     ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                         << 0x10U) 
                                        | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                           >> 0x10U))
                                     : ((0x20U == (0x20U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                         ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                             << 0xcU) 
                                            | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                               >> 0x14U))
                                         : ((0x40U 
                                             == (0x40U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                             ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                                 << 8U) 
                                                | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                                   >> 0x18U))
                                             : ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                                 << 4U) 
                                                | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[0U] 
                                                   >> 0x1cU)))))))))
                    : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s)) 
                              | (0x200U == (0x200U 
                                            & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                             | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                            | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                           | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                          | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                         | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))) 
                        | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s)))
                        ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                            ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U]
                            : ((0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                    << 0x1cU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                                 >> 4U))
                                : ((0x400U == (0x400U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                    ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                        << 0x18U) | 
                                       (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                        >> 8U)) : (
                                                   (0x800U 
                                                    == 
                                                    (0x800U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                                    ? 
                                                   ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                                     << 0x14U) 
                                                    | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                                       >> 0xcU))
                                                    : 
                                                   ((0x1000U 
                                                     == 
                                                     (0x1000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                                     ? 
                                                    ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                                      << 0x10U) 
                                                     | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                                        >> 0x10U))
                                                     : 
                                                    ((0x2000U 
                                                      == 
                                                      (0x2000U 
                                                       & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                                      ? 
                                                     ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                                       << 0xcU) 
                                                      | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                                         >> 0x14U))
                                                      : 
                                                     ((0x4000U 
                                                       == 
                                                       (0x4000U 
                                                        & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                                       ? 
                                                      ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                                        << 8U) 
                                                       | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                                          >> 0x18U))
                                                       : 
                                                      ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                                        << 4U) 
                                                       | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[1U] 
                                                          >> 0x1cU)))))))))
                        : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                            ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U]
                            : ((0x20000U == (0x20000U 
                                             & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                    << 0x1cU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                                 >> 4U))
                                : ((0x40000U == (0x40000U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                    ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                        << 0x18U) | 
                                       (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                        >> 8U)) : (
                                                   (0x80000U 
                                                    == 
                                                    (0x80000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                                    ? 
                                                   ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                                     << 0x14U) 
                                                    | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                                       >> 0xcU))
                                                    : 
                                                   ((0x100000U 
                                                     == 
                                                     (0x100000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                                     ? 
                                                    ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                                      << 0x10U) 
                                                     | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                                        >> 0x10U))
                                                     : 
                                                    ((0x200000U 
                                                      == 
                                                      (0x200000U 
                                                       & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                                      ? 
                                                     ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                                       << 0xcU) 
                                                      | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                                         >> 0x14U))
                                                      : 
                                                     ((0x400000U 
                                                       == 
                                                       (0x400000U 
                                                        & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__s))
                                                       ? 
                                                      ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                                        << 8U) 
                                                       | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__b[2U] 
                                                          >> 0x18U))
                                                       : 0U))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2261_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039471__551__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2108_) 
           << 0x10U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2275_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039518__565__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2122_) 
           << 0x11U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2276_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039521__566__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2240_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2215_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2109_) 
                                        << 0x10U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2090_) 
                                         << 0xfU) | 
                                        (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2056_) 
                                          << 0xeU) 
                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1994_) 
                                             << 9U) 
                                            | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1969_) 
                                               << 8U)))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2279_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039533__569__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2238_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2213_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2182_) 
                                        << 0x14U) | 
                                       ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2157_) 
                                        << 0x13U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2266_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039487__556__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1993_) 
           << 9U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2273_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039512__563__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2130_) 
           << 0x12U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2267_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039490__557__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2241_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2216_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2183_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2123_) 
                                         << 0x11U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2110_) 
                                            << 0x10U) 
                                           | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1970_) 
                                               << 8U) 
                                              | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1946_) 
                                                 << 7U)))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2280_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039536__570__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1941_) 
            << 7U) | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1918_) 
                      << 6U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2252_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039413__542__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
        = (0x400U | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1921_) 
                     << 6U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2257_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039435__547__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
        = (IData)((0x80000000ULL | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2155_)) 
                                     << 0x39U) | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2117_)) 
                                                   << 0x33U) 
                                                  | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2103_)) 
                                                      << 0x30U) 
                                                     | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2084_)) 
                                                         << 0x2dU) 
                                                        | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2050_)) 
                                                            << 0x2aU) 
                                                           | (QData)((IData)(
                                                                             (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1986_) 
                                                                               << 0x1bU) 
                                                                              | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1964_) 
                                                                                << 0x18U) 
                                                                                | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1920_) 
                                                                                << 0x12U))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
        = (IData)(((0x80000000ULL | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2155_)) 
                                      << 0x39U) | (
                                                   ((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2117_)) 
                                                    << 0x33U) 
                                                   | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2103_)) 
                                                       << 0x30U) 
                                                      | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2084_)) 
                                                          << 0x2dU) 
                                                         | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2050_)) 
                                                             << 0x2aU) 
                                                            | (QData)((IData)(
                                                                              (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1986_) 
                                                                                << 0x1bU) 
                                                                               | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1964_) 
                                                                                << 0x18U) 
                                                                                | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1920_) 
                                                                                << 0x12U))))))))))) 
                   >> 0x20U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[2U] = 0U;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__Vfuncout 
        = (7U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U]
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                          ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                              << 0x1dU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                           >> 3U)) : 
                         ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                           ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                               << 0x1aU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                            >> 6U))
                           : ((8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                               ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                   << 0x17U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                                >> 9U))
                               : ((0x10U == (0x10U 
                                             & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                   ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                       << 0x14U) | 
                                      (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                       >> 0xcU)) : 
                                  ((0x20U == (0x20U 
                                              & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                    ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                        << 0x11U) | 
                                       (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                        >> 0xfU)) : 
                                   ((0x40U == (0x40U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                     ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                         << 0xeU) | 
                                        (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                         >> 0x12U))
                                     : ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                         << 0xbU) | 
                                        (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                         >> 0x15U)))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                          ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                              << 8U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                        >> 0x18U)) : 
                         ((0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                           ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                               << 5U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                         >> 0x1bU))
                           : ((0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                               ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                   << 2U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[0U] 
                                             >> 0x1eU))
                               : ((0x800U == (0x800U 
                                              & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                   ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                       << 0x1fU) | 
                                      (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                       >> 1U)) : ((0x1000U 
                                                   == 
                                                   (0x1000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                                   ? 
                                                  ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                                    << 0x1cU) 
                                                   | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                                      >> 4U))
                                                   : 
                                                  ((0x2000U 
                                                    == 
                                                    (0x2000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                                    ? 
                                                   ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                                     << 0x19U) 
                                                    | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                                       >> 7U))
                                                    : 
                                                   ((0x4000U 
                                                     == 
                                                     (0x4000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                                     ? 
                                                    ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                                      << 0x16U) 
                                                     | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                                        >> 0xaU))
                                                     : 
                                                    ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                                      << 0x13U) 
                                                     | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                                        >> 0xdU)))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                          ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                              << 0x10U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                           >> 0x10U))
                          : ((0x20000U == (0x20000U 
                                           & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                              ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                  << 0xdU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                              >> 0x13U))
                              : ((0x40000U == (0x40000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                  ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                      << 0xaU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                                  >> 0x16U))
                                  : ((0x80000U == (0x80000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                      ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                          << 7U) | 
                                         (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                          >> 0x19U))
                                      : ((0x100000U 
                                          == (0x100000U 
                                              & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                          ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                              << 4U) 
                                             | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                                >> 0x1cU))
                                          : ((0x200000U 
                                              == (0x200000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                              ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[2U] 
                                                  << 1U) 
                                                 | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[1U] 
                                                    >> 0x1fU))
                                              : ((0x400000U 
                                                  == 
                                                  (0x400000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__s))
                                                  ? 
                                                 ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[2U] 
                                                   << 0x1eU) 
                                                  | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__b[2U] 
                                                     >> 2U))
                                                  : 0U))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2256_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039429__546__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1968_) 
           << 8U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2272_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039509__562__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2158_) 
           << 0x13U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__Vfuncout 
        = (1U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                             >> 1U) : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                           >> 2U) : 
                                       ((8U == (8U 
                                                & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                            >> 3U) : 
                                        ((0x10U == 
                                          (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                             >> 4U)
                                          : ((0x20U 
                                              == (0x20U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                              ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                 >> 5U)
                                              : ((0x40U 
                                                  == 
                                                  (0x40U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                  >> 6U)
                                                  : 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                  >> 7U))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                             >> 8U) : ((0x200U == (0x200U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                        ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                           >> 9U) : 
                                       ((0x400U == 
                                         (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                         ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                            >> 0xaU)
                                         : ((0x800U 
                                             == (0x800U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                             ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                >> 0xbU)
                                             : ((0x1000U 
                                                 == 
                                                 (0x1000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                                 ? 
                                                (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                 >> 0xcU)
                                                 : 
                                                ((0x2000U 
                                                  == 
                                                  (0x2000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                                  ? 
                                                 (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                  >> 0xdU)
                                                  : 
                                                 ((0x4000U 
                                                   == 
                                                   (0x4000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                   >> 0xeU)
                                                   : 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                   >> 0xfU))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                          ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                             >> 0x10U) : ((0x20000U 
                                           == (0x20000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                           ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                              >> 0x11U)
                                           : ((0x40000U 
                                               == (0x40000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                               ? (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                  >> 0x12U)
                                               : ((0x80000U 
                                                   == 
                                                   (0x80000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                                   ? 
                                                  (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                   >> 0x13U)
                                                   : 
                                                  ((0x100000U 
                                                    == 
                                                    (0x100000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                                    ? 
                                                   (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                    >> 0x14U)
                                                    : 
                                                   ((0x200000U 
                                                     == 
                                                     (0x200000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s))
                                                     ? 
                                                    (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b 
                                                     >> 0x15U)
                                                     : (IData)(
                                                               ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__s 
                                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__b) 
                                                                >> 0x16U)))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2277_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039524__567__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
        = (IData)((0xffffc0000000ULL | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2181_)) 
                                         << 0x3cU) 
                                        | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2156_)) 
                                            << 0x39U) 
                                           | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2129_)) 
                                               << 0x36U) 
                                              | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2121_)) 
                                                  << 0x33U) 
                                                 | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2107_)) 
                                                     << 0x30U) 
                                                    | (QData)((IData)(
                                                                      (0x3ffffU 
                                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1992_) 
                                                                           << 0x1bU) 
                                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1967_) 
                                                                              << 0x18U) 
                                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1943_) 
                                                                                << 0x15U) 
                                                                                | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1922_) 
                                                                                << 0x12U))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2212_) 
            << 0x1fU) | (IData)(((0xffffc0000000ULL 
                                  | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2181_)) 
                                      << 0x3cU) | (
                                                   ((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2156_)) 
                                                    << 0x39U) 
                                                   | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2129_)) 
                                                       << 0x36U) 
                                                      | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2121_)) 
                                                          << 0x33U) 
                                                         | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2107_)) 
                                                             << 0x30U) 
                                                            | (QData)((IData)(
                                                                              (0x3ffffU 
                                                                               | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1992_) 
                                                                                << 0x1bU) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1967_) 
                                                                                << 0x18U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1943_) 
                                                                                << 0x15U) 
                                                                                | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1922_) 
                                                                                << 0x12U))))))))))))) 
                                 >> 0x20U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[2U] 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2237_) 
            << 2U) | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2212_) 
                      >> 1U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__Vfuncout 
        = (7U & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s)) 
                        | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                       | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                      | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                     | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                    | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                   | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                  | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s)))
                  ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                      ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U]
                      : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                          ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                              << 0x1dU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                           >> 3U)) : 
                         ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                           ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                               << 0x1aU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                            >> 6U))
                           : ((8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                               ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                   << 0x17U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                                >> 9U))
                               : ((0x10U == (0x10U 
                                             & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                   ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                       << 0x14U) | 
                                      (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                       >> 0xcU)) : 
                                  ((0x20U == (0x20U 
                                              & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                    ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                        << 0x11U) | 
                                       (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                        >> 0xfU)) : 
                                   ((0x40U == (0x40U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                     ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                         << 0xeU) | 
                                        (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                         >> 0x12U))
                                     : ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                         << 0xbU) | 
                                        (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                         >> 0x15U)))))))))
                  : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s)) 
                            | (0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                           | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                          | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                         | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                        | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                       | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))) 
                      | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s)))
                      ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                          ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                              << 8U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                        >> 0x18U)) : 
                         ((0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                           ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                               << 5U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                         >> 0x1bU))
                           : ((0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                               ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                   << 2U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[0U] 
                                             >> 0x1eU))
                               : ((0x800U == (0x800U 
                                              & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                   ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                       << 0x1fU) | 
                                      (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                       >> 1U)) : ((0x1000U 
                                                   == 
                                                   (0x1000U 
                                                    & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                                   ? 
                                                  ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                                    << 0x1cU) 
                                                   | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                                      >> 4U))
                                                   : 
                                                  ((0x2000U 
                                                    == 
                                                    (0x2000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                                    ? 
                                                   ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                                     << 0x19U) 
                                                    | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                                       >> 7U))
                                                    : 
                                                   ((0x4000U 
                                                     == 
                                                     (0x4000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                                     ? 
                                                    ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                                      << 0x16U) 
                                                     | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                                        >> 0xaU))
                                                     : 
                                                    ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                                      << 0x13U) 
                                                     | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                                        >> 0xdU)))))))))
                      : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                          ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                              << 0x10U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                           >> 0x10U))
                          : ((0x20000U == (0x20000U 
                                           & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                              ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                  << 0xdU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                              >> 0x13U))
                              : ((0x40000U == (0x40000U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                  ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                      << 0xaU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                                  >> 0x16U))
                                  : ((0x80000U == (0x80000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                      ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                          << 7U) | 
                                         (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                          >> 0x19U))
                                      : ((0x100000U 
                                          == (0x100000U 
                                              & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                          ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                              << 4U) 
                                             | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                                >> 0x1cU))
                                          : ((0x200000U 
                                              == (0x200000U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                              ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[2U] 
                                                  << 1U) 
                                                 | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[1U] 
                                                    >> 0x1fU))
                                              : ((0x400000U 
                                                  == 
                                                  (0x400000U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__s))
                                                  ? 
                                                 ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[2U] 
                                                   << 0x1eU) 
                                                  | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__b[2U] 
                                                     >> 2U))
                                                  : 0U))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2265_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039484__555__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
        = (IData)((((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1985_)) 
                    << 0x24U) | ((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1963_)) 
                                 << 0x20U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
        = (IData)(((((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1985_)) 
                     << 0x24U) | ((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1963_)) 
                                  << 0x20U)) >> 0x20U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2231_) 
            << 0x18U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2206_) 
                          << 0x14U) | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2128_) 
                                       << 8U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__Vfuncout 
        = (0xfU & (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s)) 
                          | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                         | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                        | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                       | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                      | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                     | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                    | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s)))
                    ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                        ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U]
                        : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                            ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                << 0x1cU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                             >> 4U))
                            : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                    << 0x18U) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                                 >> 8U))
                                : ((8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                    ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                        << 0x14U) | 
                                       (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                        >> 0xcU)) : 
                                   ((0x10U == (0x10U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                     ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                         << 0x10U) 
                                        | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                           >> 0x10U))
                                     : ((0x20U == (0x20U 
                                                   & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                         ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                             << 0xcU) 
                                            | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                               >> 0x14U))
                                         : ((0x40U 
                                             == (0x40U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                             ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                                 << 8U) 
                                                | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                                   >> 0x18U))
                                             : ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                                 << 4U) 
                                                | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[0U] 
                                                   >> 0x1cU)))))))))
                    : (((((((((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s)) 
                              | (0x200U == (0x200U 
                                            & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                             | (0x400U == (0x400U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                            | (0x800U == (0x800U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                           | (0x1000U == (0x1000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                          | (0x2000U == (0x2000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                         | (0x4000U == (0x4000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))) 
                        | (0x8000U == (0x8000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s)))
                        ? ((0x100U == (0x100U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                            ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U]
                            : ((0x200U == (0x200U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                    << 0x1cU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                                 >> 4U))
                                : ((0x400U == (0x400U 
                                               & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                    ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                        << 0x18U) | 
                                       (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                        >> 8U)) : (
                                                   (0x800U 
                                                    == 
                                                    (0x800U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                                    ? 
                                                   ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                                     << 0x14U) 
                                                    | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                                       >> 0xcU))
                                                    : 
                                                   ((0x1000U 
                                                     == 
                                                     (0x1000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                                     ? 
                                                    ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                                      << 0x10U) 
                                                     | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                                        >> 0x10U))
                                                     : 
                                                    ((0x2000U 
                                                      == 
                                                      (0x2000U 
                                                       & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                                      ? 
                                                     ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                                       << 0xcU) 
                                                      | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                                         >> 0x14U))
                                                      : 
                                                     ((0x4000U 
                                                       == 
                                                       (0x4000U 
                                                        & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                                       ? 
                                                      ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                                        << 8U) 
                                                       | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                                          >> 0x18U))
                                                       : 
                                                      ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                                        << 4U) 
                                                       | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[1U] 
                                                          >> 0x1cU)))))))))
                        : ((0x10000U == (0x10000U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                            ? __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U]
                            : ((0x20000U == (0x20000U 
                                             & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                    << 0x1cU) | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                                 >> 4U))
                                : ((0x40000U == (0x40000U 
                                                 & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                    ? ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                        << 0x18U) | 
                                       (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                        >> 8U)) : (
                                                   (0x80000U 
                                                    == 
                                                    (0x80000U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                                    ? 
                                                   ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                                     << 0x14U) 
                                                    | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                                       >> 0xcU))
                                                    : 
                                                   ((0x100000U 
                                                     == 
                                                     (0x100000U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                                     ? 
                                                    ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                                      << 0x10U) 
                                                     | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                                        >> 0x10U))
                                                     : 
                                                    ((0x200000U 
                                                      == 
                                                      (0x200000U 
                                                       & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                                      ? 
                                                     ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                                       << 0xcU) 
                                                      | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                                         >> 0x14U))
                                                      : 
                                                     ((0x400000U 
                                                       == 
                                                       (0x400000U 
                                                        & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__s))
                                                       ? 
                                                      ((__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                                        << 8U) 
                                                       | (__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__b[2U] 
                                                          >> 0x18U))
                                                       : 0U))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2253_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039416__543__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__Vfuncout 
        = (((((((((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s)) 
                  | (2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))) 
                 | (4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))) 
                | (8U == (8U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))) 
               | (0x10U == (0x10U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))) 
              | (0x20U == (0x20U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))) 
             | (0x40U == (0x40U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))) 
            | (0x80U == (0x80U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s)))
            ? ((1U == (1U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))
                ? 0U : ((2U == (2U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))
                         ? 0U : ((4U == (4U & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))
                                  ? 4U : ((8U == (8U 
                                                  & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))
                                           ? 5U : (
                                                   (0x10U 
                                                    == 
                                                    (0x10U 
                                                     & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))
                                                    ? 6U
                                                    : 
                                                   ((0x20U 
                                                     == 
                                                     (0x20U 
                                                      & __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__s))
                                                     ? 7U
                                                     : 0U))))))
            : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2270_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039503__560__Vfuncout;
    vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__s 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_) 
            << 0x16U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_) 
                          << 0x15U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_) 
                                        << 0x14U) | 
                                       (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_) 
                                         << 0x13U) 
                                        | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_) 
                                            << 0x12U) 
                                           | (((0x67U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               << 0x11U) 
                                              | (((0x6fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  << 0x10U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_) 
                                                     << 0xfU) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_) 
                                                        << 0xeU) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_) 
                                                           << 0xdU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_) 
                                                              << 0xcU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2023_) 
                                                                 << 0xbU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_) 
                                                                    << 0xaU) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_) 
                                                                       << 9U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_) 
                                                                          << 8U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_) 
                                                                             << 7U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_) 
                                                                                << 6U) 
                                                                               | (((0x4fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 5U) 
                                                                                | (((0x47U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 4U) 
                                                                                | (((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 3U) 
                                                                                | (((0x57U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_)))))))))))))))))))))));
    __Vtemp_10[0U] = (IData)((((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2178_)) 
                               << 0x3cU) | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2153_)) 
                                             << 0x39U) 
                                            | (((QData)((IData)(
                                                                ((1U 
                                                                  == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                  ? 4U
                                                                  : 3U))) 
                                                << 0x36U) 
                                               | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2115_)) 
                                                   << 0x33U) 
                                                  | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2101_)) 
                                                      << 0x30U) 
                                                     | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2082_)) 
                                                         << 0x2dU) 
                                                        | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2048_)) 
                                                            << 0x2aU) 
                                                           | (((QData)((IData)(
                                                                               ((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U))) 
                                                               << 0x27U) 
                                                              | (((QData)((IData)(
                                                                                ((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U))) 
                                                                  << 0x24U) 
                                                                 | (((QData)((IData)(
                                                                                ((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U))) 
                                                                     << 0x21U) 
                                                                    | (((QData)((IData)(
                                                                                ((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U))) 
                                                                        << 0x1eU) 
                                                                       | (QData)((IData)(
                                                                                (0x2db40U 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1984_) 
                                                                                << 0x1bU) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1962_) 
                                                                                << 0x18U) 
                                                                                | ((((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U) 
                                                                                << 0x15U) 
                                                                                | ((((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U) 
                                                                                << 0x12U) 
                                                                                | (0x3fU 
                                                                                & ((((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U) 
                                                                                << 3U) 
                                                                                | ((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U))))))))))))))))))))));
    __Vtemp_10[1U] = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2205_) 
                       << 0x1fU) | (IData)(((((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2178_)) 
                                              << 0x3cU) 
                                             | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2153_)) 
                                                 << 0x39U) 
                                                | (((QData)((IData)(
                                                                    ((1U 
                                                                      == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                      ? 4U
                                                                      : 3U))) 
                                                    << 0x36U) 
                                                   | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2115_)) 
                                                       << 0x33U) 
                                                      | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2101_)) 
                                                          << 0x30U) 
                                                         | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2082_)) 
                                                             << 0x2dU) 
                                                            | (((QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2048_)) 
                                                                << 0x2aU) 
                                                               | (((QData)((IData)(
                                                                                ((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U))) 
                                                                   << 0x27U) 
                                                                  | (((QData)((IData)(
                                                                                ((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U))) 
                                                                      << 0x24U) 
                                                                     | (((QData)((IData)(
                                                                                ((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U))) 
                                                                         << 0x21U) 
                                                                        | (((QData)((IData)(
                                                                                ((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U))) 
                                                                            << 0x1eU) 
                                                                           | (QData)((IData)(
                                                                                (0x2db40U 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1984_) 
                                                                                << 0x1bU) 
                                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1962_) 
                                                                                << 0x18U) 
                                                                                | ((((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U) 
                                                                                << 0x15U) 
                                                                                | ((((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U) 
                                                                                << 0x12U) 
                                                                                | (0x3fU 
                                                                                & ((((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U) 
                                                                                << 3U) 
                                                                                | ((1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                                                 ? 4U
                                                                                 : 3U))))))))))))))))))))) 
                                            >> 0x20U)));
    vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[0U] 
        = __Vtemp_10[0U];
    vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[1U] 
        = __Vtemp_10[1U];
    vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039407__540__b[2U] 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2230_) 
            << 2U) | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2205_) 
                      >> 1U));
}
