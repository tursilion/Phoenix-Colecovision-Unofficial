// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vsim_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vsim_top__Syms.h"
#include "Vsim_top__Syms.h"
#include "Vsim_top_colecovision.h"

VL_ATTR_COLD void Vsim_top_colecovision___stl_sequent__TOP__sim_top__cv__5(Vsim_top_colecovision* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vsim_top_colecovision___stl_sequent__TOP__sim_top__cv__5\n"); );
    // Init
    SData/*15:0*/ __PVT__inst_t80__DOT__u0__DOT___142_;
    __PVT__inst_t80__DOT__u0__DOT___142_ = 0;
    CData/*1:0*/ __PVT__inst_t80__DOT__u0__DOT___176_;
    __PVT__inst_t80__DOT__u0__DOT___176_ = 0;
    CData/*7:0*/ __PVT__inst_t80__DOT__u0__DOT___223_;
    __PVT__inst_t80__DOT__u0__DOT___223_ = 0;
    CData/*7:0*/ __PVT__inst_t80__DOT__u0__DOT___253_;
    __PVT__inst_t80__DOT__u0__DOT___253_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT___255_;
    __PVT__inst_t80__DOT__u0__DOT___255_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT___256_;
    __PVT__inst_t80__DOT__u0__DOT___256_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT___258_;
    __PVT__inst_t80__DOT__u0__DOT___258_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT___259_;
    __PVT__inst_t80__DOT__u0__DOT___259_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT___264_;
    __PVT__inst_t80__DOT__u0__DOT___264_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT___267_;
    __PVT__inst_t80__DOT__u0__DOT___267_ = 0;
    CData/*1:0*/ __PVT__inst_t80__DOT__u0__DOT___284_;
    __PVT__inst_t80__DOT__u0__DOT___284_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT___467_;
    __PVT__inst_t80__DOT__u0__DOT___467_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT___483_;
    __PVT__inst_t80__DOT__u0__DOT___483_ = 0;
    CData/*7:0*/ __PVT__inst_t80__DOT__u0__DOT___506_;
    __PVT__inst_t80__DOT__u0__DOT___506_ = 0;
    CData/*7:0*/ __PVT__inst_t80__DOT__u0__DOT___507_;
    __PVT__inst_t80__DOT__u0__DOT___507_ = 0;
    CData/*7:0*/ __PVT__inst_t80__DOT__u0__DOT___533_;
    __PVT__inst_t80__DOT__u0__DOT___533_ = 0;
    CData/*2:0*/ __PVT__inst_t80__DOT__u0__DOT__regaddrb;
    __PVT__inst_t80__DOT__u0__DOT__regaddrb = 0;
    CData/*0:0*/ inst_t80__DOT__u0__DOT____VdfgTmp_h2a6c92f6__0;
    inst_t80__DOT__u0__DOT____VdfgTmp_h2a6c92f6__0 = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__alu__DOT___069_;
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___069_ = 0;
    CData/*1:0*/ __PVT__inst_t80__DOT__u0__DOT__alu__DOT___071_;
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___071_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__alu__DOT___176_;
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___176_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__alu__DOT___178_;
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___178_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__alu__DOT___179_;
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___179_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__alu__DOT___181_;
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___181_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__alu__DOT___183_;
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___183_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__alu__DOT___184_;
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___184_ = 0;
    CData/*2:0*/ __PVT__inst_t80__DOT__u0__DOT__alu__DOT___185_;
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___185_ = 0;
    CData/*2:0*/ __PVT__inst_t80__DOT__u0__DOT__alu__DOT___186_;
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___186_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__alu__DOT___187_;
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___187_ = 0;
    CData/*2:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2282_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2282_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2285_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2285_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2291_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2291_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2292_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2292_ = 0;
    CData/*1:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2293_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2293_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2294_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2294_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2306_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2306_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2311_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2311_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2316_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2316_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2317_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2317_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2318_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2318_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2326_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2326_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2327_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2327_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2330_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2330_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2331_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2331_ = 0;
    CData/*0:0*/ __PVT__sdcard__DOT__rt_en_s;
    __PVT__sdcard__DOT__rt_en_s = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033211__66__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033211__66__Vfuncout = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033211__66__a;
    __Vfunc_inst_t80__DOT__u0__DOT____033211__66__a = 0;
    QData/*47:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033211__66__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033211__66__b = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033211__66__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033211__66__s = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033218__67__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033218__67__Vfuncout = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033218__67__a;
    __Vfunc_inst_t80__DOT__u0__DOT____033218__67__a = 0;
    QData/*47:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033218__67__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033218__67__b = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033218__67__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033218__67__s = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033409__68__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033409__68__Vfuncout = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033409__68__a;
    __Vfunc_inst_t80__DOT__u0__DOT____033409__68__a = 0;
    IData/*23:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033409__68__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033409__68__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033409__68__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033409__68__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033415__69__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033415__69__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033415__69__a;
    __Vfunc_inst_t80__DOT__u0__DOT____033415__69__a = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033415__69__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033415__69__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033415__69__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033415__69__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033421__70__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033421__70__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033421__70__a;
    __Vfunc_inst_t80__DOT__u0__DOT____033421__70__a = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033421__70__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033421__70__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033421__70__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033421__70__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033427__71__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033427__71__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033427__71__a;
    __Vfunc_inst_t80__DOT__u0__DOT____033427__71__a = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033427__71__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033427__71__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033427__71__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033427__71__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033433__72__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033433__72__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033433__72__a;
    __Vfunc_inst_t80__DOT__u0__DOT____033433__72__a = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033433__72__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033433__72__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033433__72__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033433__72__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033439__73__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033439__73__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033439__73__a;
    __Vfunc_inst_t80__DOT__u0__DOT____033439__73__a = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033439__73__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033439__73__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033439__73__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033439__73__s = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033440__74__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033440__74__Vfuncout = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033440__74__a;
    __Vfunc_inst_t80__DOT__u0__DOT____033440__74__a = 0;
    IData/*23:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033440__74__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033440__74__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033440__74__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033440__74__s = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033443__75__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033443__75__Vfuncout = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033443__75__a;
    __Vfunc_inst_t80__DOT__u0__DOT____033443__75__a = 0;
    IData/*23:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033443__75__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033443__75__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033443__75__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033443__75__s = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033650__76__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033650__76__Vfuncout = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033650__76__a;
    __Vfunc_inst_t80__DOT__u0__DOT____033650__76__a = 0;
    QData/*39:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033650__76__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033650__76__b = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033650__76__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033650__76__s = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033651__77__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033651__77__Vfuncout = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033651__77__a;
    __Vfunc_inst_t80__DOT__u0__DOT____033651__77__a = 0;
    QData/*39:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033651__77__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033651__77__b = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033651__77__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033651__77__s = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033653__78__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033653__78__Vfuncout = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033653__78__a;
    __Vfunc_inst_t80__DOT__u0__DOT____033653__78__a = 0;
    QData/*39:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033653__78__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033653__78__b = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033653__78__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033653__78__s = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033663__79__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033663__79__Vfuncout = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033663__79__a;
    __Vfunc_inst_t80__DOT__u0__DOT____033663__79__a = 0;
    QData/*39:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033663__79__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033663__79__b = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033663__79__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033663__79__s = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033673__80__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033673__80__Vfuncout = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033673__80__a;
    __Vfunc_inst_t80__DOT__u0__DOT____033673__80__a = 0;
    QData/*39:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033673__80__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033673__80__b = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033673__80__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033673__80__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____034002__83__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____034002__83__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____034002__83__a;
    __Vfunc_inst_t80__DOT__u0__DOT____034002__83__a = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____034002__83__s;
    __Vfunc_inst_t80__DOT__u0__DOT____034002__83__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____034004__84__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____034004__84__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____034004__84__a;
    __Vfunc_inst_t80__DOT__u0__DOT____034004__84__a = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____034004__84__s;
    __Vfunc_inst_t80__DOT__u0__DOT____034004__84__s = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____034110__85__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____034110__85__Vfuncout = 0;
    VlWide<3>/*79:0*/ __Vfunc_inst_t80__DOT__u0__DOT____034110__85__b;
    VL_ZERO_W(80, __Vfunc_inst_t80__DOT__u0__DOT____034110__85__b);
    SData/*9:0*/ __Vfunc_inst_t80__DOT__u0__DOT____034110__85__s;
    __Vfunc_inst_t80__DOT__u0__DOT____034110__85__s = 0;
    QData/*47:0*/ __Vfunc_inst_t80__DOT__u0__DOT____034146__86__b;
    __Vfunc_inst_t80__DOT__u0__DOT____034146__86__b = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT____034146__86__s;
    __Vfunc_inst_t80__DOT__u0__DOT____034146__86__s = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____034148__87__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____034148__87__Vfuncout = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT____034148__87__a;
    __Vfunc_inst_t80__DOT__u0__DOT____034148__87__a = 0;
    QData/*47:0*/ __Vfunc_inst_t80__DOT__u0__DOT____034148__87__b;
    __Vfunc_inst_t80__DOT__u0__DOT____034148__87__b = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT____034148__87__s;
    __Vfunc_inst_t80__DOT__u0__DOT____034148__87__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__a;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__a = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__a;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__a = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__a;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__a = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__a;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__a = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__a;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__a = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__Vfuncout = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__Vfuncout = 0;
    IData/*20:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__Vfuncout = 0;
    IData/*20:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__Vfuncout = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039942__110__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039942__110__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039942__110__a;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039942__110__a = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039942__110__b;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039942__110__b = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039942__110__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039942__110__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__a = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__a = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__a = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__a = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__s = 0;
    // Body
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___176_ 
        = vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310254__92__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s 
        = (((8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
            << 6U) | (((0xbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                       << 5U) | (((0xaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                  << 4U) | (((9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                             << 3U) 
                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___137_) 
                                                << 2U) 
                                               | (((0xcU 
                                                    == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___086_)))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b 
        = ((0x40U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___160_) 
                     << 4U)) | ((0x20U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                          << 2U)) | 
                                ((0x10U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                           << 1U)) 
                                 | ((0xfffffff8U & 
                                     (((6U != (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))) 
                                       << 3U) & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_))) 
                                    | ((4U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___124_) 
                                              >> 1U)) 
                                       | ((2U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___111_) 
                                                 >> 2U)) 
                                          | (1U & (
                                                   (7U 
                                                    == 
                                                    (7U 
                                                     & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)))
                                                    ? 
                                                   ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___796_)
                                                     ? 
                                                    ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___023_) 
                                                     >> 4U)
                                                     : 
                                                    ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_) 
                                                     >> 3U))
                                                    : 
                                                   ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___043_) 
                                                    >> 3U)))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__a 
        = (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__Vfuncout 
        = (1U & ((0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                  ? ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 6U)))))))
                  : ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__b)
                                          : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__a)))))))));
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___179_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310260__95__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s 
        = (((8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
            << 6U) | (((0xbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                       << 5U) | (((0xaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                  << 4U) | (((9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                             << 3U) 
                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___137_) 
                                                << 2U) 
                                               | (((0xcU 
                                                    == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___086_)))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b 
        = ((0x40U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___160_) 
                     << 2U)) | ((0x20U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)) 
                                | ((0x10U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                             >> 1U)) 
                                   | ((0x3ffffff8U 
                                       & (((6U != (7U 
                                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))) 
                                           << 3U) & 
                                          ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_) 
                                           >> 2U))) 
                                      | ((4U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                                                >> 3U)) 
                                         | ((2U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___111_) 
                                                   >> 4U)) 
                                            | (1U & 
                                               ((7U 
                                                 == 
                                                 (7U 
                                                  & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)))
                                                 ? 
                                                ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___796_)
                                                  ? 
                                                 ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___023_) 
                                                  >> 2U)
                                                  : 
                                                 ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_) 
                                                  >> 5U))
                                                 : 
                                                ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___043_) 
                                                 >> 5U)))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__a 
        = (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                 >> 5U));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__Vfuncout 
        = (1U & ((0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                  ? ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 6U)))))))
                  : ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__b)
                                          : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__a)))))))));
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___181_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310264__97__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039942__110__s 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___026_) 
           | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___033_));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039942__110__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___041_;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039942__110__a 
        = (1U & (~ (1U & VL_REDXOR_8(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___043_))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039942__110__Vfuncout 
        = ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039942__110__s)
            ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039942__110__b)
            : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039942__110__a));
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___069_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039942__110__Vfuncout;
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___071_ 
        = (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___790_)
                  ? ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                     >> 6U) : ((2U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___043_) 
                                      >> 6U)) | ((0U 
                                                  == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___043_)) 
                                                 & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___792_)) 
                                                    | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                       >> 6U))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s 
        = (((8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
            << 6U) | (((0xbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                       << 5U) | (((0xaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                  << 4U) | (((9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                             << 3U) 
                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___137_) 
                                                << 2U) 
                                               | (((0xcU 
                                                    == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___086_)))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___159_) 
            << 6U) | ((0x20U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___149_) 
                                << 5U)) | ((0x10U & 
                                            ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___146_) 
                                             << 4U)) 
                                           | ((8U & 
                                               ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___138_) 
                                                << 3U)) 
                                              | ((4U 
                                                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___124_) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___111_) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___043_))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__Vfuncout 
        = (1U & ((0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                  ? ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 6U)))))))
                  : ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b) 
                                             >> 1U))
                                      : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__s) 
                                         & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__b)))))))));
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___184_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310287__100__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s 
        = (((8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
            << 6U) | (((0xbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                       << 5U) | (((0xaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                  << 4U) | (((9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                             << 3U) 
                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___137_) 
                                                << 2U) 
                                               | (((0xcU 
                                                    == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___086_)))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
        = ((0x1c0000U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___160_) 
                         << 0xfU)) | ((0x38000U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___149_) 
                                                   << 0xbU)) 
                                      | ((0x7000U & 
                                          ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___146_) 
                                           << 8U)) 
                                         | ((0xe00U 
                                             & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___138_) 
                                                << 5U)) 
                                            | ((0x1c0U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                                                   << 2U)) 
                                               | ((0x38U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___111_) 
                                                      >> 1U)) 
                                                  | (7U 
                                                     & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___043_) 
                                                        >> 4U))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__Vfuncout 
        = (7U & ((0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                  ? ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 9U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 0xcU)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 9U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 0xfU))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 9U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 0xcU)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 9U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 0x12U)))))))
                  : ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 9U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 0xcU)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 9U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 0xfU))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 9U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 0xcU)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 9U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__b
                                          : 0U))))))));
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___186_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310305__102__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s 
        = (((8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
            << 6U) | (((0xbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                       << 5U) | (((0xaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                  << 4U) | (((9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                             << 3U) 
                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___137_) 
                                                << 2U) 
                                               | (((0xcU 
                                                    == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___086_)))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___161_) 
            << 6U) | ((0x20U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___149_) 
                                >> 2U)) | ((0x10U & 
                                            ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___146_) 
                                             >> 3U)) 
                                           | ((8U & 
                                               ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___138_) 
                                                >> 4U)) 
                                              | ((4U 
                                                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                                                     >> 5U)) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___111_) 
                                                        >> 6U)) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___043_) 
                                                          >> 7U))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__Vfuncout 
        = (1U & ((0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                  ? ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 6U)))))))
                  : ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b) 
                                             >> 1U))
                                      : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__s) 
                                         & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__b)))))))));
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___187_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310313__103__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s 
        = (((8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
            << 6U) | (((0xbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                       << 5U) | (((0xaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                  << 4U) | (((9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                             << 3U) 
                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___137_) 
                                                << 2U) 
                                               | (((0xcU 
                                                    == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___086_)))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
        = ((0x1c0000U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___160_) 
                         << 0x12U)) | ((0x38000U & 
                                        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___149_) 
                                         << 0xeU)) 
                                       | ((0x7000U 
                                           & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___146_) 
                                              << 0xbU)) 
                                          | ((0xe00U 
                                              & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___138_) 
                                                 << 8U)) 
                                             | ((0x1c0U 
                                                 & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___124_) 
                                                    << 5U)) 
                                                | ((0x38U 
                                                    & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___111_) 
                                                       << 2U)) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___043_) 
                                                         >> 1U))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__Vfuncout 
        = (7U & ((0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                  ? ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 9U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 0xcU)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 9U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 0xfU))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 9U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 0xcU)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 9U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 0x12U)))))))
                  : ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 9U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 0xcU)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 9U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 0xfU))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 9U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 0xcU)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 9U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 6U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b 
                                             >> 3U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__s))
                                          ? __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__b
                                          : 0U))))))));
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___185_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310296__101__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___765_ = 
        (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__clken) 
          & (3U != (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2328_)))
          ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2328_)
          : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___766_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___330_ = 
        (((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___778_)) 
          & (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)))
          ? ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2324_)
              ? ((0xf0U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                           << 4U)) | (0xfU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_) 
                                              >> 4U)))
              : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2323_)
                  ? ((0xf0U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_) 
                               << 4U)) | (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_)))
                  : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_)))
          : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___341_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2320_) 
         | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2321_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___334_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2320_) 
         & (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)));
    __Vfunc_inst_t80__DOT__u0__DOT____033440__74__s 
        = (((2U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
            << 2U) | (((1U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
                       << 1U) | (0U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_)))));
    __Vfunc_inst_t80__DOT__u0__DOT____033440__74__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_) 
            << 0x10U) | (0xffffU & (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___724_) 
                                     << 8U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___724_))));
    __Vfunc_inst_t80__DOT__u0__DOT____033440__74__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___724_;
    __Vfunc_inst_t80__DOT__u0__DOT____033440__74__Vfuncout 
        = (0xffU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033440__74__s)))
                     ? __Vfunc_inst_t80__DOT__u0__DOT____033440__74__b
                     : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033440__74__s)))
                         ? (__Vfunc_inst_t80__DOT__u0__DOT____033440__74__b 
                            >> 8U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033440__74__s)))
                                       ? (__Vfunc_inst_t80__DOT__u0__DOT____033440__74__b 
                                          >> 0x10U)
                                       : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033440__74__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___269_ = __Vfunc_inst_t80__DOT__u0__DOT____033440__74__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033443__75__s 
        = (((2U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
            << 2U) | (((1U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
                       << 1U) | (0U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_)))));
    __Vfunc_inst_t80__DOT__u0__DOT____033443__75__b 
        = ((0x800000U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___726_) 
                         << 0x10U)) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___119_) 
                                        << 0x10U) | 
                                       ((0x8000U & 
                                         ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___726_) 
                                          << 8U)) | 
                                        (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___119_) 
                                          << 8U) | 
                                         ((0x80U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___726_)) 
                                          | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___119_))))));
    __Vfunc_inst_t80__DOT__u0__DOT____033443__75__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_;
    __Vfunc_inst_t80__DOT__u0__DOT____033443__75__Vfuncout 
        = (0xffU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033443__75__s)))
                     ? __Vfunc_inst_t80__DOT__u0__DOT____033443__75__b
                     : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033443__75__s)))
                         ? (__Vfunc_inst_t80__DOT__u0__DOT____033443__75__b 
                            >> 8U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033443__75__s)))
                                       ? (__Vfunc_inst_t80__DOT__u0__DOT____033443__75__b 
                                          >> 0x10U)
                                       : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033443__75__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___270_ = __Vfunc_inst_t80__DOT__u0__DOT____033443__75__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___298_ = 
        ((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_) 
            >> 2U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__b 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1547_) 
           << 1U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2332_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039684__622__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0895_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2314_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039631__604__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0881_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2299_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039587__589__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0880_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2264_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2298_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039584__588__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0872_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2255_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2289_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039561__579__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1539_) 
            << 3U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0864_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2249_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2281_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039538__571__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1544_) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0879_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2263_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2297_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039581__587__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0890_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2269_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2308_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039613__598__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1543_) 
            << 4U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0878_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2261_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__b) 
                           >> 4U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2295_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039577__585__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1541_) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0871_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2254_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2288_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039558__578__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0885_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2303_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039598__593__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0902_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2329_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039676__619__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0889_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2268_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2307_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039610__597__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0900_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__b)) 
                             >> 1U))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2326_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039667__616__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0883_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2266_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2301_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039592__591__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0903_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2279_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__a))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2330_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039679__620__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0867_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2251_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2284_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039545__574__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0886_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2304_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039601__594__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0877_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2260_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__a))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2294_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039573__584__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__b 
        = ((2U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1542_) 
                  << 1U)) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0875_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2258_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__a))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2292_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039569__582__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__b 
        = ((0xcU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1542_) 
                    << 1U)) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0876_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2259_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__Vfuncout 
        = (3U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__b) 
                         >> 2U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__a))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2293_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039571__583__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0888_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__b)) 
                             >> 1U))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2306_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039607__596__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0887_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2305_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039604__595__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0884_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2267_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2302_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039595__592__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0901_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__b)) 
                             >> 1U))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2327_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039670__617__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0868_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2252_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__a))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2285_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039548__575__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1546_) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0904_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2280_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__a))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2331_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039681__621__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0891_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2309_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039616__599__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0874_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2257_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__b) 
                         >> 1U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__a))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2291_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039565__581__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0866_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__Vfuncout 
        = (3U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__b) 
                         >> 2U) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2283_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039542__573__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0893_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2312_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039625__602__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__b 
        = ((0x38U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                     << 3U)) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0873_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2256_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2290_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039563__580__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0869_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__a 
        = (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2253_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__Vfuncout 
        = (3U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__b) 
                         >> 2U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2286_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039552__576__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1545_) 
            << 3U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0882_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2265_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2300_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039589__590__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0870_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__a 
        = (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2253_) 
                 >> 2U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__Vfuncout 
        = (3U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__b) 
                         >> 2U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2287_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039555__577__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0896_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2315_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039634__605__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0892_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__b)) 
                             >> 1U))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2311_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039622__601__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0898_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__b)) 
                             >> 1U))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2317_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039640__607__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0899_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__b)) 
                             >> 1U))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2318_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039643__608__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0897_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__b)) 
                             >> 1U))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2316_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039637__606__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__b 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0894_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2313_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039628__603__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__s 
        = (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)) 
            << 1U) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1540_) 
            << 3U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0865_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2250_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__a))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2282_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039540__572__Vfuncout;
    vlSelf->__PVT__sdcard__DOT___44_ = (0x1fU & ((IData)(vlSelf->__PVT__sdcard__DOT___52_) 
                                                 - (IData)(vlSelf->__PVT__sdcard__DOT___23_)));
    vlSelf->__PVT__sdcard__DOT___43_ = ((1U & ((~ (IData)(vlSelf->__PVT__sdcard__DOT___23_)) 
                                               | (1U 
                                                  == (IData)(vlSelf->__PVT__sdcard__DOT___52_))))
                                         ? (IData)(vlSelf->__PVT__sdcard__DOT___21_)
                                         : (IData)(vlSelf->__PVT__sdcard__DOT___51_));
    __PVT__sdcard__DOT__rt_en_s = (1U & ((~ (IData)(vlSelf->__PVT__sdcard__DOT___23_)) 
                                         | (0U == (IData)(vlSelf->__PVT__sdcard__DOT___52_))));
    if (vlSymsp->TOP.clk_3m58_en) {
        if (vlSelf->__PVT___181_) {
            vlSelf->__PVT___371_ = vlSelf->__PVT___305_;
            vlSelf->__PVT___372_ = vlSelf->__PVT___306_;
            vlSelf->__PVT___373_ = vlSelf->__PVT___307_;
        } else {
            vlSelf->__PVT___371_ = vlSelf->__PVT___176_;
            vlSelf->__PVT___372_ = vlSelf->__PVT___177_;
            vlSelf->__PVT___373_ = vlSelf->__PVT___179_;
        }
    } else {
        vlSelf->__PVT___371_ = vlSelf->__PVT___435_;
        vlSelf->__PVT___372_ = vlSelf->__PVT___436_;
        vlSelf->__PVT___373_ = vlSelf->__PVT___437_;
    }
    if (vlSelf->__PVT___427_) {
        vlSelf->__PVT___403_ = (7U & ((IData)(vlSelf->__PVT___423_) 
                                      + (IData)(vlSelf->__PVT___382_)));
        vlSelf->__PVT___404_ = (0xfU & ((IData)(vlSelf->__PVT___424_) 
                                        - (IData)(vlSelf->__PVT___382_)));
    } else {
        vlSelf->__PVT___403_ = 0U;
        vlSelf->__PVT___404_ = 0U;
    }
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s 
        = (((8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
            << 6U) | (((0xbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                       << 5U) | (((0xaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                  << 4U) | (((9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                             << 3U) 
                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___137_) 
                                                << 2U) 
                                               | (((0xcU 
                                                    == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___086_)))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b 
        = ((0x40U & (((0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_))
                       ? ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                          >> 2U) : (~ ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___159_) 
                                       ^ (1U & (VL_REDXOR_8(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___160_) 
                                                ^ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___161_)))))) 
                     << 6U)) | ((0x20U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                          << 3U)) | 
                                ((0x10U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                           << 2U)) 
                                 | (((0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___138_)) 
                                     << 3U) | ((4U 
                                                & ((~ 
                                                    (1U 
                                                     & (VL_REDXOR_4(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___124_) 
                                                        ^ 
                                                        VL_REDXOR_8(
                                                                    (0xf0U 
                                                                     & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_)))))) 
                                                   << 2U)) 
                                               | ((2U 
                                                   & ((~ 
                                                       (1U 
                                                        & VL_REDXOR_8(
                                                                      (0xffU 
                                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___111_))))) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___790_)
                                                         ? 
                                                        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                         >> 2U)
                                                         : (IData)(__PVT__inst_t80__DOT__u0__DOT__alu__DOT___069_)))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__a 
        = (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                 >> 2U));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__Vfuncout 
        = (1U & ((0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                  ? ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 6U)))))))
                  : ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__b)
                                          : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__a)))))))));
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___178_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310258__94__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s 
        = (((8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
            << 6U) | (((0xbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                       << 5U) | (((0xaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                  << 4U) | (((9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                             << 3U) 
                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___137_) 
                                                << 2U) 
                                               | (((0xcU 
                                                    == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___086_)))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b 
        = ((0x40U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___174_) 
                     << 5U)) | ((0x20U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                          >> 2U)) | 
                                ((0x10U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                           >> 3U)) 
                                 | ((8U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___138_) 
                                           >> 4U)) 
                                    | ((4U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                                              >> 5U)) 
                                       | ((2U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___111_) 
                                                 >> 6U)) 
                                          | (1U & ((IData)(__PVT__inst_t80__DOT__u0__DOT__alu__DOT___071_) 
                                                   >> 1U))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__a 
        = (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                 >> 7U));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__Vfuncout 
        = (1U & ((0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                  ? ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 6U)))))))
                  : ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__b)
                                          : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__a)))))))));
    __PVT__inst_t80__DOT__u0__DOT__alu__DOT___183_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310272__99__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s 
        = (((8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
            << 6U) | (((0xbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                       << 5U) | (((0xaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                  << 4U) | (((9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                             << 3U) 
                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___137_) 
                                                << 2U) 
                                               | (((0xcU 
                                                    == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___086_)))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b 
        = ((0x40U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___174_) 
                     << 6U)) | ((0x20U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                          >> 1U)) | 
                                ((0x10U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                           >> 2U)) 
                                 | (((0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___138_)) 
                                     << 3U) | (((0U 
                                                 == 
                                                 ((0xf0U 
                                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_)) 
                                                  | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___124_))) 
                                                << 2U) 
                                               | (((0U 
                                                    == 
                                                    (0xffU 
                                                     & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___111_))) 
                                                   << 1U) 
                                                  | (1U 
                                                     & (IData)(__PVT__inst_t80__DOT__u0__DOT__alu__DOT___071_))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__a 
        = (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                 >> 6U));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__Vfuncout 
        = (1U & ((0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                  ? ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 6U)))))))
                  : ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__b)
                                          : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__a)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___182_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310268__98__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___048_ = 
        (((IData)(__PVT__inst_t80__DOT__u0__DOT__alu__DOT___187_) 
          << 7U) | (((IData)(__PVT__inst_t80__DOT__u0__DOT__alu__DOT___186_) 
                     << 4U) | (((IData)(__PVT__inst_t80__DOT__u0__DOT__alu__DOT___185_) 
                                << 1U) | (IData)(__PVT__inst_t80__DOT__u0__DOT__alu__DOT___184_))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___723_ = 
        (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__clken) 
          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___298_))
          ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___269_)
          : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___724_));
    inst_t80__DOT__u0__DOT____VdfgTmp_h2a6c92f6__0 
        = (1U & (~ ((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
                    & (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2326_))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___009_ = 
        ((7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
          ? (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))
          : (((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2294_) 
              << 3U) | (((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2293_) 
                         << 1U) | (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2292_))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___197_ = 
        ((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
         & (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2306_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___133_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2305_) 
         | (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2306_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___149_ = 
        (0xffffU & ((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2285_)
                     ? ((IData)(1U) + (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___740_))
                     : (IData)(vlSelf->inst_t80__DOT__u0__DOT____VdfgTmp_hbde73ddd__0)));
    vlSelf->__PVT__inst_t80__DOT___42_ = ((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2331_) 
                                          & (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)));
    vlSelf->__PVT__inst_t80__DOT___40_ = (1U & (~ (
                                                   (~ (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2331_)) 
                                                   & ((~ 
                                                       ((7U 
                                                         == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                         ? 
                                                        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2345_)) 
                                                         | (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2330_))
                                                         : (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2330_))) 
                                                      & (1U 
                                                         == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___391_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2304_) 
         | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2309_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___767_ = 
        (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__clken) 
          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___233_))
          ? ((0U != (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2283_))
              ? ((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2283_))
                  ? ((0x20U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))
                      ? 2U : 1U) : ((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2283_))
                                     ? 0U : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___768_)))
              : 0U) : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___768_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___636_ = 
        ((~ (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2327_)) 
         & ((0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2283_)) 
            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___752_) 
               & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___764_))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___640_ = 
        ((0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2283_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___762_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_ = 
        (((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2291_) 
          << 3U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2290_));
    __PVT__inst_t80__DOT__u0__DOT___483_ = ((0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2286_)) 
                                            | ((1U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2286_)) 
                                               | (2U 
                                                  == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2286_))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___015_ = 
        ((IData)(vlSelf->__VdfgTmp_h7bf8ddc8__0) ? 2U
          : ((IData)(vlSelf->__VdfgTmp_h426b99eb__0)
              ? 7U : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2300_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___503_ = 
        ((((1U != (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
           & (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_))) 
          | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___501_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2287_));
    vlSelf->inst_t80__DOT__u0__DOT____VdfgTmp_h548e9c6f__0 
        = ((4U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2287_) 
                  << 2U)) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2286_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___424_ = 
        ((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
         | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2287_) 
            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___501_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___626_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___621_) 
         | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___774_) 
            | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___782_) 
               & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2315_) 
                  & (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___304_ = 
        (((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2315_)) 
          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___798_)) 
         | (9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)));
    __PVT__inst_t80__DOT__u0__DOT___467_ = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
                                             | (4U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_))) 
                                            & (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2311_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___493_ = 
        ((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
         & (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2311_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___489_ = 
        ((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
         & (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2311_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__t_res = 
        (((7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
           ? 5U : (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2282_)) 
         == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_));
    if (__PVT__sdcard__DOT__rt_en_s) {
        vlSelf->__PVT__sdcard__DOT___37_ = vlSelf->__PVT__sdcard__DOT___16_;
        vlSelf->__PVT__sdcard__DOT___38_ = vlSelf->__PVT__sdcard__DOT___17_;
        vlSelf->__PVT__sdcard__DOT___39_ = vlSelf->__PVT__sdcard__DOT___18_;
    } else {
        vlSelf->__PVT__sdcard__DOT___37_ = vlSelf->__PVT__sdcard__DOT___45_;
        vlSelf->__PVT__sdcard__DOT___38_ = vlSelf->__PVT__sdcard__DOT___46_;
        vlSelf->__PVT__sdcard__DOT___39_ = vlSelf->__PVT__sdcard__DOT___47_;
    }
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__save_mux 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2312_)
            ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_)
            : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___798_)
                ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___048_)
                : (IData)(vlSelf->__PVT__inst_t80__DOT___55_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___600_ = 
        ((IData)(inst_t80__DOT__u0__DOT____VdfgTmp_h2a6c92f6__0) 
         & (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
             & (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2327_)) 
            | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___754_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___599_ = 
        ((IData)(inst_t80__DOT__u0__DOT____VdfgTmp_h2a6c92f6__0) 
         & ((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_))
             ? ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2319_)
                 ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___754_)
                 : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___752_) 
                    | (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2327_)))
             : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___752_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___546_ = 
        ((0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_)) 
         | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_)) 
            | ((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_)) 
               | ((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_)) 
                  | ((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_)) 
                     | (5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__nextis_xy_fetch 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___015_)) 
            | (((0xcbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                | (0x36U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))) 
               & (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))) 
           & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___379_));
    if (vlSelf->__PVT__clk_en_cpu_s) {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___773_ 
            = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2320_) 
                & ((~ ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                       >> 4U)) | (~ ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                     >> 2U)))) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2321_) 
                                                   & ((~ 
                                                       ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                        >> 2U)) 
                                                      | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___589_))) 
                                                  | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2322_) 
                                                     & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___589_))));
        vlSelf->__PVT__inst_t80__DOT___62_ = (1U & 
                                              ((~ (IData)(vlSelf->__PVT__inst_t80__DOT___42_)) 
                                               | (1U 
                                                  == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
        if ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))) {
            vlSelf->__PVT__inst_t80__DOT___60_ = vlSelf->__PVT__inst_t80__DOT___25_;
            vlSelf->__PVT__inst_t80__DOT___56_ = ((3U 
                                                   != (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
                                                  & (IData)(vlSelf->__PVT__inst_t80__DOT___25_));
            vlSelf->__PVT__inst_t80__DOT___58_ = (1U 
                                                  & ((1U 
                                                      != (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
                                                     | (~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___804_))));
        } else {
            vlSelf->__PVT__inst_t80__DOT___60_ = vlSelf->__PVT__inst_t80__DOT___40_;
            if (vlSelf->__PVT__inst_t80__DOT___42_) {
                vlSelf->__PVT__inst_t80__DOT___56_ 
                    = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2301_;
                vlSelf->__PVT__inst_t80__DOT___58_ 
                    = (1U & (~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2301_)));
            } else {
                vlSelf->__PVT__inst_t80__DOT___56_ 
                    = ((IData)(vlSelf->__PVT__inst_t80__DOT___40_) 
                       | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2301_));
                vlSelf->__PVT__inst_t80__DOT___58_ 
                    = (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT___40_) 
                             | (~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2301_))));
            }
        }
        if (vlSelf->__PVT__inst_t80__DOT__u0__DOT___610_) {
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___759_ 
                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___760_;
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___755_ 
                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___604_;
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___747_ 
                = (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_));
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___749_ 
                = (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_));
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___769_ 
                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___770_;
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___805_ 
                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___806_;
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___803_ 
                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___804_;
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___751_ 
                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___599_;
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___753_ 
                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___600_;
        } else {
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___759_ 
                = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__t_res) 
                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___758_));
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___755_ 
                = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__t_res) 
                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2329_)) 
                   | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___604_));
            if (vlSelf->__PVT__inst_t80__DOT__u0__DOT__t_res) {
                if (vlSelf->__PVT__inst_t80__DOT__u0__DOT___758_) {
                    vlSelf->__PVT__inst_t80__DOT__u0__DOT___747_ 
                        = (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_));
                    vlSelf->__PVT__inst_t80__DOT__u0__DOT___749_ 
                        = (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_));
                    vlSelf->__PVT__inst_t80__DOT__u0__DOT___769_ 
                        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___770_;
                    vlSelf->__PVT__inst_t80__DOT__u0__DOT___805_ 
                        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___806_;
                    vlSelf->__PVT__inst_t80__DOT__u0__DOT___803_ 
                        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___804_;
                    vlSelf->__PVT__inst_t80__DOT__u0__DOT___751_ 
                        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___599_;
                    vlSelf->__PVT__inst_t80__DOT__u0__DOT___753_ 
                        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___600_;
                } else {
                    vlSelf->__PVT__inst_t80__DOT__u0__DOT___747_ 
                        = (7U & 1U);
                    if (vlSelf->__PVT__inst_t80__DOT__u0__DOT__nextis_xy_fetch) {
                        vlSelf->__PVT__inst_t80__DOT__u0__DOT___749_ 
                            = (7U & 6U);
                        vlSelf->__PVT__inst_t80__DOT__u0__DOT___769_ 
                            = ((0x36U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))
                                ? 2U : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_));
                        vlSelf->__PVT__inst_t80__DOT__u0__DOT___805_ 
                            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___806_;
                        vlSelf->__PVT__inst_t80__DOT__u0__DOT___803_ 
                            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___804_;
                        vlSelf->__PVT__inst_t80__DOT__u0__DOT___751_ 
                            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___599_;
                        vlSelf->__PVT__inst_t80__DOT__u0__DOT___753_ 
                            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___600_;
                    } else {
                        if ((7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))) {
                            vlSelf->__PVT__inst_t80__DOT__u0__DOT___749_ 
                                = (7U & ((IData)(1U) 
                                         + (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___770_)));
                            vlSelf->__PVT__inst_t80__DOT__u0__DOT___805_ 
                                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___806_;
                            vlSelf->__PVT__inst_t80__DOT__u0__DOT___803_ 
                                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___804_;
                            vlSelf->__PVT__inst_t80__DOT__u0__DOT___751_ 
                                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___599_;
                            vlSelf->__PVT__inst_t80__DOT__u0__DOT___753_ 
                                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___600_;
                        } else if (vlSelf->__PVT__inst_t80__DOT__u0__DOT___626_) {
                            vlSelf->__PVT__inst_t80__DOT__u0__DOT___749_ 
                                = (7U & 1U);
                            vlSelf->__PVT__inst_t80__DOT__u0__DOT___805_ 
                                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___640_;
                            vlSelf->__PVT__inst_t80__DOT__u0__DOT___803_ 
                                = ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___640_)) 
                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___636_));
                            vlSelf->__PVT__inst_t80__DOT__u0__DOT___751_ 
                                = ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___640_)) 
                                   & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___636_)) 
                                      & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___599_)));
                            vlSelf->__PVT__inst_t80__DOT__u0__DOT___753_ 
                                = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___640_)
                                    ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___600_)
                                    : ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___636_)) 
                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___600_)));
                        } else {
                            vlSelf->__PVT__inst_t80__DOT__u0__DOT___749_ 
                                = (7U & ((IData)(1U) 
                                         + (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
                            vlSelf->__PVT__inst_t80__DOT__u0__DOT___805_ 
                                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___806_;
                            vlSelf->__PVT__inst_t80__DOT__u0__DOT___803_ 
                                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___804_;
                            vlSelf->__PVT__inst_t80__DOT__u0__DOT___751_ 
                                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___599_;
                            vlSelf->__PVT__inst_t80__DOT__u0__DOT___753_ 
                                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___600_;
                        }
                        vlSelf->__PVT__inst_t80__DOT__u0__DOT___769_ 
                            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___770_;
                    }
                }
            } else {
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___747_ 
                    = (7U & ((((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___780_)) 
                               & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__auto_wait)) 
                              | ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___778_)) 
                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2301_)))
                              ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)
                              : ((IData)(1U) + (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_))));
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___749_ 
                    = (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_));
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___769_ 
                    = vlSelf->__PVT__inst_t80__DOT__u0__DOT___770_;
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___805_ 
                    = vlSelf->__PVT__inst_t80__DOT__u0__DOT___806_;
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___803_ 
                    = vlSelf->__PVT__inst_t80__DOT__u0__DOT___804_;
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___751_ 
                    = vlSelf->__PVT__inst_t80__DOT__u0__DOT___599_;
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___753_ 
                    = vlSelf->__PVT__inst_t80__DOT__u0__DOT___600_;
            }
        }
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___777_ 
            = ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__t_res)) 
               & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__auto_wait) 
                  | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2301_)));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___807_ 
            = ((0U != (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
               & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___610_)
                   ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___609_)
                   : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__t_res)
                       ? ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___758_)
                           ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___609_)
                           : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__nextis_xy_fetch)
                               ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___609_)
                               : ((7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                   ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___609_)
                                   : ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___626_)) 
                                      & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___609_)))))
                       : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___609_))));
    } else {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___773_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___774_;
        vlSelf->__PVT__inst_t80__DOT___62_ = (1U & (IData)(vlSelf->__PVT__inst_t80__DOT___63_));
        vlSelf->__PVT__inst_t80__DOT___60_ = vlSelf->__PVT__inst_t80__DOT___61_;
        vlSelf->__PVT__inst_t80__DOT___56_ = vlSelf->__PVT__inst_t80__DOT___57_;
        vlSelf->__PVT__inst_t80__DOT___58_ = (1U & (IData)(vlSelf->__PVT__inst_t80__DOT___59_));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___759_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___760_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___777_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___778_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___755_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___756_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___747_ 
            = (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___749_ 
            = (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___769_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___770_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___805_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___806_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___803_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___804_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___807_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___808_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___751_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___752_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___753_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___754_;
    }
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___215_ = 
        (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
          | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
             & (4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)))) 
         & (7U == (IData)(vlSelf->inst_t80__DOT__u0__DOT____VdfgTmp_h548e9c6f__0)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___468_ = 
        ((IData)(__PVT__inst_t80__DOT__u0__DOT___467_) 
         | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___447_) 
            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___460_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___469_ = 
        ((IData)(__PVT__inst_t80__DOT__u0__DOT___467_) 
         | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___447_) 
            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___461_)));
    __PVT__inst_t80__DOT__u0__DOT__regaddrb = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___489_)
                                                ? (1U 
                                                   | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___738_) 
                                                      << 2U))
                                                : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___734_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__regaddra 
        = (((0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___768_)) 
            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___424_))
            ? (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___738_) 
                << 2U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2286_))
            : (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2286_)) 
                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___424_))
                ? (3U | (4U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___768_) 
                               << 1U))) : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___489_)
                                            ? (2U | 
                                               ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___738_) 
                                                << 2U))
                                            : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___493_)
                                                ? (1U 
                                                   | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___738_) 
                                                      << 2U))
                                                : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___732_)))));
    __Vfunc_inst_t80__DOT__u0__DOT____033433__72__s 
        = (((2U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
            << 2U) | (((1U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
                       << 1U) | (0U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_)))));
    if (vlSelf->__PVT__inst_t80__DOT__u0__DOT___082_) {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___290_ 
            = (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                     >> 6U));
        __PVT__inst_t80__DOT__u0__DOT___264_ = (1U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                   >> 6U));
    } else if (vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2313_) {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___290_ 
            = (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___722_) 
                     >> 6U));
        __PVT__inst_t80__DOT__u0__DOT___264_ = (1U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___722_) 
                                                   >> 6U));
    } else {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___290_ 
            = (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                     >> 6U));
        __PVT__inst_t80__DOT__u0__DOT___264_ = (1U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                   >> 6U));
    }
    __Vfunc_inst_t80__DOT__u0__DOT____033433__72__b 
        = ((6U & ((- (IData)((IData)(__PVT__inst_t80__DOT__u0__DOT___264_))) 
                  << 1U)) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___724_)));
    __Vfunc_inst_t80__DOT__u0__DOT____033433__72__a 
        = __PVT__inst_t80__DOT__u0__DOT___264_;
    __Vfunc_inst_t80__DOT__u0__DOT____033433__72__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033433__72__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033433__72__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033433__72__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033433__72__b) 
                         >> 1U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033433__72__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033433__72__b) 
                                       >> 2U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033433__72__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___265_ = __Vfunc_inst_t80__DOT__u0__DOT____033433__72__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033439__73__s 
        = (((2U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
            << 2U) | (((1U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
                       << 1U) | (0U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_)))));
    __PVT__inst_t80__DOT__u0__DOT___267_ = (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___082_)
                                                   ? 
                                                  ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                   >> 7U)
                                                   : 
                                                  ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2313_)
                                                    ? 
                                                   ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___722_) 
                                                    >> 7U)
                                                    : 
                                                   ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                    >> 7U))));
    __Vfunc_inst_t80__DOT__u0__DOT____033439__73__b 
        = ((6U & ((- (IData)((IData)(__PVT__inst_t80__DOT__u0__DOT___267_))) 
                  << 1U)) | (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___724_) 
                                   >> 7U)));
    __Vfunc_inst_t80__DOT__u0__DOT____033439__73__a 
        = __PVT__inst_t80__DOT__u0__DOT___267_;
    __Vfunc_inst_t80__DOT__u0__DOT____033439__73__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033439__73__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033439__73__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033439__73__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033439__73__b) 
                         >> 1U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033439__73__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033439__73__b) 
                                       >> 2U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033439__73__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___268_ = __Vfunc_inst_t80__DOT__u0__DOT____033439__73__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033421__70__s 
        = (((2U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
            << 2U) | (((1U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
                       << 1U) | (0U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_)))));
    __PVT__inst_t80__DOT__u0__DOT___258_ = (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___082_)
                                                   ? 
                                                  ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                   >> 2U)
                                                   : 
                                                  ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2313_)
                                                    ? 
                                                   ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___722_) 
                                                    >> 2U)
                                                    : 
                                                   ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                    >> 2U))));
    __Vfunc_inst_t80__DOT__u0__DOT____033421__70__b 
        = (((IData)(__PVT__inst_t80__DOT__u0__DOT___258_) 
            << 2U) | (3U & (- (IData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___754_)))));
    __Vfunc_inst_t80__DOT__u0__DOT____033421__70__a 
        = __PVT__inst_t80__DOT__u0__DOT___258_;
    __Vfunc_inst_t80__DOT__u0__DOT____033421__70__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033421__70__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033421__70__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033421__70__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033421__70__b) 
                         >> 1U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033421__70__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033421__70__b) 
                                       >> 2U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033421__70__a)))));
    __PVT__inst_t80__DOT__u0__DOT___259_ = __Vfunc_inst_t80__DOT__u0__DOT____033421__70__Vfuncout;
    if (vlSelf->__PVT__inst_t80__DOT__u0__DOT__t_res) {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___178_ 
            = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2302_)
                ? (IData)(vlSelf->inst_t80__DOT__u0__DOT____VdfgTmp_hbde73ddd__0)
                : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2304_)
                    ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__regbusc)
                    : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___133_)
                        ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___740_)
                        : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___135_)
                            ? 0x66U : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___139_)
                                        ? (IData)(vlSelf->inst_t80__DOT__u0__DOT____VdfgTmp_hb2fda09c__0)
                                        : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___730_))))));
        if (__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2318_) {
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___177_ 
                = (7U & ((4U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_) 
                                >> 3U)) | (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_) 
                                                 >> 3U))));
            __PVT__inst_t80__DOT__u0__DOT___176_ = 
                (3U & 1U);
        } else if (__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2317_) {
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___177_ 
                = (7U & ((4U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_) 
                                >> 3U)) | ((2U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                  << 1U)) 
                                           | (1U & 
                                              ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_) 
                                               >> 3U)))));
            __PVT__inst_t80__DOT__u0__DOT___176_ = 
                (3U & (1U & (~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_))));
        } else {
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___177_ 
                = (7U & ((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2316_)
                          ? (2U | ((4U & ((~ ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_) 
                                              >> 5U)) 
                                          << 2U)) | 
                                   (1U & (~ ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_) 
                                             >> 3U)))))
                          : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                             >> 3U)));
            __PVT__inst_t80__DOT__u0__DOT___176_ = 
                (3U & ((2U & (((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2316_) 
                               << 1U) | (0xfffffffeU 
                                         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)))) 
                       | (1U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_))));
        }
    } else {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___178_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___730_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___177_ 
            = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                     >> 3U));
        __PVT__inst_t80__DOT__u0__DOT___176_ = (3U 
                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_));
    }
    if (vlSelf->__PVT__inst_t80__DOT__u0__DOT___082_) {
        __PVT__inst_t80__DOT__u0__DOT___223_ = (0xffU 
                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___362_ 
            = (0xffU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___728_));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___367_ 
            = (0xffU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___728_) 
                        >> 8U));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___261_ 
            = (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                     >> 4U));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___293_ 
            = (1U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_));
        __PVT__inst_t80__DOT__u0__DOT___284_ = (3U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                   >> 1U));
        __PVT__inst_t80__DOT__u0__DOT___255_ = (1U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                   >> 1U));
    } else {
        if (vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2313_) {
            __PVT__inst_t80__DOT__u0__DOT___223_ = 
                (0xffU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___720_));
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___261_ 
                = (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___722_) 
                         >> 4U));
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___293_ 
                = (1U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___722_));
            __PVT__inst_t80__DOT__u0__DOT___284_ = 
                (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___722_) 
                       >> 1U));
            __PVT__inst_t80__DOT__u0__DOT___255_ = 
                (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___722_) 
                       >> 1U));
        } else {
            __PVT__inst_t80__DOT__u0__DOT___223_ = 
                (0xffU & (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__t_res) 
                           & (IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2316_))
                           ? (~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_))
                           : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_)));
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___261_ 
                = (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___177_) 
                         >> 1U));
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___293_ 
                = (1U & (IData)(__PVT__inst_t80__DOT__u0__DOT___176_));
            __PVT__inst_t80__DOT__u0__DOT___284_ = 
                (3U & ((2U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                              >> 1U)) | (1U & ((IData)(__PVT__inst_t80__DOT__u0__DOT___176_) 
                                               >> 1U))));
            __PVT__inst_t80__DOT__u0__DOT___255_ = 
                (1U & ((IData)(__PVT__inst_t80__DOT__u0__DOT___176_) 
                       >> 1U));
        }
        if (vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2309_) {
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___362_ 
                = (0xffU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___511_));
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___367_ 
                = (0xffU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___510_));
        } else if (vlSelf->__PVT__inst_t80__DOT__u0__DOT___215_) {
            if ((2U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2287_))) {
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___362_ 
                    = (0xffU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___728_) 
                                - (IData)(1U)));
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___367_ 
                    = (0xffU & (0xffU & (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___728_) 
                                          - (IData)(1U)) 
                                         >> 8U)));
            } else {
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___362_ 
                    = (0xffU & ((IData)(1U) + (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___728_)));
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___367_ 
                    = (0xffU & (0xffU & (((IData)(1U) 
                                          + (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___728_)) 
                                         >> 8U)));
            }
        } else {
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___362_ 
                = (0xffU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___728_));
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___367_ 
                = (0xffU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___728_) 
                            >> 8U));
        }
    }
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___307_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2325_) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__t_res));
    __Vfunc_inst_t80__DOT__u0__DOT____033650__76__s 
        = (((0x1bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
            << 4U) | (((0x19U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
                       << 3U) | (((0x18U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
                                  << 2U) | (((0x16U 
                                              == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
                                             << 1U) 
                                            | (0x17U 
                                               == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_))))));
    __Vfunc_inst_t80__DOT__u0__DOT____033650__76__b 
        = (((QData)((IData)(((0xffffff00U & (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___330_) 
                                              << 0x18U) 
                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___330_) 
                                                 << 0x10U) 
                                                | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___330_) 
                                                   << 8U)))) 
                             | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__save_mux)))) 
            << 8U) | (QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___330_)));
    __Vfunc_inst_t80__DOT__u0__DOT____033650__76__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___330_;
    __Vfunc_inst_t80__DOT__u0__DOT____033650__76__Vfuncout 
        = (0xffU & ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                     ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                         ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b 
                                                >> 0x10U))))
                             : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b 
                                                >> 0x18U)))))
                         : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b 
                                                >> 0x10U))))
                             : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b 
                                                >> 0x20U))))))
                     : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                         ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b 
                                                >> 0x10U))))
                             : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b 
                                                >> 0x18U)))))
                         : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b 
                                                >> 0x10U))))
                             : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__b)
                                     : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033650__76__a)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___356_ = __Vfunc_inst_t80__DOT__u0__DOT____033650__76__Vfuncout;
    __PVT__inst_t80__DOT__u0__DOT___142_ = ((0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___768_))
                                             ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__regbusc)
                                             : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__nextis_xy_fetch)
                                                 ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___730_)
                                                 : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___740_)));
    __Vfunc_inst_t80__DOT__u0__DOT____034002__83__s 
        = __PVT__inst_t80__DOT__u0__DOT___483_;
    __Vfunc_inst_t80__DOT__u0__DOT____034002__83__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___468_;
    __Vfunc_inst_t80__DOT__u0__DOT____034002__83__Vfuncout 
        = ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____034002__83__s) 
           | (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034002__83__a));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___484_ = __Vfunc_inst_t80__DOT__u0__DOT____034002__83__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____034004__84__s 
        = __PVT__inst_t80__DOT__u0__DOT___483_;
    __Vfunc_inst_t80__DOT__u0__DOT____034004__84__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___469_;
    __Vfunc_inst_t80__DOT__u0__DOT____034004__84__Vfuncout 
        = ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____034004__84__s) 
           | (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034004__84__a));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___485_ = __Vfunc_inst_t80__DOT__u0__DOT____034004__84__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___509_ = 
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__regs__DOT__regsl
        [__PVT__inst_t80__DOT__u0__DOT__regaddrb];
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___508_ = 
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__regs__DOT__regsh
        [__PVT__inst_t80__DOT__u0__DOT__regaddrb];
    __PVT__inst_t80__DOT__u0__DOT___506_ = vlSelf->__PVT__inst_t80__DOT__u0__DOT__regs__DOT__regsh
        [vlSelf->__PVT__inst_t80__DOT__u0__DOT__regaddra];
    __PVT__inst_t80__DOT__u0__DOT___507_ = vlSelf->__PVT__inst_t80__DOT__u0__DOT__regs__DOT__regsl
        [vlSelf->__PVT__inst_t80__DOT__u0__DOT__regaddra];
    __Vfunc_inst_t80__DOT__u0__DOT____033409__68__s 
        = (((2U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
            << 2U) | (((1U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
                       << 1U) | (0U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_)))));
    __Vfunc_inst_t80__DOT__u0__DOT____033409__68__b 
        = (((IData)(__PVT__inst_t80__DOT__u0__DOT___223_) 
            << 0x10U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___726_) 
                          << 8U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___724_)));
    __Vfunc_inst_t80__DOT__u0__DOT____033409__68__a 
        = __PVT__inst_t80__DOT__u0__DOT___223_;
    __Vfunc_inst_t80__DOT__u0__DOT____033409__68__Vfuncout 
        = (0xffU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033409__68__s)))
                     ? __Vfunc_inst_t80__DOT__u0__DOT____033409__68__b
                     : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033409__68__s)))
                         ? (__Vfunc_inst_t80__DOT__u0__DOT____033409__68__b 
                            >> 8U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033409__68__s)))
                                       ? (__Vfunc_inst_t80__DOT__u0__DOT____033409__68__b 
                                          >> 0x10U)
                                       : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033409__68__a)))));
    __PVT__inst_t80__DOT__u0__DOT___253_ = __Vfunc_inst_t80__DOT__u0__DOT____033409__68__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___321_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___307_)
          ? ((2U & ((IData)(vlSelf->__PVT__inst_t80__DOT___55_) 
                    >> 6U)) | (0U == (IData)(vlSelf->__PVT__inst_t80__DOT___55_)))
          : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___304_)
              ? (((IData)(__PVT__inst_t80__DOT__u0__DOT__alu__DOT___183_) 
                  << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___182_))
              : ((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_))
                  ? ((4U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))
                      ? (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___268_) 
                          << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___265_))
                      : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___290_))
                  : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___290_))));
    __Vfunc_inst_t80__DOT__u0__DOT____033211__66__s 
        = (((6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___015_)) 
            << 5U) | (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___015_)) 
                       << 4U) | (((0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___015_)) 
                                  << 3U) | (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___015_)) 
                                             << 2U) 
                                            | (((4U 
                                                 == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___015_)) 
                                                << 1U) 
                                               | (2U 
                                                  == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___015_)))))));
    __Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
        = (((QData)((IData)((((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___149_) 
                              << 0x18U) | ((0xff0000U 
                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__regbusc) 
                                               << 0x10U)) 
                                           | ((0xff00U 
                                               & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__regbusc) 
                                                  << 8U)) 
                                              | (0xffU 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___728_))))))) 
            << 0x10U) | (QData)((IData)((((IData)(vlSelf->__PVT__inst_t80__DOT___55_) 
                                          << 8U) | 
                                         (0xffU & (IData)(__PVT__inst_t80__DOT__u0__DOT___142_))))));
    __Vfunc_inst_t80__DOT__u0__DOT____033211__66__a 
        = (0xffU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___730_));
    __Vfunc_inst_t80__DOT__u0__DOT____033211__66__Vfuncout 
        = (0xffU & ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                     ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                         ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                             ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 0x18U)))))
                             : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 0x20U))))))
                         : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                             ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 0x18U)))))
                             : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 0x28U)))))))
                     : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                         ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                             ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 0x18U)))))
                             : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 0x20U))))))
                         : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                             ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 0x18U)))))
                             : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__b)
                                         : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033211__66__a))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___151_ = __Vfunc_inst_t80__DOT__u0__DOT____033211__66__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033218__67__s 
        = (((6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___015_)) 
            << 5U) | (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___015_)) 
                       << 4U) | (((0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___015_)) 
                                  << 3U) | (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___015_)) 
                                             << 2U) 
                                            | (((4U 
                                                 == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___015_)) 
                                                << 1U) 
                                               | (2U 
                                                  == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___015_)))))));
    __Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
        = (((QData)((IData)(((0xff000000U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___149_) 
                                             << 0x10U)) 
                             | ((0xff0000U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__regbusc) 
                                              << 8U)) 
                                | ((0xff00U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__regbusc)) 
                                   | (0xffU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___728_) 
                                               >> 8U))))))) 
            << 0x10U) | (QData)((IData)((((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_) 
                                          << 8U) | 
                                         (0xffU & ((IData)(__PVT__inst_t80__DOT__u0__DOT___142_) 
                                                   >> 8U))))));
    __Vfunc_inst_t80__DOT__u0__DOT____033218__67__a 
        = (0xffU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___730_) 
                    >> 8U));
    __Vfunc_inst_t80__DOT__u0__DOT____033218__67__Vfuncout 
        = (0xffU & ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                     ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                         ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                             ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 0x18U)))))
                             : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 0x20U))))))
                         : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                             ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 0x18U)))))
                             : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 0x28U)))))))
                     : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                         ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                             ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 0x18U)))))
                             : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 0x20U))))))
                         : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                             ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 0x18U)))))
                             : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__b)
                                         : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033218__67__a))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___152_ = __Vfunc_inst_t80__DOT__u0__DOT____033218__67__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033663__79__s 
        = (((0x1bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
            << 4U) | (((0x19U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
                       << 3U) | (((0x18U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
                                  << 2U) | (((0x16U 
                                              == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
                                             << 1U) 
                                            | (0x17U 
                                               == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_))))));
    __Vfunc_inst_t80__DOT__u0__DOT____033663__79__b 
        = (((QData)((IData)(((0xffff0000U & (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___362_) 
                                              << 0x18U) 
                                             | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___362_) 
                                                << 0x10U))) 
                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__save_mux) 
                                 << 8U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___362_))))) 
            << 8U) | (QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___362_)));
    __Vfunc_inst_t80__DOT__u0__DOT____033663__79__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___362_;
    __Vfunc_inst_t80__DOT__u0__DOT____033663__79__Vfuncout 
        = (0xffU & ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                     ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                         ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b 
                                                >> 0x10U))))
                             : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b 
                                                >> 0x18U)))))
                         : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b 
                                                >> 0x10U))))
                             : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b 
                                                >> 0x20U))))))
                     : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                         ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b 
                                                >> 0x10U))))
                             : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b 
                                                >> 0x18U)))))
                         : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b 
                                                >> 0x10U))))
                             : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__b)
                                     : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033663__79__a)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___363_ = __Vfunc_inst_t80__DOT__u0__DOT____033663__79__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033673__80__s 
        = (((0x1bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
            << 4U) | (((0x19U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
                       << 3U) | (((0x18U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
                                  << 2U) | (((0x16U 
                                              == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
                                             << 1U) 
                                            | (0x17U 
                                               == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_))))));
    __Vfunc_inst_t80__DOT__u0__DOT____033673__80__b 
        = (((QData)((IData)((((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___367_) 
                              << 0x18U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__save_mux) 
                                            << 0x10U) 
                                           | (0xffffU 
                                              & (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___367_) 
                                                  << 8U) 
                                                 | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___367_))))))) 
            << 8U) | (QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___367_)));
    __Vfunc_inst_t80__DOT__u0__DOT____033673__80__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___367_;
    __Vfunc_inst_t80__DOT__u0__DOT____033673__80__Vfuncout 
        = (0xffU & ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                     ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                         ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b 
                                                >> 0x10U))))
                             : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b 
                                                >> 0x18U)))))
                         : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b 
                                                >> 0x10U))))
                             : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b 
                                                >> 0x20U))))))
                     : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                         ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b 
                                                >> 0x10U))))
                             : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b 
                                                >> 0x18U)))))
                         : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b 
                                                >> 0x10U))))
                             : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__b)
                                     : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033673__80__a)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___368_ = __Vfunc_inst_t80__DOT__u0__DOT____033673__80__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____034110__85__s 
        = (((0xeU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___009_)) 
            << 9U) | (((0xdU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___009_)) 
                       << 8U) | (((0xcU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___009_)) 
                                  << 7U) | (((0xbU 
                                              == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___009_)) 
                                             << 6U) 
                                            | (((0xaU 
                                                 == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___009_)) 
                                                << 5U) 
                                               | (((9U 
                                                    == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___009_)) 
                                                   << 4U) 
                                                  | (((8U 
                                                       == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___009_)) 
                                                      << 3U) 
                                                     | (((6U 
                                                          == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___009_)) 
                                                         << 2U) 
                                                        | ((((0U 
                                                              == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___009_)) 
                                                             | ((1U 
                                                                 == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___009_)) 
                                                                | ((2U 
                                                                    == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___009_)) 
                                                                   | ((3U 
                                                                       == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___009_)) 
                                                                      | ((4U 
                                                                          == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___009_)) 
                                                                         | (5U 
                                                                            == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___009_))))))) 
                                                            << 1U) 
                                                           | (7U 
                                                              == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___009_)))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT____034110__85__b[0U] 
        = (((IData)((((QData)((IData)((((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___730_) 
                                        << 8U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)))) 
                      << 0x20U) | (QData)((IData)((0x1000000U 
                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___728_) 
                                                       << 8U) 
                                                      | (IData)(vlSelf->__PVT__inst_t80__DOT___55_))))))) 
            << 0x10U) | ((((1U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___009_))
                            ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___509_)
                            : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___508_)) 
                          << 8U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_)));
    __Vfunc_inst_t80__DOT__u0__DOT____034110__85__b[1U] 
        = (((IData)((((QData)((IData)((((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___730_) 
                                        << 8U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)))) 
                      << 0x20U) | (QData)((IData)((0x1000000U 
                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___728_) 
                                                       << 8U) 
                                                      | (IData)(vlSelf->__PVT__inst_t80__DOT___55_))))))) 
            >> 0x10U) | ((IData)(((((QData)((IData)(
                                                    (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___730_) 
                                                      << 8U) 
                                                     | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)))) 
                                    << 0x20U) | (QData)((IData)(
                                                                (0x1000000U 
                                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___728_) 
                                                                     << 8U) 
                                                                    | (IData)(vlSelf->__PVT__inst_t80__DOT___55_)))))) 
                                  >> 0x20U)) << 0x10U));
    __Vfunc_inst_t80__DOT__u0__DOT____034110__85__b[2U] 
        = ((IData)(((((QData)((IData)((((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___730_) 
                                        << 8U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)))) 
                      << 0x20U) | (QData)((IData)((0x1000000U 
                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___728_) 
                                                       << 8U) 
                                                      | (IData)(vlSelf->__PVT__inst_t80__DOT___55_)))))) 
                    >> 0x20U)) >> 0x10U);
    __Vfunc_inst_t80__DOT__u0__DOT____034110__85__Vfuncout 
        = (0xffU & (((((((((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034110__85__s))) 
                           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034110__85__s)))) 
                          | (4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034110__85__s)))) 
                         | (8U == (8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034110__85__s)))) 
                        | (0x10U == (0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034110__85__s)))) 
                       | (0x20U == (0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034110__85__s)))) 
                      | (0x40U == (0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034110__85__s)))) 
                     | (0x80U == (0x80U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034110__85__s))))
                     ? ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034110__85__s)))
                         ? __Vfunc_inst_t80__DOT__u0__DOT____034110__85__b[0U]
                         : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034110__85__s)))
                             ? ((__Vfunc_inst_t80__DOT__u0__DOT____034110__85__b[0U] 
                                 << 0x18U) | (__Vfunc_inst_t80__DOT__u0__DOT____034110__85__b[0U] 
                                              >> 8U))
                             : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034110__85__s)))
                                 ? ((__Vfunc_inst_t80__DOT__u0__DOT____034110__85__b[0U] 
                                     << 0x10U) | (__Vfunc_inst_t80__DOT__u0__DOT____034110__85__b[0U] 
                                                  >> 0x10U))
                                 : ((8U == (8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034110__85__s)))
                                     ? ((__Vfunc_inst_t80__DOT__u0__DOT____034110__85__b[0U] 
                                         << 8U) | (
                                                   __Vfunc_inst_t80__DOT__u0__DOT____034110__85__b[0U] 
                                                   >> 0x18U))
                                     : ((0x10U == (0x10U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034110__85__s)))
                                         ? __Vfunc_inst_t80__DOT__u0__DOT____034110__85__b[1U]
                                         : ((0x20U 
                                             == (0x20U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034110__85__s)))
                                             ? ((__Vfunc_inst_t80__DOT__u0__DOT____034110__85__b[1U] 
                                                 << 0x18U) 
                                                | (__Vfunc_inst_t80__DOT__u0__DOT____034110__85__b[1U] 
                                                   >> 8U))
                                             : ((0x40U 
                                                 == 
                                                 (0x40U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034110__85__s)))
                                                 ? 
                                                ((__Vfunc_inst_t80__DOT__u0__DOT____034110__85__b[1U] 
                                                  << 0x10U) 
                                                 | (__Vfunc_inst_t80__DOT__u0__DOT____034110__85__b[1U] 
                                                    >> 0x10U))
                                                 : 
                                                ((__Vfunc_inst_t80__DOT__u0__DOT____034110__85__b[1U] 
                                                  << 8U) 
                                                 | (__Vfunc_inst_t80__DOT__u0__DOT____034110__85__b[1U] 
                                                    >> 0x18U)))))))))
                     : ((0x100U == (0x100U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034110__85__s)))
                         ? __Vfunc_inst_t80__DOT__u0__DOT____034110__85__b[2U]
                         : ((0x200U == (0x200U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034110__85__s)))
                             ? ((__Vfunc_inst_t80__DOT__u0__DOT____034110__85__b[2U] 
                                 << 0x18U) | (__Vfunc_inst_t80__DOT__u0__DOT____034110__85__b[2U] 
                                              >> 8U))
                             : 0U))));
    __PVT__inst_t80__DOT__u0__DOT___533_ = __Vfunc_inst_t80__DOT__u0__DOT____034110__85__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__regbusa 
        = (((IData)(__PVT__inst_t80__DOT__u0__DOT___506_) 
            << 8U) | (IData)(__PVT__inst_t80__DOT__u0__DOT___507_));
    __Vfunc_inst_t80__DOT__u0__DOT____034148__87__s 
        = (((0xaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_)) 
            << 5U) | (((9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_)) 
                       << 4U) | (((8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_)) 
                                  << 3U) | (((6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_)) 
                                             << 2U) 
                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___546_) 
                                                << 1U) 
                                               | (7U 
                                                  == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_)))))));
    __Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
        = (((QData)((IData)((((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___728_) 
                              << 8U) | (IData)(vlSelf->__PVT__inst_t80__DOT___55_)))) 
            << 0x10U) | (QData)((IData)(((((1U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2290_))
                                            ? (IData)(__PVT__inst_t80__DOT__u0__DOT___507_)
                                            : (IData)(__PVT__inst_t80__DOT__u0__DOT___506_)) 
                                          << 8U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_)))));
    __Vfunc_inst_t80__DOT__u0__DOT____034148__87__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_;
    __Vfunc_inst_t80__DOT__u0__DOT____034148__87__Vfuncout 
        = (0xffU & ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                     ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                         ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                             ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 0x18U)))))
                             : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 0x20U))))))
                         : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                             ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 0x18U)))))
                             : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 0x28U)))))))
                     : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                         ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                             ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 0x18U)))))
                             : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 0x20U))))))
                         : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                             ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 0x18U)))))
                             : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__b)
                                         : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034148__87__a))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___552_ = __Vfunc_inst_t80__DOT__u0__DOT____034148__87__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___271_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___298_)
          ? (IData)(__PVT__inst_t80__DOT__u0__DOT___253_)
          : (IData)(__PVT__inst_t80__DOT__u0__DOT___223_));
    __Vfunc_inst_t80__DOT__u0__DOT____033427__71__s 
        = (((2U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
            << 2U) | (((1U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
                       << 1U) | (0U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_)))));
    __Vfunc_inst_t80__DOT__u0__DOT____033427__71__b 
        = (6U & ((- (IData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___261_))) 
                 << 1U));
    __Vfunc_inst_t80__DOT__u0__DOT____033427__71__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___261_;
    __Vfunc_inst_t80__DOT__u0__DOT____033427__71__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033427__71__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033427__71__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033427__71__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033427__71__b) 
                         >> 1U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033427__71__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033427__71__b) 
                                       >> 2U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033427__71__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___262_ = __Vfunc_inst_t80__DOT__u0__DOT____033427__71__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___322_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___304_)
          ? ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___800_)
              ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___293_)
              : (IData)(__PVT__inst_t80__DOT__u0__DOT__alu__DOT___176_))
          : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___293_));
    __Vfunc_inst_t80__DOT__u0__DOT____033415__69__s 
        = (((2U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
            << 2U) | (((1U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))) 
                       << 1U) | (0U == (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_)))));
    __Vfunc_inst_t80__DOT__u0__DOT____033415__69__b 
        = (6U & ((- (IData)((IData)(__PVT__inst_t80__DOT__u0__DOT___255_))) 
                 << 1U));
    __Vfunc_inst_t80__DOT__u0__DOT____033415__69__a 
        = __PVT__inst_t80__DOT__u0__DOT___255_;
    __Vfunc_inst_t80__DOT__u0__DOT____033415__69__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033415__69__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033415__69__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033415__69__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033415__69__b) 
                         >> 1U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033415__69__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033415__69__b) 
                                       >> 2U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033415__69__a)))));
    __PVT__inst_t80__DOT__u0__DOT___256_ = __Vfunc_inst_t80__DOT__u0__DOT____033415__69__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____034146__86__s 
        = (((0xaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_)) 
            << 5U) | (((9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_)) 
                       << 4U) | (((8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_)) 
                                  << 3U) | (((6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_)) 
                                             << 2U) 
                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___546_) 
                                                << 1U) 
                                               | (7U 
                                                  == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_)))))));
    __Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
        = (0xffffffffffffULL & (((QData)((IData)(__PVT__inst_t80__DOT__u0__DOT___533_)) 
                                 << 0x28U) | (((QData)((IData)(__PVT__inst_t80__DOT__u0__DOT___533_)) 
                                               << 0x20U) 
                                              | (((QData)((IData)(__PVT__inst_t80__DOT__u0__DOT___533_)) 
                                                  << 0x18U) 
                                                 | (((QData)((IData)(__PVT__inst_t80__DOT__u0__DOT___533_)) 
                                                     << 0x10U) 
                                                    | (((QData)((IData)(__PVT__inst_t80__DOT__u0__DOT___533_)) 
                                                        << 8U) 
                                                       | (QData)((IData)(__PVT__inst_t80__DOT__u0__DOT___533_))))))));
    vlSelf->__Vfunc_inst_t80__DOT__u0__DOT____034146__86__Vfuncout 
        = (0xffU & ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                     ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                         ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                             ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 0x18U)))))
                             : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 0x20U))))))
                         : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                             ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 0x18U)))))
                             : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 0x28U)))))))
                     : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                         ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                             ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 0x18U)))))
                             : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 0x20U))))))
                         : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                             ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 0x18U)))))
                             : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 0x10U))))
                                 : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                     ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : (IData)(
                                                   (__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b 
                                                    >> 8U)))
                                     : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__s))
                                         ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____034146__86__b)
                                         : 0U)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___551_ = vlSelf->__Vfunc_inst_t80__DOT__u0__DOT____034146__86__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__id16 = (0xffffU 
                                                   & ((2U 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2287_))
                                                       ? 
                                                      ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__regbusa) 
                                                       - (IData)(1U))
                                                       : 
                                                      ((IData)(1U) 
                                                       + (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__regbusa))));
    __Vfunc_inst_t80__DOT__u0__DOT____033651__77__s 
        = (((0x1bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
            << 4U) | (((0x19U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
                       << 3U) | (((0x18U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
                                  << 2U) | (((0x16U 
                                              == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
                                             << 1U) 
                                            | (0x17U 
                                               == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_))))));
    __Vfunc_inst_t80__DOT__u0__DOT____033651__77__b 
        = (((QData)((IData)((((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___271_) 
                              << 0x18U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___271_) 
                                            << 0x10U) 
                                           | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___271_) 
                                               << 8U) 
                                              | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___271_)))))) 
            << 8U) | (QData)((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__save_mux)));
    __Vfunc_inst_t80__DOT__u0__DOT____033651__77__a 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___271_;
    __Vfunc_inst_t80__DOT__u0__DOT____033651__77__Vfuncout 
        = (0xffU & ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                     ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                         ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b 
                                                >> 0x10U))))
                             : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b 
                                                >> 0x18U)))))
                         : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b 
                                                >> 0x10U))))
                             : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b 
                                                >> 0x20U))))))
                     : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                         ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b 
                                                >> 0x10U))))
                             : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b 
                                                >> 0x18U)))))
                         : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b 
                                                >> 0x10U))))
                             : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__b)
                                     : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033651__77__a)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___357_ = __Vfunc_inst_t80__DOT__u0__DOT____033651__77__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___338_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___334_)
          ? ((4U & ((IData)(__PVT__inst_t80__DOT__u0__DOT__alu__DOT___185_) 
                    << 2U)) | (1U & ((IData)(__PVT__inst_t80__DOT__u0__DOT__alu__DOT___185_) 
                                     >> 2U))) : ((4U 
                                                  & (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___304_)
                                                       ? (IData)(__PVT__inst_t80__DOT__u0__DOT__alu__DOT___181_)
                                                       : 
                                                      ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___082_)
                                                        ? 
                                                       ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                        >> 5U)
                                                        : 
                                                       ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2313_)
                                                         ? 
                                                        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___722_) 
                                                         >> 5U)
                                                         : 
                                                        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___177_) 
                                                         >> 2U)))) 
                                                     << 2U)) 
                                                 | ((((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___307_)) 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___304_)
                                                          ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___180_)
                                                          : 
                                                         ((3U 
                                                           == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_))
                                                           ? 
                                                          ((4U 
                                                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))
                                                            ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___262_)
                                                            : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___261_))
                                                           : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___261_)))) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___304_)
                                                           ? (IData)(__PVT__inst_t80__DOT__u0__DOT__alu__DOT___179_)
                                                           : 
                                                          ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___082_)
                                                            ? 
                                                           ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                            >> 3U)
                                                            : 
                                                           ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2313_)
                                                             ? 
                                                            ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___722_) 
                                                             >> 3U)
                                                             : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___177_))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___285_ = 
        ((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_))
          ? ((4U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))
              ? (((IData)(__PVT__inst_t80__DOT__u0__DOT___259_) 
                  << 1U) | (IData)(__PVT__inst_t80__DOT__u0__DOT___256_))
              : (IData)(__PVT__inst_t80__DOT__u0__DOT___284_))
          : (IData)(__PVT__inst_t80__DOT__u0__DOT___284_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___337_ = 
        (1U & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___334_)) 
               & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___307_)) 
                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___304_)
                      ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___177_)
                      : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___285_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___342_ = 
        (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___341_)
                ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___782_)
                : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___307_)
                    ? (~ (1U & VL_REDXOR_8(vlSelf->__PVT__inst_t80__DOT___55_)))
                    : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___304_)
                        ? (IData)(__PVT__inst_t80__DOT__u0__DOT__alu__DOT___178_)
                        : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___285_) 
                           >> 1U)))));
    __Vfunc_inst_t80__DOT__u0__DOT____033653__78__s 
        = (((0x1bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
            << 4U) | (((0x19U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
                       << 3U) | (((0x18U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
                                  << 2U) | (((0x16U 
                                              == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
                                             << 1U) 
                                            | (0x17U 
                                               == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_))))));
    __Vfunc_inst_t80__DOT__u0__DOT____033653__78__b 
        = (((QData)((IData)((((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__save_mux) 
                              << 0x18U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___321_) 
                                            << 0x16U) 
                                           | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___338_) 
                                               << 0x13U) 
                                              | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___342_) 
                                                  << 0x12U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___337_) 
                                                     << 0x11U) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___322_) 
                                                        << 0x10U) 
                                                       | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___321_) 
                                                           << 0xeU) 
                                                          | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___338_) 
                                                              << 0xbU) 
                                                             | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___342_) 
                                                                 << 0xaU) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___337_) 
                                                                    << 9U) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___322_) 
                                                                       << 8U) 
                                                                      | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___321_) 
                                                                          << 6U) 
                                                                         | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___338_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___342_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___337_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___322_)))))))))))))))))) 
            << 8U) | (QData)((IData)((((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___321_) 
                                       << 6U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___338_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___342_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___337_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___322_))))))));
    __Vfunc_inst_t80__DOT__u0__DOT____033653__78__a 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___321_) 
            << 6U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___338_) 
                       << 3U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___342_) 
                                  << 2U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___337_) 
                                             << 1U) 
                                            | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___322_)))));
    __Vfunc_inst_t80__DOT__u0__DOT____033653__78__Vfuncout 
        = (0xffU & ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                     ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                         ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b 
                                                >> 0x10U))))
                             : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b 
                                                >> 0x18U)))))
                         : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b 
                                                >> 0x10U))))
                             : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b 
                                                >> 0x20U))))))
                     : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                         ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b 
                                                >> 0x10U))))
                             : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b 
                                                >> 0x18U)))))
                         : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b 
                                                >> 0x10U))))
                             : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b)
                                     : (IData)((__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b 
                                                >> 8U)))
                                 : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__s))
                                     ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__b)
                                     : (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033653__78__a)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___358_ = __Vfunc_inst_t80__DOT__u0__DOT____033653__78__Vfuncout;
    if (vlSelf->__PVT__inst_t80__DOT__u0__DOT__clken) {
        if ((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_))) {
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___725_ 
                = ((4U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2310_))
                    ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___270_)
                    : (IData)(vlSelf->inst_t80__DOT__u0__DOT____VdfgTmp_he66cde70__0));
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___739_ 
                = ((0xff00U & (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2308_)
                                 ? (IData)(vlSelf->__PVT__inst_t80__DOT___55_)
                                 : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___082_)
                                     ? ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___740_) 
                                        >> 8U) : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___201_)
                                                   ? 
                                                  ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___202_) 
                                                   >> 8U)
                                                   : 
                                                  ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___197_)
                                                    ? 0U
                                                    : 
                                                   ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___740_) 
                                                    >> 8U))))) 
                               << 8U)) | (0xffU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2307_)
                                                    ? (IData)(vlSelf->__PVT__inst_t80__DOT___55_)
                                                    : 
                                                   ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___082_)
                                                     ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___740_)
                                                     : 
                                                    ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___201_)
                                                      ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___202_)
                                                      : 
                                                     ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___197_)
                                                       ? 
                                                      (0x38U 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))
                                                       : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___740_)))))));
        } else {
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___725_ 
                = vlSelf->inst_t80__DOT__u0__DOT____VdfgTmp_he66cde70__0;
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___739_ 
                = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___082_)
                    ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___740_)
                    : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___201_)
                        ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___202_)
                        : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___197_)
                            ? (0x38U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))
                            : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___740_))));
        }
        if (vlSelf->__PVT__inst_t80__DOT__u0__DOT___082_) {
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___737_ 
                = (1U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___738_));
            if ((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_))) {
                if ((0U != (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2283_))) {
                    if ((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2283_))) {
                        vlSelf->__PVT__inst_t80__DOT__u0__DOT___743_ = 0U;
                        vlSelf->__PVT__inst_t80__DOT__u0__DOT___771_ 
                            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___772_;
                    } else {
                        vlSelf->__PVT__inst_t80__DOT__u0__DOT___743_ 
                            = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2283_;
                        vlSelf->__PVT__inst_t80__DOT__u0__DOT___771_ 
                            = ((2U != (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2283_)) 
                               & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___772_));
                    }
                } else {
                    vlSelf->__PVT__inst_t80__DOT__u0__DOT___743_ = 0U;
                    vlSelf->__PVT__inst_t80__DOT__u0__DOT___771_ = 0U;
                }
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___811_ 
                    = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___724_) 
                        << 8U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___726_));
            } else {
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___743_ 
                    = vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_;
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___771_ 
                    = vlSelf->__PVT__inst_t80__DOT__u0__DOT___772_;
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___811_ 
                    = vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_;
            }
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___719_ 
                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___720_;
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___721_ 
                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___722_;
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___793_ = 0U;
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___775_ 
                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___776_;
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___729_ 
                = (0xffffU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___730_) 
                              + ((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
                                 & ((~ ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___756_) 
                                        | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2329_))) 
                                    & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___804_)) 
                                       & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___806_)) 
                                          & (~ ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2302_) 
                                                | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2305_)))))))));
        } else {
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___737_ 
                = (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2314_)
                          ? (~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___738_))
                          : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___738_)));
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___743_ 
                = (((6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                    & (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2283_)))
                    ? 1U : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_));
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___771_ 
                = ((6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                   | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___772_));
            if (vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2313_) {
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___719_ 
                    = vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_;
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___721_ 
                    = vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_;
            } else {
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___719_ 
                    = vlSelf->__PVT__inst_t80__DOT__u0__DOT___720_;
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___721_ 
                    = vlSelf->__PVT__inst_t80__DOT__u0__DOT___722_;
            }
            if (vlSelf->__PVT__inst_t80__DOT__u0__DOT__t_res) {
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___793_ 
                    = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2295_;
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___775_ 
                    = ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___774_)) 
                       & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___341_) 
                          | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2322_)));
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___811_ 
                    = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2302_)
                        ? (IData)(vlSelf->inst_t80__DOT__u0__DOT____VdfgTmp_hbde73ddd__0)
                        : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2304_)
                            ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__regbusc)
                            : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___133_)
                                ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___740_)
                                : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___135_)
                                    ? 0x66U : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___139_)
                                                ? (IData)(vlSelf->inst_t80__DOT__u0__DOT____VdfgTmp_hb2fda09c__0)
                                                : (
                                                   ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___152_) 
                                                    << 8U) 
                                                   | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___151_)))))));
            } else {
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___793_ = 0U;
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___775_ 
                    = vlSelf->__PVT__inst_t80__DOT__u0__DOT___776_;
                vlSelf->__PVT__inst_t80__DOT__u0__DOT___811_ 
                    = vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_;
            }
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___729_ 
                = (0xffffU & ((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_))
                               ? ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___776_)
                                   ? ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___730_) 
                                      - (IData)(2U))
                                   : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2303_)
                                       ? ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___730_) 
                                          + (IData)(vlSelf->inst_t80__DOT__u0__DOT____VdfgTmp_h8fd225ae__0))
                                       : ((((7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2345_)) 
                                           | ((6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                              | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2284_)))
                                           ? ((IData)(1U) 
                                              + (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___730_))
                                           : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___178_))))
                               : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___178_)));
        }
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___789_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2299_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___799_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2298_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___801_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2281_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___791_ 
            = ((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
               & (IData)(((1U == (5U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2295_))) 
                          & (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)))));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___731_ 
            = ((IData)(((4U == (6U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2290_))) 
                        & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___379_)))
                ? (3U | (4U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___768_) 
                               << 1U))) : (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___738_) 
                                            << 2U) 
                                           | (3U & 
                                              ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2290_) 
                                               >> 1U))));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___733_ 
            = ((IData)(((4U == (6U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___009_))) 
                        & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___379_)))
                ? (3U | (4U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___768_) 
                               << 1U))) : (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___738_) 
                                            << 2U) 
                                           | (3U & 
                                              ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___009_) 
                                               >> 1U))));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___735_ 
            = ((((0U != (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___768_)) 
                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___391_)) 
                | (6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))
                ? (3U | (4U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___768_) 
                               << 1U))) : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___391_)
                                            ? (2U | 
                                               ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___738_) 
                                                << 2U))
                                            : (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___738_) 
                                                << 2U) 
                                               | ((IData)(vlSelf->__VdfgTmp_h7bf8ddc8__0)
                                                   ? 2U
                                                   : 
                                                  ((IData)(vlSelf->__VdfgTmp_h426b99eb__0)
                                                    ? 3U
                                                    : 
                                                   (3U 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2300_)))))));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___795_ 
            = ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___082_)) 
               & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__t_res) 
                  & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2296_)));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___797_ 
            = ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___082_)) 
               & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__t_res) 
                  & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2297_)));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___787_ 
            = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__t_res)
                ? ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2289_)
                    ? 0x17U : (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2288_) 
                                << 4U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___008_)))
                : 0U);
        if (vlSelf->__PVT__inst_t80__DOT__u0__DOT___447_) {
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___813_ 
                = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2332_)
                    ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___048_)
                    : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___356_));
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___727_ 
                = (0xffffU & (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___368_) 
                               << 8U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___363_)));
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___715_ 
                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___357_;
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___717_ 
                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___358_;
        } else {
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___813_ 
                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___330_;
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___727_ 
                = (0xffffU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___082_)
                               ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___728_)
                               : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2309_)
                                   ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__regbusc)
                                   : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___215_)
                                       ? ((2U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2287_))
                                           ? ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___728_) 
                                              - (IData)(1U))
                                           : ((IData)(1U) 
                                              + (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___728_)))
                                       : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___728_)))));
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___715_ 
                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___271_;
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___717_ 
                = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___321_) 
                    << 6U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___338_) 
                               << 3U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___342_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___337_) 
                                           << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___322_)))));
        }
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___745_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT__regbusa;
        if (vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2332_) {
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___785_ 
                = vlSelf->__PVT__inst_t80__DOT___55_;
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___783_ 
                = vlSelf->__PVT__inst_t80__DOT___55_;
        } else {
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___785_ 
                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___552_;
            vlSelf->__PVT__inst_t80__DOT__u0__DOT___783_ 
                = vlSelf->__PVT__inst_t80__DOT__u0__DOT___551_;
        }
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___781_ 
            = (((4U == (IData)(vlSelf->inst_t80__DOT__u0__DOT____VdfgTmp_h548e9c6f__0)) 
                & ((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
                   | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___501_)))
                ? (0U != (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__id16))
                : (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___798_) 
                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2315_))
                    ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___182_)
                    : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___782_)));
    } else {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___725_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___726_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___737_ 
            = (1U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___738_));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___789_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___790_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___799_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___800_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___801_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___802_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___791_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___792_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___743_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___771_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___772_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___731_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___732_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___719_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___720_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___721_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___722_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___733_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___734_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___739_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___740_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___735_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___736_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___793_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___795_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___796_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___797_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___798_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___787_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___775_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___776_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___729_ 
            = (0xffffU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___730_));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___813_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___811_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___727_ 
            = (0xffffU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___728_));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___745_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___746_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___785_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___783_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___781_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___782_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___715_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___717_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_;
    }
}
