// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vsim_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vsim_top__Syms.h"
#include "Vsim_top_colecovision.h"

VL_INLINE_OPT void Vsim_top_colecovision___nba_sequent__TOP__sim_top__cv__1(Vsim_top_colecovision* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vsim_top_colecovision___nba_sequent__TOP__sim_top__cv__1\n"); );
    // Init
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__Vfuncout = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034926__111__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034926__111__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034926__111__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034926__111__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034929__112__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034929__112__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034929__112__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034929__112__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__b = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034960__114__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034960__114__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034960__114__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034960__114__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034965__116__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034965__116__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034965__116__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034965__116__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034999__119__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034999__119__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034999__119__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034999__119__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035002__120__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035002__120__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035002__120__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035002__120__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035032__121__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035032__121__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035032__121__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035032__121__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035039__124__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035039__124__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035039__124__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035039__124__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035042__125__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035042__125__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035042__125__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035042__125__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035053__126__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035053__126__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035053__126__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035053__126__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035056__127__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035056__127__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035056__127__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035056__127__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035067__128__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035067__128__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035067__128__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035067__128__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035070__129__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035070__129__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035070__129__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035070__129__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035084__130__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035084__130__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035084__130__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035084__130__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035087__131__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035087__131__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035087__131__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035087__131__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035090__132__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035090__132__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035090__132__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035090__132__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035093__133__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035093__133__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035093__133__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035093__133__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035104__134__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035104__134__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035104__134__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035104__134__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035107__135__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035107__135__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035107__135__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035107__135__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035110__136__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035110__136__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035110__136__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035110__136__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035121__137__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035121__137__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035121__137__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035121__137__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035124__138__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035124__138__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035124__138__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035124__138__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035127__139__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035127__139__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035127__139__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035127__139__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035141__140__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035141__140__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035141__140__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035141__140__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035144__141__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035144__141__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035144__141__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035144__141__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035147__142__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035147__142__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035147__142__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035147__142__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035150__143__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035150__143__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035150__143__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035150__143__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035153__144__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035153__144__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035153__144__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035153__144__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035183__145__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035183__145__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035183__145__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035183__145__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035187__146__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035187__146__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035187__146__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035187__146__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035221__150__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035221__150__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035221__150__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035221__150__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035234__154__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035234__154__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035234__154__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035234__154__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035256__157__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035256__157__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035256__157__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035256__157__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035267__160__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035267__160__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035267__160__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035267__160__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035306__164__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035306__164__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035306__164__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035306__164__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__Vfuncout = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035312__166__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035312__166__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035312__166__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035312__166__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035316__167__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035316__167__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035316__167__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035316__167__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035357__168__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035357__168__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035357__168__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035357__168__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035361__169__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035361__169__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035361__169__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035361__169__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__Vfuncout = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035369__172__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035369__172__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035369__172__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035369__172__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__a = 0;
    SData/*14:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035607__180__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035607__180__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035607__180__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035607__180__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035609__181__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035609__181__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035609__181__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035609__181__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035614__183__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035614__183__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035614__183__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035614__183__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035617__184__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035617__184__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035617__184__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035617__184__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035712__186__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035712__186__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035712__186__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035712__186__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__Vfuncout = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035717__188__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035717__188__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035722__190__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035722__190__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035722__190__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035722__190__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035725__191__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035725__191__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035725__191__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035725__191__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035729__192__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035729__192__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035729__192__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035729__192__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035732__193__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035732__193__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035732__193__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035732__193__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035767__195__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035767__195__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035767__195__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035767__195__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__Vfuncout = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035772__197__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035772__197__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035772__197__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035772__197__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035777__199__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035777__199__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035777__199__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035777__199__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035780__200__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035780__200__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035780__200__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035780__200__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035784__201__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035784__201__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035784__201__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035784__201__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035787__202__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035787__202__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035787__202__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035787__202__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__a = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035814__204__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035814__204__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035814__204__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035814__204__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035818__205__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035818__205__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035818__205__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035818__205__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035822__206__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035822__206__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035822__206__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035822__206__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035826__207__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035826__207__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035826__207__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035826__207__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__a = 0;
    SData/*14:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035845__209__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035845__209__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035845__209__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035845__209__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035860__213__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035860__213__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035860__213__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035860__213__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035959__223__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035959__223__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035959__223__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035959__223__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035961__224__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035961__224__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035961__224__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035961__224__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035974__229__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035974__229__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035974__229__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035974__229__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035978__230__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035978__230__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035978__230__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035978__230__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035982__231__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035982__231__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035982__231__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035982__231__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036039__232__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036039__232__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036039__232__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036039__232__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036042__233__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036042__233__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036042__233__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036042__233__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036045__234__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036045__234__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036045__234__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036045__234__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__Vfuncout = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__b = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036098__236__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036098__236__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036098__236__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036098__236__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036103__238__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036103__238__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036103__238__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036103__238__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036137__240__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036137__240__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036137__240__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036137__240__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036140__241__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036140__241__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036140__241__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036140__241__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036143__242__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036143__242__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036143__242__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036143__242__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036164__245__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036164__245__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036164__245__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036164__245__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036167__246__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036167__246__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036167__246__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036167__246__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036170__247__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036170__247__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036170__247__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036170__247__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036190__250__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036190__250__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036190__250__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036190__250__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036193__251__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036193__251__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036193__251__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036193__251__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036196__252__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036196__252__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036196__252__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036196__252__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036217__255__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036217__255__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036217__255__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036217__255__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036220__256__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036220__256__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036220__256__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036220__256__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036223__257__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036223__257__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036223__257__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036223__257__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036243__260__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036243__260__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036243__260__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036243__260__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036246__261__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036246__261__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036246__261__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036246__261__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036249__262__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036249__262__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036249__262__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036249__262__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036268__264__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036268__264__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036268__264__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036268__264__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036271__265__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036271__265__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036271__265__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036271__265__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036276__267__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036276__267__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036276__267__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036276__267__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036281__269__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036281__269__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036281__269__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036281__269__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036284__270__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036284__270__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036284__270__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036284__270__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036288__271__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036288__271__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036288__271__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036288__271__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036291__272__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036291__272__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036291__272__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036291__272__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036324__278__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036324__278__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036324__278__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036324__278__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036327__279__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036327__279__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036327__279__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036327__279__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__s = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__b = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036419__289__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036419__289__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036419__289__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036419__289__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036422__290__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036422__290__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036422__290__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036422__290__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036466__294__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036466__294__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036466__294__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036466__294__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036470__295__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036470__295__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036470__295__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036470__295__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036473__296__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036473__296__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036473__296__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036473__296__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036476__297__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036476__297__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036476__297__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036476__297__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__Vfuncout = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__b = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036539__301__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036539__301__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036539__301__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036539__301__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036545__303__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036545__303__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036545__303__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036545__303__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036548__304__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036548__304__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036548__304__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036548__304__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036585__306__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036585__306__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036585__306__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036585__306__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036589__307__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036589__307__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036589__307__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036589__307__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036593__308__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036593__308__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036593__308__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036593__308__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036596__309__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036596__309__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036596__309__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036596__309__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036600__310__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036600__310__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036600__310__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036600__310__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036634__312__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036634__312__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036634__312__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036634__312__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036637__313__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036637__313__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036637__313__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036637__313__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036640__314__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036640__314__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036640__314__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036640__314__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036643__315__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036643__315__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036643__315__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036643__315__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036656__317__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036656__317__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036656__317__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036656__317__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036659__318__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036659__318__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036659__318__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036659__318__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036662__319__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036662__319__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036662__319__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036662__319__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036665__320__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036665__320__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036665__320__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036665__320__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036668__321__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036668__321__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036668__321__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036668__321__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038615__415__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038615__415__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038615__415__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038615__415__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038630__420__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038630__420__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038630__420__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038630__420__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038679__423__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038679__423__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038679__423__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038679__423__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__Vfuncout = 0;
    SData/*15:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038688__426__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038688__426__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038688__426__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038688__426__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__Vfuncout = 0;
    SData/*15:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__a = 0;
    SData/*15:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038747__435__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038747__435__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038747__435__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038747__435__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038750__436__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038750__436__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038750__436__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038750__436__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038753__437__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038753__437__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038753__437__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038753__437__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__Vfuncout = 0;
    SData/*15:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__a = 0;
    SData/*15:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038808__447__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038808__447__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038808__447__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038808__447__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038919__456__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038919__456__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038919__456__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038919__456__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038921__457__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038921__457__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038921__457__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038921__457__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038934__462__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038934__462__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038934__462__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038934__462__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038938__463__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038938__463__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038938__463__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038938__463__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039001__471__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039001__471__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039001__471__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039001__471__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039003__472__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039003__472__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039003__472__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039003__472__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039016__477__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039016__477__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039016__477__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039016__477__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039020__478__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039020__478__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039020__478__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039020__478__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039046__480__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039046__480__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039046__480__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039046__480__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039048__481__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039048__481__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039048__481__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039048__481__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039050__482__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039050__482__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039050__482__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039050__482__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039055__484__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039055__484__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039055__484__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039055__484__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039059__485__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039059__485__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039059__485__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039059__485__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039062__486__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039062__486__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039062__486__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039062__486__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039065__487__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039065__487__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039065__487__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039065__487__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039068__488__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039068__488__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039068__488__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039068__488__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039085__490__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039085__490__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039085__490__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039085__490__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039087__491__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039087__491__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039087__491__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039087__491__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039089__492__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039089__492__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039089__492__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039089__492__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039094__494__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039094__494__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039094__494__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039094__494__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039098__495__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039098__495__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039098__495__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039098__495__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039101__496__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039101__496__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039101__496__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039101__496__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039104__497__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039104__497__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039104__497__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039104__497__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039118__498__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039118__498__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039118__498__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039118__498__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039122__499__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039122__499__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039122__499__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039122__499__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039125__500__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039125__500__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039125__500__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039125__500__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039128__501__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039128__501__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039128__501__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039128__501__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039131__502__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039131__502__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039131__502__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039131__502__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039178__506__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039178__506__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039178__506__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039178__506__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039181__507__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039181__507__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039181__507__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039181__507__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039184__508__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039184__508__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039184__508__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039184__508__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039229__512__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039229__512__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039229__512__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039229__512__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039232__513__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039232__513__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039232__513__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039232__513__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039235__514__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039235__514__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039235__514__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039235__514__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__Vfuncout = 0;
    SData/*15:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039282__517__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039282__517__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039282__517__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039282__517__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__a = 0;
    SData/*15:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039294__521__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039294__521__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039294__521__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039294__521__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039304__524__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039304__524__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039304__524__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039304__524__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039307__525__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039307__525__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039307__525__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039307__525__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039310__526__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039310__526__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039310__526__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039310__526__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__Vfuncout = 0;
    SData/*15:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039345__529__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039345__529__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039345__529__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039345__529__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__a = 0;
    SData/*15:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039357__533__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039357__533__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039357__533__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039357__533__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039364__535__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039364__535__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039364__535__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039364__535__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039367__536__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039367__536__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039367__536__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039367__536__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039370__537__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039370__537__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039370__537__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039370__537__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039373__538__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039373__538__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039373__538__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039373__538__s = 0;
    // Body
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___574_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___573_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___780_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___779_));
    if (vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_) {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___770_ = 0U;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___766_ = 0U;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___720_ = 0xffU;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___802_ = 0U;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___726_ = 0U;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___728_ = 0xffffU;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_ = 0U;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___730_ = 0U;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___724_ = 0U;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___740_ = 0U;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_ = 0xffU;
        vlSelf->__PVT__inst_t80__DOT___55_ = 0U;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___722_ = 0xffU;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___768_ = 0U;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_ = 0U;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_ = 0U;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_ = 0xffU;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_ = 0U;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_ = 1U;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_ = 0U;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_ = 0U;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_ = 0U;
    } else {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___770_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___769_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___766_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___765_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___720_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___719_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___802_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___801_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___726_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___725_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___728_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___727_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___787_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___730_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___729_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___724_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___723_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___740_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___739_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___716_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___715_;
        vlSelf->__PVT__inst_t80__DOT___55_ = vlSelf->__PVT__inst_t80__DOT___54_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___722_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___721_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___768_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___767_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___747_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___743_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___717_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___793_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___749_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___741_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___811_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___813_;
    }
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___776_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___775_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___764_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___763_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___800_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___799_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___756_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___755_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___762_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___761_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___752_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___751_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___774_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___773_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___778_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___777_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___796_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___795_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___792_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___791_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___754_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___753_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___772_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___771_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___758_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___757_));
    vlSelf->__PVT__inst_t80__DOT___61_ = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_) 
                                          | (IData)(vlSelf->__PVT__inst_t80__DOT___60_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___738_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___737_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___790_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___789_));
    vlSelf->__PVT__inst_t80__DOT___59_ = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_) 
                                          | (IData)(vlSelf->__PVT__inst_t80__DOT___58_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___810_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_) 
         | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___809_));
    vlSelf->__PVT__inst_t80__DOT___57_ = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_) 
                                          | (IData)(vlSelf->__PVT__inst_t80__DOT___56_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___760_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___759_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___798_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___797_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___806_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___805_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___804_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___803_));
    vlSelf->__PVT__inst_t80__DOT___63_ = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_) 
                                          | (IData)(vlSelf->__PVT__inst_t80__DOT___62_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___808_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___071_) 
         | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___807_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___459_ = 
        ((0x10U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
         | ((0x11U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
            | ((0x12U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
               | ((0x13U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
                  | ((0x14U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
                     | (0x15U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)))))));
    vlSelf->__PVT___043_ = ((~ (IData)(vlSelf->__PVT__inst_t80__DOT___57_)) 
                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___810_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___610_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___758_) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___760_));
    vlSelf->inst_t80__DOT__u0__DOT____VdfgTmp_hb2fda09c__0 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___724_) 
            << 8U) | (0xffU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___740_)));
    vlSelf->inst_t80__DOT__u0__DOT____VdfgTmp_h8fd225ae__0 
        = ((0x8000U & ((IData)(vlSelf->__PVT__inst_t80__DOT___55_) 
                       << 8U)) | ((0x4000U & ((IData)(vlSelf->__PVT__inst_t80__DOT___55_) 
                                              << 7U)) 
                                  | ((0x2000U & ((IData)(vlSelf->__PVT__inst_t80__DOT___55_) 
                                                 << 6U)) 
                                     | ((0x1000U & 
                                         ((IData)(vlSelf->__PVT__inst_t80__DOT___55_) 
                                          << 5U)) | 
                                        ((0x800U & 
                                          ((IData)(vlSelf->__PVT__inst_t80__DOT___55_) 
                                           << 4U)) 
                                         | ((0x400U 
                                             & ((IData)(vlSelf->__PVT__inst_t80__DOT___55_) 
                                                << 3U)) 
                                            | ((0x200U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT___55_) 
                                                   << 2U)) 
                                               | ((0x100U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT___55_) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__PVT__inst_t80__DOT___55_)))))))));
    vlSelf->inst_t80__DOT__u0__DOT____VdfgTmp_hbde73ddd__0 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT___55_) 
            << 8U) | (0xffU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___740_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___379_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___772_)) 
         & (0U != (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___768_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___711_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___804_) 
         | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___806_));
    vlSelf->__PVT__inst_t80__DOT___25_ = ((1U != (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
                                          | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___804_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___447_ = 
        (((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___778_)) 
          & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___798_)) 
             & (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)))) 
         | ((7U != (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___798_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___137_ 
        = ((0xdU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
           | (0xeU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___086_ 
        = ((0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
           | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
              | ((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                 | ((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                    | ((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                       | ((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                          | ((6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                             | (7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___033_ 
        = ((2U == (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))) 
           | ((3U == (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))) 
              | (7U == (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___026_ 
        = ((0U == (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))) 
           | (1U == (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___201_ = 
        ((6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
         & (3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__s)))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1989_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__s)))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1991_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035978__230__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035978__230__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035978__230__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035978__230__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0579_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035978__230__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035725__191__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035725__191__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035725__191__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035725__191__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0476_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035725__191__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035780__200__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035780__200__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035780__200__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035780__200__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0502_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035780__200__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___139_ = 
        ((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___766_)) 
         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___804_) 
            & (3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__s)))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1924_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__s)))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1945_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__s)))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1990_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038934__462__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038934__462__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038934__462__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038934__462__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2055_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038934__462__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039016__477__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039016__477__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039016__477__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039016__477__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2089_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039016__477__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039055__484__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039055__484__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039055__484__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039055__484__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2106_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039055__484__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039094__494__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039094__494__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039094__494__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039094__494__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2120_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039094__494__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039294__521__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039294__521__Vfuncout 
        = (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039294__521__s));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2211_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039294__521__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039357__533__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039357__533__Vfuncout 
        = (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039357__533__s));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2236_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039357__533__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035053__126__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035053__126__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035053__126__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035053__126__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0163_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035053__126__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035067__128__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035067__128__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035067__128__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035067__128__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0168_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035067__128__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035087__131__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035087__131__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035087__131__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035087__131__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035087__131__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0175_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035087__131__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036637__313__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036637__313__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036637__313__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036637__313__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0846_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036637__313__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038630__420__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038630__420__Vfuncout 
        = (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038630__420__s));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1923_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038630__420__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038688__426__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038688__426__Vfuncout 
        = (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038688__426__s));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1944_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038688__426__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039128__501__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039128__501__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039128__501__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039128__501__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2131_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039128__501__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__s))
                      ? (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__s))))
                      : (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__s)))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1919_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038919__456__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038919__456__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038919__456__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038919__456__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2049_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038919__456__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039001__471__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039001__471__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039001__471__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039001__471__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2083_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039001__471__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039046__480__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039046__480__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039046__480__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039046__480__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2102_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039046__480__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039085__490__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039085__490__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039085__490__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039085__490__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2116_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039085__490__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039282__517__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039282__517__Vfuncout 
        = (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039282__517__s));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2207_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039282__517__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039345__529__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039345__529__Vfuncout 
        = (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039345__529__s));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2232_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039345__529__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035614__183__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035614__183__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035614__183__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035614__183__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0416_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035614__183__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035722__190__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035722__190__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035722__190__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035722__190__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0475_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035722__190__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035777__199__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035777__199__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035777__199__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035777__199__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0501_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035777__199__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035974__229__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035974__229__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035974__229__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035974__229__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0578_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035974__229__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036281__269__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036281__269__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036281__269__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0704_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036281__269__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039304__524__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039304__524__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039304__524__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039304__524__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039304__524__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2214_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039304__524__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039367__536__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039367__536__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039367__536__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039367__536__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039367__536__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2239_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039367__536__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039131__502__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039131__502__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039131__502__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039131__502__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039131__502__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2132_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039131__502__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__s)))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0229_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__s)))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0240_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__b 
        = (0x18U | ((1U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_))
                     ? 3U : 2U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__b) 
                         >> 3U) : 3U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0660_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__b 
        = (0x18U | ((1U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_))
                     ? 2U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__b) 
                         >> 3U) : 3U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0669_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__b 
        = (0x18U | ((0x40U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_))
                     ? 3U : 2U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__b) 
                         >> 3U) : 3U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0679_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__b 
        = (0x18U | ((0x40U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_))
                     ? 2U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__b) 
                         >> 3U) : 3U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0688_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__s)))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0720_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__s)))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0753_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s)))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1917_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s)))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1940_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034929__112__s 
        = (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034929__112__Vfuncout 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034929__112__s;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0101_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034929__112__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034960__114__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034960__114__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034960__114__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034960__114__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0118_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034960__114__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035187__146__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035187__146__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035187__146__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035187__146__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0209_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035187__146__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__s))
                      ? (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__s))))
                      : (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__s)))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0225_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035361__169__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035361__169__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035361__169__s))) 
           & ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035361__169__s))) 
              | (4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035361__169__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0273_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035361__169__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__Vfuncout 
        = (1U & ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))
                  ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))
                      ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))
                          ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))))
                          : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))
                              ? (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))
                              : (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))))
                      : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))
                          ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))))
                          : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))))))
                  : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))
                      ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))
                          ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))))
                          : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))
                              ? (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))
                              : (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))))
                      : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))
                          ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))))
                          : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0294_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035607__180__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035607__180__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035607__180__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035607__180__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0413_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035607__180__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035712__186__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035712__186__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035712__186__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035712__186__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0471_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035712__186__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035767__195__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035767__195__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035767__195__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035767__195__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0497_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035767__195__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035959__223__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035959__223__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035959__223__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035959__223__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0572_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035959__223__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036271__265__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036271__265__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036271__265__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0700_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036271__265__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036140__241__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036140__241__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036140__241__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036140__241__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0653_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036140__241__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036167__246__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036167__246__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036167__246__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036167__246__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0663_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036167__246__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036193__251__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036193__251__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036193__251__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036193__251__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0672_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036193__251__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036220__256__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036220__256__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036220__256__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036220__256__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0682_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036220__256__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036246__261__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036246__261__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036246__261__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036246__261__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0691_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036246__261__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036284__270__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036284__270__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036284__270__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036284__270__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036284__270__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0705_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036284__270__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035093__133__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035093__133__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035093__133__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0177_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035093__133__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035150__143__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035150__143__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035150__143__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0197_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035150__143__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035234__154__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035234__154__Vfuncout 
        = (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035234__154__s));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0228_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035234__154__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035267__160__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035267__160__Vfuncout 
        = (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035267__160__s));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0239_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035267__160__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__Vfuncout 
        = (1U & ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s))
                  ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s))
                      ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s))
                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s)
                          : (IData)((2U != (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s)))))
                      : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s))
                  : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s))
                      ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s))
                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s)
                          : (IData)((2U != (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s)))))
                      : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0529_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036045__234__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036045__234__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036045__234__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0613_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036045__234__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036103__238__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036103__238__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036103__238__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0633_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036103__238__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036327__279__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036327__279__Vfuncout 
        = (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036327__279__s));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0719_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036327__279__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036422__290__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036422__290__Vfuncout 
        = (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036422__290__s));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0752_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036422__290__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036476__297__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036476__297__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036476__297__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036476__297__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0777_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036476__297__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036548__304__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036548__304__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036548__304__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036548__304__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0802_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036548__304__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039062__486__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039062__486__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039062__486__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039062__486__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039062__486__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2108_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039062__486__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039101__496__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039101__496__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039101__496__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039101__496__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039101__496__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2122_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039101__496__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038750__436__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038750__436__Vfuncout 
        = (IData)((8U == (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038750__436__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1969_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038750__436__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__s))
                      ? (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__s))))
                      : (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__s)))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1994_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038938__463__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038938__463__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038938__463__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038938__463__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2056_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038938__463__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039020__478__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039020__478__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039020__478__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039020__478__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2090_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039020__478__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039065__487__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039065__487__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039065__487__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2109_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039065__487__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039307__525__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039307__525__Vfuncout 
        = (IData)((8U == (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039307__525__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2215_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039307__525__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039370__537__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039370__537__Vfuncout 
        = (IData)((8U == (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039370__537__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2240_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039370__537__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039181__507__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039181__507__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039181__507__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039181__507__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2157_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039181__507__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039232__513__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039232__513__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039232__513__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039232__513__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2182_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039232__513__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__s)))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2213_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039364__535__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039364__535__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039364__535__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039364__535__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039364__535__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2238_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039364__535__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036643__315__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036643__315__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036643__315__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036643__315__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0848_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036643__315__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036665__320__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036665__320__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036665__320__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036665__320__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0856_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036665__320__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035982__231__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035982__231__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035982__231__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035982__231__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0580_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035982__231__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036143__242__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036143__242__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036143__242__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036143__242__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0654_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036143__242__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036170__247__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036170__247__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036170__247__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036170__247__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0664_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036170__247__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036196__252__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036196__252__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036196__252__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036196__252__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0673_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036196__252__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036223__257__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036223__257__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036223__257__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036223__257__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0683_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036223__257__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036249__262__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036249__262__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036249__262__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036249__262__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0692_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036249__262__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036291__272__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036291__272__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036291__272__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036291__272__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036291__272__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0707_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036291__272__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034926__111__s 
        = (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034926__111__Vfuncout 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034926__111__s;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0100_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034926__111__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035032__121__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035032__121__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035032__121__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0155_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035032__121__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035084__130__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035084__130__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035084__130__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035084__130__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0174_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035084__130__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035141__140__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035141__140__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035141__140__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035141__140__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0194_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035141__140__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035183__145__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035183__145__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035183__145__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035183__145__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0208_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035183__145__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s)))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0223_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s)))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0235_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035845__209__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035845__209__Vfuncout 
        = (1U & ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035845__209__s))
                  ? (IData)((8U == (0xfU & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035845__209__s))))
                  : (IData)((8U == (0xfU & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035845__209__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0524_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035845__209__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036039__232__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036039__232__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036039__232__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036039__232__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0611_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036039__232__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036098__236__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036098__236__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036098__236__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036098__236__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0631_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036098__236__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036137__240__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036137__240__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036137__240__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0652_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036137__240__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036164__245__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036164__245__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036164__245__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0662_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036164__245__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036190__250__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036190__250__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036190__250__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0671_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036190__250__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036217__255__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036217__255__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036217__255__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0681_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036217__255__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036243__260__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036243__260__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036243__260__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0690_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036243__260__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036268__264__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036268__264__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036268__264__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036268__264__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0699_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036268__264__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s)))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0714_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s)))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0747_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036634__312__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036634__312__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036634__312__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0845_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036634__312__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036656__317__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036656__317__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036656__317__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0853_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036656__317__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038808__447__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038808__447__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038808__447__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038808__447__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038808__447__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1993_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038808__447__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__s))
                      ? (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__s))))
                      : (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__s)))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1946_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038753__437__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038753__437__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038753__437__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038753__437__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038753__437__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1970_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038753__437__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039068__488__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039068__488__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039068__488__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039068__488__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039068__488__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2110_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039068__488__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039104__497__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039104__497__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039104__497__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039104__497__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039104__497__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2123_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039104__497__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039125__500__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039125__500__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039125__500__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039125__500__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039125__500__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2130_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039125__500__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039235__514__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039235__514__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039235__514__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039235__514__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2183_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039235__514__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039310__526__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039310__526__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039310__526__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039310__526__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039310__526__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2216_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039310__526__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039373__538__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039373__538__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039373__538__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039373__538__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039373__538__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2241_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039373__538__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036596__309__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036596__309__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036596__309__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036596__309__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036596__309__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0825_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036596__309__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036324__278__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036324__278__Vfuncout 
        = (IData)((8U == (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036324__278__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0718_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036324__278__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036419__289__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036419__289__Vfuncout 
        = (IData)((8U == (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036419__289__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0751_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036419__289__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038615__415__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038615__415__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038615__415__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038615__415__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038615__415__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1918_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038615__415__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038679__423__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038679__423__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038679__423__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038679__423__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038679__423__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1941_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038679__423__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035860__213__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035860__213__Vfuncout 
        = (IData)((0x10U == (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035860__213__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0528_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035860__213__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036042__233__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036042__233__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036042__233__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036042__233__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0612_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036042__233__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036473__296__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036473__296__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036473__296__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036473__296__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036473__296__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0776_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036473__296__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036545__303__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036545__303__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036545__303__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036545__303__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036545__303__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0801_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036545__303__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035221__150__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035221__150__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035221__150__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035221__150__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035221__150__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0224_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035221__150__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035256__157__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035256__157__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035256__157__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035256__157__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035256__157__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0236_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035256__157__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035002__120__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035002__120__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035002__120__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035002__120__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0139_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035002__120__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035042__125__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035042__125__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035042__125__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035042__125__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0159_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035042__125__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035110__136__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035110__136__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035110__136__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035110__136__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0183_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035110__136__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035127__139__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035127__139__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035127__139__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035127__139__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0189_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035127__139__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035153__144__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035153__144__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035153__144__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035153__144__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035153__144__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0198_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035153__144__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__s))
                      ? (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__s))))
                      : (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__s)))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0241_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035316__167__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035316__167__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035316__167__s))) 
           & ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035316__167__s))) 
              | (4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035316__167__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0255_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035316__167__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__Vfuncout 
        = (1U & ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s))
                  ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s))
                      ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s))))
                      : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s))
                          ? (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s))))
                          : (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s))))))
                  : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s))
                      ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s))))
                      : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0298_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035732__193__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035732__193__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035732__193__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035732__193__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035732__193__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0478_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035732__193__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035787__202__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035787__202__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035787__202__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035787__202__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035787__202__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0504_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035787__202__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035826__207__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035826__207__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035826__207__s))) 
           & ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035826__207__s))) 
              | (4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035826__207__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0517_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035826__207__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__Vfuncout 
        = (1U & ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                  ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                      ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                              ? (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                              : (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s)))
                          : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s)))))
                      : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                              ? (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                              : (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s)))
                          : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))))))
                  : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                      ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                              ? (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                              : (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s)))
                          : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s)))))
                      : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                              ? (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                              : (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s)))
                          : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0530_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__s))
                      ? (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__s))))
                      : (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__s)))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0721_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__s))
                      ? (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__s))))
                      : (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__s)))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0754_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036600__310__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036600__310__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036600__310__s))) 
           & ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036600__310__s))) 
              | (4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036600__310__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0826_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036600__310__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036668__321__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036668__321__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036668__321__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036668__321__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0857_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036668__321__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___621_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_) 
         == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___802_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___501_ = 
        ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
         & (3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s))
                        ? 0U : 7U) : 0U) : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s))
                                             ? ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s))
                                                 ? 0U
                                                 : 7U)
                                             : 0U))
            : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s))
                        ? 0U : 7U) : 0U) : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s))
                                             ? ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s))
                                                 ? 0U
                                                 : 7U)
                                             : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1964_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s))
                        ? 0U : 7U) : 0U) : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s))
                                             ? ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s))
                                                 ? 0U
                                                 : 7U)
                                             : 0U))
            : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s))
                        ? 0U : 7U) : 0U) : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s))
                                             ? ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s))
                                                 ? 0U
                                                 : 7U)
                                             : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1986_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038921__457__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038921__457__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038921__457__s)))
            ? 5U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038921__457__s)))
                     ? 4U : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2050_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038921__457__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039003__472__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039003__472__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039003__472__s)))
            ? 5U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039003__472__s)))
                     ? 4U : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2084_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039003__472__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039048__481__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039048__481__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039048__481__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039048__481__s)))
                     ? 7U : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2103_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039048__481__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039087__491__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039087__491__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039087__491__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039087__491__s)))
                     ? 7U : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2117_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039087__491__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s))
                    ? 0U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s))
                             ? 0U : 5U)) : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s))
                                             ? 0U : 
                                            ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s))
                                              ? 0U : 4U)))
            : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s))
                    ? 0U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s))
                             ? 0U : 5U)) : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0226_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035609__181__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035609__181__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035609__181__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035609__181__s)))
                     ? 7U : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0414_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035609__181__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035961__224__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035961__224__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035961__224__s)))
            ? 5U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035961__224__s)))
                     ? 4U : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0573_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035961__224__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039050__482__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039050__482__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039050__482__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039050__482__s)))
                     ? 6U : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2104_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039050__482__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039089__492__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039089__492__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039089__492__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039089__492__s)))
                     ? 6U : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2118_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039089__492__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038747__435__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038747__435__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038747__435__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038747__435__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038747__435__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1968_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038747__435__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039184__508__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039184__508__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039184__508__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039184__508__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2158_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039184__508__Vfuncout;
    vlSelf->__VdfgTmp_h7bf8ddc8__0 = ((7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                      & (1U != (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s))
                        ? 0U : 6U) : 0U) : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s))
                                             ? ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s))
                                                 ? 0U
                                                 : 6U)
                                             : 0U))
            : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s))
                        ? 0U : 6U) : 0U) : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s))
                                             ? ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s))
                                                 ? 0U
                                                 : 6U)
                                             : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1965_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s))
                        ? 0U : 6U) : 0U) : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s))
                                             ? ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s))
                                                 ? 0U
                                                 : 6U)
                                             : 0U))
            : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s))
                        ? 0U : 6U) : 0U) : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s))
                                             ? ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s))
                                                 ? 0U
                                                 : 6U)
                                             : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1987_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                        ? 0xaU : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                                         ? 0xaU : 0U))
                : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                        ? 0xaU : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                                         ? 0xaU : 0U)))
            : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                        ? 0xaU : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                                         ? 0xaU : 0U))
                : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                        ? 0xaU : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                                         ? 0xaU : 0U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2209_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                        ? 0xaU : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                                         ? 0xaU : 0U))
                : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                        ? 0xaU : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                                         ? 0xaU : 0U)))
            : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                        ? 0xaU : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                                         ? 0xaU : 0U))
                : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                        ? 0xaU : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                                         ? 0xaU : 0U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2234_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                        ? 7U : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                                       ? 7U : 6U)) : 
               ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                     ? 7U : 6U) : 7U)) : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                                           ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                                                   ? 7U
                                                   : 6U)
                                               : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                                                   ? 7U
                                                   : 6U))
                                           : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                                                   ? 7U
                                                   : 6U)
                                               : 7U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1922_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                        ? 7U : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                                       ? 7U : 6U)) : 
               ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                     ? 7U : 6U) : 7U)) : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                                           ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                                                   ? 7U
                                                   : 6U)
                                               : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                                                   ? 7U
                                                   : 6U))
                                           : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                                                   ? 7U
                                                   : 6U)
                                               : 7U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1943_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                        ? 2U : 1U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                                       ? 2U : 7U)) : 
               ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                     ? 2U : 1U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                                    ? 2U : 7U))) : 
           ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                     ? 2U : 1U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                                    ? 2U : 7U)) : (
                                                   (2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                                                     ? 2U
                                                     : 1U)
                                                    : 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                                                     ? 2U
                                                     : 7U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1967_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                        ? 2U : 7U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                                       ? 2U : 7U)) : 
               ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                     ? 2U : 7U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                                    ? 2U : 7U))) : 
           ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                     ? 2U : 7U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                                    ? 2U : 7U)) : (
                                                   (2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                                                     ? 2U
                                                     : 7U)
                                                    : 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                                                     ? 2U
                                                     : 7U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1992_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039059__485__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039059__485__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039059__485__s)))
            ? 2U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039059__485__s)))
                     ? 2U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2107_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039059__485__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039098__495__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039098__495__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039098__495__s)))
            ? 2U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039098__495__s)))
                     ? 2U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2121_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039098__495__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039122__499__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039122__499__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039122__499__s)))
            ? 5U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039122__499__s)))
                     ? 5U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2129_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039122__499__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039178__506__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039178__506__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039178__506__s)))
            ? 0U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2156_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039178__506__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039229__512__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039229__512__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039229__512__s)))
            ? 0U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2181_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039229__512__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                        ? 0U : 2U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                                       ? 0U : 7U)) : 
               ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                     ? 0U : 2U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                                    ? 0U : 7U))) : 
           ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                     ? 0U : 2U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                                    ? 0U : 7U)) : (
                                                   (2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                                                     ? 0U
                                                     : 2U)
                                                    : 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                                                     ? 0U
                                                     : 7U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2212_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                        ? 2U : 0U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                                       ? 2U : 7U)) : 
               ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                     ? 2U : 0U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                                    ? 2U : 7U))) : 
           ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                     ? 2U : 0U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                                    ? 2U : 7U)) : (
                                                   (2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                                                     ? 2U
                                                     : 0U)
                                                    : 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                                                     ? 2U
                                                     : 7U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2237_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034965__116__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034965__116__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034965__116__s)))
            ? 2U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0120_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034965__116__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034999__119__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034999__119__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034999__119__s)))
            ? 2U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0138_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034999__119__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035039__124__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035039__124__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035039__124__s)))
            ? 2U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0158_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035039__124__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035056__127__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035056__127__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035056__127__s)))
            ? 0U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0164_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035056__127__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035070__129__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035070__129__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035070__129__s)))
            ? 1U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0169_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035070__129__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035090__132__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035090__132__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035090__132__s)))
            ? 7U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035090__132__s)))
                     ? 6U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0176_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035090__132__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035107__135__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035107__135__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035107__135__s)))
            ? 0U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0182_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035107__135__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035124__138__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035124__138__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035124__138__s)))
            ? 1U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0188_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035124__138__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035147__142__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035147__142__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035147__142__s)))
            ? 7U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035147__142__s)))
                     ? 6U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0196_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035147__142__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                        ? 7U : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                                       ? 7U : 6U)) : 
               ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                     ? 7U : 6U) : 7U)) : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                                           ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                                                   ? 7U
                                                   : 6U)
                                               : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                                                   ? 7U
                                                   : 6U))
                                           : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                                                   ? 7U
                                                   : 6U)
                                               : 7U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0227_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                        ? 7U : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                                       ? 7U : 6U)) : 
               ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                     ? 7U : 6U) : 7U)) : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                                           ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                                                   ? 7U
                                                   : 6U)
                                               : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                                                   ? 7U
                                                   : 6U))
                                           : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                                                   ? 7U
                                                   : 6U)
                                               : 7U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0238_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035312__166__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035312__166__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035312__166__s)))
            ? 5U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035312__166__s)))
                     ? 5U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0254_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035312__166__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035369__172__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035369__172__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035369__172__s)))
            ? 5U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035369__172__s)))
                     ? 5U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0276_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035369__172__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__Vfuncout 
        = ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s))
            ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s))
                ? 5U : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s))
                         ? 5U : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s))
                                  ? 5U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s))
                                           ? 5U : 7U))))
            : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s))
                ? 5U : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s))
                         ? 5U : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s))
                                  ? 5U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s))
                                           ? 5U : 7U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0297_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035617__184__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035617__184__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035617__184__s)))
            ? 2U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0417_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035617__184__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035729__192__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035729__192__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035729__192__s)))
            ? 2U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035729__192__s)))
                     ? 2U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0477_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035729__192__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035784__201__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035784__201__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035784__201__s)))
            ? 2U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035784__201__s)))
                     ? 2U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0503_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035784__201__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035822__206__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035822__206__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035822__206__s)))
            ? 5U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035822__206__s)))
                     ? 5U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0516_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035822__206__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__Vfuncout 
        = ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
            ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                        ? 5U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                 ? 5U : 7U)) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                                 ? 5U
                                                 : 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                                  ? 5U
                                                  : 7U)))
                : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                        ? 5U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                 ? 5U : 7U)) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                                 ? 5U
                                                 : 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                                  ? 5U
                                                  : 7U))))
            : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                        ? 5U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                 ? 5U : 7U)) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                                 ? 5U
                                                 : 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                                  ? 5U
                                                  : 7U)))
                : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                        ? 5U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                 ? 5U : 7U)) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                                 ? 5U
                                                 : 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                                  ? 5U
                                                  : 7U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0527_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                        ? 7U : 5U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                                       ? 7U : 5U)) : 
               ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                     ? 7U : 5U) : 7U)) : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                                           ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                                                   ? 7U
                                                   : 5U)
                                               : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                                                   ? 7U
                                                   : 5U))
                                           : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                                                   ? 7U
                                                   : 5U)
                                               : 7U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0717_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036470__295__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036470__295__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036470__295__s)))
            ? 5U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036470__295__s)))
                     ? 5U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0775_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036470__295__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036593__308__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036593__308__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036593__308__s)))
            ? 5U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036593__308__s)))
                     ? 5U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0824_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036593__308__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036640__314__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036640__314__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036640__314__s)))
            ? 4U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0847_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036640__314__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036662__319__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036662__319__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036662__319__s)))
            ? 4U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0855_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036662__319__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035104__134__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035104__134__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035104__134__s)))
            ? 7U : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0181_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035104__134__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035121__137__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035121__137__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035121__137__s)))
            ? 7U : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0187_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035121__137__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035144__141__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035144__141__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035144__141__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035144__141__s)))
                     ? 7U : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0195_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035144__141__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                        ? 0U : 5U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                                       ? 0U : 4U)) : 
               ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                     ? 0U : 5U) : 0U)) : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                                           ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                                                   ? 0U
                                                   : 5U)
                                               : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                                                   ? 0U
                                                   : 4U))
                                           : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                                                   ? 0U
                                                   : 5U)
                                               : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0237_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__Vfuncout 
        = ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
            ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                            ? 0U : 5U) : 0U) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                                                 ? 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                                                  ? 0U
                                                  : 5U)
                                                 : 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                                                  ? 0U
                                                  : 4U)))
                : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                            ? 0U : 5U) : 0U) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                                                 ? 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                                                  ? 0U
                                                  : 5U)
                                                 : 0U)))
            : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                            ? 0U : 5U) : 0U) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                                                 ? 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                                                  ? 0U
                                                  : 5U)
                                                 : 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                                                  ? 0U
                                                  : 4U)))
                : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                            ? 0U : 5U) : 0U) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                                                 ? 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                                                  ? 0U
                                                  : 5U)
                                                 : 0U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0296_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__Vfuncout;
    vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035717__188__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035717__188__Vfuncout 
        = ((1U == (1U & (IData)(vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035717__188__s)))
            ? 0U : ((2U == (2U & (IData)(vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035717__188__s)))
                     ? 0xaU : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0473_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035717__188__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035772__197__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035772__197__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035772__197__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035772__197__s)))
                     ? 0xaU : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0499_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035772__197__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036276__267__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036276__267__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036276__267__s)))
            ? 0xaU : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0702_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036276__267__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                        ? 0U : 0xdU) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                                         ? 0U : 0xcU))
                : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                        ? 0U : 0xdU) : 0U)) : ((4U 
                                                & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                                                ? (
                                                   (2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                                                     ? 0U
                                                     : 0xdU)
                                                    : 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                                                     ? 0U
                                                     : 0xcU))
                                                : (
                                                   (2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                                                     ? 0U
                                                     : 0xdU)
                                                    : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0716_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036589__307__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036589__307__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036589__307__s)))
            ? 0xdU : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036589__307__s)))
                       ? 0xcU : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0823_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036589__307__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036659__318__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036659__318__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036659__318__s)))
            ? 7U : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0854_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036659__318__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035818__205__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035818__205__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035818__205__s)))
            ? 0xdU : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035818__205__s)))
                       ? 0xcU : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0515_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035818__205__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__Vfuncout 
        = ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
            ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                            ? 0xdU : 0xcU) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                                               ? 0xdU
                                               : 0U))
                    : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                            ? 0xdU : 0xcU) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                                               ? 0xdU
                                               : 0U)))
                : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                            ? 0xdU : 0xcU) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                                               ? 0xdU
                                               : 0U))
                    : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                            ? 0xdU : 0xcU) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                                               ? 0xdU
                                               : 0U))))
            : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                            ? 0xdU : 0xcU) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                                               ? 0xdU
                                               : 0U))
                    : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                            ? 0xdU : 0xcU) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                                               ? 0xdU
                                               : 0U)))
                : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                            ? 0xdU : 0xcU) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                                               ? 0xdU
                                               : 0U))
                    : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                            ? 0xdU : 0xcU) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                                               ? 0xdU
                                               : 0U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0526_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__Vfuncout 
        = ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
            ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                            ? 0U : 5U) : 0U) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                                                 ? 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                                                  ? 0U
                                                  : 5U)
                                                 : 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                                                  ? 0U
                                                  : 4U)))
                : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                            ? 0U : 5U) : 0U) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                                                 ? 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                                                  ? 0U
                                                  : 5U)
                                                 : 0U)))
            : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                            ? 0U : 5U) : 0U) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                                                 ? 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                                                  ? 0U
                                                  : 5U)
                                                 : 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                                                  ? 0U
                                                  : 4U)))
                : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                            ? 0U : 5U) : 0U) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                                                 ? 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                                                  ? 0U
                                                  : 5U)
                                                 : 0U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0295_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036288__271__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036288__271__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036288__271__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036288__271__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0706_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036288__271__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039118__498__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039118__498__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039118__498__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039118__498__s)))
                     ? 7U : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039118__498__s)))
                              ? 7U : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2128_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039118__498__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035306__164__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035306__164__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035306__164__s)))
            ? 0xfU : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035306__164__s)))
                       ? 0xfU : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0252_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035306__164__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035357__168__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035357__168__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035357__168__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035357__168__s)))
                     ? 7U : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035357__168__s)))
                              ? 7U : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0272_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035357__168__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__Vfuncout 
        = ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
            ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                        ? 0U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                                 ? 0U : 7U)) : 0U) : 
               ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                     ? 0U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                              ? 0U : 7U)) : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                                              ? 0U : 
                                             ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                                               ? 0U
                                               : 0xfU))))
            : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                        ? 0U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                                 ? 0U : 7U)) : 0U) : 
               ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                     ? 0U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                              ? 0U : 7U)) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0293_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                        ? 0U : 0xfU) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                                         ? 0U : 0xfU))
                : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                        ? 0U : 0xfU) : 0U)) : ((4U 
                                                & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                                                ? (
                                                   (2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                                                     ? 0U
                                                     : 0xfU)
                                                    : 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                                                     ? 0U
                                                     : 0xfU))
                                                : (
                                                   (2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                                                     ? 0U
                                                     : 0xfU)
                                                    : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0715_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036466__294__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036466__294__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036466__294__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036466__294__s)))
                     ? 7U : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036466__294__s)))
                              ? 7U : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0774_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036466__294__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036539__301__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036539__301__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036539__301__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036539__301__s)))
                     ? 7U : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036539__301__s)))
                              ? 7U : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0799_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036539__301__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036585__306__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036585__306__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036585__306__s)))
            ? 0xfU : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036585__306__s)))
                       ? 0xfU : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0822_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036585__306__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035814__204__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035814__204__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035814__204__s)))
            ? 0xfU : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035814__204__s)))
                       ? 0xfU : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0514_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035814__204__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__Vfuncout 
        = ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
            ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                        ? 0xfU : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                   ? 0xfU : 0U)) : 
                   ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                     ? 0xfU : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                ? 0xfU : 0U))) : ((4U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                                   ? 
                                                  ((2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                                    ? 0xfU
                                                    : 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                                     ? 0xfU
                                                     : 0U))
                                                   : 
                                                  ((2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                                    ? 0xfU
                                                    : 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                                     ? 0xfU
                                                     : 0U))))
            : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                        ? 0xfU : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                   ? 0xfU : 0U)) : 
                   ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                     ? 0xfU : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                ? 0xfU : 0U))) : ((4U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                                   ? 
                                                  ((2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                                    ? 0xfU
                                                    : 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                                     ? 0xfU
                                                     : 0U))
                                                   : 
                                                  ((2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                                    ? 0xfU
                                                    : 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                                     ? 0xfU
                                                     : 0U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0525_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b 
        = (0xb40U | (0x3fU & ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                 ? 4U : 3U) << 3U) 
                              | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                  ? 4U : 3U))));
    if ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))) {
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__a = 4U;
    } else {
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__a = 3U;
    }
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__Vfuncout 
        = (7U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b) 
                                                >> 9U))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b)
                                             : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__a))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1962_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b 
        = (0xb40U | (0x3fU & ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                 ? 4U : 3U) << 3U) 
                              | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                  ? 4U : 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__Vfuncout 
        = (7U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b) 
                                                >> 9U))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b)
                                             : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__a))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1984_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__b 
        = (4U | (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                   ? 4U : 3U) << 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2048_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__b 
        = (4U | (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                   ? 4U : 3U) << 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2082_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__b 
        = (0x20U | ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 6U) | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                             ? 4U : 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2101_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__b 
        = (0x20U | ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 6U) | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                             ? 4U : 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2115_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__b 
        = (0x20U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                     ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2153_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__b 
        = (0x20U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                     ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2178_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b 
        = (0xb20U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                      ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__Vfuncout 
        = (7U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b) 
                                                >> 9U))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b)
                                             : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__a))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2205_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b 
        = (0xb05U | (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__Vfuncout 
        = (7U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b) 
                                                >> 9U))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b)
                                             : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__a))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2230_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__s)))
            ? 5U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__s)))
                     ? 4U : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__s)))
                              ? 4U : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0513_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__b 
        = (5U | (0x1f8U & ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                              ? 4U : 3U) << 6U) | (
                                                   ((1U 
                                                     == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                     ? 4U
                                                     : 3U) 
                                                   << 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0251_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b 
        = (0x5100U | ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                         ? 4U : 3U) << 9U) | (0x3fU 
                                              & ((((1U 
                                                    == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                    ? 4U
                                                    : 3U) 
                                                  << 3U) 
                                                 | ((1U 
                                                     == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                     ? 4U
                                                     : 3U)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__Vfuncout 
        = (7U & ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                  ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                      ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                                 >> 6U)))
                          : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                                 >> 9U))))
                      : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                                 >> 6U)))
                          : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                                 >> 0xcU)))))
                  : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                      ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                                 >> 6U)))
                          : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                                 >> 9U))))
                      : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                                 >> 6U)))
                          : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                                 : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__a)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0292_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__b 
        = (0x20U | ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 6U) | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                             ? 4U : 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0470_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__b 
        = (0x20U | ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 6U) | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                             ? 4U : 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0496_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b 
        = (0x125U | (0x7e00U & ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                   ? 4U : 3U) << 0xcU) 
                                | (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                     ? 4U : 3U) << 9U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__Vfuncout 
        = (7U & ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                  ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                      ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                                 >> 6U)))
                          : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                                 >> 9U))))
                      : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                                 >> 6U)))
                          : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                                 >> 0xcU)))))
                  : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                      ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                                 >> 6U)))
                          : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                                 >> 9U))))
                      : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                                 >> 6U)))
                          : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                                 : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__a)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0523_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__b 
        = (4U | (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                   ? 4U : 3U) << 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0571_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__b 
        = (0x28U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                     ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0651_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__b 
        = (0x28U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                     ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0661_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__b 
        = (0x28U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                     ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0670_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__b 
        = (0x28U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                     ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0680_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__b 
        = (0x28U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                     ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0689_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__b 
        = (0x145U | (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0698_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b 
        = (0x20U | ((0xfc0U & ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                  ? 4U : 3U) << 9U) 
                               | (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                    ? 4U : 3U) << 6U))) 
                    | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                        ? 4U : 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__Vfuncout 
        = (7U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b) 
                                                >> 9U))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b)
                                             : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__a))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0713_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__b 
        = (5U | (0x1f8U & ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                              ? 4U : 3U) << 6U) | (
                                                   ((1U 
                                                     == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                     ? 4U
                                                     : 3U) 
                                                   << 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0773_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__b 
        = (5U | (0x1f8U & ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                              ? 4U : 3U) << 6U) | (
                                                   ((1U 
                                                     == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                     ? 4U
                                                     : 3U) 
                                                   << 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0798_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__b 
        = (5U | (0x1f8U & ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                              ? 4U : 3U) << 6U) | (
                                                   ((1U 
                                                     == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                     ? 4U
                                                     : 3U) 
                                                   << 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0821_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__b 
        = (0x20U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                     ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0844_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__b 
        = (0x20U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                     ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0852_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___082_ = 
        ((~ ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_) 
             >> 2U)) & (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_ 
        = ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
           | (7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___589_ = 
        (1U & ((~ ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                   >> 4U)) | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                              >> 6U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2345_ 
        = ((0x36U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__b 
        = ((6U != (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                         >> 3U))) << 1U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2154_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__s)))
                     ? 1U : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__a)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0577_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__s)))
            ? 1U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__s)))
                     ? 1U : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__a)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2054_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__s)))
            ? 3U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__s)))
                     ? 3U : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__a)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2088_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__b 
        = ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                      << 5U)) | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                       >> 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__b) 
                                         >> 8U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0474_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__b 
        = (0x20U | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                               << 5U)) | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__b) 
                                         >> 8U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0500_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__b 
        = (2U | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                            << 5U)) | (0x70U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                << 1U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__b) 
                                         >> 8U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0703_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b 
        = ((0x7000U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                       << 9U)) | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                             << 5U)) 
                                  | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                           >> 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__Vfuncout 
        = (0xfU & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                    ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b) 
                                                  >> 0xcU))))
                    : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b)
                                               : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__a))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1966_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b 
        = (0x70U | ((0x7000U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                << 9U)) | ((0x700U 
                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                               << 5U)) 
                                           | (7U & 
                                              ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                               >> 3U)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__Vfuncout 
        = (0xfU & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                    ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b) 
                                                  >> 0xcU))))
                    : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b)
                                               : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__a))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1988_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__b 
        = (0xd0U | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                               << 5U)) | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__b) 
                                         >> 8U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2105_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__b 
        = (0xe0U | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                               << 5U)) | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__b) 
                                         >> 8U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2119_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b 
        = (2U | ((0x7000U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                             << 9U)) | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                   << 5U)) 
                                        | (0x70U & 
                                           ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                            << 1U)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__Vfuncout 
        = (0xfU & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                    ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b) 
                                                  >> 0xcU))))
                    : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b)
                                               : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__a))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2210_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b 
        = (2U | ((0x7000U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                             << 9U)) | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                   << 5U)) 
                                        | (0x70U & 
                                           ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                            << 1U)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__Vfuncout 
        = (0xfU & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                    ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b) 
                                                  >> 0xcU))))
                    : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b)
                                               : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__a))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2235_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__b 
        = (6U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                        >> 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2180_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s 
        = (((7U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                          >> 3U))) << 7U) | (((6U == 
                                               (7U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                   >> 3U))) 
                                              << 6U) 
                                             | (((5U 
                                                  == 
                                                  (7U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                      >> 3U))) 
                                                 << 5U) 
                                                | (((4U 
                                                     == 
                                                     (7U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                         >> 3U))) 
                                                    << 4U) 
                                                   | (((3U 
                                                        == 
                                                        (7U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                            >> 3U))) 
                                                       << 3U) 
                                                      | (((2U 
                                                           == 
                                                           (7U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                               >> 3U))) 
                                                          << 2U) 
                                                         | (((1U 
                                                              == 
                                                              (7U 
                                                               & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                  >> 3U))) 
                                                             << 1U) 
                                                            | (0U 
                                                               == 
                                                               (7U 
                                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                   >> 3U))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__b 
        = ((0x80U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)) 
           | ((0x40U & ((~ ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                            >> 7U)) << 6U)) | ((0x20U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                   << 3U)) 
                                               | ((0x10U 
                                                   & ((~ 
                                                       ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                        >> 2U)) 
                                                      << 4U)) 
                                                  | ((8U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                         << 3U)) 
                                                     | ((4U 
                                                         & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)) 
                                                            << 2U)) 
                                                        | ((2U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                               >> 5U)) 
                                                           | (1U 
                                                              & (~ 
                                                                 ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                                  >> 6U))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__Vfuncout 
        = (((((((((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s))) 
                  | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))) 
                 | (4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))) 
                | (8U == (8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))) 
               | (0x10U == (0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))) 
              | (0x20U == (0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))) 
             | (0x40U == (0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))) 
            | (0x80U == (0x80U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))) 
           & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))
               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__b)
               : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))
                   ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__b) 
                      >> 1U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))
                                 ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__b) 
                                    >> 2U) : ((8U == 
                                               (8U 
                                                & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))
                                               ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__b) 
                                                  >> 3U)
                                               : ((0x10U 
                                                   == 
                                                   (0x10U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))
                                                   ? 
                                                  ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__b) 
                                                   >> 4U)
                                                   : 
                                                  ((0x20U 
                                                    == 
                                                    (0x20U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))
                                                    ? 
                                                   ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__b) 
                                                    >> 5U)
                                                    : 
                                                   ((0x40U 
                                                     == 
                                                     (0x40U 
                                                      & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))
                                                     ? 
                                                    ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__b) 
                                                     >> 6U)
                                                     : 
                                                    ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__b) 
                                                     >> 7U)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0628_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b 
        = (((3U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                          >> 4U))) << 3U) | ((3U == 
                                              (3U & 
                                               ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 4U))) 
                                             << 2U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b) 
                                 >> 1U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b) 
                                                >> 2U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b) 
                                 >> 1U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b) 
                                                >> 3U))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b) 
                                 >> 1U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b) 
                                                >> 2U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b) 
                                 >> 1U)) : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s) 
                                            & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1921_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__b 
        = (3U & (- (IData)((3U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                         >> 4U))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0211_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__b 
        = ((3U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                         >> 4U))) << 1U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__b) 
                         >> 1U) : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__s) 
                                            & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__b)) 
                                           >> 2U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0275_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__b 
        = (((6U != (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                          >> 3U))) ? (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                            >> 3U))
             : 0U) << 3U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__b) 
                         >> 3U) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2155_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__s 
        = (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__b 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__Vfuncout 
        = ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__s)
            ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__b)
            : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0102_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__b 
        = (0x38U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__b) 
                         >> 3U) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0119_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__b 
        = ((((3U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                           >> 4U))) ? 7U : (6U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                  >> 3U))) 
            << 6U) | (((3U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                     >> 4U))) ? 3U : 
                       (1U | (6U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                    >> 3U)))) << 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__b) 
                                       >> 6U) : 0U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0274_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__b 
        = (0x38U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__b) 
                                       >> 6U) : 0U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0472_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__b 
        = (0x38U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__b) 
                                       >> 6U) : 0U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0498_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__b 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__b) 
                         >> 3U) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2179_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0437_ 
        = ((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
            ? (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))
            : 0U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__b 
        = (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__b) 
                         >> 3U) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0136_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__b 
        = (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__b) 
                         >> 3U) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0156_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__b 
        = (0x38U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                    << 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__b) 
                         >> 3U) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0415_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__Vfuncout;
    vlSelf->__VdfgTmp_h426b99eb__0 = ((6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                      & ((0x36U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                         | (0xcbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b 
        = ((((3U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                           >> 4U))) ? 9U : (6U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                  >> 3U))) 
            << 8U) | (((3U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                     >> 4U))) ? 8U : 
                       (1U | (6U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                    >> 3U)))) << 4U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__Vfuncout 
        = (0xfU & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                    ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b) 
                                                  >> 0xcU))))
                    : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b)
                                               : 0U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1942_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__b 
        = ((((3U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                           >> 4U))) ? 0xbU : (1U | 
                                              (6U & 
                                               ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 3U)))) 
            << 4U) | ((3U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                    >> 4U))) ? 7U : 
                      (6U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                             >> 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__b) 
                                         >> 8U) : 0U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0253_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__Vfuncout;
    if ((3U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                      >> 4U)))) {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0205_ = 1U;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0201_ = 0U;
    } else {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0205_ 
            = (6U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                     >> 3U));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0201_ 
            = (1U | (6U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                           >> 3U)));
    }
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s 
        = (((7U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                          >> 3U))) << 7U) | (((6U == 
                                               (7U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                   >> 3U))) 
                                              << 6U) 
                                             | (((5U 
                                                  == 
                                                  (7U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                      >> 3U))) 
                                                 << 5U) 
                                                | (((4U 
                                                     == 
                                                     (7U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                         >> 3U))) 
                                                    << 4U) 
                                                   | (((3U 
                                                        == 
                                                        (7U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                            >> 3U))) 
                                                       << 3U) 
                                                      | (((2U 
                                                           == 
                                                           (7U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                               >> 3U))) 
                                                          << 2U) 
                                                         | (((1U 
                                                              == 
                                                              (7U 
                                                               & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                  >> 3U))) 
                                                             << 1U) 
                                                            | (0U 
                                                               == 
                                                               (7U 
                                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                   >> 3U))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__b 
        = ((0x80U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)) 
           | ((0x40U & ((~ ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                            >> 7U)) << 6U)) | ((0x20U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                   << 3U)) 
                                               | ((0x10U 
                                                   & ((~ 
                                                       ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                        >> 2U)) 
                                                      << 4U)) 
                                                  | ((8U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                         << 3U)) 
                                                     | ((4U 
                                                         & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)) 
                                                            << 2U)) 
                                                        | ((2U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                               >> 5U)) 
                                                           | (1U 
                                                              & (~ 
                                                                 ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                                  >> 6U))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__Vfuncout 
        = (((((((((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s))) 
                  | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))) 
                 | (4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))) 
                | (8U == (8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))) 
               | (0x10U == (0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))) 
              | (0x20U == (0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))) 
             | (0x40U == (0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))) 
            | (0x80U == (0x80U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))) 
           & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))
               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__b)
               : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))
                   ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__b) 
                      >> 1U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))
                                 ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__b) 
                                    >> 2U) : ((8U == 
                                               (8U 
                                                & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))
                                               ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__b) 
                                                  >> 3U)
                                               : ((0x10U 
                                                   == 
                                                   (0x10U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))
                                                   ? 
                                                  ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__b) 
                                                   >> 4U)
                                                   : 
                                                  ((0x20U 
                                                    == 
                                                    (0x20U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))
                                                    ? 
                                                   ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__b) 
                                                    >> 5U)
                                                    : 
                                                   ((0x40U 
                                                     == 
                                                     (0x40U 
                                                      & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))
                                                     ? 
                                                    ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__b) 
                                                     >> 6U)
                                                     : 
                                                    ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__b) 
                                                     >> 7U)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0791_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b 
        = (0xcU | ((((8U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))
                      ? 0xdU : 5U) << 8U) | (((8U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))
                                               ? 0xeU
                                               : 6U) 
                                             << 4U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__Vfuncout 
        = (0xfU & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                    ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b) 
                                                  >> 0xcU))))
                    : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b)
                                               : 0U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1963_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b 
        = (0xcU | (((8U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))
                     ? 0xeU : 6U) << 4U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__Vfuncout 
        = (0xfU & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                    ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b) 
                                                  >> 0xcU))))
                    : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b)
                                               : 0U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1985_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b 
        = (((8U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))
             ? 0xeU : 6U) << 8U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__Vfuncout 
        = (0xfU & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                    ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b) 
                                                  >> 0xcU))))
                    : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b)
                                               : 0U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2206_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b 
        = (((8U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))
             ? 0xeU : 6U) << 8U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__Vfuncout 
        = (0xfU & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                    ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b) 
                                                  >> 0xcU))))
                    : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b)
                                               : 0U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2231_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1351_ 
        = ((0xc0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xc1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xc2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0xc3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0xc4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0xc5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0xc7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | ((0xc8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                | ((0xc9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                   | ((0xcaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                      | ((0xcbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                         | ((0xccU 
                                             == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                            | ((0xcdU 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               | ((0xcfU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  | ((0xd0U 
                                                      == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                     | ((0xd1U 
                                                         == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                        | ((0xd2U 
                                                            == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                           | ((0xd3U 
                                                               == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                              | ((0xd4U 
                                                                  == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                 | ((0xd5U 
                                                                     == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                    | ((0xd7U 
                                                                        == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                       | ((0xd8U 
                                                                           == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                          | ((0xd9U 
                                                                              == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                             | ((0xdaU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xdbU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xdcU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xddU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xdfU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe0U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe2U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe3U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe4U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe5U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe7U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe8U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe9U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xeaU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xebU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xecU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xedU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xefU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf0U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf2U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf3U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf4U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf5U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf7U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf8U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf9U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xfaU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xfbU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xfcU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xfdU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | (0xffU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))))))))))))))))))))))))))))))))))))))))))))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1066_ 
        = ((6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x16U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xeU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x1eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x2eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x3eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0x26U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | (0x36U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_ 
        = ((0U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                         >> 4U))) | ((1U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                   >> 4U))) 
                                     | (2U == (3U & 
                                               ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 4U)))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s 
        = (((6U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                          >> 3U))) << 6U) | (((5U == 
                                               (7U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                   >> 3U))) 
                                              << 5U) 
                                             | (((4U 
                                                  == 
                                                  (7U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                      >> 3U))) 
                                                 << 4U) 
                                                | (((3U 
                                                     == 
                                                     (7U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                         >> 3U))) 
                                                    << 3U) 
                                                   | (((2U 
                                                        == 
                                                        (7U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                            >> 3U))) 
                                                       << 2U) 
                                                      | (((1U 
                                                           == 
                                                           (7U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                               >> 3U))) 
                                                          << 1U) 
                                                         | (0U 
                                                            == 
                                                            (7U 
                                                             & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                >> 3U)))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__Vfuncout 
        = ((0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
            ? ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                    ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                        ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 8U)))
                        : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 0x10U))))
                    : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                        ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 8U)))
                        : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 0x20U)))))
                : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                    ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                        ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 8U)))
                        : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 0x10U))))
                    : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                        ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 8U)))
                        : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 0x40U))))))
            : ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                    ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                        ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 8U)))
                        : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 0x10U))))
                    : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                        ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 8U)))
                        : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 0x20U)))))
                : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                    ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                        ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 8U)))
                        : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 0x10U))))
                    : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                        ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 8U)))
                        : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 0x80U)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___007_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s 
        = (((7U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                          >> 3U))) << 7U) | (((6U == 
                                               (7U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                   >> 3U))) 
                                              << 6U) 
                                             | (((5U 
                                                  == 
                                                  (7U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                      >> 3U))) 
                                                 << 5U) 
                                                | (((4U 
                                                     == 
                                                     (7U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                         >> 3U))) 
                                                    << 4U) 
                                                   | (((3U 
                                                        == 
                                                        (7U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                            >> 3U))) 
                                                       << 3U) 
                                                      | (((2U 
                                                           == 
                                                           (7U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                               >> 3U))) 
                                                          << 2U) 
                                                         | (((1U 
                                                              == 
                                                              (7U 
                                                               & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                  >> 3U))) 
                                                             << 1U) 
                                                            | (0U 
                                                               == 
                                                               (7U 
                                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                   >> 3U))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__b 
        = ((0x80U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)) 
           | ((0x40U & ((~ ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                            >> 7U)) << 6U)) | ((0x20U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                   << 3U)) 
                                               | ((0x10U 
                                                   & ((~ 
                                                       ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                        >> 2U)) 
                                                      << 4U)) 
                                                  | ((8U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                         << 3U)) 
                                                     | ((4U 
                                                         & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)) 
                                                            << 2U)) 
                                                        | ((2U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                               >> 5U)) 
                                                           | (1U 
                                                              & (~ 
                                                                 ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                                  >> 6U))))))))));
    vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__Vfuncout 
        = (((((((((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s))) 
                  | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))) 
                 | (4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))) 
                | (8U == (8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))) 
               | (0x10U == (0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))) 
              | (0x20U == (0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))) 
             | (0x40U == (0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))) 
            | (0x80U == (0x80U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))) 
           & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))
               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__b)
               : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))
                   ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__b) 
                      >> 1U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))
                                 ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__b) 
                                    >> 2U) : ((8U == 
                                               (8U 
                                                & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))
                                               ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__b) 
                                                  >> 3U)
                                               : ((0x10U 
                                                   == 
                                                   (0x10U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))
                                                   ? 
                                                  ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__b) 
                                                   >> 4U)
                                                   : 
                                                  ((0x20U 
                                                    == 
                                                    (0x20U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))
                                                    ? 
                                                   ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__b) 
                                                    >> 5U)
                                                    : 
                                                   ((0x40U 
                                                     == 
                                                     (0x40U 
                                                      & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))
                                                     ? 
                                                    ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__b) 
                                                     >> 6U)
                                                     : 
                                                    ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__b) 
                                                     >> 7U)))))))));
}
