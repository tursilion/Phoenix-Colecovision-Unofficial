// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Primary model header
//
// This header should be included by all source files instantiating the design.
// The class here is then constructed to instantiate the design.
// See the Verilator manual for examples.

#ifndef VERILATED_VSIM_TOP_H_
#define VERILATED_VSIM_TOP_H_  // guard

#include "verilated.h"
#include "svdpi.h"

class Vsim_top__Syms;
class Vsim_top___024root;
class Vsim_top_sim_top;


// This class is the main interface to the Verilated model
class alignas(VL_CACHE_LINE_BYTES) Vsim_top VL_NOT_FINAL : public VerilatedModel {
  private:
    // Symbol table holding complete model state (owned by this class)
    Vsim_top__Syms* const vlSymsp;

  public:

    // PORTS
    // The application code writes and reads these signals to
    // propagate new values into/out from the Verilated model.
    VL_IN8(&clk,0,0);
    VL_IN8(&clk_3m58_en,0,0);
    VL_IN8(&por_n,0,0);
    VL_IN8(&p1,2,1);
    VL_IN8(&p2,2,1);
    VL_IN8(&p3,2,1);
    VL_IN8(&p4,2,1);
    VL_IN8(&p6,2,1);
    VL_IN8(&p7,2,1);
    VL_IN8(&p9,2,1);
    VL_OUT8(&p5,0,0);
    VL_OUT8(&p8,0,0);
    VL_IN8(&sd_miso,0,0);
    VL_OUT8(&sd_mosi,0,0);
    VL_OUT8(&sd_sclk,0,0);
    VL_OUT8(&sd_cs_n,0,0);
    VL_OUT8(&sram_wdata,7,0);
    VL_IN8(&sram_rdata,7,0);
    VL_OUT8(&sram_we_n,0,0);
    VL_OUT8(&sram_ce_n,0,0);
    VL_OUT8(&led,0,0);
    VL_OUT8(&cart_en_n,0,0);
    VL_OUT8(&dbg_m1_n,0,0);
    VL_OUT8(&dbg_clken,0,0);
    VL_OUT8(&dbg_loader,0,0);
    VL_OUT8(&dbg_din,7,0);
    VL_OUT8(&dbg_iorq_n,0,0);
    VL_OUT8(&dbg_wr_n,0,0);
    VL_OUT8(&dbg_sdcs_n,0,0);
    VL_OUT8(&dbg_dout,7,0);
    VL_OUT8(&dbg_ext,7,0);
    VL_OUT8(&dbg_mux,7,0);
    VL_OUT8(&dbg_mreq_n,0,0);
    VL_OUT8(&dbg_ext_en,0,0);
    VL_OUT8(&dbg_mc_bank,5,0);
    VL_OUT8(&dbg_rd_n,0,0);
    VL_OUT8(&dbg_cwait_n,0,0);
    VL_OUT8(&dbg_tstate,2,0);
    VL_OUT8(&dbg_mcycle,2,0);
    VL_OUT8(&dbg_rom_page,7,0);
    VL_OUT8(&dbg_mask,7,0);
    VL_OUT8(&dbg_c_line,5,0);
    VL_OUT8(&dbg_c_hit,0,0);
    VL_OUT16(&cpu_a,14,0);
    VL_OUT16(&dbg_addr,15,0);
    VL_OUT(&sram_addr,18,0);

    // CELLS
    // Public to allow access to /* verilator public */ items.
    // Otherwise the application code can consider these internals.
    Vsim_top_sim_top* const sim_top;

    // Root instance pointer to allow access to model internals,
    // including inlined /* verilator public_flat_* */ items.
    Vsim_top___024root* const rootp;

    // CONSTRUCTORS
    /// Construct the model; called by application code
    /// If contextp is null, then the model will use the default global context
    /// If name is "", then makes a wrapper with a
    /// single model invisible with respect to DPI scope names.
    explicit Vsim_top(VerilatedContext* contextp, const char* name = "TOP");
    explicit Vsim_top(const char* name = "TOP");
    /// Destroy the model; called (often implicitly) by application code
    virtual ~Vsim_top();
  private:
    VL_UNCOPYABLE(Vsim_top);  ///< Copying not allowed

  public:
    // API METHODS
    /// Evaluate the model.  Application must call when inputs change.
    void eval() { eval_step(); }
    /// Evaluate when calling multiple units/models per time step.
    void eval_step();
    /// Evaluate at end of a timestep for tracing, when using eval_step().
    /// Application must call after all eval() and before time changes.
    void eval_end_step() {}
    /// Simulation complete, run final blocks.  Application must call on completion.
    void final();
    /// Are there scheduled events to handle?
    bool eventsPending();
    /// Returns time at next time slot. Aborts if !eventsPending()
    uint64_t nextTimeSlot();
    /// Trace signals in the model; called by application code
    void trace(VerilatedVcdC* tfp, int levels, int options = 0);
    /// Retrieve name of this model instance (as passed to constructor).
    const char* name() const;

    // Abstract methods from VerilatedModel
    const char* hierName() const override final;
    const char* modelName() const override final;
    unsigned threads() const override final;
    /// Prepare for cloning the model at the process level (e.g. fork in Linux)
    /// Release necessary resources. Called before cloning.
    void prepareClone() const;
    /// Re-init after cloning the model at the process level (e.g. fork in Linux)
    /// Re-allocate necessary resources. Called after cloning.
    void atClone() const;
};

#endif  // guard
