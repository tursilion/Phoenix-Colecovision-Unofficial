// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vsim_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vsim_top__Syms.h"
#include "Vsim_top__Syms.h"
#include "Vsim_top___024root.h"

#ifdef VL_DEBUG
VL_ATTR_COLD void Vsim_top___024root___dump_triggers__ico(Vsim_top___024root* vlSelf);
#endif  // VL_DEBUG

void Vsim_top___024root___eval_triggers__ico(Vsim_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsim_top___024root___eval_triggers__ico\n"); );
    // Body
    vlSelf->__VicoTriggered.set(0U, (0U == vlSelf->__VicoIterCount));
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vsim_top___024root___dump_triggers__ico(vlSelf);
    }
#endif
}

VL_INLINE_OPT void Vsim_top___024root___ico_sequent__TOP__0(Vsim_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsim_top___024root___ico_sequent__TOP__0\n"); );
    // Body
    vlSelf->dbg_clken = vlSymsp->TOP__sim_top__cv.__PVT__clk_en_cpu_s;
}

void Vsim_top_colecovision___ico_sequent__TOP__sim_top__cv__0(Vsim_top_colecovision* vlSelf);
void Vsim_top_vdp_spy___ico_sequent__TOP__sim_top__cv__inst_f18a__spy__0(Vsim_top_vdp_spy* vlSelf);
void Vsim_top_colecovision___ico_sequent__TOP__sim_top__cv__1(Vsim_top_colecovision* vlSelf);

void Vsim_top___024root___eval_ico(Vsim_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsim_top___024root___eval_ico\n"); );
    // Body
    if ((1ULL & vlSelf->__VicoTriggered.word(0U))) {
        Vsim_top_colecovision___ico_sequent__TOP__sim_top__cv__0((&vlSymsp->TOP__sim_top__cv));
        Vsim_top_vdp_spy___ico_sequent__TOP__sim_top__cv__inst_f18a__spy__0((&vlSymsp->TOP__sim_top__cv__inst_f18a__spy));
        Vsim_top___024root___ico_sequent__TOP__0(vlSelf);
        Vsim_top_colecovision___ico_sequent__TOP__sim_top__cv__1((&vlSymsp->TOP__sim_top__cv));
    }
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vsim_top___024root___dump_triggers__act(Vsim_top___024root* vlSelf);
#endif  // VL_DEBUG

void Vsim_top___024root___eval_triggers__act(Vsim_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsim_top___024root___eval_triggers__act\n"); );
    // Body
    vlSelf->__VactTriggered.set(0U, ((IData)(vlSelf->clk) 
                                     & (~ (IData)(vlSelf->__Vtrigprevexpr___TOP__clk__0))));
    vlSelf->__VactTriggered.set(1U, (((IData)(vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT__u0__DOT___071_) 
                                      & (~ (IData)(vlSelf->__Vtrigprevexpr___TOP__sim_top__cv____PVT__inst_t80__DOT__u0__DOT___071___0))) 
                                     | ((IData)(vlSelf->clk) 
                                        & (~ (IData)(vlSelf->__Vtrigprevexpr___TOP__clk__0)))));
    vlSelf->__Vtrigprevexpr___TOP__clk__0 = vlSelf->clk;
    vlSelf->__Vtrigprevexpr___TOP__sim_top__cv____PVT__inst_t80__DOT__u0__DOT___071___0 
        = vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT__u0__DOT___071_;
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vsim_top___024root___dump_triggers__act(vlSelf);
    }
#endif
}

VL_INLINE_OPT void Vsim_top___024root___nba_sequent__TOP__0(Vsim_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsim_top___024root___nba_sequent__TOP__0\n"); );
    // Body
    vlSelf->sram_ce_n = vlSymsp->TOP__sim_top__cv.__PVT__ext512__DOT___18_;
    vlSelf->sram_we_n = vlSymsp->TOP__sim_top__cv.__PVT__ext512__DOT___19_;
    vlSelf->p8 = (1U & (~ (IData)(vlSymsp->TOP__sim_top__cv.__PVT__ctrl_b__DOT___67_)));
    vlSelf->p5 = vlSymsp->TOP__sim_top__cv.__PVT__ctrl_b__DOT___67_;
    vlSelf->dbg_mc_bank = vlSymsp->TOP__sim_top__cv.__PVT___431_;
    vlSelf->dbg_mask = vlSymsp->TOP__sim_top__cv.__PVT___430_;
    vlSelf->dbg_ext = vlSymsp->TOP__sim_top__cv.__PVT__ext512__DOT___17_;
    vlSelf->sram_wdata = vlSymsp->TOP__sim_top__cv.__PVT__ext512__DOT___16_;
    vlSelf->sram_addr = vlSymsp->TOP__sim_top__cv.__PVT__ext512__DOT___15_;
    vlSelf->dbg_cwait_n = vlSymsp->TOP__sim_top__cv.__PVT___019_;
    vlSelf->dbg_clken = vlSymsp->TOP__sim_top__cv.__PVT__clk_en_cpu_s;
    vlSelf->dbg_loader = vlSymsp->TOP__sim_top__cv.__PVT___415_;
    vlSelf->led = ((IData)(vlSymsp->TOP__sim_top__cv.__PVT___030_) 
                   | (IData)(vlSymsp->TOP__sim_top__cv.__PVT___415_));
    if (vlSymsp->TOP__sim_top__cv.__PVT__cache_active_s) {
        vlSelf->sd_cs_n = (1U & (~ (IData)(vlSymsp->TOP__sim_top__cv.__PVT__cache__DOT__f_cs)));
        vlSelf->sd_sclk = vlSymsp->TOP__sim_top__cv.__PVT__cache__DOT__spi_sclk_r;
        vlSelf->sd_mosi = (1U & ((IData)(vlSymsp->TOP__sim_top__cv.__PVT__cache__DOT__spi_tx) 
                                 >> 7U));
    } else {
        vlSelf->sd_cs_n = (1U & (IData)(vlSymsp->TOP__sim_top__cv.__PVT__sdcard__DOT___50_));
        vlSelf->sd_sclk = vlSymsp->TOP__sim_top__cv.__PVT__sdcard__DOT___51_;
        vlSelf->sd_mosi = (1U & ((IData)(vlSymsp->TOP__sim_top__cv.__PVT__sdcard__DOT___46_) 
                                 >> 7U));
    }
}

VL_INLINE_OPT void Vsim_top___024root___nba_sequent__TOP__1(Vsim_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsim_top___024root___nba_sequent__TOP__1\n"); );
    // Body
    vlSelf->dbg_rd_n = vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT___61_;
    vlSelf->dbg_iorq_n = vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT___59_;
    vlSelf->dbg_mreq_n = vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT___57_;
    vlSelf->dbg_tstate = vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT__u0__DOT___748_;
    vlSelf->dbg_mcycle = vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT__u0__DOT___750_;
    vlSelf->dbg_wr_n = vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT___63_;
    vlSelf->dbg_m1_n = vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT__u0__DOT___808_;
    vlSelf->dbg_addr = vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT__u0__DOT___812_;
    vlSelf->cpu_a = (0x7fffU & (IData)(vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT__u0__DOT___812_));
    vlSelf->dbg_dout = vlSymsp->TOP__sim_top__cv.__PVT__inst_t80__DOT__u0__DOT___814_;
    vlSelf->cart_en_n = (1U & (((~ (IData)(vlSymsp->TOP__sim_top__cv.__PVT___043_)) 
                                | (IData)(vlSymsp->TOP__sim_top__cv.__PVT___115_)) 
                               & (((~ (IData)(vlSymsp->TOP__sim_top__cv.__PVT___043_)) 
                                   | (IData)(vlSymsp->TOP__sim_top__cv.__PVT___116_)) 
                                  & (((~ (IData)(vlSymsp->TOP__sim_top__cv.__PVT___043_)) 
                                      | (IData)(vlSymsp->TOP__sim_top__cv.__PVT___117_)) 
                                     & ((~ (IData)(vlSymsp->TOP__sim_top__cv.__PVT___043_)) 
                                        | (IData)(vlSymsp->TOP__sim_top__cv.__PVT___118_))))));
    vlSelf->dbg_sdcs_n = vlSymsp->TOP__sim_top__cv.__PVT__sd_cs_n_s;
}

VL_INLINE_OPT void Vsim_top___024root___nba_comb__TOP__0(Vsim_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsim_top___024root___nba_comb__TOP__0\n"); );
    // Body
    vlSelf->dbg_rom_page = vlSymsp->TOP__sim_top__cv.__PVT__rom_page_s;
    vlSelf->dbg_mux = vlSymsp->TOP__sim_top__cv.__PVT__cpu_data_mux_s;
    vlSelf->dbg_ext_en = vlSymsp->TOP__sim_top__cv.__PVT__ext_ram_en_s;
    vlSelf->dbg_c_hit = (1U & ((IData)(vlSymsp->TOP__sim_top__cv.__PVT__cache__DOT__c_map_q) 
                               >> 6U));
    vlSelf->dbg_c_line = (0x3fU & (IData)(vlSymsp->TOP__sim_top__cv.__PVT__cache__DOT__c_map_q));
    vlSelf->dbg_din = vlSymsp->TOP__sim_top__cv.__PVT__d_to_cpu_s;
}

void Vsim_top_colecovision___nba_sequent__TOP__sim_top__cv__0(Vsim_top_colecovision* vlSelf);
void Vsim_top_vdp_spy___nba_sequent__TOP__sim_top__cv__inst_f18a__spy__0(Vsim_top_vdp_spy* vlSelf);
void Vsim_top_colecovision___nba_sequent__TOP__sim_top__cv__1(Vsim_top_colecovision* vlSelf);
void Vsim_top_colecovision___nba_sequent__TOP__sim_top__cv__2(Vsim_top_colecovision* vlSelf);
void Vsim_top_colecovision___nba_sequent__TOP__sim_top__cv__3(Vsim_top_colecovision* vlSelf);
void Vsim_top_colecovision___nba_sequent__TOP__sim_top__cv__4(Vsim_top_colecovision* vlSelf);
void Vsim_top_colecovision___nba_sequent__TOP__sim_top__cv__5(Vsim_top_colecovision* vlSelf);
void Vsim_top_colecovision___nba_comb__TOP__sim_top__cv__0(Vsim_top_colecovision* vlSelf);
void Vsim_top_colecovision___nba_comb__TOP__sim_top__cv__1(Vsim_top_colecovision* vlSelf);

void Vsim_top___024root___eval_nba(Vsim_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsim_top___024root___eval_nba\n"); );
    // Body
    if ((1ULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vsim_top_colecovision___nba_sequent__TOP__sim_top__cv__0((&vlSymsp->TOP__sim_top__cv));
        Vsim_top_vdp_spy___nba_sequent__TOP__sim_top__cv__inst_f18a__spy__0((&vlSymsp->TOP__sim_top__cv__inst_f18a__spy));
        Vsim_top___024root___nba_sequent__TOP__0(vlSelf);
    }
    if ((2ULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vsim_top_colecovision___nba_sequent__TOP__sim_top__cv__1((&vlSymsp->TOP__sim_top__cv));
        Vsim_top_colecovision___nba_sequent__TOP__sim_top__cv__2((&vlSymsp->TOP__sim_top__cv));
        Vsim_top_colecovision___nba_sequent__TOP__sim_top__cv__3((&vlSymsp->TOP__sim_top__cv));
        Vsim_top_colecovision___nba_sequent__TOP__sim_top__cv__4((&vlSymsp->TOP__sim_top__cv));
        Vsim_top_colecovision___nba_sequent__TOP__sim_top__cv__5((&vlSymsp->TOP__sim_top__cv));
        Vsim_top___024root___nba_sequent__TOP__1(vlSelf);
    }
    if ((3ULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vsim_top_colecovision___nba_comb__TOP__sim_top__cv__0((&vlSymsp->TOP__sim_top__cv));
        Vsim_top_colecovision___nba_comb__TOP__sim_top__cv__1((&vlSymsp->TOP__sim_top__cv));
        Vsim_top___024root___nba_comb__TOP__0(vlSelf);
    }
}
