// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vsim_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vsim_top__Syms.h"
#include "Vsim_top__Syms.h"
#include "Vsim_top_colecovision.h"

VL_ATTR_COLD void Vsim_top_colecovision___stl_sequent__TOP__sim_top__cv__0(Vsim_top_colecovision* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vsim_top_colecovision___stl_sequent__TOP__sim_top__cv__0\n"); );
    // Init
    CData/*0:0*/ __Vfunc___03369__0__Vfuncout;
    __Vfunc___03369__0__Vfuncout = 0;
    CData/*2:0*/ __Vfunc___03369__0__s;
    __Vfunc___03369__0__s = 0;
    CData/*0:0*/ __Vfunc___03372__1__Vfuncout;
    __Vfunc___03372__1__Vfuncout = 0;
    CData/*2:0*/ __Vfunc___03372__1__s;
    __Vfunc___03372__1__s = 0;
    CData/*0:0*/ __Vfunc___03375__2__Vfuncout;
    __Vfunc___03375__2__Vfuncout = 0;
    CData/*2:0*/ __Vfunc___03375__2__s;
    __Vfunc___03375__2__s = 0;
    CData/*0:0*/ __Vfunc___03395__8__Vfuncout;
    __Vfunc___03395__8__Vfuncout = 0;
    CData/*7:0*/ __Vfunc___03395__8__s;
    __Vfunc___03395__8__s = 0;
    CData/*0:0*/ __Vfunc___03398__9__Vfuncout;
    __Vfunc___03398__9__Vfuncout = 0;
    CData/*7:0*/ __Vfunc___03398__9__s;
    __Vfunc___03398__9__s = 0;
    CData/*0:0*/ __Vfunc___03401__10__Vfuncout;
    __Vfunc___03401__10__Vfuncout = 0;
    CData/*7:0*/ __Vfunc___03401__10__s;
    __Vfunc___03401__10__s = 0;
    CData/*0:0*/ __Vfunc___03404__11__Vfuncout;
    __Vfunc___03404__11__Vfuncout = 0;
    CData/*7:0*/ __Vfunc___03404__11__s;
    __Vfunc___03404__11__s = 0;
    CData/*5:0*/ __Vfunc___03405__12__Vfuncout;
    __Vfunc___03405__12__Vfuncout = 0;
    CData/*5:0*/ __Vfunc___03405__12__a;
    __Vfunc___03405__12__a = 0;
    QData/*47:0*/ __Vfunc___03405__12__b;
    __Vfunc___03405__12__b = 0;
    CData/*7:0*/ __Vfunc___03405__12__s;
    __Vfunc___03405__12__s = 0;
    CData/*7:0*/ __Vfunc___03470__16__Vfuncout;
    __Vfunc___03470__16__Vfuncout = 0;
    CData/*7:0*/ __Vfunc___03470__16__a;
    __Vfunc___03470__16__a = 0;
    IData/*23:0*/ __Vfunc___03470__16__b;
    __Vfunc___03470__16__b = 0;
    CData/*2:0*/ __Vfunc___03470__16__s;
    __Vfunc___03470__16__s = 0;
    CData/*0:0*/ __Vfunc___03681__24__Vfuncout;
    __Vfunc___03681__24__Vfuncout = 0;
    SData/*12:0*/ __Vfunc___03681__24__b;
    __Vfunc___03681__24__b = 0;
    SData/*12:0*/ __Vfunc___03681__24__s;
    __Vfunc___03681__24__s = 0;
    CData/*0:0*/ __Vfunc___03683__25__Vfuncout;
    __Vfunc___03683__25__Vfuncout = 0;
    SData/*12:0*/ __Vfunc___03683__25__b;
    __Vfunc___03683__25__b = 0;
    SData/*12:0*/ __Vfunc___03683__25__s;
    __Vfunc___03683__25__s = 0;
    CData/*0:0*/ __Vfunc___03684__26__Vfuncout;
    __Vfunc___03684__26__Vfuncout = 0;
    CData/*0:0*/ __Vfunc___03684__26__a;
    __Vfunc___03684__26__a = 0;
    SData/*12:0*/ __Vfunc___03684__26__b;
    __Vfunc___03684__26__b = 0;
    SData/*12:0*/ __Vfunc___03684__26__s;
    __Vfunc___03684__26__s = 0;
    CData/*3:0*/ __Vfunc___03685__27__Vfuncout;
    __Vfunc___03685__27__Vfuncout = 0;
    CData/*3:0*/ __Vfunc___03685__27__a;
    __Vfunc___03685__27__a = 0;
    QData/*51:0*/ __Vfunc___03685__27__b;
    __Vfunc___03685__27__b = 0;
    SData/*12:0*/ __Vfunc___03685__27__s;
    __Vfunc___03685__27__s = 0;
    CData/*7:0*/ __Vfunc___03687__28__Vfuncout;
    __Vfunc___03687__28__Vfuncout = 0;
    VlWide<4>/*103:0*/ __Vfunc___03687__28__b;
    VL_ZERO_W(104, __Vfunc___03687__28__b);
    SData/*12:0*/ __Vfunc___03687__28__s;
    __Vfunc___03687__28__s = 0;
    CData/*0:0*/ __Vfunc___03688__29__Vfuncout;
    __Vfunc___03688__29__Vfuncout = 0;
    CData/*0:0*/ __Vfunc___03688__29__a;
    __Vfunc___03688__29__a = 0;
    SData/*12:0*/ __Vfunc___03688__29__b;
    __Vfunc___03688__29__b = 0;
    SData/*12:0*/ __Vfunc___03688__29__s;
    __Vfunc___03688__29__s = 0;
    CData/*0:0*/ __Vfunc___03691__30__Vfuncout;
    __Vfunc___03691__30__Vfuncout = 0;
    SData/*12:0*/ __Vfunc___03691__30__s;
    __Vfunc___03691__30__s = 0;
    CData/*0:0*/ __Vfunc___03692__31__Vfuncout;
    __Vfunc___03692__31__Vfuncout = 0;
    CData/*0:0*/ __Vfunc___03692__31__a;
    __Vfunc___03692__31__a = 0;
    SData/*12:0*/ __Vfunc___03692__31__b;
    __Vfunc___03692__31__b = 0;
    SData/*12:0*/ __Vfunc___03692__31__s;
    __Vfunc___03692__31__s = 0;
    CData/*0:0*/ __Vfunc___03693__32__Vfuncout;
    __Vfunc___03693__32__Vfuncout = 0;
    CData/*0:0*/ __Vfunc___03693__32__a;
    __Vfunc___03693__32__a = 0;
    SData/*12:0*/ __Vfunc___03693__32__b;
    __Vfunc___03693__32__b = 0;
    SData/*12:0*/ __Vfunc___03693__32__s;
    __Vfunc___03693__32__s = 0;
    CData/*0:0*/ __Vfunc___03694__33__Vfuncout;
    __Vfunc___03694__33__Vfuncout = 0;
    CData/*0:0*/ __Vfunc___03694__33__a;
    __Vfunc___03694__33__a = 0;
    SData/*12:0*/ __Vfunc___03694__33__b;
    __Vfunc___03694__33__b = 0;
    SData/*12:0*/ __Vfunc___03694__33__s;
    __Vfunc___03694__33__s = 0;
    CData/*0:0*/ __Vfunc___03695__34__Vfuncout;
    __Vfunc___03695__34__Vfuncout = 0;
    CData/*0:0*/ __Vfunc___03695__34__a;
    __Vfunc___03695__34__a = 0;
    SData/*12:0*/ __Vfunc___03695__34__b;
    __Vfunc___03695__34__b = 0;
    SData/*12:0*/ __Vfunc___03695__34__s;
    __Vfunc___03695__34__s = 0;
    CData/*1:0*/ __Vfunc___03697__35__Vfuncout;
    __Vfunc___03697__35__Vfuncout = 0;
    CData/*1:0*/ __Vfunc___03697__35__a;
    __Vfunc___03697__35__a = 0;
    IData/*25:0*/ __Vfunc___03697__35__b;
    __Vfunc___03697__35__b = 0;
    SData/*12:0*/ __Vfunc___03697__35__s;
    __Vfunc___03697__35__s = 0;
    CData/*7:0*/ __Vfunc___03698__36__Vfuncout;
    __Vfunc___03698__36__Vfuncout = 0;
    CData/*7:0*/ __Vfunc___03698__36__a;
    __Vfunc___03698__36__a = 0;
    VlWide<4>/*103:0*/ __Vfunc___03698__36__b;
    VL_ZERO_W(104, __Vfunc___03698__36__b);
    SData/*12:0*/ __Vfunc___03698__36__s;
    __Vfunc___03698__36__s = 0;
    CData/*7:0*/ __Vfunc___03714__42__Vfuncout;
    __Vfunc___03714__42__Vfuncout = 0;
    CData/*7:0*/ __Vfunc___03714__42__b;
    __Vfunc___03714__42__b = 0;
    CData/*0:0*/ __Vfunc___03714__42__s;
    __Vfunc___03714__42__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__a;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__a = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034926__111__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034926__111__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034926__111__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034926__111__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034929__112__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034929__112__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034929__112__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034929__112__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__b = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034960__114__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034960__114__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034960__114__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034960__114__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034965__116__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034965__116__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034965__116__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034965__116__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034999__119__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034999__119__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034999__119__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034999__119__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035002__120__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035002__120__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035002__120__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035002__120__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035032__121__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035032__121__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035032__121__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035032__121__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035039__124__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035039__124__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035039__124__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035039__124__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035042__125__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035042__125__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035042__125__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035042__125__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035053__126__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035053__126__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035053__126__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035053__126__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035056__127__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035056__127__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035056__127__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035056__127__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035067__128__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035067__128__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035067__128__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035067__128__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035070__129__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035070__129__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035070__129__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035070__129__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035084__130__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035084__130__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035084__130__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035084__130__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035087__131__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035087__131__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035087__131__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035087__131__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035090__132__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035090__132__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035090__132__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035090__132__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035093__133__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035093__133__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035093__133__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035093__133__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035104__134__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035104__134__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035104__134__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035104__134__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035107__135__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035107__135__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035107__135__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035107__135__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035110__136__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035110__136__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035110__136__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035110__136__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035121__137__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035121__137__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035121__137__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035121__137__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035124__138__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035124__138__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035124__138__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035124__138__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035127__139__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035127__139__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035127__139__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035127__139__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035141__140__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035141__140__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035141__140__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035141__140__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035144__141__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035144__141__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035144__141__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035144__141__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035147__142__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035147__142__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035147__142__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035147__142__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035150__143__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035150__143__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035150__143__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035150__143__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035153__144__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035153__144__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035153__144__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035153__144__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035183__145__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035183__145__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035183__145__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035183__145__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035187__146__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035187__146__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035187__146__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035187__146__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035221__150__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035221__150__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035221__150__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035221__150__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035234__154__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035234__154__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035234__154__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035234__154__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035256__157__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035256__157__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035256__157__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035256__157__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035267__160__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035267__160__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035267__160__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035267__160__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035312__166__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035312__166__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035312__166__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035312__166__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035316__167__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035316__167__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035316__167__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035316__167__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035361__169__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035361__169__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035361__169__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035361__169__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__Vfuncout = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035369__172__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035369__172__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035369__172__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035369__172__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035607__180__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035607__180__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035607__180__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035607__180__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035609__181__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035609__181__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035609__181__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035609__181__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035614__183__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035614__183__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035614__183__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035614__183__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035617__184__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035617__184__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035617__184__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035617__184__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035712__186__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035712__186__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035712__186__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035712__186__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__Vfuncout = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035722__190__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035722__190__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035722__190__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035722__190__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035725__191__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035725__191__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035725__191__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035725__191__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035729__192__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035729__192__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035729__192__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035729__192__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035732__193__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035732__193__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035732__193__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035732__193__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035767__195__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035767__195__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035767__195__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035767__195__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__Vfuncout = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035777__199__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035777__199__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035777__199__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035777__199__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035780__200__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035780__200__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035780__200__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035780__200__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035784__201__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035784__201__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035784__201__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035784__201__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035787__202__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035787__202__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035787__202__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035787__202__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035822__206__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035822__206__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035822__206__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035822__206__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035826__207__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035826__207__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035826__207__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035826__207__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035845__209__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035845__209__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035845__209__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035845__209__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035860__213__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035860__213__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035860__213__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035860__213__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035959__223__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035959__223__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035959__223__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035959__223__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035961__224__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035961__224__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035961__224__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035961__224__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035974__229__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035974__229__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035974__229__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035974__229__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035978__230__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035978__230__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035978__230__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035978__230__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035982__231__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035982__231__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035982__231__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035982__231__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036039__232__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036039__232__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036039__232__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036039__232__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036042__233__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036042__233__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036042__233__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036042__233__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036045__234__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036045__234__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036045__234__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036045__234__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__Vfuncout = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__b = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036098__236__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036098__236__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036098__236__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036098__236__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036103__238__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036103__238__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036103__238__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036103__238__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036137__240__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036137__240__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036137__240__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036137__240__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036140__241__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036140__241__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036140__241__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036140__241__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036143__242__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036143__242__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036143__242__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036143__242__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036164__245__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036164__245__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036164__245__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036164__245__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036167__246__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036167__246__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036167__246__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036167__246__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036170__247__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036170__247__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036170__247__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036170__247__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036190__250__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036190__250__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036190__250__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036190__250__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036193__251__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036193__251__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036193__251__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036193__251__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036196__252__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036196__252__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036196__252__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036196__252__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036217__255__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036217__255__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036217__255__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036217__255__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036220__256__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036220__256__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036220__256__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036220__256__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036223__257__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036223__257__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036223__257__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036223__257__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036243__260__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036243__260__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036243__260__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036243__260__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036246__261__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036246__261__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036246__261__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036246__261__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036249__262__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036249__262__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036249__262__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036249__262__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036268__264__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036268__264__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036268__264__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036268__264__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036271__265__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036271__265__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036271__265__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036271__265__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036281__269__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036281__269__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036281__269__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036281__269__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036284__270__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036284__270__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036284__270__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036284__270__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036291__272__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036291__272__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036291__272__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036291__272__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036324__278__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036324__278__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036324__278__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036324__278__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036327__279__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036327__279__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036327__279__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036327__279__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036419__289__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036419__289__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036419__289__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036419__289__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036422__290__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036422__290__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036422__290__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036422__290__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036470__295__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036470__295__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036470__295__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036470__295__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036473__296__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036473__296__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036473__296__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036473__296__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036476__297__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036476__297__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036476__297__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036476__297__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036545__303__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036545__303__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036545__303__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036545__303__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036548__304__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036548__304__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036548__304__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036548__304__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036593__308__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036593__308__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036593__308__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036593__308__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036596__309__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036596__309__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036596__309__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036596__309__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036600__310__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036600__310__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036600__310__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036600__310__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036634__312__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036634__312__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036634__312__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036634__312__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036637__313__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036637__313__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036637__313__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036637__313__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036640__314__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036640__314__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036640__314__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036640__314__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036643__315__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036643__315__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036643__315__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036643__315__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036656__317__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036656__317__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036656__317__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036656__317__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036662__319__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036662__319__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036662__319__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036662__319__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036665__320__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036665__320__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036665__320__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036665__320__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036668__321__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036668__321__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036668__321__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036668__321__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038615__415__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038615__415__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038615__415__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038615__415__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038630__420__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038630__420__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038630__420__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038630__420__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038679__423__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038679__423__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038679__423__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038679__423__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__Vfuncout = 0;
    SData/*15:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038688__426__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038688__426__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038688__426__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038688__426__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__a = 0;
    SData/*15:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038747__435__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038747__435__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038747__435__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038747__435__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038750__436__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038750__436__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038750__436__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038750__436__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038753__437__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038753__437__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038753__437__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038753__437__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__a = 0;
    SData/*15:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038808__447__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038808__447__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038808__447__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038808__447__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038919__456__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038919__456__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038919__456__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038919__456__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038921__457__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038921__457__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038921__457__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038921__457__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038934__462__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038934__462__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038934__462__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038934__462__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038938__463__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038938__463__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038938__463__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038938__463__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039001__471__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039001__471__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039001__471__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039001__471__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039003__472__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039003__472__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039003__472__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039003__472__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__a = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039016__477__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039016__477__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039016__477__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039016__477__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039020__478__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039020__478__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039020__478__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039020__478__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039046__480__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039046__480__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039046__480__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039046__480__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039048__481__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039048__481__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039048__481__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039048__481__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039050__482__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039050__482__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039050__482__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039050__482__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039055__484__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039055__484__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039055__484__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039055__484__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039059__485__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039059__485__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039059__485__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039059__485__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039062__486__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039062__486__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039062__486__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039062__486__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039065__487__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039065__487__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039065__487__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039065__487__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039068__488__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039068__488__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039068__488__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039068__488__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039085__490__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039085__490__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039085__490__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039085__490__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039087__491__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039087__491__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039087__491__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039087__491__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039089__492__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039089__492__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039089__492__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039089__492__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039094__494__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039094__494__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039094__494__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039094__494__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039098__495__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039098__495__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039098__495__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039098__495__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039101__496__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039101__496__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039101__496__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039101__496__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039104__497__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039104__497__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039104__497__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039104__497__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039122__499__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039122__499__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039122__499__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039122__499__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039125__500__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039125__500__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039125__500__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039125__500__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039128__501__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039128__501__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039128__501__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039128__501__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039131__502__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039131__502__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039131__502__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039131__502__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039178__506__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039178__506__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039178__506__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039178__506__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039181__507__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039181__507__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039181__507__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039181__507__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039184__508__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039184__508__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039184__508__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039184__508__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039229__512__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039229__512__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039229__512__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039229__512__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039232__513__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039232__513__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039232__513__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039232__513__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039235__514__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039235__514__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039235__514__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039235__514__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039282__517__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039282__517__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039282__517__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039282__517__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__a = 0;
    SData/*15:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039294__521__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039294__521__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039294__521__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039294__521__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039304__524__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039304__524__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039304__524__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039304__524__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039307__525__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039307__525__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039307__525__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039307__525__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039310__526__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039310__526__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039310__526__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039310__526__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039345__529__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039345__529__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039345__529__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039345__529__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__a = 0;
    SData/*15:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039357__533__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039357__533__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039357__533__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039357__533__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039364__535__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039364__535__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039364__535__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039364__535__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039367__536__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039367__536__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039367__536__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039367__536__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039370__537__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039370__537__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039370__537__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039370__537__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039373__538__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039373__538__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039373__538__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039373__538__s = 0;
    CData/*0:0*/ __Vfunc_sdcard__DOT____032682__626__Vfuncout;
    __Vfunc_sdcard__DOT____032682__626__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_sdcard__DOT____032682__626__b;
    __Vfunc_sdcard__DOT____032682__626__b = 0;
    CData/*3:0*/ __Vfunc_sdcard__DOT____032682__626__s;
    __Vfunc_sdcard__DOT____032682__626__s = 0;
    CData/*0:0*/ __Vfunc_sdcard__DOT____032693__628__Vfuncout;
    __Vfunc_sdcard__DOT____032693__628__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_sdcard__DOT____032693__628__b;
    __Vfunc_sdcard__DOT____032693__628__b = 0;
    CData/*3:0*/ __Vfunc_sdcard__DOT____032693__628__s;
    __Vfunc_sdcard__DOT____032693__628__s = 0;
    CData/*3:0*/ __Vfunc_ym2149_audio_inst__DOT____031777__645__Vfuncout;
    __Vfunc_ym2149_audio_inst__DOT____031777__645__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_ym2149_audio_inst__DOT____031777__645__a;
    __Vfunc_ym2149_audio_inst__DOT____031777__645__a = 0;
    SData/*11:0*/ __Vfunc_ym2149_audio_inst__DOT____031777__645__b;
    __Vfunc_ym2149_audio_inst__DOT____031777__645__b = 0;
    CData/*2:0*/ __Vfunc_ym2149_audio_inst__DOT____031777__645__s;
    __Vfunc_ym2149_audio_inst__DOT____031777__645__s = 0;
    CData/*0:0*/ __Vfunc_ym2149_audio_inst__DOT____031780__646__Vfuncout;
    __Vfunc_ym2149_audio_inst__DOT____031780__646__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_ym2149_audio_inst__DOT____031780__646__s;
    __Vfunc_ym2149_audio_inst__DOT____031780__646__s = 0;
    CData/*0:0*/ __Vfunc_ym2149_audio_inst__DOT____031784__647__Vfuncout;
    __Vfunc_ym2149_audio_inst__DOT____031784__647__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_ym2149_audio_inst__DOT____031784__647__s;
    __Vfunc_ym2149_audio_inst__DOT____031784__647__s = 0;
    VlWide<4>/*127:0*/ __Vtemp_2;
    VlWide<4>/*127:0*/ __Vtemp_3;
    // Body
    vlSelf->__PVT___360_ = ((IData)(vlSymsp->TOP.clk_3m58_en) 
                            | (IData)(vlSelf->__PVT___416_));
    vlSelf->__PVT___402_ = ((IData)(vlSelf->__PVT___427_)
                             ? (IData)(vlSelf->__PVT___421_)
                             : 0U);
    if (vlSymsp->TOP.clk_3m58_en) {
        vlSelf->__PVT__ctrl_b__DOT___68_ = vlSelf->__PVT__ctrl_b__DOT__p1_9cd__DOT___11_;
        vlSelf->__PVT__ctrl_b__DOT___70_ = vlSelf->__PVT__ctrl_b__DOT__p2_9cd__DOT___11_;
        vlSelf->__PVT__ctrl_b__DOT___74_ = (0U == (IData)(vlSelf->__PVT__ctrl_b__DOT___73_));
        vlSelf->__PVT__ctrl_b__DOT___76_ = (0U == (IData)(vlSelf->__PVT__ctrl_b__DOT___79_));
        vlSelf->__PVT__ctrl_b__DOT___80_ = (0U == (IData)(vlSelf->__PVT__ctrl_b__DOT___83_));
        vlSelf->__PVT__ctrl_b__DOT__p1_1__DOT___4_ 
            = ((0xeU & ((IData)(vlSelf->__PVT__ctrl_b__DOT__p1_1__DOT___5_) 
                        << 1U)) | (1U & (IData)(vlSymsp->TOP.p1)));
        vlSelf->__PVT__ctrl_b__DOT__p1_1__DOT___6_ 
            = ((0U != (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_1__DOT___5_)) 
               & ((0xfU == (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_1__DOT___5_)) 
                  | (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_1__DOT___7_)));
        vlSelf->__PVT__ctrl_b__DOT__p1_2__DOT___4_ 
            = ((0xeU & ((IData)(vlSelf->__PVT__ctrl_b__DOT__p1_2__DOT___5_) 
                        << 1U)) | (1U & (IData)(vlSymsp->TOP.p2)));
        vlSelf->__PVT__ctrl_b__DOT__p1_2__DOT___6_ 
            = ((0U != (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_2__DOT___5_)) 
               & ((0xfU == (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_2__DOT___5_)) 
                  | (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_2__DOT___7_)));
        vlSelf->__PVT__ctrl_b__DOT__p1_3__DOT___4_ 
            = ((0xeU & ((IData)(vlSelf->__PVT__ctrl_b__DOT__p1_3__DOT___5_) 
                        << 1U)) | (1U & (IData)(vlSymsp->TOP.p3)));
        vlSelf->__PVT__ctrl_b__DOT__p1_3__DOT___6_ 
            = ((0U != (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_3__DOT___5_)) 
               & ((0xfU == (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_3__DOT___5_)) 
                  | (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_3__DOT___7_)));
        vlSelf->__PVT__ctrl_b__DOT__p1_4__DOT___4_ 
            = ((0xeU & ((IData)(vlSelf->__PVT__ctrl_b__DOT__p1_4__DOT___5_) 
                        << 1U)) | (1U & (IData)(vlSymsp->TOP.p4)));
        vlSelf->__PVT__ctrl_b__DOT__p1_4__DOT___6_ 
            = ((0U != (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_4__DOT___5_)) 
               & ((0xfU == (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_4__DOT___5_)) 
                  | (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_4__DOT___7_)));
        vlSelf->__PVT__ctrl_b__DOT__p1_6__DOT___4_ 
            = ((0xeU & ((IData)(vlSelf->__PVT__ctrl_b__DOT__p1_6__DOT___5_) 
                        << 1U)) | (1U & (IData)(vlSymsp->TOP.p6)));
        vlSelf->__PVT__ctrl_b__DOT__p1_6__DOT___6_ 
            = ((0U != (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_6__DOT___5_)) 
               & ((0xfU == (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_6__DOT___5_)) 
                  | (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_6__DOT___7_)));
        vlSelf->__PVT__ctrl_b__DOT__p1_7__DOT___4_ 
            = ((0xeU & ((IData)(vlSelf->__PVT__ctrl_b__DOT__p1_7__DOT___5_) 
                        << 1U)) | (1U & (IData)(vlSymsp->TOP.p7)));
        vlSelf->__PVT__ctrl_b__DOT__p1_7__DOT___6_ 
            = ((0U != (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_7__DOT___5_)) 
               & ((0xfU == (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_7__DOT___5_)) 
                  | (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_7__DOT___7_)));
        vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___25_ 
            = ((0xeU & ((IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___26_) 
                        << 1U)) | (1U & (IData)(vlSymsp->TOP.p9)));
        vlSelf->__PVT__ctrl_b__DOT__p1_9cd__DOT___12_ 
            = vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___28_;
        vlSelf->__PVT__ctrl_b__DOT__p2_1__DOT___4_ 
            = ((0xeU & ((IData)(vlSelf->__PVT__ctrl_b__DOT__p2_1__DOT___5_) 
                        << 1U)) | (1U & ((IData)(vlSymsp->TOP.p1) 
                                         >> 1U)));
        vlSelf->__PVT__ctrl_b__DOT__p2_1__DOT___6_ 
            = ((0U != (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_1__DOT___5_)) 
               & ((0xfU == (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_1__DOT___5_)) 
                  | (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_1__DOT___7_)));
        vlSelf->__PVT__ctrl_b__DOT__p2_2__DOT___4_ 
            = ((0xeU & ((IData)(vlSelf->__PVT__ctrl_b__DOT__p2_2__DOT___5_) 
                        << 1U)) | (1U & ((IData)(vlSymsp->TOP.p2) 
                                         >> 1U)));
        vlSelf->__PVT__ctrl_b__DOT__p2_2__DOT___6_ 
            = ((0U != (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_2__DOT___5_)) 
               & ((0xfU == (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_2__DOT___5_)) 
                  | (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_2__DOT___7_)));
        vlSelf->__PVT__ctrl_b__DOT__p2_3__DOT___4_ 
            = ((0xeU & ((IData)(vlSelf->__PVT__ctrl_b__DOT__p2_3__DOT___5_) 
                        << 1U)) | (1U & ((IData)(vlSymsp->TOP.p3) 
                                         >> 1U)));
        vlSelf->__PVT__ctrl_b__DOT__p2_3__DOT___6_ 
            = ((0U != (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_3__DOT___5_)) 
               & ((0xfU == (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_3__DOT___5_)) 
                  | (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_3__DOT___7_)));
        vlSelf->__PVT__ctrl_b__DOT__p2_4__DOT___4_ 
            = ((0xeU & ((IData)(vlSelf->__PVT__ctrl_b__DOT__p2_4__DOT___5_) 
                        << 1U)) | (1U & ((IData)(vlSymsp->TOP.p4) 
                                         >> 1U)));
        vlSelf->__PVT__ctrl_b__DOT__p2_4__DOT___6_ 
            = ((0U != (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_4__DOT___5_)) 
               & ((0xfU == (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_4__DOT___5_)) 
                  | (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_4__DOT___7_)));
        vlSelf->__PVT__ctrl_b__DOT__p2_6__DOT___4_ 
            = ((0xeU & ((IData)(vlSelf->__PVT__ctrl_b__DOT__p2_6__DOT___5_) 
                        << 1U)) | (1U & ((IData)(vlSymsp->TOP.p6) 
                                         >> 1U)));
        vlSelf->__PVT__ctrl_b__DOT__p2_6__DOT___6_ 
            = ((0U != (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_6__DOT___5_)) 
               & ((0xfU == (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_6__DOT___5_)) 
                  | (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_6__DOT___7_)));
        vlSelf->__PVT__ctrl_b__DOT__p2_7__DOT___4_ 
            = ((0xeU & ((IData)(vlSelf->__PVT__ctrl_b__DOT__p2_7__DOT___5_) 
                        << 1U)) | (1U & ((IData)(vlSymsp->TOP.p7) 
                                         >> 1U)));
        vlSelf->__PVT__ctrl_b__DOT__p2_7__DOT___6_ 
            = ((0U != (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_7__DOT___5_)) 
               & ((0xfU == (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_7__DOT___5_)) 
                  | (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_7__DOT___7_)));
        vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___25_ 
            = ((0xeU & ((IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___26_) 
                        << 1U)) | (1U & ((IData)(vlSymsp->TOP.p9) 
                                         >> 1U)));
        vlSelf->__PVT__ctrl_b__DOT__p2_9cd__DOT___12_ 
            = vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___28_;
        vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___27_ 
            = ((~ ((0U != (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___31_)) 
                   & (0U == (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___33_)))) 
               & (((0U != (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___33_)) 
                   & (0U == (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___31_))) 
                  | (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___28_)));
        vlSelf->__PVT__ctrl_b__DOT__p1_9cd__DOT___10_ 
            = ((2U & (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9cd__DOT___15_))
                ? (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___28_)
                : (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9cd__DOT___11_));
        vlSelf->__PVT__ctrl_b__DOT__p1_9cd__DOT___14_ 
            = (3U & ((IData)((((IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9cd__DOT___15_) 
                               >> 1U) | ((IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___28_) 
                                         == (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9cd__DOT___13_))))
                      ? (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9cd__DOT___15_)
                      : ((IData)(1U) + (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9cd__DOT___15_))));
        vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___27_ 
            = ((~ ((0U != (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___31_)) 
                   & (0U == (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___33_)))) 
               & (((0U != (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___33_)) 
                   & (0U == (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___31_))) 
                  | (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___28_)));
        vlSelf->__PVT__ctrl_b__DOT__p2_9cd__DOT___10_ 
            = ((2U & (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9cd__DOT___15_))
                ? (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___28_)
                : (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9cd__DOT___11_));
        vlSelf->__PVT__ctrl_b__DOT__p2_9cd__DOT___14_ 
            = (3U & ((IData)((((IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9cd__DOT___15_) 
                               >> 1U) | ((IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___28_) 
                                         == (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9cd__DOT___13_))))
                      ? (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9cd__DOT___15_)
                      : ((IData)(1U) + (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9cd__DOT___15_))));
    } else {
        vlSelf->__PVT__ctrl_b__DOT___68_ = vlSelf->__PVT__ctrl_b__DOT___69_;
        vlSelf->__PVT__ctrl_b__DOT___70_ = vlSelf->__PVT__ctrl_b__DOT___71_;
        vlSelf->__PVT__ctrl_b__DOT___74_ = vlSelf->__PVT__ctrl_b__DOT___75_;
        vlSelf->__PVT__ctrl_b__DOT___76_ = vlSelf->__PVT__ctrl_b__DOT___77_;
        vlSelf->__PVT__ctrl_b__DOT___80_ = vlSelf->__PVT__ctrl_b__DOT___81_;
        vlSelf->__PVT__ctrl_b__DOT__p1_1__DOT___4_ 
            = vlSelf->__PVT__ctrl_b__DOT__p1_1__DOT___5_;
        vlSelf->__PVT__ctrl_b__DOT__p1_1__DOT___6_ 
            = vlSelf->__PVT__ctrl_b__DOT__p1_1__DOT___7_;
        vlSelf->__PVT__ctrl_b__DOT__p1_2__DOT___4_ 
            = vlSelf->__PVT__ctrl_b__DOT__p1_2__DOT___5_;
        vlSelf->__PVT__ctrl_b__DOT__p1_2__DOT___6_ 
            = vlSelf->__PVT__ctrl_b__DOT__p1_2__DOT___7_;
        vlSelf->__PVT__ctrl_b__DOT__p1_3__DOT___4_ 
            = vlSelf->__PVT__ctrl_b__DOT__p1_3__DOT___5_;
        vlSelf->__PVT__ctrl_b__DOT__p1_3__DOT___6_ 
            = vlSelf->__PVT__ctrl_b__DOT__p1_3__DOT___7_;
        vlSelf->__PVT__ctrl_b__DOT__p1_4__DOT___4_ 
            = vlSelf->__PVT__ctrl_b__DOT__p1_4__DOT___5_;
        vlSelf->__PVT__ctrl_b__DOT__p1_4__DOT___6_ 
            = vlSelf->__PVT__ctrl_b__DOT__p1_4__DOT___7_;
        vlSelf->__PVT__ctrl_b__DOT__p1_6__DOT___4_ 
            = vlSelf->__PVT__ctrl_b__DOT__p1_6__DOT___5_;
        vlSelf->__PVT__ctrl_b__DOT__p1_6__DOT___6_ 
            = vlSelf->__PVT__ctrl_b__DOT__p1_6__DOT___7_;
        vlSelf->__PVT__ctrl_b__DOT__p1_7__DOT___4_ 
            = vlSelf->__PVT__ctrl_b__DOT__p1_7__DOT___5_;
        vlSelf->__PVT__ctrl_b__DOT__p1_7__DOT___6_ 
            = vlSelf->__PVT__ctrl_b__DOT__p1_7__DOT___7_;
        vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___25_ 
            = vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___26_;
        vlSelf->__PVT__ctrl_b__DOT__p1_9cd__DOT___12_ 
            = vlSelf->__PVT__ctrl_b__DOT__p1_9cd__DOT___13_;
        vlSelf->__PVT__ctrl_b__DOT__p2_1__DOT___4_ 
            = vlSelf->__PVT__ctrl_b__DOT__p2_1__DOT___5_;
        vlSelf->__PVT__ctrl_b__DOT__p2_1__DOT___6_ 
            = vlSelf->__PVT__ctrl_b__DOT__p2_1__DOT___7_;
        vlSelf->__PVT__ctrl_b__DOT__p2_2__DOT___4_ 
            = vlSelf->__PVT__ctrl_b__DOT__p2_2__DOT___5_;
        vlSelf->__PVT__ctrl_b__DOT__p2_2__DOT___6_ 
            = vlSelf->__PVT__ctrl_b__DOT__p2_2__DOT___7_;
        vlSelf->__PVT__ctrl_b__DOT__p2_3__DOT___4_ 
            = vlSelf->__PVT__ctrl_b__DOT__p2_3__DOT___5_;
        vlSelf->__PVT__ctrl_b__DOT__p2_3__DOT___6_ 
            = vlSelf->__PVT__ctrl_b__DOT__p2_3__DOT___7_;
        vlSelf->__PVT__ctrl_b__DOT__p2_4__DOT___4_ 
            = vlSelf->__PVT__ctrl_b__DOT__p2_4__DOT___5_;
        vlSelf->__PVT__ctrl_b__DOT__p2_4__DOT___6_ 
            = vlSelf->__PVT__ctrl_b__DOT__p2_4__DOT___7_;
        vlSelf->__PVT__ctrl_b__DOT__p2_6__DOT___4_ 
            = vlSelf->__PVT__ctrl_b__DOT__p2_6__DOT___5_;
        vlSelf->__PVT__ctrl_b__DOT__p2_6__DOT___6_ 
            = vlSelf->__PVT__ctrl_b__DOT__p2_6__DOT___7_;
        vlSelf->__PVT__ctrl_b__DOT__p2_7__DOT___4_ 
            = vlSelf->__PVT__ctrl_b__DOT__p2_7__DOT___5_;
        vlSelf->__PVT__ctrl_b__DOT__p2_7__DOT___6_ 
            = vlSelf->__PVT__ctrl_b__DOT__p2_7__DOT___7_;
        vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___25_ 
            = vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___26_;
        vlSelf->__PVT__ctrl_b__DOT__p2_9cd__DOT___12_ 
            = vlSelf->__PVT__ctrl_b__DOT__p2_9cd__DOT___13_;
        vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___27_ 
            = vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___28_;
        vlSelf->__PVT__ctrl_b__DOT__p1_9cd__DOT___10_ 
            = vlSelf->__PVT__ctrl_b__DOT__p1_9cd__DOT___11_;
        vlSelf->__PVT__ctrl_b__DOT__p1_9cd__DOT___14_ 
            = (3U & (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9cd__DOT___15_));
        vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___27_ 
            = vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___28_;
        vlSelf->__PVT__ctrl_b__DOT__p2_9cd__DOT___10_ 
            = vlSelf->__PVT__ctrl_b__DOT__p2_9cd__DOT___11_;
        vlSelf->__PVT__ctrl_b__DOT__p2_9cd__DOT___14_ 
            = (3U & (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9cd__DOT___15_));
    }
    vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___30_ = (0x7ffU 
                                                   & (((IData)(vlSymsp->TOP.clk_3m58_en) 
                                                       & ((0U 
                                                           != (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___31_)) 
                                                          | (0U 
                                                             == (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___26_))))
                                                       ? 
                                                      ((0U 
                                                        == (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___26_))
                                                        ? 0x599U
                                                        : 
                                                       ((IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___31_) 
                                                        - (IData)(1U)))
                                                       : (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___31_)));
    vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___32_ = (0x1ffU 
                                                   & (((IData)(vlSymsp->TOP.clk_3m58_en) 
                                                       & ((0U 
                                                           != (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___33_)) 
                                                          | (0xfU 
                                                             == (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___26_))))
                                                       ? 
                                                      ((0xfU 
                                                        == (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___26_))
                                                        ? 0x1f6U
                                                        : 
                                                       ((IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___33_) 
                                                        - (IData)(1U)))
                                                       : (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9__DOT___33_)));
    vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___30_ = (0x7ffU 
                                                   & (((IData)(vlSymsp->TOP.clk_3m58_en) 
                                                       & ((0U 
                                                           != (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___31_)) 
                                                          | (0U 
                                                             == (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___26_))))
                                                       ? 
                                                      ((0U 
                                                        == (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___26_))
                                                        ? 0x599U
                                                        : 
                                                       ((IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___31_) 
                                                        - (IData)(1U)))
                                                       : (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___31_)));
    vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___32_ = (0x1ffU 
                                                   & (((IData)(vlSymsp->TOP.clk_3m58_en) 
                                                       & ((0U 
                                                           != (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___33_)) 
                                                          | (0xfU 
                                                             == (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___26_))))
                                                       ? 
                                                      ((0xfU 
                                                        == (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___26_))
                                                        ? 0x1f6U
                                                        : 
                                                       ((IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___33_) 
                                                        - (IData)(1U)))
                                                       : (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9__DOT___33_)));
    vlSelf->__PVT__cache__DOT__f_cmd_byte = (0xffU 
                                             & ((0U 
                                                 == (IData)(vlSelf->__PVT__cache__DOT__f_ci))
                                                 ? 
                                                ((IData)(vlSelf->__PVT__cache__DOT__f_stop)
                                                  ? 0x4cU
                                                  : 0x52U)
                                                 : 
                                                ((5U 
                                                  == (IData)(vlSelf->__PVT__cache__DOT__f_ci))
                                                  ? 0xffU
                                                  : 
                                                 ((IData)(vlSelf->__PVT__cache__DOT__f_stop)
                                                   ? 0U
                                                   : 
                                                  ((1U 
                                                    == (IData)(vlSelf->__PVT__cache__DOT__f_ci))
                                                    ? 
                                                   (vlSelf->__PVT__cache__DOT__f_arg 
                                                    >> 0x18U)
                                                    : 
                                                   ((2U 
                                                     == (IData)(vlSelf->__PVT__cache__DOT__f_ci))
                                                     ? 
                                                    (vlSelf->__PVT__cache__DOT__f_arg 
                                                     >> 0x10U)
                                                     : 
                                                    ((3U 
                                                      == (IData)(vlSelf->__PVT__cache__DOT__f_ci))
                                                      ? 
                                                     (vlSelf->__PVT__cache__DOT__f_arg 
                                                      >> 8U)
                                                      : vlSelf->__PVT__cache__DOT__f_arg)))))));
    vlSelf->__PVT___489_ = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___808_) 
                            | ((~ ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___808_)) 
                                   & (IData)(vlSelf->__PVT___407_))) 
                               & ((IData)(vlSelf->__PVT___408_) 
                                  | (IData)(vlSymsp->TOP.clk_3m58_en))));
    __Vfunc_sdcard__DOT____032682__626__s = (((3U == (IData)(vlSelf->__PVT__sdcard__DOT___45_)) 
                                              << 3U) 
                                             | (((2U 
                                                  == (IData)(vlSelf->__PVT__sdcard__DOT___45_)) 
                                                 << 2U) 
                                                | (((1U 
                                                     == (IData)(vlSelf->__PVT__sdcard__DOT___45_)) 
                                                    << 1U) 
                                                   | (0U 
                                                      == (IData)(vlSelf->__PVT__sdcard__DOT___45_)))));
    __Vfunc_sdcard__DOT____032682__626__b = ((0xcU 
                                              & ((- (IData)((IData)(vlSelf->__PVT__sdcard__DOT___48_))) 
                                                 << 2U)) 
                                             | (((IData)(vlSymsp->TOP.sd_miso) 
                                                 << 1U) 
                                                | (IData)(vlSelf->__PVT__sdcard__DOT___48_)));
    __Vfunc_sdcard__DOT____032682__626__Vfuncout = 
        (1U & ((8U & (IData)(__Vfunc_sdcard__DOT____032682__626__s))
                ? ((4U & (IData)(__Vfunc_sdcard__DOT____032682__626__s))
                    ? ((2U & (IData)(__Vfunc_sdcard__DOT____032682__626__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032682__626__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032682__626__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032682__626__b) 
                               >> 1U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032682__626__s))
                                           ? (IData)(__Vfunc_sdcard__DOT____032682__626__b)
                                           : ((IData)(__Vfunc_sdcard__DOT____032682__626__b) 
                                              >> 2U)))
                    : ((2U & (IData)(__Vfunc_sdcard__DOT____032682__626__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032682__626__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032682__626__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032682__626__b) 
                               >> 1U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032682__626__s))
                                           ? (IData)(__Vfunc_sdcard__DOT____032682__626__b)
                                           : ((IData)(__Vfunc_sdcard__DOT____032682__626__b) 
                                              >> 3U))))
                : ((4U & (IData)(__Vfunc_sdcard__DOT____032682__626__s))
                    ? ((2U & (IData)(__Vfunc_sdcard__DOT____032682__626__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032682__626__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032682__626__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032682__626__b) 
                               >> 1U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032682__626__s))
                                           ? (IData)(__Vfunc_sdcard__DOT____032682__626__b)
                                           : ((IData)(__Vfunc_sdcard__DOT____032682__626__b) 
                                              >> 2U)))
                    : ((2U & (IData)(__Vfunc_sdcard__DOT____032682__626__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032682__626__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032682__626__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032682__626__b) 
                               >> 1U)) : ((IData)(__Vfunc_sdcard__DOT____032682__626__s) 
                                          & (IData)(__Vfunc_sdcard__DOT____032682__626__b))))));
    vlSelf->__PVT__sdcard__DOT___19_ = __Vfunc_sdcard__DOT____032682__626__Vfuncout;
    __Vfunc___03395__8__s = (((7U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                            >> 0xdU))) 
                              << 7U) | (((6U == (7U 
                                                 & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                    >> 0xdU))) 
                                         << 6U) | (
                                                   ((5U 
                                                     == 
                                                     (7U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                         >> 0xdU))) 
                                                    << 5U) 
                                                   | (((4U 
                                                        == 
                                                        (7U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                            >> 0xdU))) 
                                                       << 4U) 
                                                      | (((3U 
                                                           == 
                                                           (7U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                               >> 0xdU))) 
                                                          << 3U) 
                                                         | (((2U 
                                                              == 
                                                              (7U 
                                                               & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                  >> 0xdU))) 
                                                             << 2U) 
                                                            | (((1U 
                                                                 == 
                                                                 (7U 
                                                                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                     >> 0xdU))) 
                                                                << 1U) 
                                                               | (0U 
                                                                  == 
                                                                  (7U 
                                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                      >> 0xdU))))))))));
    __Vfunc___03395__8__Vfuncout = (1U & ((~ ((((((
                                                   ((1U 
                                                     == 
                                                     (1U 
                                                      & (IData)(__Vfunc___03395__8__s))) 
                                                    | (2U 
                                                       == 
                                                       (2U 
                                                        & (IData)(__Vfunc___03395__8__s)))) 
                                                   | (4U 
                                                      == 
                                                      (4U 
                                                       & (IData)(__Vfunc___03395__8__s)))) 
                                                  | (8U 
                                                     == 
                                                     (8U 
                                                      & (IData)(__Vfunc___03395__8__s)))) 
                                                 | (0x10U 
                                                    == 
                                                    (0x10U 
                                                     & (IData)(__Vfunc___03395__8__s)))) 
                                                | (0x20U 
                                                   == 
                                                   (0x20U 
                                                    & (IData)(__Vfunc___03395__8__s)))) 
                                               | (0x40U 
                                                  == 
                                                  (0x40U 
                                                   & (IData)(__Vfunc___03395__8__s)))) 
                                              | (0x80U 
                                                 == 
                                                 (0x80U 
                                                  & (IData)(__Vfunc___03395__8__s))))) 
                                          | ((1U == 
                                              (1U & (IData)(__Vfunc___03395__8__s))) 
                                             | ((2U 
                                                 == 
                                                 (2U 
                                                  & (IData)(__Vfunc___03395__8__s))) 
                                                | ((4U 
                                                    == 
                                                    (4U 
                                                     & (IData)(__Vfunc___03395__8__s))) 
                                                   | ((8U 
                                                       == 
                                                       (8U 
                                                        & (IData)(__Vfunc___03395__8__s))) 
                                                      | (0x10U 
                                                         != 
                                                         (0x10U 
                                                          & (IData)(__Vfunc___03395__8__s)))))))));
    vlSelf->__PVT___115_ = __Vfunc___03395__8__Vfuncout;
    __Vfunc___03398__9__s = (((7U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                            >> 0xdU))) 
                              << 7U) | (((6U == (7U 
                                                 & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                    >> 0xdU))) 
                                         << 6U) | (
                                                   ((5U 
                                                     == 
                                                     (7U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                         >> 0xdU))) 
                                                    << 5U) 
                                                   | (((4U 
                                                        == 
                                                        (7U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                            >> 0xdU))) 
                                                       << 4U) 
                                                      | (((3U 
                                                           == 
                                                           (7U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                               >> 0xdU))) 
                                                          << 3U) 
                                                         | (((2U 
                                                              == 
                                                              (7U 
                                                               & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                  >> 0xdU))) 
                                                             << 2U) 
                                                            | (((1U 
                                                                 == 
                                                                 (7U 
                                                                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                     >> 0xdU))) 
                                                                << 1U) 
                                                               | (0U 
                                                                  == 
                                                                  (7U 
                                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                      >> 0xdU))))))))));
    __Vfunc___03398__9__Vfuncout = (1U & ((~ ((((((
                                                   ((1U 
                                                     == 
                                                     (1U 
                                                      & (IData)(__Vfunc___03398__9__s))) 
                                                    | (2U 
                                                       == 
                                                       (2U 
                                                        & (IData)(__Vfunc___03398__9__s)))) 
                                                   | (4U 
                                                      == 
                                                      (4U 
                                                       & (IData)(__Vfunc___03398__9__s)))) 
                                                  | (8U 
                                                     == 
                                                     (8U 
                                                      & (IData)(__Vfunc___03398__9__s)))) 
                                                 | (0x10U 
                                                    == 
                                                    (0x10U 
                                                     & (IData)(__Vfunc___03398__9__s)))) 
                                                | (0x20U 
                                                   == 
                                                   (0x20U 
                                                    & (IData)(__Vfunc___03398__9__s)))) 
                                               | (0x40U 
                                                  == 
                                                  (0x40U 
                                                   & (IData)(__Vfunc___03398__9__s)))) 
                                              | (0x80U 
                                                 == 
                                                 (0x80U 
                                                  & (IData)(__Vfunc___03398__9__s))))) 
                                          | ((1U == 
                                              (1U & (IData)(__Vfunc___03398__9__s))) 
                                             | ((2U 
                                                 == 
                                                 (2U 
                                                  & (IData)(__Vfunc___03398__9__s))) 
                                                | ((4U 
                                                    == 
                                                    (4U 
                                                     & (IData)(__Vfunc___03398__9__s))) 
                                                   | ((8U 
                                                       == 
                                                       (8U 
                                                        & (IData)(__Vfunc___03398__9__s))) 
                                                      | ((0x10U 
                                                          == 
                                                          (0x10U 
                                                           & (IData)(__Vfunc___03398__9__s))) 
                                                         | (0x20U 
                                                            != 
                                                            (0x20U 
                                                             & (IData)(__Vfunc___03398__9__s))))))))));
    vlSelf->__PVT___116_ = __Vfunc___03398__9__Vfuncout;
    __Vfunc___03401__10__s = (((7U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                             >> 0xdU))) 
                               << 7U) | (((6U == (7U 
                                                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                     >> 0xdU))) 
                                          << 6U) | 
                                         (((5U == (7U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                      >> 0xdU))) 
                                           << 5U) | 
                                          (((4U == 
                                             (7U & 
                                              ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 0xdU))) 
                                            << 4U) 
                                           | (((3U 
                                                == 
                                                (7U 
                                                 & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                    >> 0xdU))) 
                                               << 3U) 
                                              | (((2U 
                                                   == 
                                                   (7U 
                                                    & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                       >> 0xdU))) 
                                                  << 2U) 
                                                 | (((1U 
                                                      == 
                                                      (7U 
                                                       & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                          >> 0xdU))) 
                                                     << 1U) 
                                                    | (0U 
                                                       == 
                                                       (7U 
                                                        & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                           >> 0xdU))))))))));
    __Vfunc___03401__10__Vfuncout = (1U & ((~ (((((
                                                   (((1U 
                                                      == 
                                                      (1U 
                                                       & (IData)(__Vfunc___03401__10__s))) 
                                                     | (2U 
                                                        == 
                                                        (2U 
                                                         & (IData)(__Vfunc___03401__10__s)))) 
                                                    | (4U 
                                                       == 
                                                       (4U 
                                                        & (IData)(__Vfunc___03401__10__s)))) 
                                                   | (8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03401__10__s)))) 
                                                  | (0x10U 
                                                     == 
                                                     (0x10U 
                                                      & (IData)(__Vfunc___03401__10__s)))) 
                                                 | (0x20U 
                                                    == 
                                                    (0x20U 
                                                     & (IData)(__Vfunc___03401__10__s)))) 
                                                | (0x40U 
                                                   == 
                                                   (0x40U 
                                                    & (IData)(__Vfunc___03401__10__s)))) 
                                               | (0x80U 
                                                  == 
                                                  (0x80U 
                                                   & (IData)(__Vfunc___03401__10__s))))) 
                                           | ((1U == 
                                               (1U 
                                                & (IData)(__Vfunc___03401__10__s))) 
                                              | ((2U 
                                                  == 
                                                  (2U 
                                                   & (IData)(__Vfunc___03401__10__s))) 
                                                 | ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03401__10__s))) 
                                                    | ((8U 
                                                        == 
                                                        (8U 
                                                         & (IData)(__Vfunc___03401__10__s))) 
                                                       | ((0x10U 
                                                           == 
                                                           (0x10U 
                                                            & (IData)(__Vfunc___03401__10__s))) 
                                                          | ((0x20U 
                                                              == 
                                                              (0x20U 
                                                               & (IData)(__Vfunc___03401__10__s))) 
                                                             | (0x40U 
                                                                != 
                                                                (0x40U 
                                                                 & (IData)(__Vfunc___03401__10__s)))))))))));
    vlSelf->__PVT___117_ = __Vfunc___03401__10__Vfuncout;
    __Vfunc___03404__11__s = (((7U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                             >> 0xdU))) 
                               << 7U) | (((6U == (7U 
                                                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                     >> 0xdU))) 
                                          << 6U) | 
                                         (((5U == (7U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                      >> 0xdU))) 
                                           << 5U) | 
                                          (((4U == 
                                             (7U & 
                                              ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 0xdU))) 
                                            << 4U) 
                                           | (((3U 
                                                == 
                                                (7U 
                                                 & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                    >> 0xdU))) 
                                               << 3U) 
                                              | (((2U 
                                                   == 
                                                   (7U 
                                                    & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                       >> 0xdU))) 
                                                  << 2U) 
                                                 | (((1U 
                                                      == 
                                                      (7U 
                                                       & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                          >> 0xdU))) 
                                                     << 1U) 
                                                    | (0U 
                                                       == 
                                                       (7U 
                                                        & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                           >> 0xdU))))))))));
    __Vfunc___03404__11__Vfuncout = (1U & ((~ (((((
                                                   (((1U 
                                                      == 
                                                      (1U 
                                                       & (IData)(__Vfunc___03404__11__s))) 
                                                     | (2U 
                                                        == 
                                                        (2U 
                                                         & (IData)(__Vfunc___03404__11__s)))) 
                                                    | (4U 
                                                       == 
                                                       (4U 
                                                        & (IData)(__Vfunc___03404__11__s)))) 
                                                   | (8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03404__11__s)))) 
                                                  | (0x10U 
                                                     == 
                                                     (0x10U 
                                                      & (IData)(__Vfunc___03404__11__s)))) 
                                                 | (0x20U 
                                                    == 
                                                    (0x20U 
                                                     & (IData)(__Vfunc___03404__11__s)))) 
                                                | (0x40U 
                                                   == 
                                                   (0x40U 
                                                    & (IData)(__Vfunc___03404__11__s)))) 
                                               | (0x80U 
                                                  == 
                                                  (0x80U 
                                                   & (IData)(__Vfunc___03404__11__s))))) 
                                           | ((1U == 
                                               (1U 
                                                & (IData)(__Vfunc___03404__11__s))) 
                                              | ((2U 
                                                  == 
                                                  (2U 
                                                   & (IData)(__Vfunc___03404__11__s))) 
                                                 | ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03404__11__s))) 
                                                    | ((8U 
                                                        == 
                                                        (8U 
                                                         & (IData)(__Vfunc___03404__11__s))) 
                                                       | ((0x10U 
                                                           == 
                                                           (0x10U 
                                                            & (IData)(__Vfunc___03404__11__s))) 
                                                          | ((0x20U 
                                                              == 
                                                              (0x20U 
                                                               & (IData)(__Vfunc___03404__11__s))) 
                                                             | (0x40U 
                                                                == 
                                                                (0x40U 
                                                                 & (IData)(__Vfunc___03404__11__s)))))))))));
    vlSelf->__PVT___118_ = __Vfunc___03404__11__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___589_ = 
        (1U & ((~ ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                   >> 4U)) | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                              >> 6U)));
    __Vfunc_sdcard__DOT____032693__628__s = (((3U == (IData)(vlSelf->__PVT__sdcard__DOT___45_)) 
                                              << 3U) 
                                             | (((2U 
                                                  == (IData)(vlSelf->__PVT__sdcard__DOT___45_)) 
                                                 << 2U) 
                                                | (((1U 
                                                     == (IData)(vlSelf->__PVT__sdcard__DOT___45_)) 
                                                    << 1U) 
                                                   | (0U 
                                                      == (IData)(vlSelf->__PVT__sdcard__DOT___45_)))));
    __Vfunc_sdcard__DOT____032693__628__b = (2U | ((IData)(vlSelf->__PVT__sdcard__DOT___51_) 
                                                   << 3U));
    __Vfunc_sdcard__DOT____032693__628__Vfuncout = 
        (1U & ((8U & (IData)(__Vfunc_sdcard__DOT____032693__628__s))
                ? ((4U & (IData)(__Vfunc_sdcard__DOT____032693__628__s))
                    ? ((2U & (IData)(__Vfunc_sdcard__DOT____032693__628__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032693__628__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032693__628__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032693__628__b) 
                               >> 1U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032693__628__s))
                                           ? (IData)(__Vfunc_sdcard__DOT____032693__628__b)
                                           : ((IData)(__Vfunc_sdcard__DOT____032693__628__b) 
                                              >> 2U)))
                    : ((2U & (IData)(__Vfunc_sdcard__DOT____032693__628__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032693__628__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032693__628__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032693__628__b) 
                               >> 1U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032693__628__s))
                                           ? (IData)(__Vfunc_sdcard__DOT____032693__628__b)
                                           : ((IData)(__Vfunc_sdcard__DOT____032693__628__b) 
                                              >> 3U))))
                : ((4U & (IData)(__Vfunc_sdcard__DOT____032693__628__s))
                    ? ((2U & (IData)(__Vfunc_sdcard__DOT____032693__628__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032693__628__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032693__628__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032693__628__b) 
                               >> 1U)) : ((1U & (IData)(__Vfunc_sdcard__DOT____032693__628__s))
                                           ? (IData)(__Vfunc_sdcard__DOT____032693__628__b)
                                           : ((IData)(__Vfunc_sdcard__DOT____032693__628__b) 
                                              >> 2U)))
                    : ((2U & (IData)(__Vfunc_sdcard__DOT____032693__628__s))
                        ? ((1U & (IData)(__Vfunc_sdcard__DOT____032693__628__s))
                            ? (IData)(__Vfunc_sdcard__DOT____032693__628__b)
                            : ((IData)(__Vfunc_sdcard__DOT____032693__628__b) 
                               >> 1U)) : ((IData)(__Vfunc_sdcard__DOT____032693__628__s) 
                                          & (IData)(__Vfunc_sdcard__DOT____032693__628__b))))));
    vlSelf->__PVT__sdcard__DOT___21_ = __Vfunc_sdcard__DOT____032693__628__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___201_ = 
        ((6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
         & (3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___609_ = 
        (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
          & (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))) 
         | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___808_));
    __Vfunc___03405__12__s = (((7U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                             >> 0xdU))) 
                               << 7U) | (((6U == (7U 
                                                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                     >> 0xdU))) 
                                          << 6U) | 
                                         (((5U == (7U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                      >> 0xdU))) 
                                           << 5U) | 
                                          (((4U == 
                                             (7U & 
                                              ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 0xdU))) 
                                            << 4U) 
                                           | (((3U 
                                                == 
                                                (7U 
                                                 & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                    >> 0xdU))) 
                                               << 3U) 
                                              | (((2U 
                                                   == 
                                                   (7U 
                                                    & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                       >> 0xdU))) 
                                                  << 2U) 
                                                 | (((1U 
                                                      == 
                                                      (7U 
                                                       & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                          >> 0xdU))) 
                                                     << 1U) 
                                                    | (0U 
                                                       == 
                                                       (7U 
                                                        & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                           >> 0xdU))))))))));
    __Vfunc___03405__12__b = (((QData)((IData)((0x3fU 
                                                & ((0x7fU 
                                                    == 
                                                    (0x7fU 
                                                     & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                        >> 6U)))
                                                    ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)
                                                    : (IData)(vlSelf->__PVT___431_))))) 
                               << 0x2aU) | (0x3ffffffffffULL 
                                            & (((QData)((IData)(vlSelf->__PVT___431_)) 
                                                << 0x24U) 
                                               | (((QData)((IData)(vlSelf->__PVT___431_)) 
                                                   << 0x1eU) 
                                                  | (((QData)((IData)(vlSelf->__PVT___431_)) 
                                                      << 0x18U) 
                                                     | (((QData)((IData)(vlSelf->__PVT___431_)) 
                                                         << 0x12U) 
                                                        | (((QData)((IData)(vlSelf->__PVT___431_)) 
                                                            << 0xcU) 
                                                           | (((QData)((IData)(vlSelf->__PVT___431_)) 
                                                               << 6U) 
                                                              | (QData)((IData)(vlSelf->__PVT___431_))))))))));
    __Vfunc___03405__12__a = vlSelf->__PVT___431_;
    __Vfunc___03405__12__Vfuncout = (0x3fU & ((((((
                                                   (((1U 
                                                      == 
                                                      (1U 
                                                       & (IData)(__Vfunc___03405__12__s))) 
                                                     | (2U 
                                                        == 
                                                        (2U 
                                                         & (IData)(__Vfunc___03405__12__s)))) 
                                                    | (4U 
                                                       == 
                                                       (4U 
                                                        & (IData)(__Vfunc___03405__12__s)))) 
                                                   | (8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03405__12__s)))) 
                                                  | (0x10U 
                                                     == 
                                                     (0x10U 
                                                      & (IData)(__Vfunc___03405__12__s)))) 
                                                 | (0x20U 
                                                    == 
                                                    (0x20U 
                                                     & (IData)(__Vfunc___03405__12__s)))) 
                                                | (0x40U 
                                                   == 
                                                   (0x40U 
                                                    & (IData)(__Vfunc___03405__12__s)))) 
                                               | (0x80U 
                                                  == 
                                                  (0x80U 
                                                   & (IData)(__Vfunc___03405__12__s))))
                                               ? ((1U 
                                                   == 
                                                   (1U 
                                                    & (IData)(__Vfunc___03405__12__s)))
                                                   ? (IData)(__Vfunc___03405__12__b)
                                                   : 
                                                  ((2U 
                                                    == 
                                                    (2U 
                                                     & (IData)(__Vfunc___03405__12__s)))
                                                    ? (IData)(
                                                              (__Vfunc___03405__12__b 
                                                               >> 6U))
                                                    : 
                                                   ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03405__12__s)))
                                                     ? (IData)(
                                                               (__Vfunc___03405__12__b 
                                                                >> 0xcU))
                                                     : 
                                                    ((8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03405__12__s)))
                                                      ? (IData)(
                                                                (__Vfunc___03405__12__b 
                                                                 >> 0x12U))
                                                      : 
                                                     ((0x10U 
                                                       == 
                                                       (0x10U 
                                                        & (IData)(__Vfunc___03405__12__s)))
                                                       ? (IData)(
                                                                 (__Vfunc___03405__12__b 
                                                                  >> 0x18U))
                                                       : 
                                                      ((0x20U 
                                                        == 
                                                        (0x20U 
                                                         & (IData)(__Vfunc___03405__12__s)))
                                                        ? (IData)(
                                                                  (__Vfunc___03405__12__b 
                                                                   >> 0x1eU))
                                                        : 
                                                       ((0x40U 
                                                         == 
                                                         (0x40U 
                                                          & (IData)(__Vfunc___03405__12__s)))
                                                         ? (IData)(
                                                                   (__Vfunc___03405__12__b 
                                                                    >> 0x24U))
                                                         : (IData)(
                                                                   (__Vfunc___03405__12__b 
                                                                    >> 0x2aU)))))))))
                                               : (IData)(__Vfunc___03405__12__a)));
    vlSelf->__PVT___119_ = __Vfunc___03405__12__Vfuncout;
    __Vfunc_ym2149_audio_inst__DOT____031777__645__s 
        = (((2U == (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___053_)) 
            << 2U) | (((1U == (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___053_)) 
                       << 1U) | (0U == (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___053_))));
    __Vfunc_ym2149_audio_inst__DOT____031777__645__b 
        = (0xfffU & (((IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_) 
                      << 8U) | (((IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_) 
                                 << 4U) | (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_))));
    __Vfunc_ym2149_audio_inst__DOT____031777__645__a 
        = (0xfU & ((0U == (0xfU & ((IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_) 
                                   >> 4U))) ? (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___051_)
                    : (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)));
    __Vfunc_ym2149_audio_inst__DOT____031777__645__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_ym2149_audio_inst__DOT____031777__645__s)))
                    ? (IData)(__Vfunc_ym2149_audio_inst__DOT____031777__645__b)
                    : ((2U == (2U & (IData)(__Vfunc_ym2149_audio_inst__DOT____031777__645__s)))
                        ? ((IData)(__Vfunc_ym2149_audio_inst__DOT____031777__645__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_ym2149_audio_inst__DOT____031777__645__s)))
                                      ? ((IData)(__Vfunc_ym2149_audio_inst__DOT____031777__645__b) 
                                         >> 8U) : (IData)(__Vfunc_ym2149_audio_inst__DOT____031777__645__a)))));
    vlSelf->__PVT__ym2149_audio_inst__DOT___157_ = __Vfunc_ym2149_audio_inst__DOT____031777__645__Vfuncout;
    __Vfunc___03681__24__s = (((0xeU == (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                               << 0xcU) | (((0xbU == 
                                             (0xfU 
                                              & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                            << 0xbU) 
                                           | (((0xaU 
                                                == 
                                                (0xfU 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                               << 0xaU) 
                                              | (((9U 
                                                   == 
                                                   (0xfU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                  << 9U) 
                                                 | (((8U 
                                                      == 
                                                      (0xfU 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                     << 8U) 
                                                    | (((7U 
                                                         == 
                                                         (0xfU 
                                                          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                        << 7U) 
                                                       | (((6U 
                                                            == 
                                                            (0xfU 
                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                           << 6U) 
                                                          | (((5U 
                                                               == 
                                                               (0xfU 
                                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                              << 5U) 
                                                             | (((4U 
                                                                  == 
                                                                  (0xfU 
                                                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                 << 4U) 
                                                                | (((3U 
                                                                     == 
                                                                     (0xfU 
                                                                      & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                    << 3U) 
                                                                   | (((2U 
                                                                        == 
                                                                        (0xfU 
                                                                         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                       << 2U) 
                                                                      | (((1U 
                                                                           == 
                                                                           (0xfU 
                                                                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                          << 1U) 
                                                                         | (0U 
                                                                            == 
                                                                            (0xfU 
                                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))))))))))))));
    __Vfunc___03681__24__b = ((2U & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT___63_)) 
                                     << 1U)) | (1U 
                                                & (~ (IData)(vlSelf->__PVT__inst_t80__DOT___63_))));
    __Vfunc___03681__24__Vfuncout = (1U & (((((((((1U 
                                                   == 
                                                   (1U 
                                                    & (IData)(__Vfunc___03681__24__s))) 
                                                  | (2U 
                                                     == 
                                                     (2U 
                                                      & (IData)(__Vfunc___03681__24__s)))) 
                                                 | (4U 
                                                    == 
                                                    (4U 
                                                     & (IData)(__Vfunc___03681__24__s)))) 
                                                | (8U 
                                                   == 
                                                   (8U 
                                                    & (IData)(__Vfunc___03681__24__s)))) 
                                               | (0x10U 
                                                  == 
                                                  (0x10U 
                                                   & (IData)(__Vfunc___03681__24__s)))) 
                                              | (0x20U 
                                                 == 
                                                 (0x20U 
                                                  & (IData)(__Vfunc___03681__24__s)))) 
                                             | (0x40U 
                                                == 
                                                (0x40U 
                                                 & (IData)(__Vfunc___03681__24__s)))) 
                                            | (0x80U 
                                               == (0x80U 
                                                   & (IData)(__Vfunc___03681__24__s))))
                                            ? ((1U 
                                                == 
                                                (1U 
                                                 & (IData)(__Vfunc___03681__24__s)))
                                                ? (IData)(__Vfunc___03681__24__b)
                                                : (
                                                   (2U 
                                                    == 
                                                    (2U 
                                                     & (IData)(__Vfunc___03681__24__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03681__24__b) 
                                                    >> 1U)
                                                    : 
                                                   ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03681__24__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03681__24__b) 
                                                     >> 2U)
                                                     : 
                                                    ((8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03681__24__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03681__24__b) 
                                                      >> 3U)
                                                      : 
                                                     ((0x10U 
                                                       == 
                                                       (0x10U 
                                                        & (IData)(__Vfunc___03681__24__s)))
                                                       ? 
                                                      ((IData)(__Vfunc___03681__24__b) 
                                                       >> 4U)
                                                       : 
                                                      ((0x20U 
                                                        == 
                                                        (0x20U 
                                                         & (IData)(__Vfunc___03681__24__s)))
                                                        ? 
                                                       ((IData)(__Vfunc___03681__24__b) 
                                                        >> 5U)
                                                        : 
                                                       ((0x40U 
                                                         == 
                                                         (0x40U 
                                                          & (IData)(__Vfunc___03681__24__s)))
                                                         ? 
                                                        ((IData)(__Vfunc___03681__24__b) 
                                                         >> 6U)
                                                         : 
                                                        ((IData)(__Vfunc___03681__24__b) 
                                                         >> 7U))))))))
                                            : ((0x100U 
                                                == 
                                                (0x100U 
                                                 & (IData)(__Vfunc___03681__24__s)))
                                                ? ((IData)(__Vfunc___03681__24__b) 
                                                   >> 8U)
                                                : (
                                                   (0x200U 
                                                    == 
                                                    (0x200U 
                                                     & (IData)(__Vfunc___03681__24__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03681__24__b) 
                                                    >> 9U)
                                                    : 
                                                   ((0x400U 
                                                     == 
                                                     (0x400U 
                                                      & (IData)(__Vfunc___03681__24__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03681__24__b) 
                                                     >> 0xaU)
                                                     : 
                                                    ((0x800U 
                                                      == 
                                                      (0x800U 
                                                       & (IData)(__Vfunc___03681__24__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03681__24__b) 
                                                      >> 0xbU)
                                                      : (IData)(
                                                                (((IData)(__Vfunc___03681__24__s) 
                                                                  & (IData)(__Vfunc___03681__24__b)) 
                                                                 >> 0xcU))))))));
    vlSelf->__PVT___262_ = __Vfunc___03681__24__Vfuncout;
    __Vfunc___03683__25__s = (((0xeU == (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                               << 0xcU) | (((0xbU == 
                                             (0xfU 
                                              & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                            << 0xbU) 
                                           | (((0xaU 
                                                == 
                                                (0xfU 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                               << 0xaU) 
                                              | (((9U 
                                                   == 
                                                   (0xfU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                  << 9U) 
                                                 | (((8U 
                                                      == 
                                                      (0xfU 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                     << 8U) 
                                                    | (((7U 
                                                         == 
                                                         (0xfU 
                                                          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                        << 7U) 
                                                       | (((6U 
                                                            == 
                                                            (0xfU 
                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                           << 6U) 
                                                          | (((5U 
                                                               == 
                                                               (0xfU 
                                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                              << 5U) 
                                                             | (((4U 
                                                                  == 
                                                                  (0xfU 
                                                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                 << 4U) 
                                                                | (((3U 
                                                                     == 
                                                                     (0xfU 
                                                                      & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                    << 3U) 
                                                                   | (((2U 
                                                                        == 
                                                                        (0xfU 
                                                                         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                       << 2U) 
                                                                      | (((1U 
                                                                           == 
                                                                           (0xfU 
                                                                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                          << 1U) 
                                                                         | (0U 
                                                                            == 
                                                                            (0xfU 
                                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))))))))))))));
    __Vfunc___03683__25__b = ((4U & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT___61_)) 
                                     << 2U)) | (1U 
                                                & (~ (IData)(vlSelf->__PVT__inst_t80__DOT___63_))));
    __Vfunc___03683__25__Vfuncout = (1U & (((((((((1U 
                                                   == 
                                                   (1U 
                                                    & (IData)(__Vfunc___03683__25__s))) 
                                                  | (2U 
                                                     == 
                                                     (2U 
                                                      & (IData)(__Vfunc___03683__25__s)))) 
                                                 | (4U 
                                                    == 
                                                    (4U 
                                                     & (IData)(__Vfunc___03683__25__s)))) 
                                                | (8U 
                                                   == 
                                                   (8U 
                                                    & (IData)(__Vfunc___03683__25__s)))) 
                                               | (0x10U 
                                                  == 
                                                  (0x10U 
                                                   & (IData)(__Vfunc___03683__25__s)))) 
                                              | (0x20U 
                                                 == 
                                                 (0x20U 
                                                  & (IData)(__Vfunc___03683__25__s)))) 
                                             | (0x40U 
                                                == 
                                                (0x40U 
                                                 & (IData)(__Vfunc___03683__25__s)))) 
                                            | (0x80U 
                                               == (0x80U 
                                                   & (IData)(__Vfunc___03683__25__s))))
                                            ? ((1U 
                                                == 
                                                (1U 
                                                 & (IData)(__Vfunc___03683__25__s)))
                                                ? (IData)(__Vfunc___03683__25__b)
                                                : (
                                                   (2U 
                                                    == 
                                                    (2U 
                                                     & (IData)(__Vfunc___03683__25__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03683__25__b) 
                                                    >> 1U)
                                                    : 
                                                   ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03683__25__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03683__25__b) 
                                                     >> 2U)
                                                     : 
                                                    ((8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03683__25__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03683__25__b) 
                                                      >> 3U)
                                                      : 
                                                     ((0x10U 
                                                       == 
                                                       (0x10U 
                                                        & (IData)(__Vfunc___03683__25__s)))
                                                       ? 
                                                      ((IData)(__Vfunc___03683__25__b) 
                                                       >> 4U)
                                                       : 
                                                      ((0x20U 
                                                        == 
                                                        (0x20U 
                                                         & (IData)(__Vfunc___03683__25__s)))
                                                        ? 
                                                       ((IData)(__Vfunc___03683__25__b) 
                                                        >> 5U)
                                                        : 
                                                       ((0x40U 
                                                         == 
                                                         (0x40U 
                                                          & (IData)(__Vfunc___03683__25__s)))
                                                         ? 
                                                        ((IData)(__Vfunc___03683__25__b) 
                                                         >> 6U)
                                                         : 
                                                        ((IData)(__Vfunc___03683__25__b) 
                                                         >> 7U))))))))
                                            : ((0x100U 
                                                == 
                                                (0x100U 
                                                 & (IData)(__Vfunc___03683__25__s)))
                                                ? ((IData)(__Vfunc___03683__25__b) 
                                                   >> 8U)
                                                : (
                                                   (0x200U 
                                                    == 
                                                    (0x200U 
                                                     & (IData)(__Vfunc___03683__25__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03683__25__b) 
                                                    >> 9U)
                                                    : 
                                                   ((0x400U 
                                                     == 
                                                     (0x400U 
                                                      & (IData)(__Vfunc___03683__25__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03683__25__b) 
                                                     >> 0xaU)
                                                     : 
                                                    ((0x800U 
                                                      == 
                                                      (0x800U 
                                                       & (IData)(__Vfunc___03683__25__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03683__25__b) 
                                                      >> 0xbU)
                                                      : (IData)(
                                                                (((IData)(__Vfunc___03683__25__s) 
                                                                  & (IData)(__Vfunc___03683__25__b)) 
                                                                 >> 0xcU))))))));
    vlSelf->__PVT___263_ = __Vfunc___03683__25__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT___25_ = ((1U != (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
                                          | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___804_));
    __Vfunc_ym2149_audio_inst__DOT____031784__647__s 
        = (((2U == (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___053_)) 
            << 2U) | (((1U == (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___053_)) 
                       << 1U) | (0U == (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___053_))));
    __Vfunc_ym2149_audio_inst__DOT____031784__647__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_ym2149_audio_inst__DOT____031784__647__s))) 
           & (IData)((((IData)(__Vfunc_ym2149_audio_inst__DOT____031784__647__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_ym2149_audio_inst__DOT____031784__647__s))))));
    vlSelf->__PVT__ym2149_audio_inst__DOT___159_ = __Vfunc_ym2149_audio_inst__DOT____031784__647__Vfuncout;
    vlSelf->__PVT___039_ = ((IData)(vlSelf->__PVT___432_) 
                            | (IData)(vlSelf->__PVT___434_));
    vlSelf->__PVT__cache_n_pages_s = (0x1ffU & ((IData)(vlSelf->__PVT___432_)
                                                 ? 
                                                ((IData)(1U) 
                                                 + 
                                                 (1U 
                                                  | (0x7eU 
                                                     & ((IData)(vlSelf->__PVT___430_) 
                                                        << 1U))))
                                                 : 
                                                ((IData)(1U) 
                                                 + (IData)(vlSelf->__PVT___430_))));
    __Vfunc_ym2149_audio_inst__DOT____031780__646__s 
        = (((2U == (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___053_)) 
            << 2U) | (((1U == (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___053_)) 
                       << 1U) | (0U == (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___053_))));
    __Vfunc_ym2149_audio_inst__DOT____031780__646__Vfuncout 
        = (IData)((((IData)(__Vfunc_ym2149_audio_inst__DOT____031780__646__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_ym2149_audio_inst__DOT____031780__646__s)))));
    vlSelf->__PVT__ym2149_audio_inst__DOT___158_ = __Vfunc_ym2149_audio_inst__DOT____031780__646__Vfuncout;
    __Vfunc___03688__29__s = (((0xeU == (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                               << 0xcU) | (((0xbU == 
                                             (0xfU 
                                              & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                            << 0xbU) 
                                           | (((0xaU 
                                                == 
                                                (0xfU 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                               << 0xaU) 
                                              | (((9U 
                                                   == 
                                                   (0xfU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                  << 9U) 
                                                 | (((8U 
                                                      == 
                                                      (0xfU 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                     << 8U) 
                                                    | (((7U 
                                                         == 
                                                         (0xfU 
                                                          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                        << 7U) 
                                                       | (((6U 
                                                            == 
                                                            (0xfU 
                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                           << 6U) 
                                                          | (((5U 
                                                               == 
                                                               (0xfU 
                                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                              << 5U) 
                                                             | (((4U 
                                                                  == 
                                                                  (0xfU 
                                                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                 << 4U) 
                                                                | (((3U 
                                                                     == 
                                                                     (0xfU 
                                                                      & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                    << 3U) 
                                                                   | (((2U 
                                                                        == 
                                                                        (0xfU 
                                                                         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                       << 2U) 
                                                                      | (((1U 
                                                                           == 
                                                                           (0xfU 
                                                                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                          << 1U) 
                                                                         | (0U 
                                                                            == 
                                                                            (0xfU 
                                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))))))))))))));
    __Vfunc___03688__29__b = ((0x1fc0U & ((- (IData)((IData)(vlSelf->__PVT___415_))) 
                                          << 6U)) | 
                              ((((IData)(vlSelf->__PVT___415_) 
                                 & (IData)(vlSelf->__PVT__inst_t80__DOT___61_)) 
                                << 5U) | (0x1fU & (- (IData)((IData)(vlSelf->__PVT___415_))))));
    __Vfunc___03688__29__a = vlSelf->__PVT___415_;
    __Vfunc___03688__29__Vfuncout = (1U & (((((((((1U 
                                                   == 
                                                   (1U 
                                                    & (IData)(__Vfunc___03688__29__s))) 
                                                  | (2U 
                                                     == 
                                                     (2U 
                                                      & (IData)(__Vfunc___03688__29__s)))) 
                                                 | (4U 
                                                    == 
                                                    (4U 
                                                     & (IData)(__Vfunc___03688__29__s)))) 
                                                | (8U 
                                                   == 
                                                   (8U 
                                                    & (IData)(__Vfunc___03688__29__s)))) 
                                               | (0x10U 
                                                  == 
                                                  (0x10U 
                                                   & (IData)(__Vfunc___03688__29__s)))) 
                                              | (0x20U 
                                                 == 
                                                 (0x20U 
                                                  & (IData)(__Vfunc___03688__29__s)))) 
                                             | (0x40U 
                                                == 
                                                (0x40U 
                                                 & (IData)(__Vfunc___03688__29__s)))) 
                                            | (0x80U 
                                               == (0x80U 
                                                   & (IData)(__Vfunc___03688__29__s))))
                                            ? ((1U 
                                                == 
                                                (1U 
                                                 & (IData)(__Vfunc___03688__29__s)))
                                                ? (IData)(__Vfunc___03688__29__b)
                                                : (
                                                   (2U 
                                                    == 
                                                    (2U 
                                                     & (IData)(__Vfunc___03688__29__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03688__29__b) 
                                                    >> 1U)
                                                    : 
                                                   ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03688__29__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03688__29__b) 
                                                     >> 2U)
                                                     : 
                                                    ((8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03688__29__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03688__29__b) 
                                                      >> 3U)
                                                      : 
                                                     ((0x10U 
                                                       == 
                                                       (0x10U 
                                                        & (IData)(__Vfunc___03688__29__s)))
                                                       ? 
                                                      ((IData)(__Vfunc___03688__29__b) 
                                                       >> 4U)
                                                       : 
                                                      ((0x20U 
                                                        == 
                                                        (0x20U 
                                                         & (IData)(__Vfunc___03688__29__s)))
                                                        ? 
                                                       ((IData)(__Vfunc___03688__29__b) 
                                                        >> 5U)
                                                        : 
                                                       ((0x40U 
                                                         == 
                                                         (0x40U 
                                                          & (IData)(__Vfunc___03688__29__s)))
                                                         ? 
                                                        ((IData)(__Vfunc___03688__29__b) 
                                                         >> 6U)
                                                         : 
                                                        ((IData)(__Vfunc___03688__29__b) 
                                                         >> 7U))))))))
                                            : ((0x100U 
                                                == 
                                                (0x100U 
                                                 & (IData)(__Vfunc___03688__29__s)))
                                                ? ((IData)(__Vfunc___03688__29__b) 
                                                   >> 8U)
                                                : (
                                                   (0x200U 
                                                    == 
                                                    (0x200U 
                                                     & (IData)(__Vfunc___03688__29__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03688__29__b) 
                                                    >> 9U)
                                                    : 
                                                   ((0x400U 
                                                     == 
                                                     (0x400U 
                                                      & (IData)(__Vfunc___03688__29__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03688__29__b) 
                                                     >> 0xaU)
                                                     : 
                                                    ((0x800U 
                                                      == 
                                                      (0x800U 
                                                       & (IData)(__Vfunc___03688__29__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03688__29__b) 
                                                      >> 0xbU)
                                                      : 
                                                     ((0x1000U 
                                                       == 
                                                       (0x1000U 
                                                        & (IData)(__Vfunc___03688__29__s)))
                                                       ? 
                                                      ((IData)(__Vfunc___03688__29__b) 
                                                       >> 0xcU)
                                                       : (IData)(__Vfunc___03688__29__a))))))));
    vlSelf->__PVT___268_ = __Vfunc___03688__29__Vfuncout;
    __Vfunc___03684__26__s = (((0xeU == (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                               << 0xcU) | (((0xbU == 
                                             (0xfU 
                                              & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                            << 0xbU) 
                                           | (((0xaU 
                                                == 
                                                (0xfU 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                               << 0xaU) 
                                              | (((9U 
                                                   == 
                                                   (0xfU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                  << 9U) 
                                                 | (((8U 
                                                      == 
                                                      (0xfU 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                     << 8U) 
                                                    | (((7U 
                                                         == 
                                                         (0xfU 
                                                          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                        << 7U) 
                                                       | (((6U 
                                                            == 
                                                            (0xfU 
                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                           << 6U) 
                                                          | (((5U 
                                                               == 
                                                               (0xfU 
                                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                              << 5U) 
                                                             | (((4U 
                                                                  == 
                                                                  (0xfU 
                                                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                 << 4U) 
                                                                | (((3U 
                                                                     == 
                                                                     (0xfU 
                                                                      & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                    << 3U) 
                                                                   | (((2U 
                                                                        == 
                                                                        (0xfU 
                                                                         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                       << 2U) 
                                                                      | (((1U 
                                                                           == 
                                                                           (0xfU 
                                                                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                          << 1U) 
                                                                         | (0U 
                                                                            == 
                                                                            (0xfU 
                                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))))))))))))));
    __Vfunc___03684__26__b = ((0x1ff0U & ((- (IData)((IData)(vlSelf->__PVT___412_))) 
                                          << 4U)) | 
                              ((8U & (((IData)(vlSelf->__PVT__inst_t80__DOT___63_)
                                        ? (IData)(vlSelf->__PVT___412_)
                                        : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_)) 
                                      << 3U)) | (7U 
                                                 & (- (IData)((IData)(vlSelf->__PVT___412_))))));
    __Vfunc___03684__26__a = vlSelf->__PVT___412_;
    __Vfunc___03684__26__Vfuncout = (1U & (((((((((1U 
                                                   == 
                                                   (1U 
                                                    & (IData)(__Vfunc___03684__26__s))) 
                                                  | (2U 
                                                     == 
                                                     (2U 
                                                      & (IData)(__Vfunc___03684__26__s)))) 
                                                 | (4U 
                                                    == 
                                                    (4U 
                                                     & (IData)(__Vfunc___03684__26__s)))) 
                                                | (8U 
                                                   == 
                                                   (8U 
                                                    & (IData)(__Vfunc___03684__26__s)))) 
                                               | (0x10U 
                                                  == 
                                                  (0x10U 
                                                   & (IData)(__Vfunc___03684__26__s)))) 
                                              | (0x20U 
                                                 == 
                                                 (0x20U 
                                                  & (IData)(__Vfunc___03684__26__s)))) 
                                             | (0x40U 
                                                == 
                                                (0x40U 
                                                 & (IData)(__Vfunc___03684__26__s)))) 
                                            | (0x80U 
                                               == (0x80U 
                                                   & (IData)(__Vfunc___03684__26__s))))
                                            ? ((1U 
                                                == 
                                                (1U 
                                                 & (IData)(__Vfunc___03684__26__s)))
                                                ? (IData)(__Vfunc___03684__26__b)
                                                : (
                                                   (2U 
                                                    == 
                                                    (2U 
                                                     & (IData)(__Vfunc___03684__26__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03684__26__b) 
                                                    >> 1U)
                                                    : 
                                                   ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03684__26__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03684__26__b) 
                                                     >> 2U)
                                                     : 
                                                    ((8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03684__26__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03684__26__b) 
                                                      >> 3U)
                                                      : 
                                                     ((0x10U 
                                                       == 
                                                       (0x10U 
                                                        & (IData)(__Vfunc___03684__26__s)))
                                                       ? 
                                                      ((IData)(__Vfunc___03684__26__b) 
                                                       >> 4U)
                                                       : 
                                                      ((0x20U 
                                                        == 
                                                        (0x20U 
                                                         & (IData)(__Vfunc___03684__26__s)))
                                                        ? 
                                                       ((IData)(__Vfunc___03684__26__b) 
                                                        >> 5U)
                                                        : 
                                                       ((0x40U 
                                                         == 
                                                         (0x40U 
                                                          & (IData)(__Vfunc___03684__26__s)))
                                                         ? 
                                                        ((IData)(__Vfunc___03684__26__b) 
                                                         >> 6U)
                                                         : 
                                                        ((IData)(__Vfunc___03684__26__b) 
                                                         >> 7U))))))))
                                            : ((0x100U 
                                                == 
                                                (0x100U 
                                                 & (IData)(__Vfunc___03684__26__s)))
                                                ? ((IData)(__Vfunc___03684__26__b) 
                                                   >> 8U)
                                                : (
                                                   (0x200U 
                                                    == 
                                                    (0x200U 
                                                     & (IData)(__Vfunc___03684__26__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03684__26__b) 
                                                    >> 9U)
                                                    : 
                                                   ((0x400U 
                                                     == 
                                                     (0x400U 
                                                      & (IData)(__Vfunc___03684__26__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03684__26__b) 
                                                     >> 0xaU)
                                                     : 
                                                    ((0x800U 
                                                      == 
                                                      (0x800U 
                                                       & (IData)(__Vfunc___03684__26__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03684__26__b) 
                                                      >> 0xbU)
                                                      : 
                                                     ((0x1000U 
                                                       == 
                                                       (0x1000U 
                                                        & (IData)(__Vfunc___03684__26__s)))
                                                       ? 
                                                      ((IData)(__Vfunc___03684__26__b) 
                                                       >> 0xcU)
                                                       : (IData)(__Vfunc___03684__26__a))))))));
    vlSelf->__PVT___264_ = __Vfunc___03684__26__Vfuncout;
    __Vfunc___03692__31__s = (((0xeU == (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                               << 0xcU) | (((0xbU == 
                                             (0xfU 
                                              & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                            << 0xbU) 
                                           | (((0xaU 
                                                == 
                                                (0xfU 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                               << 0xaU) 
                                              | (((9U 
                                                   == 
                                                   (0xfU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                  << 9U) 
                                                 | (((8U 
                                                      == 
                                                      (0xfU 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                     << 8U) 
                                                    | (((7U 
                                                         == 
                                                         (0xfU 
                                                          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                        << 7U) 
                                                       | (((6U 
                                                            == 
                                                            (0xfU 
                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                           << 6U) 
                                                          | (((5U 
                                                               == 
                                                               (0xfU 
                                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                              << 5U) 
                                                             | (((4U 
                                                                  == 
                                                                  (0xfU 
                                                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                 << 4U) 
                                                                | (((3U 
                                                                     == 
                                                                     (0xfU 
                                                                      & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                    << 3U) 
                                                                   | (((2U 
                                                                        == 
                                                                        (0xfU 
                                                                         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                       << 2U) 
                                                                      | (((1U 
                                                                           == 
                                                                           (0xfU 
                                                                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                          << 1U) 
                                                                         | (0U 
                                                                            == 
                                                                            (0xfU 
                                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))))))))))))));
    __Vfunc___03692__31__b = ((0x1f80U & ((- (IData)((IData)(vlSelf->__PVT___417_))) 
                                          << 7U)) | 
                              ((0x40U & (((IData)(vlSelf->__PVT__inst_t80__DOT___63_)
                                           ? (IData)(vlSelf->__PVT___417_)
                                           : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_) 
                                              >> 1U)) 
                                         << 6U)) | 
                               (0x3fU & (- (IData)((IData)(vlSelf->__PVT___417_))))));
    __Vfunc___03692__31__a = vlSelf->__PVT___417_;
    __Vfunc___03692__31__Vfuncout = (1U & (((((((((1U 
                                                   == 
                                                   (1U 
                                                    & (IData)(__Vfunc___03692__31__s))) 
                                                  | (2U 
                                                     == 
                                                     (2U 
                                                      & (IData)(__Vfunc___03692__31__s)))) 
                                                 | (4U 
                                                    == 
                                                    (4U 
                                                     & (IData)(__Vfunc___03692__31__s)))) 
                                                | (8U 
                                                   == 
                                                   (8U 
                                                    & (IData)(__Vfunc___03692__31__s)))) 
                                               | (0x10U 
                                                  == 
                                                  (0x10U 
                                                   & (IData)(__Vfunc___03692__31__s)))) 
                                              | (0x20U 
                                                 == 
                                                 (0x20U 
                                                  & (IData)(__Vfunc___03692__31__s)))) 
                                             | (0x40U 
                                                == 
                                                (0x40U 
                                                 & (IData)(__Vfunc___03692__31__s)))) 
                                            | (0x80U 
                                               == (0x80U 
                                                   & (IData)(__Vfunc___03692__31__s))))
                                            ? ((1U 
                                                == 
                                                (1U 
                                                 & (IData)(__Vfunc___03692__31__s)))
                                                ? (IData)(__Vfunc___03692__31__b)
                                                : (
                                                   (2U 
                                                    == 
                                                    (2U 
                                                     & (IData)(__Vfunc___03692__31__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03692__31__b) 
                                                    >> 1U)
                                                    : 
                                                   ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03692__31__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03692__31__b) 
                                                     >> 2U)
                                                     : 
                                                    ((8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03692__31__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03692__31__b) 
                                                      >> 3U)
                                                      : 
                                                     ((0x10U 
                                                       == 
                                                       (0x10U 
                                                        & (IData)(__Vfunc___03692__31__s)))
                                                       ? 
                                                      ((IData)(__Vfunc___03692__31__b) 
                                                       >> 4U)
                                                       : 
                                                      ((0x20U 
                                                        == 
                                                        (0x20U 
                                                         & (IData)(__Vfunc___03692__31__s)))
                                                        ? 
                                                       ((IData)(__Vfunc___03692__31__b) 
                                                        >> 5U)
                                                        : 
                                                       ((0x40U 
                                                         == 
                                                         (0x40U 
                                                          & (IData)(__Vfunc___03692__31__s)))
                                                         ? 
                                                        ((IData)(__Vfunc___03692__31__b) 
                                                         >> 6U)
                                                         : 
                                                        ((IData)(__Vfunc___03692__31__b) 
                                                         >> 7U))))))))
                                            : ((0x100U 
                                                == 
                                                (0x100U 
                                                 & (IData)(__Vfunc___03692__31__s)))
                                                ? ((IData)(__Vfunc___03692__31__b) 
                                                   >> 8U)
                                                : (
                                                   (0x200U 
                                                    == 
                                                    (0x200U 
                                                     & (IData)(__Vfunc___03692__31__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03692__31__b) 
                                                    >> 9U)
                                                    : 
                                                   ((0x400U 
                                                     == 
                                                     (0x400U 
                                                      & (IData)(__Vfunc___03692__31__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03692__31__b) 
                                                     >> 0xaU)
                                                     : 
                                                    ((0x800U 
                                                      == 
                                                      (0x800U 
                                                       & (IData)(__Vfunc___03692__31__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03692__31__b) 
                                                      >> 0xbU)
                                                      : 
                                                     ((0x1000U 
                                                       == 
                                                       (0x1000U 
                                                        & (IData)(__Vfunc___03692__31__s)))
                                                       ? 
                                                      ((IData)(__Vfunc___03692__31__b) 
                                                       >> 0xcU)
                                                       : (IData)(__Vfunc___03692__31__a))))))));
    vlSelf->__PVT___270_ = __Vfunc___03692__31__Vfuncout;
    __Vfunc___03693__32__s = (((0xeU == (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                               << 0xcU) | (((0xbU == 
                                             (0xfU 
                                              & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                            << 0xbU) 
                                           | (((0xaU 
                                                == 
                                                (0xfU 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                               << 0xaU) 
                                              | (((9U 
                                                   == 
                                                   (0xfU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                  << 9U) 
                                                 | (((8U 
                                                      == 
                                                      (0xfU 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                     << 8U) 
                                                    | (((7U 
                                                         == 
                                                         (0xfU 
                                                          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                        << 7U) 
                                                       | (((6U 
                                                            == 
                                                            (0xfU 
                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                           << 6U) 
                                                          | (((5U 
                                                               == 
                                                               (0xfU 
                                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                              << 5U) 
                                                             | (((4U 
                                                                  == 
                                                                  (0xfU 
                                                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                 << 4U) 
                                                                | (((3U 
                                                                     == 
                                                                     (0xfU 
                                                                      & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                    << 3U) 
                                                                   | (((2U 
                                                                        == 
                                                                        (0xfU 
                                                                         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                       << 2U) 
                                                                      | (((1U 
                                                                           == 
                                                                           (0xfU 
                                                                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                          << 1U) 
                                                                         | (0U 
                                                                            == 
                                                                            (0xfU 
                                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))))))))))))));
    __Vfunc___03693__32__b = ((0x1f80U & ((- (IData)((IData)(vlSelf->__PVT___418_))) 
                                          << 7U)) | 
                              ((0x40U & (((IData)(vlSelf->__PVT__inst_t80__DOT___63_)
                                           ? (IData)(vlSelf->__PVT___418_)
                                           : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_)) 
                                         << 6U)) | 
                               (0x3fU & (- (IData)((IData)(vlSelf->__PVT___418_))))));
    __Vfunc___03693__32__a = vlSelf->__PVT___418_;
    __Vfunc___03693__32__Vfuncout = (1U & (((((((((1U 
                                                   == 
                                                   (1U 
                                                    & (IData)(__Vfunc___03693__32__s))) 
                                                  | (2U 
                                                     == 
                                                     (2U 
                                                      & (IData)(__Vfunc___03693__32__s)))) 
                                                 | (4U 
                                                    == 
                                                    (4U 
                                                     & (IData)(__Vfunc___03693__32__s)))) 
                                                | (8U 
                                                   == 
                                                   (8U 
                                                    & (IData)(__Vfunc___03693__32__s)))) 
                                               | (0x10U 
                                                  == 
                                                  (0x10U 
                                                   & (IData)(__Vfunc___03693__32__s)))) 
                                              | (0x20U 
                                                 == 
                                                 (0x20U 
                                                  & (IData)(__Vfunc___03693__32__s)))) 
                                             | (0x40U 
                                                == 
                                                (0x40U 
                                                 & (IData)(__Vfunc___03693__32__s)))) 
                                            | (0x80U 
                                               == (0x80U 
                                                   & (IData)(__Vfunc___03693__32__s))))
                                            ? ((1U 
                                                == 
                                                (1U 
                                                 & (IData)(__Vfunc___03693__32__s)))
                                                ? (IData)(__Vfunc___03693__32__b)
                                                : (
                                                   (2U 
                                                    == 
                                                    (2U 
                                                     & (IData)(__Vfunc___03693__32__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03693__32__b) 
                                                    >> 1U)
                                                    : 
                                                   ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03693__32__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03693__32__b) 
                                                     >> 2U)
                                                     : 
                                                    ((8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03693__32__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03693__32__b) 
                                                      >> 3U)
                                                      : 
                                                     ((0x10U 
                                                       == 
                                                       (0x10U 
                                                        & (IData)(__Vfunc___03693__32__s)))
                                                       ? 
                                                      ((IData)(__Vfunc___03693__32__b) 
                                                       >> 4U)
                                                       : 
                                                      ((0x20U 
                                                        == 
                                                        (0x20U 
                                                         & (IData)(__Vfunc___03693__32__s)))
                                                        ? 
                                                       ((IData)(__Vfunc___03693__32__b) 
                                                        >> 5U)
                                                        : 
                                                       ((0x40U 
                                                         == 
                                                         (0x40U 
                                                          & (IData)(__Vfunc___03693__32__s)))
                                                         ? 
                                                        ((IData)(__Vfunc___03693__32__b) 
                                                         >> 6U)
                                                         : 
                                                        ((IData)(__Vfunc___03693__32__b) 
                                                         >> 7U))))))))
                                            : ((0x100U 
                                                == 
                                                (0x100U 
                                                 & (IData)(__Vfunc___03693__32__s)))
                                                ? ((IData)(__Vfunc___03693__32__b) 
                                                   >> 8U)
                                                : (
                                                   (0x200U 
                                                    == 
                                                    (0x200U 
                                                     & (IData)(__Vfunc___03693__32__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03693__32__b) 
                                                    >> 9U)
                                                    : 
                                                   ((0x400U 
                                                     == 
                                                     (0x400U 
                                                      & (IData)(__Vfunc___03693__32__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03693__32__b) 
                                                     >> 0xaU)
                                                     : 
                                                    ((0x800U 
                                                      == 
                                                      (0x800U 
                                                       & (IData)(__Vfunc___03693__32__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03693__32__b) 
                                                      >> 0xbU)
                                                      : 
                                                     ((0x1000U 
                                                       == 
                                                       (0x1000U 
                                                        & (IData)(__Vfunc___03693__32__s)))
                                                       ? 
                                                      ((IData)(__Vfunc___03693__32__b) 
                                                       >> 0xcU)
                                                       : (IData)(__Vfunc___03693__32__a))))))));
    vlSelf->__PVT___271_ = __Vfunc___03693__32__Vfuncout;
    __Vfunc___03694__33__s = (((0xeU == (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                               << 0xcU) | (((0xbU == 
                                             (0xfU 
                                              & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                            << 0xbU) 
                                           | (((0xaU 
                                                == 
                                                (0xfU 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                               << 0xaU) 
                                              | (((9U 
                                                   == 
                                                   (0xfU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                  << 9U) 
                                                 | (((8U 
                                                      == 
                                                      (0xfU 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                     << 8U) 
                                                    | (((7U 
                                                         == 
                                                         (0xfU 
                                                          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                        << 7U) 
                                                       | (((6U 
                                                            == 
                                                            (0xfU 
                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                           << 6U) 
                                                          | (((5U 
                                                               == 
                                                               (0xfU 
                                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                              << 5U) 
                                                             | (((4U 
                                                                  == 
                                                                  (0xfU 
                                                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                 << 4U) 
                                                                | (((3U 
                                                                     == 
                                                                     (0xfU 
                                                                      & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                    << 3U) 
                                                                   | (((2U 
                                                                        == 
                                                                        (0xfU 
                                                                         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                       << 2U) 
                                                                      | (((1U 
                                                                           == 
                                                                           (0xfU 
                                                                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                          << 1U) 
                                                                         | (0U 
                                                                            == 
                                                                            (0xfU 
                                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))))))))))))));
    __Vfunc___03694__33__b = ((0x1ff0U & ((- (IData)((IData)(vlSelf->__PVT___427_))) 
                                          << 4U)) | 
                              ((8U & (((IData)(vlSelf->__PVT__inst_t80__DOT___63_)
                                        ? (IData)(vlSelf->__PVT___427_)
                                        : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_) 
                                           >> 2U)) 
                                      << 3U)) | (7U 
                                                 & (- (IData)((IData)(vlSelf->__PVT___427_))))));
    __Vfunc___03694__33__a = vlSelf->__PVT___427_;
    __Vfunc___03694__33__Vfuncout = (1U & (((((((((1U 
                                                   == 
                                                   (1U 
                                                    & (IData)(__Vfunc___03694__33__s))) 
                                                  | (2U 
                                                     == 
                                                     (2U 
                                                      & (IData)(__Vfunc___03694__33__s)))) 
                                                 | (4U 
                                                    == 
                                                    (4U 
                                                     & (IData)(__Vfunc___03694__33__s)))) 
                                                | (8U 
                                                   == 
                                                   (8U 
                                                    & (IData)(__Vfunc___03694__33__s)))) 
                                               | (0x10U 
                                                  == 
                                                  (0x10U 
                                                   & (IData)(__Vfunc___03694__33__s)))) 
                                              | (0x20U 
                                                 == 
                                                 (0x20U 
                                                  & (IData)(__Vfunc___03694__33__s)))) 
                                             | (0x40U 
                                                == 
                                                (0x40U 
                                                 & (IData)(__Vfunc___03694__33__s)))) 
                                            | (0x80U 
                                               == (0x80U 
                                                   & (IData)(__Vfunc___03694__33__s))))
                                            ? ((1U 
                                                == 
                                                (1U 
                                                 & (IData)(__Vfunc___03694__33__s)))
                                                ? (IData)(__Vfunc___03694__33__b)
                                                : (
                                                   (2U 
                                                    == 
                                                    (2U 
                                                     & (IData)(__Vfunc___03694__33__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03694__33__b) 
                                                    >> 1U)
                                                    : 
                                                   ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03694__33__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03694__33__b) 
                                                     >> 2U)
                                                     : 
                                                    ((8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03694__33__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03694__33__b) 
                                                      >> 3U)
                                                      : 
                                                     ((0x10U 
                                                       == 
                                                       (0x10U 
                                                        & (IData)(__Vfunc___03694__33__s)))
                                                       ? 
                                                      ((IData)(__Vfunc___03694__33__b) 
                                                       >> 4U)
                                                       : 
                                                      ((0x20U 
                                                        == 
                                                        (0x20U 
                                                         & (IData)(__Vfunc___03694__33__s)))
                                                        ? 
                                                       ((IData)(__Vfunc___03694__33__b) 
                                                        >> 5U)
                                                        : 
                                                       ((0x40U 
                                                         == 
                                                         (0x40U 
                                                          & (IData)(__Vfunc___03694__33__s)))
                                                         ? 
                                                        ((IData)(__Vfunc___03694__33__b) 
                                                         >> 6U)
                                                         : 
                                                        ((IData)(__Vfunc___03694__33__b) 
                                                         >> 7U))))))))
                                            : ((0x100U 
                                                == 
                                                (0x100U 
                                                 & (IData)(__Vfunc___03694__33__s)))
                                                ? ((IData)(__Vfunc___03694__33__b) 
                                                   >> 8U)
                                                : (
                                                   (0x200U 
                                                    == 
                                                    (0x200U 
                                                     & (IData)(__Vfunc___03694__33__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03694__33__b) 
                                                    >> 9U)
                                                    : 
                                                   ((0x400U 
                                                     == 
                                                     (0x400U 
                                                      & (IData)(__Vfunc___03694__33__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03694__33__b) 
                                                     >> 0xaU)
                                                     : 
                                                    ((0x800U 
                                                      == 
                                                      (0x800U 
                                                       & (IData)(__Vfunc___03694__33__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03694__33__b) 
                                                      >> 0xbU)
                                                      : 
                                                     ((0x1000U 
                                                       == 
                                                       (0x1000U 
                                                        & (IData)(__Vfunc___03694__33__s)))
                                                       ? 
                                                      ((IData)(__Vfunc___03694__33__b) 
                                                       >> 0xcU)
                                                       : (IData)(__Vfunc___03694__33__a))))))));
    vlSelf->__PVT___272_ = __Vfunc___03694__33__Vfuncout;
    __Vfunc___03695__34__s = (((0xeU == (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                               << 0xcU) | (((0xbU == 
                                             (0xfU 
                                              & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                            << 0xbU) 
                                           | (((0xaU 
                                                == 
                                                (0xfU 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                               << 0xaU) 
                                              | (((9U 
                                                   == 
                                                   (0xfU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                  << 9U) 
                                                 | (((8U 
                                                      == 
                                                      (0xfU 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                     << 8U) 
                                                    | (((7U 
                                                         == 
                                                         (0xfU 
                                                          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                        << 7U) 
                                                       | (((6U 
                                                            == 
                                                            (0xfU 
                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                           << 6U) 
                                                          | (((5U 
                                                               == 
                                                               (0xfU 
                                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                              << 5U) 
                                                             | (((4U 
                                                                  == 
                                                                  (0xfU 
                                                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                 << 4U) 
                                                                | (((3U 
                                                                     == 
                                                                     (0xfU 
                                                                      & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                    << 3U) 
                                                                   | (((2U 
                                                                        == 
                                                                        (0xfU 
                                                                         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                       << 2U) 
                                                                      | (((1U 
                                                                           == 
                                                                           (0xfU 
                                                                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                          << 1U) 
                                                                         | (0U 
                                                                            == 
                                                                            (0xfU 
                                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))))))))))))));
    __Vfunc___03695__34__b = ((0x1fc0U & ((- (IData)((IData)(vlSelf->__PVT___428_))) 
                                          << 6U)) | 
                              ((0x20U & (((IData)(vlSelf->__PVT__inst_t80__DOT___63_)
                                           ? (IData)(vlSelf->__PVT___428_)
                                           : (~ (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_) 
                                                  >> 1U) 
                                                 | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_)))) 
                                         << 5U)) | 
                               (0x1fU & (- (IData)((IData)(vlSelf->__PVT___428_))))));
    __Vfunc___03695__34__a = vlSelf->__PVT___428_;
    __Vfunc___03695__34__Vfuncout = (1U & (((((((((1U 
                                                   == 
                                                   (1U 
                                                    & (IData)(__Vfunc___03695__34__s))) 
                                                  | (2U 
                                                     == 
                                                     (2U 
                                                      & (IData)(__Vfunc___03695__34__s)))) 
                                                 | (4U 
                                                    == 
                                                    (4U 
                                                     & (IData)(__Vfunc___03695__34__s)))) 
                                                | (8U 
                                                   == 
                                                   (8U 
                                                    & (IData)(__Vfunc___03695__34__s)))) 
                                               | (0x10U 
                                                  == 
                                                  (0x10U 
                                                   & (IData)(__Vfunc___03695__34__s)))) 
                                              | (0x20U 
                                                 == 
                                                 (0x20U 
                                                  & (IData)(__Vfunc___03695__34__s)))) 
                                             | (0x40U 
                                                == 
                                                (0x40U 
                                                 & (IData)(__Vfunc___03695__34__s)))) 
                                            | (0x80U 
                                               == (0x80U 
                                                   & (IData)(__Vfunc___03695__34__s))))
                                            ? ((1U 
                                                == 
                                                (1U 
                                                 & (IData)(__Vfunc___03695__34__s)))
                                                ? (IData)(__Vfunc___03695__34__b)
                                                : (
                                                   (2U 
                                                    == 
                                                    (2U 
                                                     & (IData)(__Vfunc___03695__34__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03695__34__b) 
                                                    >> 1U)
                                                    : 
                                                   ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03695__34__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03695__34__b) 
                                                     >> 2U)
                                                     : 
                                                    ((8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03695__34__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03695__34__b) 
                                                      >> 3U)
                                                      : 
                                                     ((0x10U 
                                                       == 
                                                       (0x10U 
                                                        & (IData)(__Vfunc___03695__34__s)))
                                                       ? 
                                                      ((IData)(__Vfunc___03695__34__b) 
                                                       >> 4U)
                                                       : 
                                                      ((0x20U 
                                                        == 
                                                        (0x20U 
                                                         & (IData)(__Vfunc___03695__34__s)))
                                                        ? 
                                                       ((IData)(__Vfunc___03695__34__b) 
                                                        >> 5U)
                                                        : 
                                                       ((0x40U 
                                                         == 
                                                         (0x40U 
                                                          & (IData)(__Vfunc___03695__34__s)))
                                                         ? 
                                                        ((IData)(__Vfunc___03695__34__b) 
                                                         >> 6U)
                                                         : 
                                                        ((IData)(__Vfunc___03695__34__b) 
                                                         >> 7U))))))))
                                            : ((0x100U 
                                                == 
                                                (0x100U 
                                                 & (IData)(__Vfunc___03695__34__s)))
                                                ? ((IData)(__Vfunc___03695__34__b) 
                                                   >> 8U)
                                                : (
                                                   (0x200U 
                                                    == 
                                                    (0x200U 
                                                     & (IData)(__Vfunc___03695__34__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03695__34__b) 
                                                    >> 9U)
                                                    : 
                                                   ((0x400U 
                                                     == 
                                                     (0x400U 
                                                      & (IData)(__Vfunc___03695__34__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03695__34__b) 
                                                     >> 0xaU)
                                                     : 
                                                    ((0x800U 
                                                      == 
                                                      (0x800U 
                                                       & (IData)(__Vfunc___03695__34__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03695__34__b) 
                                                      >> 0xbU)
                                                      : 
                                                     ((0x1000U 
                                                       == 
                                                       (0x1000U 
                                                        & (IData)(__Vfunc___03695__34__s)))
                                                       ? 
                                                      ((IData)(__Vfunc___03695__34__b) 
                                                       >> 0xcU)
                                                       : (IData)(__Vfunc___03695__34__a))))))));
    vlSelf->__PVT___273_ = __Vfunc___03695__34__Vfuncout;
    __Vfunc___03697__35__s = (((0xeU == (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                               << 0xcU) | (((0xbU == 
                                             (0xfU 
                                              & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                            << 0xbU) 
                                           | (((0xaU 
                                                == 
                                                (0xfU 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                               << 0xaU) 
                                              | (((9U 
                                                   == 
                                                   (0xfU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                  << 9U) 
                                                 | (((8U 
                                                      == 
                                                      (0xfU 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                     << 8U) 
                                                    | (((7U 
                                                         == 
                                                         (0xfU 
                                                          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                        << 7U) 
                                                       | (((6U 
                                                            == 
                                                            (0xfU 
                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                           << 6U) 
                                                          | (((5U 
                                                               == 
                                                               (0xfU 
                                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                              << 5U) 
                                                             | (((4U 
                                                                  == 
                                                                  (0xfU 
                                                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                 << 4U) 
                                                                | (((3U 
                                                                     == 
                                                                     (0xfU 
                                                                      & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                    << 3U) 
                                                                   | (((2U 
                                                                        == 
                                                                        (0xfU 
                                                                         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                       << 2U) 
                                                                      | (((1U 
                                                                           == 
                                                                           (0xfU 
                                                                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                          << 1U) 
                                                                         | (0U 
                                                                            == 
                                                                            (0xfU 
                                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))))))))))))));
    __Vfunc___03697__35__b = ((0x3fff000U & (((IData)(vlSelf->__PVT___429_) 
                                              << 0x18U) 
                                             | (((IData)(vlSelf->__PVT___429_) 
                                                 << 0x16U) 
                                                | (((IData)(vlSelf->__PVT___429_) 
                                                    << 0x14U) 
                                                   | (((IData)(vlSelf->__PVT___429_) 
                                                       << 0x12U) 
                                                      | (((IData)(vlSelf->__PVT___429_) 
                                                          << 0x10U) 
                                                         | (((IData)(vlSelf->__PVT___429_) 
                                                             << 0xeU) 
                                                            | ((IData)(vlSelf->__PVT___429_) 
                                                               << 0xcU)))))))) 
                              | ((0xc00U & (((IData)(vlSelf->__PVT__inst_t80__DOT___63_)
                                              ? (IData)(vlSelf->__PVT___429_)
                                              : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_) 
                                                 >> 4U)) 
                                            << 0xaU)) 
                                 | (0x3ffU & (((IData)(vlSelf->__PVT___429_) 
                                               << 8U) 
                                              | (((IData)(vlSelf->__PVT___429_) 
                                                  << 6U) 
                                                 | (((IData)(vlSelf->__PVT___429_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->__PVT___429_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__PVT___429_))))))));
    __Vfunc___03697__35__a = vlSelf->__PVT___429_;
    __Vfunc___03697__35__Vfuncout = (3U & (((((((((1U 
                                                   == 
                                                   (1U 
                                                    & (IData)(__Vfunc___03697__35__s))) 
                                                  | (2U 
                                                     == 
                                                     (2U 
                                                      & (IData)(__Vfunc___03697__35__s)))) 
                                                 | (4U 
                                                    == 
                                                    (4U 
                                                     & (IData)(__Vfunc___03697__35__s)))) 
                                                | (8U 
                                                   == 
                                                   (8U 
                                                    & (IData)(__Vfunc___03697__35__s)))) 
                                               | (0x10U 
                                                  == 
                                                  (0x10U 
                                                   & (IData)(__Vfunc___03697__35__s)))) 
                                              | (0x20U 
                                                 == 
                                                 (0x20U 
                                                  & (IData)(__Vfunc___03697__35__s)))) 
                                             | (0x40U 
                                                == 
                                                (0x40U 
                                                 & (IData)(__Vfunc___03697__35__s)))) 
                                            | (0x80U 
                                               == (0x80U 
                                                   & (IData)(__Vfunc___03697__35__s))))
                                            ? ((1U 
                                                == 
                                                (1U 
                                                 & (IData)(__Vfunc___03697__35__s)))
                                                ? __Vfunc___03697__35__b
                                                : (
                                                   (2U 
                                                    == 
                                                    (2U 
                                                     & (IData)(__Vfunc___03697__35__s)))
                                                    ? 
                                                   (__Vfunc___03697__35__b 
                                                    >> 2U)
                                                    : 
                                                   ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03697__35__s)))
                                                     ? 
                                                    (__Vfunc___03697__35__b 
                                                     >> 4U)
                                                     : 
                                                    ((8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03697__35__s)))
                                                      ? 
                                                     (__Vfunc___03697__35__b 
                                                      >> 6U)
                                                      : 
                                                     ((0x10U 
                                                       == 
                                                       (0x10U 
                                                        & (IData)(__Vfunc___03697__35__s)))
                                                       ? 
                                                      (__Vfunc___03697__35__b 
                                                       >> 8U)
                                                       : 
                                                      ((0x20U 
                                                        == 
                                                        (0x20U 
                                                         & (IData)(__Vfunc___03697__35__s)))
                                                        ? 
                                                       (__Vfunc___03697__35__b 
                                                        >> 0xaU)
                                                        : 
                                                       ((0x40U 
                                                         == 
                                                         (0x40U 
                                                          & (IData)(__Vfunc___03697__35__s)))
                                                         ? 
                                                        (__Vfunc___03697__35__b 
                                                         >> 0xcU)
                                                         : 
                                                        (__Vfunc___03697__35__b 
                                                         >> 0xeU))))))))
                                            : ((0x100U 
                                                == 
                                                (0x100U 
                                                 & (IData)(__Vfunc___03697__35__s)))
                                                ? (__Vfunc___03697__35__b 
                                                   >> 0x10U)
                                                : (
                                                   (0x200U 
                                                    == 
                                                    (0x200U 
                                                     & (IData)(__Vfunc___03697__35__s)))
                                                    ? 
                                                   (__Vfunc___03697__35__b 
                                                    >> 0x12U)
                                                    : 
                                                   ((0x400U 
                                                     == 
                                                     (0x400U 
                                                      & (IData)(__Vfunc___03697__35__s)))
                                                     ? 
                                                    (__Vfunc___03697__35__b 
                                                     >> 0x14U)
                                                     : 
                                                    ((0x800U 
                                                      == 
                                                      (0x800U 
                                                       & (IData)(__Vfunc___03697__35__s)))
                                                      ? 
                                                     (__Vfunc___03697__35__b 
                                                      >> 0x16U)
                                                      : 
                                                     ((0x1000U 
                                                       == 
                                                       (0x1000U 
                                                        & (IData)(__Vfunc___03697__35__s)))
                                                       ? 
                                                      (__Vfunc___03697__35__b 
                                                       >> 0x18U)
                                                       : (IData)(__Vfunc___03697__35__a))))))));
    vlSelf->__PVT___274_ = __Vfunc___03697__35__Vfuncout;
    __Vfunc___03698__36__s = (((0xeU == (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                               << 0xcU) | (((0xbU == 
                                             (0xfU 
                                              & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                            << 0xbU) 
                                           | (((0xaU 
                                                == 
                                                (0xfU 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                               << 0xaU) 
                                              | (((9U 
                                                   == 
                                                   (0xfU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                  << 9U) 
                                                 | (((8U 
                                                      == 
                                                      (0xfU 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                     << 8U) 
                                                    | (((7U 
                                                         == 
                                                         (0xfU 
                                                          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                        << 7U) 
                                                       | (((6U 
                                                            == 
                                                            (0xfU 
                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                           << 6U) 
                                                          | (((5U 
                                                               == 
                                                               (0xfU 
                                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                              << 5U) 
                                                             | (((4U 
                                                                  == 
                                                                  (0xfU 
                                                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                 << 4U) 
                                                                | (((3U 
                                                                     == 
                                                                     (0xfU 
                                                                      & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                    << 3U) 
                                                                   | (((2U 
                                                                        == 
                                                                        (0xfU 
                                                                         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                       << 2U) 
                                                                      | (((1U 
                                                                           == 
                                                                           (0xfU 
                                                                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                          << 1U) 
                                                                         | (0U 
                                                                            == 
                                                                            (0xfU 
                                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))))))))))))));
    __Vtemp_2[2U] = (((IData)((((QData)((IData)(((0xffffff00U 
                                                  & (((IData)(vlSelf->__PVT___430_) 
                                                      << 0x18U) 
                                                     | (((IData)(vlSelf->__PVT___430_) 
                                                         << 0x10U) 
                                                        | ((IData)(vlSelf->__PVT___430_) 
                                                           << 8U)))) 
                                                 | ((IData)(vlSelf->__PVT__inst_t80__DOT___63_)
                                                     ? (IData)(vlSelf->__PVT___430_)
                                                     : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_))))) 
                                << 0x20U) | (QData)((IData)(
                                                            (((IData)(vlSelf->__PVT___430_) 
                                                              << 0x18U) 
                                                             | (((IData)(vlSelf->__PVT___430_) 
                                                                 << 0x10U) 
                                                                | (((IData)(vlSelf->__PVT___430_) 
                                                                    << 8U) 
                                                                   | (IData)(vlSelf->__PVT___430_)))))))) 
                      >> 0x18U) | ((IData)(((((QData)((IData)(
                                                              ((0xffffff00U 
                                                                & (((IData)(vlSelf->__PVT___430_) 
                                                                    << 0x18U) 
                                                                   | (((IData)(vlSelf->__PVT___430_) 
                                                                       << 0x10U) 
                                                                      | ((IData)(vlSelf->__PVT___430_) 
                                                                         << 8U)))) 
                                                               | ((IData)(vlSelf->__PVT__inst_t80__DOT___63_)
                                                                   ? (IData)(vlSelf->__PVT___430_)
                                                                   : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_))))) 
                                              << 0x20U) 
                                             | (QData)((IData)(
                                                               (((IData)(vlSelf->__PVT___430_) 
                                                                 << 0x18U) 
                                                                | (((IData)(vlSelf->__PVT___430_) 
                                                                    << 0x10U) 
                                                                   | (((IData)(vlSelf->__PVT___430_) 
                                                                       << 8U) 
                                                                      | (IData)(vlSelf->__PVT___430_))))))) 
                                            >> 0x20U)) 
                                   << 8U));
    __Vfunc___03698__36__b[0U] = ((((IData)(vlSelf->__PVT___430_) 
                                    << 0x18U) | (((IData)(vlSelf->__PVT___430_) 
                                                  << 0x10U) 
                                                 | ((IData)(vlSelf->__PVT___430_) 
                                                    << 8U))) 
                                  | (IData)(vlSelf->__PVT___430_));
    __Vfunc___03698__36__b[1U] = (((0xffU & (IData)(vlSelf->__PVT___430_)) 
                                   | ((0xffU & ((IData)(vlSelf->__PVT___430_) 
                                                >> 8U)) 
                                      | ((0xffU & ((IData)(vlSelf->__PVT___430_) 
                                                   >> 0x10U)) 
                                         | ((IData)(vlSelf->__PVT___430_) 
                                            >> 0x18U)))) 
                                  | ((IData)((((QData)((IData)(
                                                               ((0xffffff00U 
                                                                 & (((IData)(vlSelf->__PVT___430_) 
                                                                     << 0x18U) 
                                                                    | (((IData)(vlSelf->__PVT___430_) 
                                                                        << 0x10U) 
                                                                       | ((IData)(vlSelf->__PVT___430_) 
                                                                          << 8U)))) 
                                                                | ((IData)(vlSelf->__PVT__inst_t80__DOT___63_)
                                                                    ? (IData)(vlSelf->__PVT___430_)
                                                                    : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_))))) 
                                               << 0x20U) 
                                              | (QData)((IData)(
                                                                (((IData)(vlSelf->__PVT___430_) 
                                                                  << 0x18U) 
                                                                 | (((IData)(vlSelf->__PVT___430_) 
                                                                     << 0x10U) 
                                                                    | (((IData)(vlSelf->__PVT___430_) 
                                                                        << 8U) 
                                                                       | (IData)(vlSelf->__PVT___430_)))))))) 
                                     << 8U));
    __Vfunc___03698__36__b[2U] = __Vtemp_2[2U];
    __Vfunc___03698__36__b[3U] = ((IData)(((((QData)((IData)(
                                                             ((0xffffff00U 
                                                               & (((IData)(vlSelf->__PVT___430_) 
                                                                   << 0x18U) 
                                                                  | (((IData)(vlSelf->__PVT___430_) 
                                                                      << 0x10U) 
                                                                     | ((IData)(vlSelf->__PVT___430_) 
                                                                        << 8U)))) 
                                                              | ((IData)(vlSelf->__PVT__inst_t80__DOT___63_)
                                                                  ? (IData)(vlSelf->__PVT___430_)
                                                                  : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_))))) 
                                             << 0x20U) 
                                            | (QData)((IData)(
                                                              (((IData)(vlSelf->__PVT___430_) 
                                                                << 0x18U) 
                                                               | (((IData)(vlSelf->__PVT___430_) 
                                                                   << 0x10U) 
                                                                  | (((IData)(vlSelf->__PVT___430_) 
                                                                      << 8U) 
                                                                     | (IData)(vlSelf->__PVT___430_))))))) 
                                           >> 0x20U)) 
                                  >> 0x18U);
    __Vfunc___03698__36__a = vlSelf->__PVT___430_;
    __Vfunc___03698__36__Vfuncout = (0xffU & ((((((
                                                   (((1U 
                                                      == 
                                                      (1U 
                                                       & (IData)(__Vfunc___03698__36__s))) 
                                                     | (2U 
                                                        == 
                                                        (2U 
                                                         & (IData)(__Vfunc___03698__36__s)))) 
                                                    | (4U 
                                                       == 
                                                       (4U 
                                                        & (IData)(__Vfunc___03698__36__s)))) 
                                                   | (8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03698__36__s)))) 
                                                  | (0x10U 
                                                     == 
                                                     (0x10U 
                                                      & (IData)(__Vfunc___03698__36__s)))) 
                                                 | (0x20U 
                                                    == 
                                                    (0x20U 
                                                     & (IData)(__Vfunc___03698__36__s)))) 
                                                | (0x40U 
                                                   == 
                                                   (0x40U 
                                                    & (IData)(__Vfunc___03698__36__s)))) 
                                               | (0x80U 
                                                  == 
                                                  (0x80U 
                                                   & (IData)(__Vfunc___03698__36__s))))
                                               ? ((1U 
                                                   == 
                                                   (1U 
                                                    & (IData)(__Vfunc___03698__36__s)))
                                                   ? 
                                                  __Vfunc___03698__36__b[0U]
                                                   : 
                                                  ((2U 
                                                    == 
                                                    (2U 
                                                     & (IData)(__Vfunc___03698__36__s)))
                                                    ? 
                                                   ((__Vfunc___03698__36__b[0U] 
                                                     << 0x18U) 
                                                    | (__Vfunc___03698__36__b[0U] 
                                                       >> 8U))
                                                    : 
                                                   ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03698__36__s)))
                                                     ? 
                                                    ((__Vfunc___03698__36__b[0U] 
                                                      << 0x10U) 
                                                     | (__Vfunc___03698__36__b[0U] 
                                                        >> 0x10U))
                                                     : 
                                                    ((8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03698__36__s)))
                                                      ? 
                                                     ((__Vfunc___03698__36__b[0U] 
                                                       << 8U) 
                                                      | (__Vfunc___03698__36__b[0U] 
                                                         >> 0x18U))
                                                      : 
                                                     ((0x10U 
                                                       == 
                                                       (0x10U 
                                                        & (IData)(__Vfunc___03698__36__s)))
                                                       ? 
                                                      __Vfunc___03698__36__b[1U]
                                                       : 
                                                      ((0x20U 
                                                        == 
                                                        (0x20U 
                                                         & (IData)(__Vfunc___03698__36__s)))
                                                        ? 
                                                       ((__Vfunc___03698__36__b[1U] 
                                                         << 0x18U) 
                                                        | (__Vfunc___03698__36__b[1U] 
                                                           >> 8U))
                                                        : 
                                                       ((0x40U 
                                                         == 
                                                         (0x40U 
                                                          & (IData)(__Vfunc___03698__36__s)))
                                                         ? 
                                                        ((__Vfunc___03698__36__b[1U] 
                                                          << 0x10U) 
                                                         | (__Vfunc___03698__36__b[1U] 
                                                            >> 0x10U))
                                                         : 
                                                        ((__Vfunc___03698__36__b[1U] 
                                                          << 8U) 
                                                         | (__Vfunc___03698__36__b[1U] 
                                                            >> 0x18U)))))))))
                                               : ((0x100U 
                                                   == 
                                                   (0x100U 
                                                    & (IData)(__Vfunc___03698__36__s)))
                                                   ? 
                                                  __Vfunc___03698__36__b[2U]
                                                   : 
                                                  ((0x200U 
                                                    == 
                                                    (0x200U 
                                                     & (IData)(__Vfunc___03698__36__s)))
                                                    ? 
                                                   ((__Vfunc___03698__36__b[2U] 
                                                     << 0x18U) 
                                                    | (__Vfunc___03698__36__b[2U] 
                                                       >> 8U))
                                                    : 
                                                   ((0x400U 
                                                     == 
                                                     (0x400U 
                                                      & (IData)(__Vfunc___03698__36__s)))
                                                     ? 
                                                    ((__Vfunc___03698__36__b[2U] 
                                                      << 0x10U) 
                                                     | (__Vfunc___03698__36__b[2U] 
                                                        >> 0x10U))
                                                     : 
                                                    ((0x800U 
                                                      == 
                                                      (0x800U 
                                                       & (IData)(__Vfunc___03698__36__s)))
                                                      ? 
                                                     ((__Vfunc___03698__36__b[2U] 
                                                       << 8U) 
                                                      | (__Vfunc___03698__36__b[2U] 
                                                         >> 0x18U))
                                                      : 
                                                     ((0x1000U 
                                                       == 
                                                       (0x1000U 
                                                        & (IData)(__Vfunc___03698__36__s)))
                                                       ? 
                                                      __Vfunc___03698__36__b[3U]
                                                       : (IData)(__Vfunc___03698__36__a))))))));
    vlSelf->__PVT___275_ = __Vfunc___03698__36__Vfuncout;
    __Vfunc___03470__16__s = (((2U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                             >> 0xdU))) 
                               << 2U) | (((1U == (3U 
                                                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                     >> 0xdU))) 
                                          << 1U) | 
                                         (0U == (3U 
                                                 & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                    >> 0xdU)))));
    __Vfunc___03470__16__b = (((IData)(vlSelf->__PVT___436_) 
                               << 0x10U) | ((IData)(vlSelf->__PVT___435_) 
                                            << 8U));
    __Vfunc___03470__16__a = vlSelf->__PVT___437_;
    __Vfunc___03470__16__Vfuncout = (0xffU & ((1U == 
                                               (1U 
                                                & (IData)(__Vfunc___03470__16__s)))
                                               ? __Vfunc___03470__16__b
                                               : ((2U 
                                                   == 
                                                   (2U 
                                                    & (IData)(__Vfunc___03470__16__s)))
                                                   ? 
                                                  (__Vfunc___03470__16__b 
                                                   >> 8U)
                                                   : 
                                                  ((4U 
                                                    == 
                                                    (4U 
                                                     & (IData)(__Vfunc___03470__16__s)))
                                                    ? 
                                                   (__Vfunc___03470__16__b 
                                                    >> 0x10U)
                                                    : (IData)(__Vfunc___03470__16__a)))));
    vlSelf->__PVT___144_ = __Vfunc___03470__16__Vfuncout;
    __Vfunc___03685__27__s = (((0xeU == (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                               << 0xcU) | (((0xbU == 
                                             (0xfU 
                                              & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                            << 0xbU) 
                                           | (((0xaU 
                                                == 
                                                (0xfU 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                               << 0xaU) 
                                              | (((9U 
                                                   == 
                                                   (0xfU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                  << 9U) 
                                                 | (((8U 
                                                      == 
                                                      (0xfU 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                     << 8U) 
                                                    | (((7U 
                                                         == 
                                                         (0xfU 
                                                          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                        << 7U) 
                                                       | (((6U 
                                                            == 
                                                            (0xfU 
                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                           << 6U) 
                                                          | (((5U 
                                                               == 
                                                               (0xfU 
                                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                              << 5U) 
                                                             | (((4U 
                                                                  == 
                                                                  (0xfU 
                                                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                 << 4U) 
                                                                | (((3U 
                                                                     == 
                                                                     (0xfU 
                                                                      & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                    << 3U) 
                                                                   | (((2U 
                                                                        == 
                                                                        (0xfU 
                                                                         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                       << 2U) 
                                                                      | (((1U 
                                                                           == 
                                                                           (0xfU 
                                                                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                          << 1U) 
                                                                         | (0U 
                                                                            == 
                                                                            (0xfU 
                                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))))))))))))));
    __Vfunc___03685__27__b = (((QData)((IData)((((IData)(vlSelf->__PVT___414_) 
                                                 << 0x1cU) 
                                                | (((IData)(vlSelf->__PVT___414_) 
                                                    << 0x18U) 
                                                   | (((IData)(vlSelf->__PVT___414_) 
                                                       << 0x14U) 
                                                      | (((IData)(vlSelf->__PVT___414_) 
                                                          << 0x10U) 
                                                         | (((IData)(vlSelf->__PVT___414_) 
                                                             << 0xcU) 
                                                            | (((IData)(vlSelf->__PVT___414_) 
                                                                << 8U) 
                                                               | (((IData)(vlSelf->__PVT___414_) 
                                                                   << 4U) 
                                                                  | (IData)(vlSelf->__PVT___414_)))))))))) 
                               << 0x14U) | (QData)((IData)(
                                                           ((0xf0000U 
                                                             & (((IData)(vlSelf->__PVT___434_)
                                                                  ? (IData)(vlSelf->__PVT___414_)
                                                                  : 
                                                                 (((~ (IData)(vlSelf->__PVT__inst_t80__DOT___63_)) 
                                                                   & (0U 
                                                                      != 
                                                                      (0xfU 
                                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_))))
                                                                   ? (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_)
                                                                   : (IData)(vlSelf->__PVT___414_))) 
                                                                << 0x10U)) 
                                                            | (0xffffU 
                                                               & (((IData)(vlSelf->__PVT___414_) 
                                                                   << 0xcU) 
                                                                  | (((IData)(vlSelf->__PVT___414_) 
                                                                      << 8U) 
                                                                     | (((IData)(vlSelf->__PVT___414_) 
                                                                         << 4U) 
                                                                        | (IData)(vlSelf->__PVT___414_)))))))));
    __Vfunc___03685__27__a = vlSelf->__PVT___414_;
    __Vfunc___03685__27__Vfuncout = (0xfU & (((((((
                                                   ((1U 
                                                     == 
                                                     (1U 
                                                      & (IData)(__Vfunc___03685__27__s))) 
                                                    | (2U 
                                                       == 
                                                       (2U 
                                                        & (IData)(__Vfunc___03685__27__s)))) 
                                                   | (4U 
                                                      == 
                                                      (4U 
                                                       & (IData)(__Vfunc___03685__27__s)))) 
                                                  | (8U 
                                                     == 
                                                     (8U 
                                                      & (IData)(__Vfunc___03685__27__s)))) 
                                                 | (0x10U 
                                                    == 
                                                    (0x10U 
                                                     & (IData)(__Vfunc___03685__27__s)))) 
                                                | (0x20U 
                                                   == 
                                                   (0x20U 
                                                    & (IData)(__Vfunc___03685__27__s)))) 
                                               | (0x40U 
                                                  == 
                                                  (0x40U 
                                                   & (IData)(__Vfunc___03685__27__s)))) 
                                              | (0x80U 
                                                 == 
                                                 (0x80U 
                                                  & (IData)(__Vfunc___03685__27__s))))
                                              ? ((1U 
                                                  == 
                                                  (1U 
                                                   & (IData)(__Vfunc___03685__27__s)))
                                                  ? (IData)(__Vfunc___03685__27__b)
                                                  : 
                                                 ((2U 
                                                   == 
                                                   (2U 
                                                    & (IData)(__Vfunc___03685__27__s)))
                                                   ? (IData)(
                                                             (__Vfunc___03685__27__b 
                                                              >> 4U))
                                                   : 
                                                  ((4U 
                                                    == 
                                                    (4U 
                                                     & (IData)(__Vfunc___03685__27__s)))
                                                    ? (IData)(
                                                              (__Vfunc___03685__27__b 
                                                               >> 8U))
                                                    : 
                                                   ((8U 
                                                     == 
                                                     (8U 
                                                      & (IData)(__Vfunc___03685__27__s)))
                                                     ? (IData)(
                                                               (__Vfunc___03685__27__b 
                                                                >> 0xcU))
                                                     : 
                                                    ((0x10U 
                                                      == 
                                                      (0x10U 
                                                       & (IData)(__Vfunc___03685__27__s)))
                                                      ? (IData)(
                                                                (__Vfunc___03685__27__b 
                                                                 >> 0x10U))
                                                      : 
                                                     ((0x20U 
                                                       == 
                                                       (0x20U 
                                                        & (IData)(__Vfunc___03685__27__s)))
                                                       ? (IData)(
                                                                 (__Vfunc___03685__27__b 
                                                                  >> 0x14U))
                                                       : 
                                                      ((0x40U 
                                                        == 
                                                        (0x40U 
                                                         & (IData)(__Vfunc___03685__27__s)))
                                                        ? (IData)(
                                                                  (__Vfunc___03685__27__b 
                                                                   >> 0x18U))
                                                        : (IData)(
                                                                  (__Vfunc___03685__27__b 
                                                                   >> 0x1cU)))))))))
                                              : ((0x100U 
                                                  == 
                                                  (0x100U 
                                                   & (IData)(__Vfunc___03685__27__s)))
                                                  ? (IData)(
                                                            (__Vfunc___03685__27__b 
                                                             >> 0x20U))
                                                  : 
                                                 ((0x200U 
                                                   == 
                                                   (0x200U 
                                                    & (IData)(__Vfunc___03685__27__s)))
                                                   ? (IData)(
                                                             (__Vfunc___03685__27__b 
                                                              >> 0x24U))
                                                   : 
                                                  ((0x400U 
                                                    == 
                                                    (0x400U 
                                                     & (IData)(__Vfunc___03685__27__s)))
                                                    ? (IData)(
                                                              (__Vfunc___03685__27__b 
                                                               >> 0x28U))
                                                    : 
                                                   ((0x800U 
                                                     == 
                                                     (0x800U 
                                                      & (IData)(__Vfunc___03685__27__s)))
                                                     ? (IData)(
                                                               (__Vfunc___03685__27__b 
                                                                >> 0x2cU))
                                                     : 
                                                    ((0x1000U 
                                                      == 
                                                      (0x1000U 
                                                       & (IData)(__Vfunc___03685__27__s)))
                                                      ? (IData)(
                                                                (__Vfunc___03685__27__b 
                                                                 >> 0x30U))
                                                      : (IData)(__Vfunc___03685__27__a))))))));
    vlSelf->__PVT___265_ = __Vfunc___03685__27__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___711_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___804_) 
         | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___806_));
    vlSelf->inst_t80__DOT__u0__DOT____VdfgTmp_h8fd225ae__0 
        = ((0x8000U & ((IData)(vlSelf->__PVT__inst_t80__DOT___55_) 
                       << 8U)) | ((0x4000U & ((IData)(vlSelf->__PVT__inst_t80__DOT___55_) 
                                              << 7U)) 
                                  | ((0x2000U & ((IData)(vlSelf->__PVT__inst_t80__DOT___55_) 
                                                 << 6U)) 
                                     | ((0x1000U & 
                                         ((IData)(vlSelf->__PVT__inst_t80__DOT___55_) 
                                          << 5U)) | 
                                        ((0x800U & 
                                          ((IData)(vlSelf->__PVT__inst_t80__DOT___55_) 
                                           << 4U)) 
                                         | ((0x400U 
                                             & ((IData)(vlSelf->__PVT__inst_t80__DOT___55_) 
                                                << 3U)) 
                                            | ((0x200U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT___55_) 
                                                   << 2U)) 
                                               | ((0x100U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT___55_) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__PVT__inst_t80__DOT___55_)))))))));
    vlSelf->__PVT__ym2149_audio_inst__DOT___106_ = 
        (1U & ((~ (1U & (((IData)(0xfU) - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)) 
                         >> 3U))) & (~ (3U & (((IData)(0xfU) 
                                               - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)) 
                                              >> 2U)))));
    vlSelf->__PVT__ym2149_audio_inst__DOT___107_ = 
        (1U & ((~ (1U & (((IData)(0xfU) - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)) 
                         >> 3U))) & (((IData)(0xfU) 
                                      - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)) 
                                     >> 2U)));
    vlSelf->__PVT__ym2149_audio_inst__DOT___108_ = 
        (1U & ((~ (3U & (((IData)(0xfU) - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)) 
                         >> 2U))) & (((IData)(0xfU) 
                                      - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)) 
                                     >> 3U)));
    vlSelf->__PVT__ym2149_audio_inst__DOT___109_ = 
        (1U & ((((IData)(0xfU) - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)) 
                >> 3U) & (((IData)(0xfU) - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)) 
                          >> 2U)));
    vlSelf->__PVT__sn76489_audio_inst__DOT___002_ = 
        (1U & ((~ (IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___155_)) 
               & (~ (IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___154_))));
    vlSelf->__PVT___077_ = (1U & ((IData)(vlSelf->__PVT___428_) 
                                  | ((IData)(vlSelf->__PVT__inst_t80__DOT___63_) 
                                     | (IData)(vlSelf->__PVT___429_))));
    vlSelf->__PVT___058_ = (1U & ((IData)(vlSelf->__PVT___415_) 
                                  | ((~ (IData)(vlSelf->__PVT___412_)) 
                                     | (IData)(vlSelf->__PVT__inst_t80__DOT___63_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__s)))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1989_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038796__443__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__s)))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1991_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038802__445__Vfuncout;
    __Vfunc___03714__42__s = (1U == (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)));
    __Vfunc___03714__42__b = ((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                               ? 0U : (0xffU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)));
    __Vfunc___03714__42__Vfuncout = ((IData)(__Vfunc___03714__42__s)
                                      ? (IData)(__Vfunc___03714__42__b)
                                      : 0U);
    vlSelf->__PVT___286_ = __Vfunc___03714__42__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035978__230__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035978__230__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035978__230__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035978__230__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0579_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035978__230__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___459_ = 
        ((0x10U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
         | ((0x11U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
            | ((0x12U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
               | ((0x13U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
                  | ((0x14U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)) 
                     | (0x15U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)))))));
    vlSelf->inst_t80__DOT__u0__DOT____VdfgTmp_hb2fda09c__0 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___724_) 
            << 8U) | (0xffU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___740_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035725__191__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035725__191__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035725__191__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035725__191__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0476_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035725__191__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035780__200__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035780__200__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035780__200__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035780__200__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0502_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035780__200__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___139_ = 
        ((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___766_)) 
         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___804_) 
            & (3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2345_ 
        = ((0x36U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__s)))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1924_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038633__421__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__s)))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1945_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038691__427__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__s)))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1990_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038799__444__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038934__462__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038934__462__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038934__462__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038934__462__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2055_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038934__462__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039016__477__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039016__477__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039016__477__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039016__477__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2089_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039016__477__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039055__484__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039055__484__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039055__484__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039055__484__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2106_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039055__484__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039094__494__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039094__494__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039094__494__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039094__494__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2120_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039094__494__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039294__521__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039294__521__Vfuncout 
        = (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039294__521__s));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2211_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039294__521__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039357__533__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039357__533__Vfuncout 
        = (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039357__533__s));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2236_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039357__533__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035053__126__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035053__126__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035053__126__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035053__126__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0163_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035053__126__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035067__128__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035067__128__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035067__128__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035067__128__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0168_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035067__128__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035087__131__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035087__131__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035087__131__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035087__131__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035087__131__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0175_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035087__131__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036637__313__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036637__313__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036637__313__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036637__313__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0846_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036637__313__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038630__420__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038630__420__Vfuncout 
        = (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038630__420__s));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1923_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038630__420__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038688__426__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038688__426__Vfuncout 
        = (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038688__426__s));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1944_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038688__426__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039128__501__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039128__501__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039128__501__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039128__501__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2131_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039128__501__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__s))
                      ? (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__s))))
                      : (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__s)))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1919_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038619__416__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038919__456__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038919__456__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038919__456__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038919__456__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2049_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038919__456__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039001__471__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039001__471__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039001__471__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039001__471__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2083_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039001__471__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039046__480__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039046__480__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039046__480__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039046__480__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2102_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039046__480__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039085__490__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039085__490__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039085__490__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039085__490__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2116_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039085__490__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039282__517__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039282__517__Vfuncout 
        = (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039282__517__s));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2207_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039282__517__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039345__529__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039345__529__Vfuncout 
        = (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039345__529__s));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2232_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039345__529__Vfuncout;
    __Vfunc___03687__28__s = (((0xeU == (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                               << 0xcU) | (((0xbU == 
                                             (0xfU 
                                              & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                            << 0xbU) 
                                           | (((0xaU 
                                                == 
                                                (0xfU 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                               << 0xaU) 
                                              | (((9U 
                                                   == 
                                                   (0xfU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                  << 9U) 
                                                 | (((8U 
                                                      == 
                                                      (0xfU 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                     << 8U) 
                                                    | (((7U 
                                                         == 
                                                         (0xfU 
                                                          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                        << 7U) 
                                                       | (((6U 
                                                            == 
                                                            (0xfU 
                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                           << 6U) 
                                                          | (((5U 
                                                               == 
                                                               (0xfU 
                                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                              << 5U) 
                                                             | (((4U 
                                                                  == 
                                                                  (0xfU 
                                                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                 << 4U) 
                                                                | (((3U 
                                                                     == 
                                                                     (0xfU 
                                                                      & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                    << 3U) 
                                                                   | (((2U 
                                                                        == 
                                                                        (0xfU 
                                                                         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                       << 2U) 
                                                                      | (((1U 
                                                                           == 
                                                                           (0xfU 
                                                                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                          << 1U) 
                                                                         | (0U 
                                                                            == 
                                                                            (0xfU 
                                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))))))))))))));
    __Vtemp_3[1U] = (((IData)((((QData)((IData)(((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                  ? 0U
                                                  : (IData)(vlSelf->__PVT___020_)))) 
                                << 0x38U) | (((QData)((IData)(
                                                              ((((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                                  ? 0U
                                                                  : (IData)(vlSelf->__PVT___437_)) 
                                                                << 0x18U) 
                                                               | (((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                                    ? 0U
                                                                    : (IData)(vlSelf->__PVT___436_)) 
                                                                  << 0x10U)))) 
                                              << 0x18U) 
                                             | (QData)((IData)(
                                                               ((((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                                   ? 0U
                                                                   : (IData)(vlSelf->__PVT__sdcard__DOT___46_)) 
                                                                 << 0x10U) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                                     ? 0U
                                                                     : 
                                                                    (((IData)(vlSelf->__PVT___416_) 
                                                                      << 7U) 
                                                                     | (((IData)(vlSelf->__PVT___417_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->__PVT___418_)))) 
                                                                   << 8U))))))) 
                      << 8U) | (IData)(((((QData)((IData)(
                                                          ((IData)(vlSelf->__PVT___434_)
                                                            ? 
                                                           ((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                             ? 0U
                                                             : (IData)(vlSelf->__PVT___435_))
                                                            : 
                                                           ((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                             ? 0U
                                                             : (IData)(vlSelf->__PVT___414_))))) 
                                          << 0x20U) 
                                         | (QData)((IData)(
                                                           (((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                              ? 0U
                                                              : (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___052_)) 
                                                            << 0x10U)))) 
                                        >> 0x20U)));
    __Vtemp_3[2U] = (((IData)((((QData)((IData)(((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                  ? 0U
                                                  : (IData)(vlSelf->__PVT___020_)))) 
                                << 0x38U) | (((QData)((IData)(
                                                              ((((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                                  ? 0U
                                                                  : (IData)(vlSelf->__PVT___437_)) 
                                                                << 0x18U) 
                                                               | (((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                                    ? 0U
                                                                    : (IData)(vlSelf->__PVT___436_)) 
                                                                  << 0x10U)))) 
                                              << 0x18U) 
                                             | (QData)((IData)(
                                                               ((((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                                   ? 0U
                                                                   : (IData)(vlSelf->__PVT__sdcard__DOT___46_)) 
                                                                 << 0x10U) 
                                                                | (((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                                     ? 0U
                                                                     : 
                                                                    (((IData)(vlSelf->__PVT___416_) 
                                                                      << 7U) 
                                                                     | (((IData)(vlSelf->__PVT___417_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->__PVT___418_)))) 
                                                                   << 8U))))))) 
                      >> 0x18U) | ((IData)(((((QData)((IData)(
                                                              ((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                                ? 0U
                                                                : (IData)(vlSelf->__PVT___020_)))) 
                                              << 0x38U) 
                                             | (((QData)((IData)(
                                                                 ((((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                                     ? 0U
                                                                     : (IData)(vlSelf->__PVT___437_)) 
                                                                   << 0x18U) 
                                                                  | (((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                                       ? 0U
                                                                       : (IData)(vlSelf->__PVT___436_)) 
                                                                     << 0x10U)))) 
                                                 << 0x18U) 
                                                | (QData)((IData)(
                                                                  ((((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                                      ? 0U
                                                                      : (IData)(vlSelf->__PVT__sdcard__DOT___46_)) 
                                                                    << 0x10U) 
                                                                   | (((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                                        ? 0U
                                                                        : 
                                                                       (((IData)(vlSelf->__PVT___416_) 
                                                                         << 7U) 
                                                                        | (((IData)(vlSelf->__PVT___417_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->__PVT___418_)))) 
                                                                      << 8U)))))) 
                                            >> 0x20U)) 
                                   << 8U));
    __Vfunc___03687__28__b[0U] = (IData)((((QData)((IData)(
                                                           ((IData)(vlSelf->__PVT___434_)
                                                             ? 
                                                            ((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                              ? 0U
                                                              : (IData)(vlSelf->__PVT___435_))
                                                             : 
                                                            ((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                              ? 0U
                                                              : (IData)(vlSelf->__PVT___414_))))) 
                                           << 0x20U) 
                                          | (QData)((IData)(
                                                            (((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                               ? 0U
                                                               : (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___052_)) 
                                                             << 0x10U)))));
    __Vfunc___03687__28__b[1U] = __Vtemp_3[1U];
    __Vfunc___03687__28__b[2U] = __Vtemp_3[2U];
    __Vfunc___03687__28__b[3U] = ((IData)(((((QData)((IData)(
                                                             ((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                               ? 0U
                                                               : (IData)(vlSelf->__PVT___020_)))) 
                                             << 0x38U) 
                                            | (((QData)((IData)(
                                                                ((((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                                    ? 0U
                                                                    : (IData)(vlSelf->__PVT___437_)) 
                                                                  << 0x18U) 
                                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                                      ? 0U
                                                                      : (IData)(vlSelf->__PVT___436_)) 
                                                                    << 0x10U)))) 
                                                << 0x18U) 
                                               | (QData)((IData)(
                                                                 ((((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                                     ? 0U
                                                                     : (IData)(vlSelf->__PVT__sdcard__DOT___46_)) 
                                                                   << 0x10U) 
                                                                  | (((IData)(vlSelf->__PVT__inst_t80__DOT___61_)
                                                                       ? 0U
                                                                       : 
                                                                      (((IData)(vlSelf->__PVT___416_) 
                                                                        << 7U) 
                                                                       | (((IData)(vlSelf->__PVT___417_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->__PVT___418_)))) 
                                                                     << 8U)))))) 
                                           >> 0x20U)) 
                                  >> 0x18U);
    __Vfunc___03687__28__Vfuncout = (0xffU & ((((((
                                                   (((1U 
                                                      == 
                                                      (1U 
                                                       & (IData)(__Vfunc___03687__28__s))) 
                                                     | (2U 
                                                        == 
                                                        (2U 
                                                         & (IData)(__Vfunc___03687__28__s)))) 
                                                    | (4U 
                                                       == 
                                                       (4U 
                                                        & (IData)(__Vfunc___03687__28__s)))) 
                                                   | (8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03687__28__s)))) 
                                                  | (0x10U 
                                                     == 
                                                     (0x10U 
                                                      & (IData)(__Vfunc___03687__28__s)))) 
                                                 | (0x20U 
                                                    == 
                                                    (0x20U 
                                                     & (IData)(__Vfunc___03687__28__s)))) 
                                                | (0x40U 
                                                   == 
                                                   (0x40U 
                                                    & (IData)(__Vfunc___03687__28__s)))) 
                                               | (0x80U 
                                                  == 
                                                  (0x80U 
                                                   & (IData)(__Vfunc___03687__28__s))))
                                               ? ((1U 
                                                   == 
                                                   (1U 
                                                    & (IData)(__Vfunc___03687__28__s)))
                                                   ? 
                                                  __Vfunc___03687__28__b[0U]
                                                   : 
                                                  ((2U 
                                                    == 
                                                    (2U 
                                                     & (IData)(__Vfunc___03687__28__s)))
                                                    ? 
                                                   ((__Vfunc___03687__28__b[0U] 
                                                     << 0x18U) 
                                                    | (__Vfunc___03687__28__b[0U] 
                                                       >> 8U))
                                                    : 
                                                   ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03687__28__s)))
                                                     ? 
                                                    ((__Vfunc___03687__28__b[0U] 
                                                      << 0x10U) 
                                                     | (__Vfunc___03687__28__b[0U] 
                                                        >> 0x10U))
                                                     : 
                                                    ((8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03687__28__s)))
                                                      ? 
                                                     ((__Vfunc___03687__28__b[0U] 
                                                       << 8U) 
                                                      | (__Vfunc___03687__28__b[0U] 
                                                         >> 0x18U))
                                                      : 
                                                     ((0x10U 
                                                       == 
                                                       (0x10U 
                                                        & (IData)(__Vfunc___03687__28__s)))
                                                       ? 
                                                      __Vfunc___03687__28__b[1U]
                                                       : 
                                                      ((0x20U 
                                                        == 
                                                        (0x20U 
                                                         & (IData)(__Vfunc___03687__28__s)))
                                                        ? 
                                                       ((__Vfunc___03687__28__b[1U] 
                                                         << 0x18U) 
                                                        | (__Vfunc___03687__28__b[1U] 
                                                           >> 8U))
                                                        : 
                                                       ((0x40U 
                                                         == 
                                                         (0x40U 
                                                          & (IData)(__Vfunc___03687__28__s)))
                                                         ? 
                                                        ((__Vfunc___03687__28__b[1U] 
                                                          << 0x10U) 
                                                         | (__Vfunc___03687__28__b[1U] 
                                                            >> 0x10U))
                                                         : 
                                                        ((__Vfunc___03687__28__b[1U] 
                                                          << 8U) 
                                                         | (__Vfunc___03687__28__b[1U] 
                                                            >> 0x18U)))))))))
                                               : ((0x100U 
                                                   == 
                                                   (0x100U 
                                                    & (IData)(__Vfunc___03687__28__s)))
                                                   ? 
                                                  __Vfunc___03687__28__b[2U]
                                                   : 
                                                  ((0x200U 
                                                    == 
                                                    (0x200U 
                                                     & (IData)(__Vfunc___03687__28__s)))
                                                    ? 
                                                   ((__Vfunc___03687__28__b[2U] 
                                                     << 0x18U) 
                                                    | (__Vfunc___03687__28__b[2U] 
                                                       >> 8U))
                                                    : 
                                                   ((0x400U 
                                                     == 
                                                     (0x400U 
                                                      & (IData)(__Vfunc___03687__28__s)))
                                                     ? 
                                                    ((__Vfunc___03687__28__b[2U] 
                                                      << 0x10U) 
                                                     | (__Vfunc___03687__28__b[2U] 
                                                        >> 0x10U))
                                                     : 
                                                    ((0x800U 
                                                      == 
                                                      (0x800U 
                                                       & (IData)(__Vfunc___03687__28__s)))
                                                      ? 
                                                     ((__Vfunc___03687__28__b[2U] 
                                                       << 8U) 
                                                      | (__Vfunc___03687__28__b[2U] 
                                                         >> 0x18U))
                                                      : 
                                                     ((0x1000U 
                                                       == 
                                                       (0x1000U 
                                                        & (IData)(__Vfunc___03687__28__s)))
                                                       ? 
                                                      __Vfunc___03687__28__b[3U]
                                                       : 0U)))))));
    vlSelf->__PVT___266_ = __Vfunc___03687__28__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035614__183__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035614__183__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035614__183__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035614__183__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0416_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035614__183__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035722__190__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035722__190__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035722__190__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035722__190__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0475_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035722__190__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035777__199__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035777__199__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035777__199__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035777__199__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0501_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035777__199__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035974__229__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035974__229__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035974__229__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035974__229__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0578_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035974__229__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036281__269__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036281__269__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036281__269__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0704_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036281__269__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039304__524__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039304__524__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039304__524__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039304__524__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039304__524__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2214_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039304__524__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039367__536__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039367__536__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039367__536__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039367__536__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039367__536__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2239_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039367__536__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039131__502__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039131__502__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039131__502__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039131__502__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039131__502__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2132_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039131__502__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__b 
        = ((6U != (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                         >> 3U))) << 1U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2154_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039173__504__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__s)))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0229_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035237__155__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__s)))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0240_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035270__161__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__b 
        = (0x18U | ((1U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_))
                     ? 3U : 2U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__b) 
                         >> 3U) : 3U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0660_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036158__243__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__b 
        = (0x18U | ((1U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_))
                     ? 2U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__b) 
                         >> 3U) : 3U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0669_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036184__248__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__b 
        = (0x18U | ((0x40U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_))
                     ? 3U : 2U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__b) 
                         >> 3U) : 3U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0679_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036211__253__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__b 
        = (0x18U | ((0x40U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_))
                     ? 2U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__b) 
                         >> 3U) : 3U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0688_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036237__258__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__s)))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0720_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036330__280__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__s)))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0753_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036425__291__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s)))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1917_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038612__414__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s)))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1940_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038676__422__Vfuncout;
    vlSelf->__PVT___059_ = ((IData)(vlSelf->__PVT___415_)
                             ? (IData)(vlSelf->__PVT__loader__DOT___0_)
                             : ((IData)(vlSelf->__PVT___412_)
                                 ? (IData)(vlSelf->__PVT__ext512__DOT___17_)
                                 : (IData)(vlSymsp->TOP__sim_top.__PVT__cart_bus)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034929__112__s 
        = (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034929__112__Vfuncout 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034929__112__s;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0101_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034929__112__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034960__114__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034960__114__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034960__114__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034960__114__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0118_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034960__114__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035187__146__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035187__146__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035187__146__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035187__146__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0209_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035187__146__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__s))
                      ? (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__s))))
                      : (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__s)))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0225_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035225__151__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035361__169__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035361__169__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035361__169__s))) 
           & ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035361__169__s))) 
              | (4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035361__169__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0273_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035361__169__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__Vfuncout 
        = (1U & ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))
                  ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))
                      ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))
                          ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))))
                          : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))
                              ? (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))
                              : (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))))
                      : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))
                          ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))))
                          : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))))))
                  : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))
                      ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))
                          ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))))
                          : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))
                              ? (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))
                              : (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))))
                      : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))
                          ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))))
                          : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__s))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0294_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035409__175__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035607__180__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035607__180__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035607__180__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035607__180__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0413_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035607__180__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035712__186__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035712__186__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035712__186__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035712__186__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0471_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035712__186__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035767__195__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035767__195__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035767__195__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035767__195__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0497_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035767__195__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035959__223__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035959__223__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035959__223__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035959__223__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0572_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035959__223__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036271__265__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036271__265__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036271__265__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0700_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036271__265__Vfuncout;
    vlSelf->__PVT___226_ = (1U & VL_REDXOR_8((0x30U 
                                              & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__s)))
                     ? 1U : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__a)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0577_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035970__228__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036140__241__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036140__241__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036140__241__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036140__241__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0653_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036140__241__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036167__246__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036167__246__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036167__246__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036167__246__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0663_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036167__246__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036193__251__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036193__251__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036193__251__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036193__251__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0672_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036193__251__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036220__256__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036220__256__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036220__256__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036220__256__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0682_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036220__256__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036246__261__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036246__261__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036246__261__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036246__261__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0691_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036246__261__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036284__270__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036284__270__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036284__270__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036284__270__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036284__270__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0705_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036284__270__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__s)))
            ? 1U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__s)))
                     ? 1U : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__a)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2054_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038930__461__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__s)))
            ? 3U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__s)))
                     ? 3U : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__a)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2088_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039012__476__Vfuncout;
    vlSelf->__PVT___046_ = (1U & ((~ (IData)(vlSelf->__PVT___428_)) 
                                  | (IData)(vlSelf->__PVT___412_)));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s 
        = (((5U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                          >> 3U))) << 6U) | (((6U == 
                                               (7U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                   >> 3U))) 
                                              << 5U) 
                                             | (((4U 
                                                  == 
                                                  (7U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                      >> 3U))) 
                                                 << 4U) 
                                                | (((3U 
                                                     == 
                                                     (7U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                         >> 3U))) 
                                                    << 3U) 
                                                   | (((1U 
                                                        == 
                                                        (7U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                            >> 3U))) 
                                                       << 2U) 
                                                      | (((2U 
                                                           == 
                                                           (7U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                               >> 3U))) 
                                                          << 1U) 
                                                         | (0U 
                                                            == 
                                                            (7U 
                                                             & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                >> 3U)))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b 
        = ((0x40U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                     << 6U)) | ((0x20U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                                          >> 2U)) | 
                                ((0x10U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                                           >> 3U)) 
                                 | ((8U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                                           << 3U)) 
                                    | ((4U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                                              << 2U)) 
                                       | ((2U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                                                 >> 6U)) 
                                          | (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                                                   >> 7U))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__a 
        = (1U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__Vfuncout 
        = (1U & ((0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                  ? ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 6U)))))))
                  : ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__b)
                                          : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__a)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___158_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310183__88__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__b 
        = ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                      << 5U)) | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                       >> 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__b) 
                                         >> 8U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0474_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035719__189__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__b 
        = (0x20U | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                               << 5U)) | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__b) 
                                         >> 8U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0500_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035774__198__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__b 
        = (2U | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                            << 5U)) | (0x70U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                << 1U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__b) 
                                         >> 8U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0703_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036278__268__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b 
        = ((0x7000U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                       << 9U)) | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                             << 5U)) 
                                  | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                           >> 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__Vfuncout 
        = (0xfU & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                    ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b) 
                                                  >> 0xcU))))
                    : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__b)
                                               : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__a))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1966_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038740__433__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b 
        = (0x70U | ((0x7000U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                << 9U)) | ((0x700U 
                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                               << 5U)) 
                                           | (7U & 
                                              ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                               >> 3U)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__Vfuncout 
        = (0xfU & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                    ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b) 
                                                  >> 0xcU))))
                    : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__b)
                                               : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__a))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1988_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038793__442__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__b 
        = (0xd0U | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                               << 5U)) | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__b) 
                                         >> 8U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2105_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039052__483__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__b 
        = (0xe0U | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                               << 5U)) | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__b) 
                                         >> 8U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2119_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039091__493__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b 
        = (2U | ((0x7000U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                             << 9U)) | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                   << 5U)) 
                                        | (0x70U & 
                                           ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                            << 1U)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__Vfuncout 
        = (0xfU & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                    ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b) 
                                                  >> 0xcU))))
                    : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__b)
                                               : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__a))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2210_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039291__520__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b 
        = (2U | ((0x7000U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                             << 9U)) | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                   << 5U)) 
                                        | (0x70U & 
                                           ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                            << 1U)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__Vfuncout 
        = (0xfU & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                    ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b) 
                                                  >> 0xcU))))
                    : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__b)
                                               : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__a))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2235_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039354__532__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___447_ = 
        (((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___778_)) 
          & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___798_)) 
             & (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)))) 
         | ((7U != (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___798_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035093__133__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035093__133__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035093__133__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0177_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035093__133__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035150__143__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035150__143__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035150__143__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0197_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035150__143__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035234__154__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035234__154__Vfuncout 
        = (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035234__154__s));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0228_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035234__154__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035267__160__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035267__160__Vfuncout 
        = (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035267__160__s));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0239_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035267__160__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__Vfuncout 
        = (1U & ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s))
                  ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s))
                      ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s))
                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s)
                          : (IData)((2U != (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s)))))
                      : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s))
                  : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s))
                      ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s))
                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s)
                          : (IData)((2U != (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s)))))
                      : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0529_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035864__214__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036045__234__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036045__234__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036045__234__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0613_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036045__234__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036103__238__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036103__238__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036103__238__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0633_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036103__238__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036327__279__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036327__279__Vfuncout 
        = (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036327__279__s));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0719_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036327__279__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036422__290__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036422__290__Vfuncout 
        = (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036422__290__s));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0752_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036422__290__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036476__297__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036476__297__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036476__297__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036476__297__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0777_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036476__297__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036548__304__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036548__304__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036548__304__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036548__304__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0802_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036548__304__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039062__486__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039062__486__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039062__486__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039062__486__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039062__486__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2108_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039062__486__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039101__496__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039101__496__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039101__496__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039101__496__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039101__496__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2122_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039101__496__Vfuncout;
    __Vfunc___03369__0__s = (((0x1ffeU == (0x1fffU 
                                           & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                              << 2U) | (((0x1ffdU == 
                                          (0x1fffU 
                                           & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                         << 1U) | (0x1ffcU 
                                                   == 
                                                   (0x1fffU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))));
    __Vfunc___03369__0__Vfuncout = (1U == (1U & (IData)(__Vfunc___03369__0__s)));
    vlSelf->__PVT___101_ = __Vfunc___03369__0__Vfuncout;
    __Vfunc___03372__1__s = (((0x1ffeU == (0x1fffU 
                                           & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                              << 2U) | (((0x1ffdU == 
                                          (0x1fffU 
                                           & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                         << 1U) | (0x1ffcU 
                                                   == 
                                                   (0x1fffU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))));
    __Vfunc___03372__1__Vfuncout = (IData)((((IData)(__Vfunc___03372__1__s) 
                                             >> 1U) 
                                            & (1U != 
                                               (1U 
                                                & (IData)(__Vfunc___03372__1__s)))));
    vlSelf->__PVT___102_ = __Vfunc___03372__1__Vfuncout;
    __Vfunc___03375__2__s = (((0x1ffeU == (0x1fffU 
                                           & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                              << 2U) | (((0x1ffdU == 
                                          (0x1fffU 
                                           & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                         << 1U) | (0x1ffcU 
                                                   == 
                                                   (0x1fffU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))));
    __Vfunc___03375__2__Vfuncout = ((1U != (1U & (IData)(__Vfunc___03375__2__s))) 
                                    & (IData)((((IData)(__Vfunc___03375__2__s) 
                                                >> 2U) 
                                               & (2U 
                                                  != 
                                                  (2U 
                                                   & (IData)(__Vfunc___03375__2__s))))));
    vlSelf->__PVT___103_ = __Vfunc___03375__2__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038750__436__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038750__436__Vfuncout 
        = (IData)((8U == (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038750__436__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1969_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038750__436__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__s))
                      ? (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__s))))
                      : (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__s)))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1994_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038812__448__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038938__463__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038938__463__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038938__463__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038938__463__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2056_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038938__463__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039020__478__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039020__478__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039020__478__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039020__478__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2090_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039020__478__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039065__487__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039065__487__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039065__487__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2109_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039065__487__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039307__525__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039307__525__Vfuncout 
        = (IData)((8U == (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039307__525__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2215_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039307__525__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039370__537__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039370__537__Vfuncout 
        = (IData)((8U == (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039370__537__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2240_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039370__537__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039181__507__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039181__507__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039181__507__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039181__507__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2157_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039181__507__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039232__513__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039232__513__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039232__513__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039232__513__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2182_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039232__513__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__s)))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2213_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039301__523__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039364__535__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039364__535__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039364__535__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039364__535__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039364__535__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2238_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039364__535__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036643__315__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036643__315__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036643__315__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036643__315__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0848_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036643__315__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036665__320__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036665__320__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036665__320__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036665__320__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0856_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036665__320__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035982__231__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035982__231__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035982__231__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035982__231__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0580_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035982__231__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036143__242__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036143__242__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036143__242__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036143__242__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0654_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036143__242__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036170__247__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036170__247__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036170__247__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036170__247__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0664_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036170__247__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036196__252__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036196__252__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036196__252__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036196__252__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0673_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036196__252__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036223__257__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036223__257__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036223__257__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036223__257__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0683_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036223__257__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036249__262__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036249__262__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036249__262__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036249__262__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0692_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036249__262__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036291__272__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036291__272__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036291__272__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036291__272__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036291__272__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0707_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036291__272__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034926__111__s 
        = (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034926__111__Vfuncout 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034926__111__s;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0100_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034926__111__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035032__121__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035032__121__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035032__121__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0155_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035032__121__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035084__130__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035084__130__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035084__130__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035084__130__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0174_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035084__130__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035141__140__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035141__140__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035141__140__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035141__140__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0194_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035141__140__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035183__145__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035183__145__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035183__145__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035183__145__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0208_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035183__145__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s)))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0223_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035218__149__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s)))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0235_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035253__156__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035845__209__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035845__209__Vfuncout 
        = (1U & ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035845__209__s))
                  ? (IData)((8U == (0xfU & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035845__209__s))))
                  : (IData)((8U == (0xfU & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035845__209__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0524_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035845__209__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036039__232__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036039__232__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036039__232__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036039__232__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0611_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036039__232__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036098__236__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036098__236__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036098__236__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036098__236__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0631_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036098__236__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036137__240__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036137__240__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036137__240__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0652_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036137__240__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036164__245__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036164__245__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036164__245__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0662_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036164__245__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036190__250__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036190__250__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036190__250__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0671_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036190__250__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036217__255__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036217__255__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036217__255__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0681_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036217__255__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036243__260__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036243__260__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036243__260__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0690_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036243__260__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036268__264__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036268__264__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036268__264__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036268__264__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0699_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036268__264__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s)))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0714_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036309__274__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s)))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s))
                      ? (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s))
                      : (((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s) 
                          >> 1U) | (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0747_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036407__285__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036634__312__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036634__312__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036634__312__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0845_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036634__312__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036656__317__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036656__317__Vfuncout 
        = (1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036656__317__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0853_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036656__317__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__b 
        = (6U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                        >> 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2180_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039226__511__Vfuncout;
    vlSelf->__PVT___049_ = (1U & ((~ (IData)(vlSelf->__PVT___413_)) 
                                  | (~ (IData)(vlSelf->__PVT___412_))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___610_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___758_) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___760_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038808__447__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038808__447__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038808__447__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038808__447__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038808__447__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1993_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038808__447__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__s))
                      ? (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__s))))
                      : (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__s)))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1946_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038695__428__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038753__437__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038753__437__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038753__437__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038753__437__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038753__437__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1970_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038753__437__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039068__488__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039068__488__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039068__488__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039068__488__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039068__488__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2110_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039068__488__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039104__497__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039104__497__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039104__497__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039104__497__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039104__497__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2123_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039104__497__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039125__500__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039125__500__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039125__500__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039125__500__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039125__500__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2130_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039125__500__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039235__514__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039235__514__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039235__514__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039235__514__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2183_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039235__514__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039310__526__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039310__526__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039310__526__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039310__526__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039310__526__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2216_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039310__526__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039373__538__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039373__538__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039373__538__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039373__538__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039373__538__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2241_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039373__538__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036596__309__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036596__309__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036596__309__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036596__309__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036596__309__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0825_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036596__309__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036324__278__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036324__278__Vfuncout 
        = (IData)((8U == (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036324__278__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0718_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036324__278__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036419__289__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036419__289__Vfuncout 
        = (IData)((8U == (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036419__289__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0751_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036419__289__Vfuncout;
    vlSelf->__PVT__ctrl_b__DOT__p2_qa_s = (1U & (~ 
                                                 ((IData)(vlSelf->__PVT__ctrl_b__DOT___81_) 
                                                  & (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_9cd__DOT___11_))));
    vlSelf->__PVT__ctrl_b__DOT__p1_qa_s = (1U & (~ 
                                                 ((IData)(vlSelf->__PVT__ctrl_b__DOT___77_) 
                                                  & (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_9cd__DOT___11_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038615__415__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038615__415__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038615__415__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038615__415__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038615__415__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1918_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038615__415__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038679__423__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038679__423__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038679__423__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038679__423__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038679__423__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1941_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038679__423__Vfuncout;
    __Vfunc___03691__30__s = (((0xeU == (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                               << 0xcU) | (((0xbU == 
                                             (0xfU 
                                              & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                            << 0xbU) 
                                           | (((0xaU 
                                                == 
                                                (0xfU 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                               << 0xaU) 
                                              | (((9U 
                                                   == 
                                                   (0xfU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                  << 9U) 
                                                 | (((8U 
                                                      == 
                                                      (0xfU 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                     << 8U) 
                                                    | (((7U 
                                                         == 
                                                         (0xfU 
                                                          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                        << 7U) 
                                                       | (((6U 
                                                            == 
                                                            (0xfU 
                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                           << 6U) 
                                                          | (((5U 
                                                               == 
                                                               (0xfU 
                                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                              << 5U) 
                                                             | (((4U 
                                                                  == 
                                                                  (0xfU 
                                                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                 << 4U) 
                                                                | (((3U 
                                                                     == 
                                                                     (0xfU 
                                                                      & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                    << 3U) 
                                                                   | (((2U 
                                                                        == 
                                                                        (0xfU 
                                                                         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                       << 2U) 
                                                                      | (((1U 
                                                                           == 
                                                                           (0xfU 
                                                                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                          << 1U) 
                                                                         | (0U 
                                                                            == 
                                                                            (0xfU 
                                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))))))))))))));
    __Vfunc___03691__30__Vfuncout = (1U & ((~ (((((
                                                   (((1U 
                                                      == 
                                                      (1U 
                                                       & (IData)(__Vfunc___03691__30__s))) 
                                                     | (2U 
                                                        == 
                                                        (2U 
                                                         & (IData)(__Vfunc___03691__30__s)))) 
                                                    | (4U 
                                                       == 
                                                       (4U 
                                                        & (IData)(__Vfunc___03691__30__s)))) 
                                                   | (8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03691__30__s)))) 
                                                  | (0x10U 
                                                     == 
                                                     (0x10U 
                                                      & (IData)(__Vfunc___03691__30__s)))) 
                                                 | (0x20U 
                                                    == 
                                                    (0x20U 
                                                     & (IData)(__Vfunc___03691__30__s)))) 
                                                | (0x40U 
                                                   == 
                                                   (0x40U 
                                                    & (IData)(__Vfunc___03691__30__s)))) 
                                               | (0x80U 
                                                  == 
                                                  (0x80U 
                                                   & (IData)(__Vfunc___03691__30__s))))) 
                                           | ((1U == 
                                               (1U 
                                                & (IData)(__Vfunc___03691__30__s))) 
                                              | ((2U 
                                                  == 
                                                  (2U 
                                                   & (IData)(__Vfunc___03691__30__s))) 
                                                 | ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03691__30__s))) 
                                                    | ((8U 
                                                        == 
                                                        (8U 
                                                         & (IData)(__Vfunc___03691__30__s))) 
                                                       | ((0x10U 
                                                           == 
                                                           (0x10U 
                                                            & (IData)(__Vfunc___03691__30__s))) 
                                                          | ((0x20U 
                                                              == 
                                                              (0x20U 
                                                               & (IData)(__Vfunc___03691__30__s))) 
                                                             | (0x40U 
                                                                == 
                                                                (0x40U 
                                                                 & (IData)(__Vfunc___03691__30__s)))))))))));
    vlSelf->__PVT___269_ = __Vfunc___03691__30__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035860__213__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035860__213__Vfuncout 
        = (IData)((0x10U == (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035860__213__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0528_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035860__213__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036042__233__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036042__233__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036042__233__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036042__233__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0612_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036042__233__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036473__296__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036473__296__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036473__296__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036473__296__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036473__296__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0776_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036473__296__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036545__303__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036545__303__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036545__303__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036545__303__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036545__303__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0801_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036545__303__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035221__150__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035221__150__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035221__150__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035221__150__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035221__150__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0224_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035221__150__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035256__157__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035256__157__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035256__157__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035256__157__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035256__157__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0236_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035256__157__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035002__120__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035002__120__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035002__120__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035002__120__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0139_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035002__120__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035042__125__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035042__125__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035042__125__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035042__125__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0159_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035042__125__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035110__136__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035110__136__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035110__136__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035110__136__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0183_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035110__136__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035127__139__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035127__139__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035127__139__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035127__139__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0189_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035127__139__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035153__144__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035153__144__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035153__144__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035153__144__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035153__144__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0198_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035153__144__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__s))
                      ? (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__s))))
                      : (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__s)))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0241_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035274__162__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035316__167__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035316__167__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035316__167__s))) 
           & ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035316__167__s))) 
              | (4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035316__167__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0255_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035316__167__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__Vfuncout 
        = (1U & ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s))
                  ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s))
                      ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s))))
                      : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s))
                          ? (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s))))
                          : (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s))))))
                  : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s))
                      ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s))))
                      : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0298_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035427__179__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035732__193__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035732__193__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035732__193__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035732__193__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035732__193__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0478_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035732__193__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035787__202__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035787__202__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035787__202__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035787__202__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035787__202__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0504_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035787__202__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035826__207__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035826__207__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035826__207__s))) 
           & ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035826__207__s))) 
              | (4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035826__207__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0517_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035826__207__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__Vfuncout 
        = (1U & ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                  ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                      ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                              ? (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                              : (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s)))
                          : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s)))))
                      : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                              ? (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                              : (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s)))
                          : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))))))
                  : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                      ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                              ? (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                              : (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s)))
                          : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s)))))
                      : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                              ? (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))
                              : (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s)))
                          : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__s))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0530_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035868__215__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__s))
                      ? (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__s))))
                      : (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__s)))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0721_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036334__281__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__s))
                      ? (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__s))))
                      : (IData)((0U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__s)))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0754_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036429__292__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036600__310__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036600__310__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036600__310__s))) 
           & ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036600__310__s))) 
              | (4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036600__310__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0826_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036600__310__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036668__321__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036668__321__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036668__321__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036668__321__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0857_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036668__321__Vfuncout;
    vlSelf->inst_t80__DOT__u0__DOT____VdfgTmp_hbde73ddd__0 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT___55_) 
            << 8U) | (0xffU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___740_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___621_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_) 
         == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___802_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s 
        = (((7U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                          >> 3U))) << 7U) | (((6U == 
                                               (7U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                   >> 3U))) 
                                              << 6U) 
                                             | (((5U 
                                                  == 
                                                  (7U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                      >> 3U))) 
                                                 << 5U) 
                                                | (((4U 
                                                     == 
                                                     (7U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                         >> 3U))) 
                                                    << 4U) 
                                                   | (((3U 
                                                        == 
                                                        (7U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                            >> 3U))) 
                                                       << 3U) 
                                                      | (((2U 
                                                           == 
                                                           (7U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                               >> 3U))) 
                                                          << 2U) 
                                                         | (((1U 
                                                              == 
                                                              (7U 
                                                               & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                  >> 3U))) 
                                                             << 1U) 
                                                            | (0U 
                                                               == 
                                                               (7U 
                                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                   >> 3U))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__b 
        = ((0x80U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)) 
           | ((0x40U & ((~ ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                            >> 7U)) << 6U)) | ((0x20U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                   << 3U)) 
                                               | ((0x10U 
                                                   & ((~ 
                                                       ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                        >> 2U)) 
                                                      << 4U)) 
                                                  | ((8U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                         << 3U)) 
                                                     | ((4U 
                                                         & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)) 
                                                            << 2U)) 
                                                        | ((2U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                               >> 5U)) 
                                                           | (1U 
                                                              & (~ 
                                                                 ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                                  >> 6U))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__Vfuncout 
        = (((((((((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s))) 
                  | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))) 
                 | (4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))) 
                | (8U == (8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))) 
               | (0x10U == (0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))) 
              | (0x20U == (0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))) 
             | (0x40U == (0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))) 
            | (0x80U == (0x80U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))) 
           & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))
               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__b)
               : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))
                   ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__b) 
                      >> 1U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))
                                 ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__b) 
                                    >> 2U) : ((8U == 
                                               (8U 
                                                & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))
                                               ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__b) 
                                                  >> 3U)
                                               : ((0x10U 
                                                   == 
                                                   (0x10U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))
                                                   ? 
                                                  ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__b) 
                                                   >> 4U)
                                                   : 
                                                  ((0x20U 
                                                    == 
                                                    (0x20U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))
                                                    ? 
                                                   ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__b) 
                                                    >> 5U)
                                                    : 
                                                   ((0x40U 
                                                     == 
                                                     (0x40U 
                                                      & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__s)))
                                                     ? 
                                                    ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__b) 
                                                     >> 6U)
                                                     : 
                                                    ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__b) 
                                                     >> 7U)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0628_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036088__235__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___501_ = 
        ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
         & (3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b 
        = (((3U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                          >> 4U))) << 3U) | ((3U == 
                                              (3U & 
                                               ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 4U))) 
                                             << 2U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b) 
                                 >> 1U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b) 
                                                >> 2U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b) 
                                 >> 1U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b) 
                                                >> 3U))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b) 
                                 >> 1U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b) 
                                                >> 2U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b) 
                                 >> 1U)) : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__s) 
                                            & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__b))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1921_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038623__418__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__b 
        = (3U & (- (IData)((3U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                         >> 4U))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0211_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035191__148__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__b 
        = ((3U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                         >> 4U))) << 1U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__b) 
                         >> 1U) : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__s) 
                                            & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__b)) 
                                           >> 2U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0275_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035365__171__Vfuncout;
    vlSelf->__PVT__io_decode_s = ((6U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                         >> 4U)) | (IData)(vlSelf->__PVT__inst_t80__DOT___63_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___379_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___772_)) 
         & (0U != (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___768_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s))
                        ? 0U : 7U) : 0U) : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s))
                                             ? ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s))
                                                 ? 0U
                                                 : 7U)
                                             : 0U))
            : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s))
                        ? 0U : 7U) : 0U) : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s))
                                             ? ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__s))
                                                 ? 0U
                                                 : 7U)
                                             : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1964_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038735__431__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s))
                        ? 0U : 7U) : 0U) : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s))
                                             ? ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s))
                                                 ? 0U
                                                 : 7U)
                                             : 0U))
            : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s))
                        ? 0U : 7U) : 0U) : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s))
                                             ? ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__s))
                                                 ? 0U
                                                 : 7U)
                                             : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1986_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038788__440__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038921__457__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038921__457__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038921__457__s)))
            ? 5U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038921__457__s)))
                     ? 4U : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2050_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038921__457__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039003__472__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039003__472__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039003__472__s)))
            ? 5U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039003__472__s)))
                     ? 4U : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2084_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039003__472__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039048__481__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039048__481__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039048__481__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039048__481__s)))
                     ? 7U : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2103_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039048__481__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039087__491__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039087__491__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039087__491__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039087__491__s)))
                     ? 7U : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2117_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039087__491__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__b 
        = (((6U != (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                          >> 3U))) ? (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                            >> 3U))
             : 0U) << 3U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__b) 
                         >> 3U) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2155_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039175__505__Vfuncout;
    vlSelf->__PVT___066_ = ((IData)(vlSelf->__PVT___412_) 
                            | (IData)(vlSelf->__PVT___415_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s))
                    ? 0U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s))
                             ? 0U : 5U)) : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s))
                                             ? 0U : 
                                            ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s))
                                              ? 0U : 4U)))
            : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s))
                    ? 0U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__s))
                             ? 0U : 5U)) : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0226_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035227__152__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035609__181__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035609__181__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035609__181__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035609__181__s)))
                     ? 7U : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0414_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035609__181__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035961__224__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035961__224__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035961__224__s)))
            ? 5U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035961__224__s)))
                     ? 4U : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0573_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035961__224__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__s 
        = (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__b 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__Vfuncout 
        = ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__s)
            ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__b)
            : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0102_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034931__113__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__b 
        = (0x38U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__b) 
                         >> 3U) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0119_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034962__115__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__b 
        = ((((3U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                           >> 4U))) ? 7U : (6U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                  >> 3U))) 
            << 6U) | (((3U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                     >> 4U))) ? 3U : 
                       (1U | (6U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                    >> 3U)))) << 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__b) 
                                       >> 6U) : 0U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0274_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035363__170__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__b 
        = (0x38U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__b) 
                                       >> 6U) : 0U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0472_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035714__187__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__b 
        = (0x38U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__b) 
                                       >> 6U) : 0U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0498_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035769__196__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039050__482__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039050__482__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039050__482__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039050__482__s)))
                     ? 6U : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2104_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039050__482__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039089__492__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039089__492__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039089__492__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039089__492__s)))
                     ? 6U : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2118_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039089__492__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__b 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__b) 
                         >> 3U) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2179_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039224__510__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038747__435__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038747__435__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038747__435__s))
                  ? (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038747__435__s))))
                  : (IData)((4U == (7U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038747__435__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1968_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038747__435__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0437_ 
        = ((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
            ? (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))
            : 0U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__b 
        = (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__b) 
                         >> 3U) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0136_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034994__117__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__b 
        = (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__b) 
                         >> 3U) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0156_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035034__122__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__b 
        = (0x38U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                    << 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__b) 
                         >> 3U) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0415_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035611__182__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039184__508__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039184__508__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039184__508__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039184__508__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2158_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039184__508__Vfuncout;
    vlSelf->__VdfgTmp_h7bf8ddc8__0 = ((7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                      & (1U != (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_)));
    vlSelf->__VdfgTmp_h426b99eb__0 = ((6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                      & ((0x36U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                         | (0xcbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))));
    vlSelf->__PVT___212_ = ((~ (IData)(vlSelf->__PVT__inst_t80__DOT___63_)) 
                            & (IData)(vlSelf->__PVT___434_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___510_ = 
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__regs__DOT__regsh
        [vlSelf->__PVT__inst_t80__DOT__u0__DOT___736_];
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___511_ = 
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__regs__DOT__regsl
        [vlSelf->__PVT__inst_t80__DOT__u0__DOT___736_];
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s))
                        ? 0U : 6U) : 0U) : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s))
                                             ? ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s))
                                                 ? 0U
                                                 : 6U)
                                             : 0U))
            : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s))
                        ? 0U : 6U) : 0U) : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s))
                                             ? ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__s))
                                                 ? 0U
                                                 : 6U)
                                             : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1965_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038738__432__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s))
                        ? 0U : 6U) : 0U) : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s))
                                             ? ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s))
                                                 ? 0U
                                                 : 6U)
                                             : 0U))
            : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s))
                        ? 0U : 6U) : 0U) : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s))
                                             ? ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__s))
                                                 ? 0U
                                                 : 6U)
                                             : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1987_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038791__441__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                        ? 0xaU : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                                         ? 0xaU : 0U))
                : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                        ? 0xaU : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                                         ? 0xaU : 0U)))
            : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                        ? 0xaU : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                                         ? 0xaU : 0U))
                : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                        ? 0xaU : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__s))
                                         ? 0xaU : 0U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2209_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039289__519__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                        ? 0xaU : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                                         ? 0xaU : 0U))
                : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                        ? 0xaU : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                                         ? 0xaU : 0U)))
            : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                        ? 0xaU : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                                         ? 0xaU : 0U))
                : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                        ? 0xaU : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__s))
                                         ? 0xaU : 0U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2234_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039352__531__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b 
        = ((((3U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                           >> 4U))) ? 9U : (6U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                  >> 3U))) 
            << 8U) | (((3U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                     >> 4U))) ? 8U : 
                       (1U | (6U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                    >> 3U)))) << 4U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__Vfuncout 
        = (0xfU & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                    ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b) 
                                                  >> 0xcU))))
                    : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__b)
                                               : 0U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1942_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038681__424__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                        ? 7U : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                                       ? 7U : 6U)) : 
               ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                     ? 7U : 6U) : 7U)) : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                                           ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                                                   ? 7U
                                                   : 6U)
                                               : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                                                   ? 7U
                                                   : 6U))
                                           : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__s))
                                                   ? 7U
                                                   : 6U)
                                               : 7U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1922_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038627__419__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                        ? 7U : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                                       ? 7U : 6U)) : 
               ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                     ? 7U : 6U) : 7U)) : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                                           ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                                                   ? 7U
                                                   : 6U)
                                               : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                                                   ? 7U
                                                   : 6U))
                                           : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__s))
                                                   ? 7U
                                                   : 6U)
                                               : 7U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1943_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038685__425__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                        ? 2U : 1U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                                       ? 2U : 7U)) : 
               ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                     ? 2U : 1U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                                    ? 2U : 7U))) : 
           ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                     ? 2U : 1U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                                    ? 2U : 7U)) : (
                                                   (2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                                                     ? 2U
                                                     : 1U)
                                                    : 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__s))
                                                     ? 2U
                                                     : 7U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1967_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038744__434__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                        ? 2U : 7U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                                       ? 2U : 7U)) : 
               ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                     ? 2U : 7U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                                    ? 2U : 7U))) : 
           ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                     ? 2U : 7U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                                    ? 2U : 7U)) : (
                                                   (2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                                                     ? 2U
                                                     : 7U)
                                                    : 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__s))
                                                     ? 2U
                                                     : 7U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1992_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038805__446__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039059__485__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039059__485__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039059__485__s)))
            ? 2U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039059__485__s)))
                     ? 2U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2107_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039059__485__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039098__495__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039098__495__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039098__495__s)))
            ? 2U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039098__495__s)))
                     ? 2U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2121_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039098__495__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039122__499__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039122__499__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039122__499__s)))
            ? 5U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039122__499__s)))
                     ? 5U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2129_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039122__499__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039178__506__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039178__506__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039178__506__s)))
            ? 0U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2156_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039178__506__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039229__512__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039229__512__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039229__512__s)))
            ? 0U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2181_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039229__512__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                        ? 0U : 2U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                                       ? 0U : 7U)) : 
               ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                     ? 0U : 2U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                                    ? 0U : 7U))) : 
           ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                     ? 0U : 2U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                                    ? 0U : 7U)) : (
                                                   (2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                                                     ? 0U
                                                     : 2U)
                                                    : 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__s))
                                                     ? 0U
                                                     : 7U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2212_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039298__522__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                        ? 2U : 0U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                                       ? 2U : 7U)) : 
               ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                     ? 2U : 0U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                                    ? 2U : 7U))) : 
           ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
             ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                     ? 2U : 0U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                                    ? 2U : 7U)) : (
                                                   (2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                                                     ? 2U
                                                     : 0U)
                                                    : 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__s))
                                                     ? 2U
                                                     : 7U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2237_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039361__534__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034965__116__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034965__116__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034965__116__s)))
            ? 2U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0120_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034965__116__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034999__119__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034999__119__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034999__119__s)))
            ? 2U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0138_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____034999__119__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035039__124__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035039__124__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035039__124__s)))
            ? 2U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0158_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035039__124__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035056__127__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035056__127__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035056__127__s)))
            ? 0U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0164_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035056__127__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035070__129__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035070__129__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035070__129__s)))
            ? 1U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0169_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035070__129__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035090__132__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035090__132__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035090__132__s)))
            ? 7U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035090__132__s)))
                     ? 6U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0176_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035090__132__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035107__135__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035107__135__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035107__135__s)))
            ? 0U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0182_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035107__135__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035124__138__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035124__138__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035124__138__s)))
            ? 1U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0188_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035124__138__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035147__142__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035147__142__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035147__142__s)))
            ? 7U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035147__142__s)))
                     ? 6U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0196_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035147__142__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                        ? 7U : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                                       ? 7U : 6U)) : 
               ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                     ? 7U : 6U) : 7U)) : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                                           ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                                                   ? 7U
                                                   : 6U)
                                               : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                                                   ? 7U
                                                   : 6U))
                                           : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__s))
                                                   ? 7U
                                                   : 6U)
                                               : 7U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0227_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035231__153__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                        ? 7U : 6U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                                       ? 7U : 6U)) : 
               ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                     ? 7U : 6U) : 7U)) : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                                           ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                                                   ? 7U
                                                   : 6U)
                                               : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                                                   ? 7U
                                                   : 6U))
                                           : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__s))
                                                   ? 7U
                                                   : 6U)
                                               : 7U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0238_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035264__159__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035312__166__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035312__166__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035312__166__s)))
            ? 5U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035312__166__s)))
                     ? 5U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0254_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035312__166__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035369__172__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035369__172__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035369__172__s)))
            ? 5U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035369__172__s)))
                     ? 5U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0276_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035369__172__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__Vfuncout 
        = ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s))
            ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s))
                ? 5U : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s))
                         ? 5U : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s))
                                  ? 5U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s))
                                           ? 5U : 7U))))
            : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s))
                ? 5U : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s))
                         ? 5U : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s))
                                  ? 5U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__s))
                                           ? 5U : 7U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0297_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035423__178__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035617__184__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035617__184__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035617__184__s)))
            ? 2U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0417_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035617__184__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035729__192__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035729__192__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035729__192__s)))
            ? 2U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035729__192__s)))
                     ? 2U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0477_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035729__192__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035784__201__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035784__201__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035784__201__s)))
            ? 2U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035784__201__s)))
                     ? 2U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0503_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035784__201__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035822__206__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035822__206__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035822__206__s)))
            ? 5U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035822__206__s)))
                     ? 5U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0516_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035822__206__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__Vfuncout 
        = ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
            ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                        ? 5U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                 ? 5U : 7U)) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                                 ? 5U
                                                 : 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                                  ? 5U
                                                  : 7U)))
                : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                        ? 5U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                 ? 5U : 7U)) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                                 ? 5U
                                                 : 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                                  ? 5U
                                                  : 7U))))
            : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                        ? 5U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                 ? 5U : 7U)) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                                 ? 5U
                                                 : 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                                  ? 5U
                                                  : 7U)))
                : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                        ? 5U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                 ? 5U : 7U)) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                                 ? 5U
                                                 : 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__s))
                                                  ? 5U
                                                  : 7U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0527_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035857__212__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                        ? 7U : 5U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                                       ? 7U : 5U)) : 
               ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                     ? 7U : 5U) : 7U)) : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                                           ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                                                   ? 7U
                                                   : 5U)
                                               : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                                                   ? 7U
                                                   : 5U))
                                           : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__s))
                                                   ? 7U
                                                   : 5U)
                                               : 7U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0717_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036321__277__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036470__295__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036470__295__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036470__295__s)))
            ? 5U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036470__295__s)))
                     ? 5U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0775_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036470__295__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036593__308__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036593__308__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036593__308__s)))
            ? 5U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036593__308__s)))
                     ? 5U : 7U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0824_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036593__308__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036640__314__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036640__314__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036640__314__s)))
            ? 4U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0847_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036640__314__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036662__319__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036662__319__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036662__319__s)))
            ? 4U : 7U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0855_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036662__319__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035104__134__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035104__134__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035104__134__s)))
            ? 7U : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0181_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035104__134__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035121__137__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035121__137__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035121__137__s)))
            ? 7U : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0187_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035121__137__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035144__141__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035144__141__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035144__141__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035144__141__s)))
                     ? 7U : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0195_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035144__141__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                        ? 0U : 5U) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                                       ? 0U : 4U)) : 
               ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                 ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                     ? 0U : 5U) : 0U)) : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                                           ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                                                   ? 0U
                                                   : 5U)
                                               : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                                                   ? 0U
                                                   : 4U))
                                           : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                                               ? ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__s))
                                                   ? 0U
                                                   : 5U)
                                               : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0237_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035260__158__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__Vfuncout 
        = ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
            ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                            ? 0U : 5U) : 0U) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                                                 ? 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                                                  ? 0U
                                                  : 5U)
                                                 : 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                                                  ? 0U
                                                  : 4U)))
                : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                            ? 0U : 5U) : 0U) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                                                 ? 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                                                  ? 0U
                                                  : 5U)
                                                 : 0U)))
            : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                            ? 0U : 5U) : 0U) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                                                 ? 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                                                  ? 0U
                                                  : 5U)
                                                 : 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                                                  ? 0U
                                                  : 4U)))
                : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                            ? 0U : 5U) : 0U) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                                                 ? 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__s))
                                                  ? 0U
                                                  : 5U)
                                                 : 0U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0296_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035417__177__Vfuncout;
    vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035717__188__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
}
