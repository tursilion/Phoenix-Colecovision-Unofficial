# Verilated -*- Makefile -*-
# DESCRIPTION: Verilator output: Make include file with class lists
#
# This file lists generated Verilated files, for including in higher level makefiles.
# See Vsim_top.mk for the caller.

### Switches...
# C11 constructs required?  0/1 (always on now)
VM_C11 = 1
# Timing enabled?  0/1
VM_TIMING = 0
# Coverage output mode?  0/1 (from --coverage)
VM_COVERAGE = 0
# Parallel builds?  0/1 (from --output-split)
VM_PARALLEL_BUILDS = 1
# Tracing output mode?  0/1 (from --trace/--trace-fst)
VM_TRACE = 0
# Tracing output mode in VCD format?  0/1 (from --trace)
VM_TRACE_VCD = 0
# Tracing output mode in FST format?  0/1 (from --trace-fst)
VM_TRACE_FST = 0

### Object file lists...
# Generated module classes, fast-path, compile with highest optimization
VM_CLASSES_FAST += \
	Vsim_top \
	Vsim_top___024root__DepSet_h25cf915e__0 \
	Vsim_top___024root__DepSet_h9a1654b3__0 \
	Vsim_top_colecovision__DepSet_h76d109b7__0 \
	Vsim_top_colecovision__DepSet_h76d109b7__1 \
	Vsim_top_colecovision__DepSet_hc90fdbdc__0 \
	Vsim_top_colecovision__DepSet_hc90fdbdc__1 \
	Vsim_top_colecovision__DepSet_hc90fdbdc__2 \
	Vsim_top_colecovision__DepSet_hc90fdbdc__3 \
	Vsim_top_colecovision__DepSet_hc90fdbdc__4 \
	Vsim_top_vdp_spy__DepSet_hb4272cbf__0 \
	Vsim_top_vdp_spy__DepSet_h0bfdfed4__0 \

# Generated module classes, non-fast-path, compile with low/medium optimization
VM_CLASSES_SLOW += \
	Vsim_top___024root__Slow \
	Vsim_top___024root__DepSet_h25cf915e__0__Slow \
	Vsim_top___024root__DepSet_h9a1654b3__0__Slow \
	Vsim_top_sim_top__Slow \
	Vsim_top_sim_top__DepSet_hd7f4482f__0__Slow \
	Vsim_top_colecovision__Slow \
	Vsim_top_colecovision__DepSet_h76d109b7__0__Slow \
	Vsim_top_colecovision__DepSet_h76d109b7__1__Slow \
	Vsim_top_colecovision__DepSet_h76d109b7__2__Slow \
	Vsim_top_colecovision__DepSet_h76d109b7__3__Slow \
	Vsim_top_colecovision__DepSet_h76d109b7__4__Slow \
	Vsim_top_colecovision__DepSet_hc90fdbdc__0__Slow \
	Vsim_top_colecovision__DepSet_hc90fdbdc__1__Slow \
	Vsim_top_colecovision__DepSet_hc90fdbdc__2__Slow \
	Vsim_top_colecovision__DepSet_hc90fdbdc__3__Slow \
	Vsim_top_f18a_core__Slow \
	Vsim_top_f18a_core__DepSet_hda5ce571__0__Slow \
	Vsim_top_vdp_spy__Slow \
	Vsim_top_vdp_spy__DepSet_h0bfdfed4__0__Slow \

# Generated support classes, fast-path, compile with highest optimization
VM_SUPPORT_FAST += \
	Vsim_top__Dpi \

# Generated support classes, non-fast-path, compile with low/medium optimization
VM_SUPPORT_SLOW += \
	Vsim_top__Syms \

# Global classes, need linked once per executable, fast-path, compile with highest optimization
VM_GLOBAL_FAST += \
	verilated \
	verilated_dpi \
	verilated_threads \

# Global classes, need linked once per executable, non-fast-path, compile with low/medium optimization
VM_GLOBAL_SLOW += \


# Verilated -*- Makefile -*-
