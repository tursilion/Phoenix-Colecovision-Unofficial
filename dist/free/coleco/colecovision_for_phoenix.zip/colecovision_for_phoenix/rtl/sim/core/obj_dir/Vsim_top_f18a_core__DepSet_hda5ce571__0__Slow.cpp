// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vsim_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vsim_top__Syms.h"
#include "Vsim_top_f18a_core.h"

VL_ATTR_COLD void Vsim_top_f18a_core___ctor_var_reset(Vsim_top_f18a_core* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+          Vsim_top_f18a_core___ctor_var_reset\n"); );
    // Body
    vlSelf->__PVT__clk_100m0_i = VL_RAND_RESET_I(1);
    vlSelf->__PVT__clk_25m0_i = VL_RAND_RESET_I(1);
    vlSelf->__PVT__reset_n_i = VL_RAND_RESET_I(1);
    vlSelf->__PVT__mode_i = VL_RAND_RESET_I(1);
    vlSelf->__PVT__csw_n_i = VL_RAND_RESET_I(1);
    vlSelf->__PVT__csr_n_i = VL_RAND_RESET_I(1);
    vlSelf->__PVT__cd_i = VL_RAND_RESET_I(8);
    vlSelf->__PVT__sprite_max_i = VL_RAND_RESET_I(1);
    vlSelf->__PVT__scanlines_i = VL_RAND_RESET_I(1);
    vlSelf->__PVT__spi_miso_i = VL_RAND_RESET_I(1);
    vlSelf->__PVT__int_n_o = VL_RAND_RESET_I(1);
    vlSelf->__PVT__cd_o = VL_RAND_RESET_I(8);
    vlSelf->__PVT__blank_o = VL_RAND_RESET_I(1);
    vlSelf->__PVT__hsync_o = VL_RAND_RESET_I(1);
    vlSelf->__PVT__vsync_o = VL_RAND_RESET_I(1);
    vlSelf->__PVT__red_o = VL_RAND_RESET_I(4);
    vlSelf->__PVT__grn_o = VL_RAND_RESET_I(4);
    vlSelf->__PVT__blu_o = VL_RAND_RESET_I(4);
    vlSelf->__PVT__spi_clk_o = VL_RAND_RESET_I(1);
    vlSelf->__PVT__spi_cs_o = VL_RAND_RESET_I(1);
    vlSelf->__PVT__spi_mosi_o = VL_RAND_RESET_I(1);
}
