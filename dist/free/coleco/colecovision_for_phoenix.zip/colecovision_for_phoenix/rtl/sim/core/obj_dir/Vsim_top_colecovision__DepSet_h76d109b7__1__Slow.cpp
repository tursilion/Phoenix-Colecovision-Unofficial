// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vsim_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vsim_top__Syms.h"
#include "Vsim_top__Syms.h"
#include "Vsim_top_colecovision.h"

VL_ATTR_COLD void Vsim_top_colecovision___stl_sequent__TOP__sim_top__cv__1(Vsim_top_colecovision* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vsim_top_colecovision___stl_sequent__TOP__sim_top__cv__1\n"); );
    // Init
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0736_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0736_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1166_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1166_ = 0;
    CData/*0:0*/ __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1559_;
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1559_ = 0;
    CData/*0:0*/ __VdfgTmp_h8a4cccd7__0;
    __VdfgTmp_h8a4cccd7__0 = 0;
    CData/*0:0*/ __Vfunc___03386__3__Vfuncout;
    __Vfunc___03386__3__Vfuncout = 0;
    CData/*7:0*/ __Vfunc___03386__3__b;
    __Vfunc___03386__3__b = 0;
    CData/*7:0*/ __Vfunc___03386__3__s;
    __Vfunc___03386__3__s = 0;
    CData/*0:0*/ __Vfunc___03387__4__Vfuncout;
    __Vfunc___03387__4__Vfuncout = 0;
    CData/*0:0*/ __Vfunc___03387__4__a;
    __Vfunc___03387__4__a = 0;
    CData/*7:0*/ __Vfunc___03387__4__b;
    __Vfunc___03387__4__b = 0;
    CData/*7:0*/ __Vfunc___03387__4__s;
    __Vfunc___03387__4__s = 0;
    CData/*7:0*/ __Vfunc___03390__6__Vfuncout;
    __Vfunc___03390__6__Vfuncout = 0;
    CData/*7:0*/ __Vfunc___03390__6__a;
    __Vfunc___03390__6__a = 0;
    QData/*63:0*/ __Vfunc___03390__6__b;
    __Vfunc___03390__6__b = 0;
    CData/*7:0*/ __Vfunc___03390__6__s;
    __Vfunc___03390__6__s = 0;
    CData/*0:0*/ __Vfunc___03407__13__Vfuncout;
    __Vfunc___03407__13__Vfuncout = 0;
    CData/*7:0*/ __Vfunc___03407__13__b;
    __Vfunc___03407__13__b = 0;
    CData/*7:0*/ __Vfunc___03407__13__s;
    __Vfunc___03407__13__s = 0;
    CData/*0:0*/ __Vfunc___03409__14__Vfuncout;
    __Vfunc___03409__14__Vfuncout = 0;
    CData/*7:0*/ __Vfunc___03409__14__b;
    __Vfunc___03409__14__b = 0;
    CData/*7:0*/ __Vfunc___03409__14__s;
    __Vfunc___03409__14__s = 0;
    CData/*0:0*/ __Vfunc___03411__15__Vfuncout;
    __Vfunc___03411__15__Vfuncout = 0;
    CData/*7:0*/ __Vfunc___03411__15__b;
    __Vfunc___03411__15__b = 0;
    CData/*7:0*/ __Vfunc___03411__15__s;
    __Vfunc___03411__15__s = 0;
    CData/*0:0*/ __Vfunc___03503__17__Vfuncout;
    __Vfunc___03503__17__Vfuncout = 0;
    CData/*5:0*/ __Vfunc___03503__17__s;
    __Vfunc___03503__17__s = 0;
    CData/*0:0*/ __Vfunc___03506__18__Vfuncout;
    __Vfunc___03506__18__Vfuncout = 0;
    CData/*5:0*/ __Vfunc___03506__18__s;
    __Vfunc___03506__18__s = 0;
    CData/*0:0*/ __Vfunc___03509__19__Vfuncout;
    __Vfunc___03509__19__Vfuncout = 0;
    CData/*5:0*/ __Vfunc___03509__19__s;
    __Vfunc___03509__19__s = 0;
    CData/*0:0*/ __Vfunc___03513__21__Vfuncout;
    __Vfunc___03513__21__Vfuncout = 0;
    CData/*5:0*/ __Vfunc___03513__21__s;
    __Vfunc___03513__21__s = 0;
    CData/*0:0*/ __Vfunc___03516__22__Vfuncout;
    __Vfunc___03516__22__Vfuncout = 0;
    CData/*5:0*/ __Vfunc___03516__22__s;
    __Vfunc___03516__22__s = 0;
    CData/*0:0*/ __Vfunc___03518__23__Vfuncout;
    __Vfunc___03518__23__Vfuncout = 0;
    CData/*5:0*/ __Vfunc___03518__23__b;
    __Vfunc___03518__23__b = 0;
    CData/*5:0*/ __Vfunc___03518__23__s;
    __Vfunc___03518__23__s = 0;
    CData/*0:0*/ __Vfunc___03699__37__Vfuncout;
    __Vfunc___03699__37__Vfuncout = 0;
    CData/*0:0*/ __Vfunc___03699__37__a;
    __Vfunc___03699__37__a = 0;
    SData/*12:0*/ __Vfunc___03699__37__b;
    __Vfunc___03699__37__b = 0;
    SData/*12:0*/ __Vfunc___03699__37__s;
    __Vfunc___03699__37__s = 0;
    CData/*0:0*/ __Vfunc___03700__38__Vfuncout;
    __Vfunc___03700__38__Vfuncout = 0;
    CData/*0:0*/ __Vfunc___03700__38__a;
    __Vfunc___03700__38__a = 0;
    SData/*12:0*/ __Vfunc___03700__38__b;
    __Vfunc___03700__38__b = 0;
    SData/*12:0*/ __Vfunc___03700__38__s;
    __Vfunc___03700__38__s = 0;
    CData/*0:0*/ __Vfunc___03719__43__Vfuncout;
    __Vfunc___03719__43__Vfuncout = 0;
    CData/*1:0*/ __Vfunc___03719__43__b;
    __Vfunc___03719__43__b = 0;
    CData/*1:0*/ __Vfunc___03719__43__s;
    __Vfunc___03719__43__s = 0;
    CData/*0:0*/ __Vfunc___03721__44__Vfuncout;
    __Vfunc___03721__44__Vfuncout = 0;
    CData/*1:0*/ __Vfunc___03721__44__b;
    __Vfunc___03721__44__b = 0;
    CData/*1:0*/ __Vfunc___03721__44__s;
    __Vfunc___03721__44__s = 0;
    CData/*0:0*/ __Vfunc___03722__45__Vfuncout;
    __Vfunc___03722__45__Vfuncout = 0;
    CData/*0:0*/ __Vfunc___03722__45__a;
    __Vfunc___03722__45__a = 0;
    CData/*1:0*/ __Vfunc___03722__45__b;
    __Vfunc___03722__45__b = 0;
    CData/*1:0*/ __Vfunc___03722__45__s;
    __Vfunc___03722__45__s = 0;
    CData/*3:0*/ __Vfunc___03723__46__Vfuncout;
    __Vfunc___03723__46__Vfuncout = 0;
    CData/*3:0*/ __Vfunc___03723__46__a;
    __Vfunc___03723__46__a = 0;
    CData/*7:0*/ __Vfunc___03723__46__b;
    __Vfunc___03723__46__b = 0;
    CData/*1:0*/ __Vfunc___03723__46__s;
    __Vfunc___03723__46__s = 0;
    CData/*7:0*/ __Vfunc___03725__47__Vfuncout;
    __Vfunc___03725__47__Vfuncout = 0;
    SData/*15:0*/ __Vfunc___03725__47__b;
    __Vfunc___03725__47__b = 0;
    CData/*1:0*/ __Vfunc___03725__47__s;
    __Vfunc___03725__47__s = 0;
    CData/*0:0*/ __Vfunc___03726__48__Vfuncout;
    __Vfunc___03726__48__Vfuncout = 0;
    CData/*0:0*/ __Vfunc___03726__48__a;
    __Vfunc___03726__48__a = 0;
    CData/*1:0*/ __Vfunc___03726__48__b;
    __Vfunc___03726__48__b = 0;
    CData/*1:0*/ __Vfunc___03726__48__s;
    __Vfunc___03726__48__s = 0;
    CData/*0:0*/ __Vfunc___03728__49__Vfuncout;
    __Vfunc___03728__49__Vfuncout = 0;
    CData/*1:0*/ __Vfunc___03728__49__b;
    __Vfunc___03728__49__b = 0;
    CData/*1:0*/ __Vfunc___03728__49__s;
    __Vfunc___03728__49__s = 0;
    CData/*0:0*/ __Vfunc___03729__50__Vfuncout;
    __Vfunc___03729__50__Vfuncout = 0;
    CData/*0:0*/ __Vfunc___03729__50__a;
    __Vfunc___03729__50__a = 0;
    CData/*1:0*/ __Vfunc___03729__50__b;
    __Vfunc___03729__50__b = 0;
    CData/*1:0*/ __Vfunc___03729__50__s;
    __Vfunc___03729__50__s = 0;
    CData/*0:0*/ __Vfunc___03730__51__Vfuncout;
    __Vfunc___03730__51__Vfuncout = 0;
    CData/*0:0*/ __Vfunc___03730__51__a;
    __Vfunc___03730__51__a = 0;
    CData/*1:0*/ __Vfunc___03730__51__b;
    __Vfunc___03730__51__b = 0;
    CData/*1:0*/ __Vfunc___03730__51__s;
    __Vfunc___03730__51__s = 0;
    CData/*0:0*/ __Vfunc___03731__52__Vfuncout;
    __Vfunc___03731__52__Vfuncout = 0;
    CData/*0:0*/ __Vfunc___03731__52__a;
    __Vfunc___03731__52__a = 0;
    CData/*1:0*/ __Vfunc___03731__52__b;
    __Vfunc___03731__52__b = 0;
    CData/*1:0*/ __Vfunc___03731__52__s;
    __Vfunc___03731__52__s = 0;
    CData/*0:0*/ __Vfunc___03732__53__Vfuncout;
    __Vfunc___03732__53__Vfuncout = 0;
    CData/*0:0*/ __Vfunc___03732__53__a;
    __Vfunc___03732__53__a = 0;
    CData/*1:0*/ __Vfunc___03732__53__b;
    __Vfunc___03732__53__b = 0;
    CData/*1:0*/ __Vfunc___03732__53__s;
    __Vfunc___03732__53__s = 0;
    CData/*1:0*/ __Vfunc___03734__54__Vfuncout;
    __Vfunc___03734__54__Vfuncout = 0;
    CData/*1:0*/ __Vfunc___03734__54__a;
    __Vfunc___03734__54__a = 0;
    CData/*3:0*/ __Vfunc___03734__54__b;
    __Vfunc___03734__54__b = 0;
    CData/*1:0*/ __Vfunc___03734__54__s;
    __Vfunc___03734__54__s = 0;
    CData/*7:0*/ __Vfunc___03735__55__Vfuncout;
    __Vfunc___03735__55__Vfuncout = 0;
    CData/*7:0*/ __Vfunc___03735__55__a;
    __Vfunc___03735__55__a = 0;
    SData/*15:0*/ __Vfunc___03735__55__b;
    __Vfunc___03735__55__b = 0;
    CData/*1:0*/ __Vfunc___03735__55__s;
    __Vfunc___03735__55__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033959__81__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033959__81__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033959__81__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033959__81__b = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033959__81__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033959__81__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033961__82__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033961__82__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033961__82__b;
    __Vfunc_inst_t80__DOT__u0__DOT____033961__82__b = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT____033961__82__s;
    __Vfunc_inst_t80__DOT__u0__DOT____033961__82__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__a;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__a = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__a;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__a = 0;
    QData/*41:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__Vfuncout = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__Vfuncout = 0;
    CData/*6:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__b;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__s;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035306__164__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035306__164__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035306__164__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035306__164__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__Vfuncout = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035357__168__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035357__168__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035357__168__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035357__168__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__a = 0;
    SData/*14:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035717__188__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035717__188__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035772__197__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035772__197__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035772__197__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035772__197__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__a = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035814__204__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035814__204__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035814__204__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035814__204__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035818__205__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035818__205__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035818__205__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035818__205__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__a = 0;
    SData/*14:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__Vfuncout = 0;
    CData/*4:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035923__216__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035923__216__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035923__216__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035923__216__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__b = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035928__218__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035928__218__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035928__218__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035928__218__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035945__219__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035945__219__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035945__219__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035945__219__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__b = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035950__221__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035950__221__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035950__221__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035950__221__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036276__267__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036276__267__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036276__267__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036276__267__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036288__271__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036288__271__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036288__271__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036288__271__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__b = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__Vfuncout = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__Vfuncout = 0;
    SData/*15:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__Vfuncout = 0;
    SData/*15:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__Vfuncout = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036466__294__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036466__294__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036466__294__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036466__294__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__Vfuncout = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__b = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__Vfuncout = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036539__301__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036539__301__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036539__301__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036539__301__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__Vfuncout = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036585__306__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036585__306__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036585__306__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036585__306__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036589__307__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036589__307__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036589__307__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036589__307__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036659__318__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036659__318__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036659__318__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036659__318__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036978__364__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036978__364__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036978__364__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036978__364__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036983__366__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036983__366__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036983__366__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036983__366__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036987__367__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036987__367__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036990__368__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036990__368__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036990__368__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036990__368__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037187__370__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037187__370__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037187__370__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037187__370__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037192__372__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037192__372__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037192__372__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037192__372__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037199__374__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037199__374__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037199__374__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037199__374__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__a = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__a = 0;
    CData/*7:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037491__382__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037491__382__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037491__382__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037491__382__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037496__384__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037496__384__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037496__384__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037496__384__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037503__386__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037503__386__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037503__386__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037503__386__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037700__388__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037700__388__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037700__388__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037700__388__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037705__390__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037705__390__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037705__390__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037705__390__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037712__392__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037712__392__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037712__392__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037712__392__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037763__394__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037763__394__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037763__394__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037763__394__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037768__396__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037768__396__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037768__396__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037768__396__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037775__398__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037775__398__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037775__398__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037775__398__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037972__400__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037972__400__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037972__400__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037972__400__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__Vfuncout = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037977__402__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037977__402__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037977__402__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037977__402__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037984__404__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037984__404__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037984__404__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037984__404__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__Vfuncout = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__Vfuncout = 0;
    SData/*15:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__Vfuncout = 0;
    SData/*15:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038883__449__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038883__449__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038883__449__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038883__449__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__b = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038888__451__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038888__451__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038888__451__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038888__451__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038905__452__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038905__452__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038905__452__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038905__452__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__b = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038910__454__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038910__454__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038910__454__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038910__454__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038965__464__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038965__464__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038965__464__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038965__464__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__b = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038970__466__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038970__466__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038970__466__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038970__466__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038987__467__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038987__467__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038987__467__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038987__467__s = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__Vfuncout = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__b = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__s = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038992__469__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038992__469__Vfuncout = 0;
    CData/*0:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038992__469__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038992__469__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__a = 0;
    SData/*8:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__b = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039118__498__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039118__498__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039118__498__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039118__498__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__a = 0;
    CData/*5:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__b = 0;
    CData/*1:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__Vfuncout = 0;
    SData/*15:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__a;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__a = 0;
    SData/*11:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__Vfuncout = 0;
    SData/*15:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b = 0;
    CData/*3:0*/ __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s = 0;
    CData/*0:0*/ __Vfunc_sn76489_audio_inst__DOT____031256__630__Vfuncout;
    __Vfunc_sn76489_audio_inst__DOT____031256__630__Vfuncout = 0;
    CData/*2:0*/ __Vfunc_sn76489_audio_inst__DOT____031256__630__b;
    __Vfunc_sn76489_audio_inst__DOT____031256__630__b = 0;
    CData/*2:0*/ __Vfunc_sn76489_audio_inst__DOT____031256__630__s;
    __Vfunc_sn76489_audio_inst__DOT____031256__630__s = 0;
    CData/*1:0*/ __Vfunc_sn76489_audio_inst__DOT____031258__631__Vfuncout;
    __Vfunc_sn76489_audio_inst__DOT____031258__631__Vfuncout = 0;
    CData/*5:0*/ __Vfunc_sn76489_audio_inst__DOT____031258__631__b;
    __Vfunc_sn76489_audio_inst__DOT____031258__631__b = 0;
    CData/*2:0*/ __Vfunc_sn76489_audio_inst__DOT____031258__631__s;
    __Vfunc_sn76489_audio_inst__DOT____031258__631__s = 0;
    CData/*4:0*/ __Vfunc_sn76489_audio_inst__DOT____031260__632__Vfuncout;
    __Vfunc_sn76489_audio_inst__DOT____031260__632__Vfuncout = 0;
    SData/*14:0*/ __Vfunc_sn76489_audio_inst__DOT____031260__632__b;
    __Vfunc_sn76489_audio_inst__DOT____031260__632__b = 0;
    CData/*2:0*/ __Vfunc_sn76489_audio_inst__DOT____031260__632__s;
    __Vfunc_sn76489_audio_inst__DOT____031260__632__s = 0;
    CData/*31:0*/ __Vdeeptemp_hed498a0d__0;
    // Body
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035717__188__Vfuncout 
        = ((1U == (1U & (IData)(vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035717__188__s)))
            ? 0U : ((2U == (2U & (IData)(vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035717__188__s)))
                     ? 0xaU : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0473_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035717__188__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035772__197__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035772__197__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035772__197__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035772__197__s)))
                     ? 0xaU : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0499_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035772__197__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036276__267__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036276__267__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036276__267__s)))
            ? 0xaU : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0702_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036276__267__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                        ? 0U : 0xdU) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                                         ? 0U : 0xcU))
                : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                        ? 0U : 0xdU) : 0U)) : ((4U 
                                                & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                                                ? (
                                                   (2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                                                     ? 0U
                                                     : 0xdU)
                                                    : 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                                                     ? 0U
                                                     : 0xcU))
                                                : (
                                                   (2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__s))
                                                     ? 0U
                                                     : 0xdU)
                                                    : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0716_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036317__276__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036589__307__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036589__307__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036589__307__s)))
            ? 0xdU : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036589__307__s)))
                       ? 0xcU : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0823_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036589__307__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036659__318__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036659__318__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036659__318__s)))
            ? 7U : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0854_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036659__318__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__b 
        = ((((3U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                           >> 4U))) ? 0xbU : (1U | 
                                              (6U & 
                                               ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 3U)))) 
            << 4U) | ((3U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                    >> 4U))) ? 7U : 
                      (6U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                             >> 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__b) 
                                         >> 8U) : 0U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0253_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035308__165__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035818__205__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035818__205__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035818__205__s)))
            ? 0xdU : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035818__205__s)))
                       ? 0xcU : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0515_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035818__205__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__Vfuncout 
        = ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
            ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                            ? 0xdU : 0xcU) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                                               ? 0xdU
                                               : 0U))
                    : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                            ? 0xdU : 0xcU) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                                               ? 0xdU
                                               : 0U)))
                : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                            ? 0xdU : 0xcU) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                                               ? 0xdU
                                               : 0U))
                    : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                            ? 0xdU : 0xcU) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                                               ? 0xdU
                                               : 0U))))
            : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                            ? 0xdU : 0xcU) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                                               ? 0xdU
                                               : 0U))
                    : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                            ? 0xdU : 0xcU) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                                               ? 0xdU
                                               : 0U)))
                : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                            ? 0xdU : 0xcU) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                                               ? 0xdU
                                               : 0U))
                    : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                            ? 0xdU : 0xcU) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__s))
                                               ? 0xdU
                                               : 0U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0526_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035853__211__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__Vfuncout 
        = ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
            ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                            ? 0U : 5U) : 0U) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                                                 ? 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                                                  ? 0U
                                                  : 5U)
                                                 : 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                                                  ? 0U
                                                  : 4U)))
                : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                            ? 0U : 5U) : 0U) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                                                 ? 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                                                  ? 0U
                                                  : 5U)
                                                 : 0U)))
            : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                            ? 0U : 5U) : 0U) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                                                 ? 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                                                  ? 0U
                                                  : 5U)
                                                 : 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                                                  ? 0U
                                                  : 4U)))
                : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                        ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                            ? 0U : 5U) : 0U) : ((2U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                                                 ? 
                                                ((1U 
                                                  & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__s))
                                                  ? 0U
                                                  : 5U)
                                                 : 0U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0295_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035413__176__Vfuncout;
    vlSelf->__PVT___181_ = ((~ (IData)(vlSelf->__PVT__inst_t80__DOT___59_)) 
                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___808_));
    vlSelf->__PVT___043_ = ((~ (IData)(vlSelf->__PVT__inst_t80__DOT___57_)) 
                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___810_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036288__271__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036288__271__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036288__271__s))) 
           | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036288__271__s))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0706_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036288__271__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s 
        = (((5U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                          >> 3U))) << 6U) | (((6U == 
                                               (7U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                   >> 3U))) 
                                              << 5U) 
                                             | (((4U 
                                                  == 
                                                  (7U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                      >> 3U))) 
                                                 << 4U) 
                                                | (((3U 
                                                     == 
                                                     (7U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                         >> 3U))) 
                                                    << 3U) 
                                                   | (((1U 
                                                        == 
                                                        (7U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                            >> 3U))) 
                                                       << 2U) 
                                                      | (((2U 
                                                           == 
                                                           (7U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                               >> 3U))) 
                                                          << 1U) 
                                                         | (0U 
                                                            == 
                                                            (7U 
                                                             & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                >> 3U)))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b 
        = ((0x60U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                     >> 1U)) | ((0x10U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                                          >> 2U)) | 
                                ((8U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                        << 3U)) | (
                                                   (4U 
                                                    & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                                                          >> 5U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                                                            >> 6U)))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__Vfuncout 
        = (1U & ((0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                  ? ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 6U)))))))
                  : ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b) 
                                             >> 1U))
                                      : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__s) 
                                         & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__b)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___161_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310202__91__Vfuncout;
    if ((3U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                      >> 4U)))) {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0205_ = 1U;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0201_ = 0U;
    } else {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0205_ 
            = (6U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                     >> 3U));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0201_ 
            = (1U | (6U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                           >> 3U)));
    }
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s 
        = (((5U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                          >> 3U))) << 6U) | (((6U == 
                                               (7U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                   >> 3U))) 
                                              << 5U) 
                                             | (((4U 
                                                  == 
                                                  (7U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                      >> 3U))) 
                                                 << 4U) 
                                                | (((3U 
                                                     == 
                                                     (7U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                         >> 3U))) 
                                                    << 3U) 
                                                   | (((1U 
                                                        == 
                                                        (7U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                            >> 3U))) 
                                                       << 2U) 
                                                      | (((2U 
                                                           == 
                                                           (7U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                               >> 3U))) 
                                                          << 1U) 
                                                         | (0U 
                                                            == 
                                                            (7U 
                                                             & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                >> 3U)))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b 
        = (0x20U | ((0x40U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                              << 5U)) | ((8U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                                                << 2U)) 
                                         | ((4U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                                                   << 1U)) 
                                            | ((2U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                   << 1U)) 
                                               | (1U 
                                                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                                                     >> 7U)))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__a 
        = (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                 >> 1U));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__Vfuncout 
        = (1U & ((0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                  ? ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 6U)))))))
                  : ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                      ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 5U))))))
                      : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                          ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 4U)))))
                          : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                              ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 3U))))
                              : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                  ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 2U)))
                                  : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                      ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b) 
                                             >> 1U))
                                      : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__s))
                                          ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__b)
                                          : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__a)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___159_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310188__89__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s 
        = (((7U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                          >> 3U))) << 7U) | (((6U == 
                                               (7U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                   >> 3U))) 
                                              << 6U) 
                                             | (((5U 
                                                  == 
                                                  (7U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                      >> 3U))) 
                                                 << 5U) 
                                                | (((4U 
                                                     == 
                                                     (7U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                         >> 3U))) 
                                                    << 4U) 
                                                   | (((3U 
                                                        == 
                                                        (7U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                            >> 3U))) 
                                                       << 3U) 
                                                      | (((2U 
                                                           == 
                                                           (7U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                               >> 3U))) 
                                                          << 2U) 
                                                         | (((1U 
                                                              == 
                                                              (7U 
                                                               & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                  >> 3U))) 
                                                             << 1U) 
                                                            | (0U 
                                                               == 
                                                               (7U 
                                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                   >> 3U))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__b 
        = ((0x80U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)) 
           | ((0x40U & ((~ ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                            >> 7U)) << 6U)) | ((0x20U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                   << 3U)) 
                                               | ((0x10U 
                                                   & ((~ 
                                                       ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                        >> 2U)) 
                                                      << 4U)) 
                                                  | ((8U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                         << 3U)) 
                                                     | ((4U 
                                                         & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)) 
                                                            << 2U)) 
                                                        | ((2U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                               >> 5U)) 
                                                           | (1U 
                                                              & (~ 
                                                                 ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                                  >> 6U))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__Vfuncout 
        = (((((((((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s))) 
                  | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))) 
                 | (4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))) 
                | (8U == (8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))) 
               | (0x10U == (0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))) 
              | (0x20U == (0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))) 
             | (0x40U == (0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))) 
            | (0x80U == (0x80U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))) 
           & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))
               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__b)
               : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))
                   ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__b) 
                      >> 1U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))
                                 ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__b) 
                                    >> 2U) : ((8U == 
                                               (8U 
                                                & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))
                                               ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__b) 
                                                  >> 3U)
                                               : ((0x10U 
                                                   == 
                                                   (0x10U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))
                                                   ? 
                                                  ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__b) 
                                                   >> 4U)
                                                   : 
                                                  ((0x20U 
                                                    == 
                                                    (0x20U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))
                                                    ? 
                                                   ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__b) 
                                                    >> 5U)
                                                    : 
                                                   ((0x40U 
                                                     == 
                                                     (0x40U 
                                                      & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__s)))
                                                     ? 
                                                    ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__b) 
                                                     >> 6U)
                                                     : 
                                                    ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__b) 
                                                     >> 7U)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0791_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036517__298__Vfuncout;
    vlSelf->__PVT__clk_en_cpu_s = ((IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___157_) 
                                   & ((IData)(vlSymsp->TOP.clk_3m58_en) 
                                      & ((IData)(vlSelf->__PVT___408_) 
                                         & ((IData)(vlSelf->__PVT___019_) 
                                            & (IData)(vlSelf->__PVT__sdcard__DOT___49_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___124_ 
        = (0xfU & ((1U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))
                    ? ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_) 
                       >> 4U) : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039118__498__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039118__498__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039118__498__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039118__498__s)))
                     ? 7U : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039118__498__s)))
                              ? 7U : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2128_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039118__498__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b 
        = (0xcU | ((((8U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))
                      ? 0xdU : 5U) << 8U) | (((8U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))
                                               ? 0xeU
                                               : 6U) 
                                             << 4U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__Vfuncout 
        = (0xfU & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                    ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b) 
                                                  >> 0xcU))))
                    : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__b)
                                               : 0U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1963_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038733__430__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b 
        = (0xcU | (((8U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))
                     ? 0xeU : 6U) << 4U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__Vfuncout 
        = (0xfU & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                    ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b) 
                                                  >> 0xcU))))
                    : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__b)
                                               : 0U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1985_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038786__439__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b 
        = (((8U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))
             ? 0xeU : 6U) << 8U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__Vfuncout 
        = (0xfU & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                    ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b) 
                                                  >> 0xcU))))
                    : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__b)
                                               : 0U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2206_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039279__516__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b 
        = (((8U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))
             ? 0xeU : 6U) << 8U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__Vfuncout 
        = (0xfU & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                    ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b) 
                                                  >> 0xcU))))
                    : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__b)
                                               : 0U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2231_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039342__528__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035306__164__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035306__164__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035306__164__s)))
            ? 0xfU : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035306__164__s)))
                       ? 0xfU : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0252_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035306__164__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035357__168__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035357__168__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035357__168__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035357__168__s)))
                     ? 7U : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035357__168__s)))
                              ? 7U : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0272_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035357__168__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__Vfuncout 
        = ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
            ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                        ? 0U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                                 ? 0U : 7U)) : 0U) : 
               ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                     ? 0U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                              ? 0U : 7U)) : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                                              ? 0U : 
                                             ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                                               ? 0U
                                               : 0xfU))))
            : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                        ? 0U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                                 ? 0U : 7U)) : 0U) : 
               ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                 ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                     ? 0U : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__s))
                              ? 0U : 7U)) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0293_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035405__174__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__Vfuncout 
        = ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
            ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                        ? 0U : 0xfU) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                                         ? 0U : 0xfU))
                : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                    ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                        ? 0U : 0xfU) : 0U)) : ((4U 
                                                & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                                                ? (
                                                   (2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                                                     ? 0U
                                                     : 0xfU)
                                                    : 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                                                     ? 0U
                                                     : 0xfU))
                                                : (
                                                   (2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                                                    ? 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__s))
                                                     ? 0U
                                                     : 0xfU)
                                                    : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0715_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036313__275__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036466__294__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036466__294__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036466__294__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036466__294__s)))
                     ? 7U : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036466__294__s)))
                              ? 7U : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0774_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036466__294__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036539__301__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036539__301__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036539__301__s)))
            ? 0U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036539__301__s)))
                     ? 7U : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036539__301__s)))
                              ? 7U : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0799_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036539__301__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036585__306__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036585__306__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036585__306__s)))
            ? 0xfU : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036585__306__s)))
                       ? 0xfU : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0822_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036585__306__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035814__204__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035814__204__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035814__204__s)))
            ? 0xfU : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035814__204__s)))
                       ? 0xfU : 0U));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0514_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035814__204__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__Vfuncout 
        = ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
            ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                        ? 0xfU : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                   ? 0xfU : 0U)) : 
                   ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                     ? 0xfU : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                ? 0xfU : 0U))) : ((4U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                                   ? 
                                                  ((2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                                    ? 0xfU
                                                    : 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                                     ? 0xfU
                                                     : 0U))
                                                   : 
                                                  ((2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                                    ? 0xfU
                                                    : 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                                     ? 0xfU
                                                     : 0U))))
            : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                    ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                        ? 0xfU : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                   ? 0xfU : 0U)) : 
                   ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                     ? 0xfU : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                ? 0xfU : 0U))) : ((4U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                                   ? 
                                                  ((2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                                    ? 0xfU
                                                    : 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                                     ? 0xfU
                                                     : 0U))
                                                   : 
                                                  ((2U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                                    ? 0xfU
                                                    : 
                                                   ((1U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__s))
                                                     ? 0xfU
                                                     : 0U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0525_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035849__210__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s 
        = (((5U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                          >> 3U))) << 6U) | (((6U == 
                                               (7U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                   >> 3U))) 
                                              << 5U) 
                                             | (((4U 
                                                  == 
                                                  (7U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                      >> 3U))) 
                                                 << 4U) 
                                                | (((3U 
                                                     == 
                                                     (7U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                         >> 3U))) 
                                                    << 3U) 
                                                   | (((1U 
                                                        == 
                                                        (7U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                            >> 3U))) 
                                                       << 2U) 
                                                      | (((2U 
                                                           == 
                                                           (7U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                               >> 3U))) 
                                                          << 1U) 
                                                         | (0U 
                                                            == 
                                                            (7U 
                                                             & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                >> 3U)))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
        = (((QData)((IData)((0x3fU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                                      >> 2U)))) << 0x24U) 
           | (((QData)((IData)((0x3fU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_)))) 
               << 0x1eU) | (QData)((IData)(((0x3f000000U 
                                             & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                                                << 0x18U)) 
                                            | ((0xfc0000U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                                                   << 0x10U)) 
                                               | ((0x3f000U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                                                      << 0xaU)) 
                                                  | ((0xfc0U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                                                         << 6U)) 
                                                     | (0x3fU 
                                                        & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__a 
        = (0x3fU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                    >> 2U));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__Vfuncout 
        = (0x3fU & ((0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                     ? ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                         ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                             ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                 ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                     ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0xcU))))
                                     : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0x12U)))))
                                 : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                     ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0xcU))))
                                     : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0x18U))))))
                             : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                 ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                     ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0xcU))))
                                     : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0x12U)))))
                                 : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                     ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0xcU))))
                                     : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0x1eU)))))))
                         : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                             ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                 ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                     ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0xcU))))
                                     : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0x12U)))))
                                 : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                     ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0xcU))))
                                     : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0x18U))))))
                             : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                 ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                     ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0xcU))))
                                     : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0x12U)))))
                                 : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                     ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0xcU))))
                                     : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0x24U))))))))
                     : ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                         ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                             ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                 ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                     ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0xcU))))
                                     : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0x12U)))))
                                 : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                     ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0xcU))))
                                     : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0x18U))))))
                             : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                 ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                     ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0xcU))))
                                     : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0x12U)))))
                                 : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                     ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0xcU))))
                                     : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0x1eU)))))))
                         : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                             ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                 ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                     ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0xcU))))
                                     : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0x12U)))))
                                 : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                     ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0xcU))))
                                     : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0x18U))))))
                             : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                 ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                     ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0xcU))))
                                     : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0x12U)))))
                                 : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                     ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 0xcU))))
                                     : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                         ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(
                                                       (__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b 
                                                        >> 6U)))
                                         : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__b)
                                             : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__a)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___160_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____0310197__90__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b 
        = (0xb40U | (0x3fU & ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                 ? 4U : 3U) << 3U) 
                              | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                  ? 4U : 3U))));
    if ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))) {
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__a = 4U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__a = 4U;
    } else {
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__a = 3U;
        __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__a = 3U;
    }
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__Vfuncout 
        = (7U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b) 
                                                >> 9U))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__b)
                                             : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__a))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1962_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038730__429__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b 
        = (0xb40U | (0x3fU & ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                 ? 4U : 3U) << 3U) 
                              | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                  ? 4U : 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__Vfuncout 
        = (7U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b) 
                                                >> 9U))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__b)
                                             : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__a))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1984_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038783__438__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__b 
        = (4U | (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                   ? 4U : 3U) << 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2048_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038915__455__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__b 
        = (4U | (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                   ? 4U : 3U) << 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2082_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038997__470__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__b 
        = (0x20U | ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 6U) | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                             ? 4U : 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2101_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039043__479__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__b 
        = (0x20U | ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 6U) | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                             ? 4U : 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2115_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039082__489__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__b 
        = (0x20U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                     ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2153_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039171__503__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__b 
        = (0x20U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                     ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2178_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039222__509__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b 
        = (0xb20U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                      ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__Vfuncout 
        = (7U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b) 
                                                >> 9U))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__b)
                                             : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__a))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2205_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039277__515__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s 
        = (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b 
        = (0xb05U | (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__Vfuncout 
        = (7U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b) 
                                                >> 9U))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__b)
                                             : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__a))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2230_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____039340__527__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__s)))
            ? 5U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__s)))
                     ? 4U : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__s)))
                              ? 4U : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0513_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035810__203__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__b 
        = (5U | (0x1f8U & ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                              ? 4U : 3U) << 6U) | (
                                                   ((1U 
                                                     == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                     ? 4U
                                                     : 3U) 
                                                   << 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0251_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035302__163__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b 
        = (0x5100U | ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                         ? 4U : 3U) << 9U) | (0x3fU 
                                              & ((((1U 
                                                    == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                    ? 4U
                                                    : 3U) 
                                                  << 3U) 
                                                 | ((1U 
                                                     == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                     ? 4U
                                                     : 3U)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__Vfuncout 
        = (7U & ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                  ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                      ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                                 >> 6U)))
                          : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                                 >> 9U))))
                      : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                                 >> 6U)))
                          : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                                 >> 0xcU)))))
                  : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                      ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                                 >> 6U)))
                          : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                                 >> 9U))))
                      : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                                 >> 6U)))
                          : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__b)
                                                 : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__a)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0292_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035401__173__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__b 
        = (0x20U | ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 6U) | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                             ? 4U : 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0470_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035709__185__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__b 
        = (0x20U | ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 6U) | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                             ? 4U : 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0496_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035764__194__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 4U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 3U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                             << 1U) 
                                            | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b 
        = (0x125U | (0x7e00U & ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                   ? 4U : 3U) << 0xcU) 
                                | (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                     ? 4U : 3U) << 9U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__Vfuncout 
        = (7U & ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                  ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                      ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                                 >> 6U)))
                          : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                                 >> 9U))))
                      : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                                 >> 6U)))
                          : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                                 >> 0xcU)))))
                  : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                      ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                                 >> 6U)))
                          : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                                 >> 9U))))
                      : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                          ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                                 : 
                                                ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                                 >> 6U)))
                          : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                              ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                  : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b) 
                                     >> 3U)) : ((1U 
                                                 & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__s))
                                                 ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__b)
                                                 : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__a)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0523_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035842__208__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__b 
        = (4U | (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                   ? 4U : 3U) << 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0571_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035955__222__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__b 
        = (0x28U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                     ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0651_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036134__239__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__b 
        = (0x28U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                     ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0661_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036161__244__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__b 
        = (0x28U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                     ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0670_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036187__249__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__b 
        = (0x28U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                     ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0680_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036214__254__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__b 
        = (0x28U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                     ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0689_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036240__259__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__b 
        = (0x145U | (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                       ? 4U : 3U) << 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0698_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036265__263__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b 
        = (0x20U | ((0xfc0U & ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                  ? 4U : 3U) << 9U) 
                               | (((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                    ? 4U : 3U) << 6U))) 
                    | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                        ? 4U : 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__Vfuncout 
        = (7U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b) 
                                                >> 9U))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__b)
                                             : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__a))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0713_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036305__273__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__b 
        = (5U | (0x1f8U & ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                              ? 4U : 3U) << 6U) | (
                                                   ((1U 
                                                     == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                     ? 4U
                                                     : 3U) 
                                                   << 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0773_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036462__293__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__b 
        = (5U | (0x1f8U & ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                              ? 4U : 3U) << 6U) | (
                                                   ((1U 
                                                     == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                     ? 4U
                                                     : 3U) 
                                                   << 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0798_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036535__300__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__b 
        = (5U | (0x1f8U & ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                              ? 4U : 3U) << 6U) | (
                                                   ((1U 
                                                     == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                     ? 4U
                                                     : 3U) 
                                                   << 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__b) 
                                       >> 6U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0821_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036581__305__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__b 
        = (0x20U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                     ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0844_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036631__311__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__b 
        = (0x20U | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                     ? 4U : 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__b) 
                         >> 3U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0852_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036653__316__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___082_ = 
        ((~ ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_) 
             >> 2U)) & (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___137_ 
        = ((0xdU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
           | (0xeU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___086_ 
        = ((0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
           | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
              | ((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                 | ((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                    | ((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                       | ((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                          | ((6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)) 
                             | (7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___033_ 
        = ((2U == (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))) 
           | ((3U == (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))) 
              | (7U == (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___026_ 
        = ((0U == (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))) 
           | (1U == (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1351_ 
        = ((0xc0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xc1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xc2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0xc3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0xc4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0xc5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0xc7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | ((0xc8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                | ((0xc9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                   | ((0xcaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                      | ((0xcbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                         | ((0xccU 
                                             == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                            | ((0xcdU 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               | ((0xcfU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  | ((0xd0U 
                                                      == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                     | ((0xd1U 
                                                         == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                        | ((0xd2U 
                                                            == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                           | ((0xd3U 
                                                               == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                              | ((0xd4U 
                                                                  == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                 | ((0xd5U 
                                                                     == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                    | ((0xd7U 
                                                                        == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                       | ((0xd8U 
                                                                           == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                          | ((0xd9U 
                                                                              == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                             | ((0xdaU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xdbU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xdcU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xddU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xdfU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe0U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe2U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe3U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe4U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe5U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe7U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe8U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe9U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xeaU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xebU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xecU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xedU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xefU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf0U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf2U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf3U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf4U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf5U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf7U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf8U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf9U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xfaU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xfbU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xfcU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xfdU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | (0xffU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))))))))))))))))))))))))))))))))))))))))))))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1066_ 
        = ((6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x16U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xeU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x1eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x2eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x3eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0x26U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | (0x36U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_ 
        = ((0U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                         >> 4U))) | ((1U == (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                   >> 4U))) 
                                     | (2U == (3U & 
                                               ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 4U)))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s 
        = (((6U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                          >> 3U))) << 6U) | (((5U == 
                                               (7U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                   >> 3U))) 
                                              << 5U) 
                                             | (((4U 
                                                  == 
                                                  (7U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                      >> 3U))) 
                                                 << 4U) 
                                                | (((3U 
                                                     == 
                                                     (7U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                         >> 3U))) 
                                                    << 3U) 
                                                   | (((2U 
                                                        == 
                                                        (7U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                            >> 3U))) 
                                                       << 2U) 
                                                      | (((1U 
                                                           == 
                                                           (7U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                               >> 3U))) 
                                                          << 1U) 
                                                         | (0U 
                                                            == 
                                                            (7U 
                                                             & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                >> 3U)))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__Vfuncout 
        = ((0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
            ? ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                    ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                        ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 8U)))
                        : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 0x10U))))
                    : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                        ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 8U)))
                        : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 0x20U)))))
                : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                    ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                        ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 8U)))
                        : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 0x10U))))
                    : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                        ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 8U)))
                        : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 0x40U))))))
            : ((0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                ? ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                    ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                        ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 8U)))
                        : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 0x10U))))
                    : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                        ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 8U)))
                        : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 0x20U)))))
                : ((0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                    ? ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                        ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 8U)))
                        : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 0x10U))))
                    : ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                        ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 8U)))
                        : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                            ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 4U))
                            : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                    ? 1U : 2U) : ((1U 
                                                   & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__s))
                                                   ? 1U
                                                   : 0x80U)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___007_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039751__104__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___089_ 
        = (1U & ((9U < (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_))) 
                 | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                    >> 4U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s 
        = (((7U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                          >> 3U))) << 7U) | (((6U == 
                                               (7U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                   >> 3U))) 
                                              << 6U) 
                                             | (((5U 
                                                  == 
                                                  (7U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                      >> 3U))) 
                                                 << 5U) 
                                                | (((4U 
                                                     == 
                                                     (7U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                         >> 3U))) 
                                                    << 4U) 
                                                   | (((3U 
                                                        == 
                                                        (7U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                            >> 3U))) 
                                                       << 3U) 
                                                      | (((2U 
                                                           == 
                                                           (7U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                               >> 3U))) 
                                                          << 2U) 
                                                         | (((1U 
                                                              == 
                                                              (7U 
                                                               & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                  >> 3U))) 
                                                             << 1U) 
                                                            | (0U 
                                                               == 
                                                               (7U 
                                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                                   >> 3U))))))))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__b 
        = ((0x80U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)) 
           | ((0x40U & ((~ ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                            >> 7U)) << 6U)) | ((0x20U 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                   << 3U)) 
                                               | ((0x10U 
                                                   & ((~ 
                                                       ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                        >> 2U)) 
                                                      << 4U)) 
                                                  | ((8U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                         << 3U)) 
                                                     | ((4U 
                                                         & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)) 
                                                            << 2U)) 
                                                        | ((2U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                               >> 5U)) 
                                                           | (1U 
                                                              & (~ 
                                                                 ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                                                                  >> 6U))))))))));
    vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__Vfuncout 
        = (((((((((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s))) 
                  | (2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))) 
                 | (4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))) 
                | (8U == (8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))) 
               | (0x10U == (0x10U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))) 
              | (0x20U == (0x20U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))) 
             | (0x40U == (0x40U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))) 
            | (0x80U == (0x80U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))) 
           & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))
               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__b)
               : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))
                   ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__b) 
                      >> 1U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))
                                 ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__b) 
                                    >> 2U) : ((8U == 
                                               (8U 
                                                & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))
                                               ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__b) 
                                                  >> 3U)
                                               : ((0x10U 
                                                   == 
                                                   (0x10U 
                                                    & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))
                                                   ? 
                                                  ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__b) 
                                                   >> 4U)
                                                   : 
                                                  ((0x20U 
                                                    == 
                                                    (0x20U 
                                                     & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))
                                                    ? 
                                                   ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__b) 
                                                    >> 5U)
                                                    : 
                                                   ((0x40U 
                                                     == 
                                                     (0x40U 
                                                      & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__s)))
                                                     ? 
                                                    ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__b) 
                                                     >> 6U)
                                                     : 
                                                    ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__b) 
                                                     >> 7U)))))))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0736_ 
        = vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036378__282__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___014_ 
        = (0x3fU & (((0x1eU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                               << 1U)) | (1U & (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_) 
                                                 >> 1U) 
                                                ^ (IData)(
                                                          ((1U 
                                                            == 
                                                            (5U 
                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))) 
                                                           & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_)))))) 
                    + (1U | (0x1eU & (((2U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))
                                        ? (~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_))
                                        : (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_)) 
                                      << 1U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2248_ 
        = ((0xa3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xabU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xb3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0xbbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2223_ 
        = ((0xa2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xaaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xb2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0xbaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2198_ 
        = ((0x41U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x49U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x51U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x59U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x61U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x69U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0x71U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | (0x79U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2173_ 
        = ((0x40U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x48U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x50U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x58U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x60U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x68U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0x70U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | (0x78U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2147_ 
        = ((0x45U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x4dU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x55U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x5dU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x65U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x6dU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0x75U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | (0x7dU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2097_ 
        = ((0x42U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x52U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x62U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0x72U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2063_ 
        = ((0x4aU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x5aU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x6aU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0x7aU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2029_ 
        = ((0x5eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | (0x77U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2026_ 
        = ((0x56U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | (0x76U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2016_ 
        = ((0x44U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x4cU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x54U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x5cU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x64U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x6cU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0x74U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | (0x7cU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2001_ 
        = ((0xa1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xa9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xb1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0xb9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1977_ 
        = ((0xa0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xa8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xb0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0xb8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1953_ 
        = ((0x43U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x53U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x63U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0x73U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1931_ 
        = ((0x4bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x5bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x6bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0x7bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1902_ 
        = ((0x7eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | (0x7fU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1559_ 
        = ((0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | (5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0863_ 
        = ((0xddU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | (0xfdU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0841_ 
        = ((0xc7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xcfU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xd7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0xdfU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0xe7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0xefU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0xf7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | (0xffU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0817_ 
        = ((0xc0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xc8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xd0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0xd8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0xe0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0xe8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0xf0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | (0xf8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0769_ 
        = ((0xc4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xccU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xd4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0xdcU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0xe4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0xecU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0xf4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | (0xfcU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0648_ 
        = ((0xc2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xcaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xd2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0xdaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0xe2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0xeaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0xf2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | (0xfaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0608_ 
        = ((7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x17U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xfU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0x1fU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0601_ 
        = ((0xbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x1bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x2bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0x3bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0594_ 
        = ((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x13U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x23U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0x33U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0587_ 
        = ((9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x19U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x29U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0x39U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0492_ 
        = ((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xdU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x15U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x1dU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x25U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x2dU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | (0x3dU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0466_ 
        = ((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xcU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x14U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x1cU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x24U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x2cU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | (0x3cU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0283_ 
        = ((0xc1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xd1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xe1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0xf1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0262_ 
        = ((0xc5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xd5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xe5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0xf5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0218_ 
        = ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x11U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x21U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | (0x31U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0152_ 
        = ((0x70U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x71U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x72U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x73U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x74U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x75U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | (0x77U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0115_ 
        = ((6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xeU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x16U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x1eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x26U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x2eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | (0x3eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0453_ 
        = ((0xc6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0xceU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0xd6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0xdeU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0xe6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0xeeU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0xf6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | (0xfeU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0432_ 
        = ((0x86U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x8eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x96U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x9eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0xa6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0xaeU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0xb6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | (0xbeU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0410_ 
        = ((0x80U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x81U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x82U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x83U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x84U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x85U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0x87U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | ((0x88U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                | ((0x89U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                   | ((0x8aU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                      | ((0x8bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                         | ((0x8cU 
                                             == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                            | ((0x8dU 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               | ((0x8fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  | ((0x90U 
                                                      == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                     | ((0x91U 
                                                         == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                        | ((0x92U 
                                                            == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                           | ((0x93U 
                                                               == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                              | ((0x94U 
                                                                  == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                 | ((0x95U 
                                                                     == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                    | ((0x97U 
                                                                        == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                       | ((0x98U 
                                                                           == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                          | ((0x99U 
                                                                              == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                             | ((0x9aU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x9bU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x9cU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x9dU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x9fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa0U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa2U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa3U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa4U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa5U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa7U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa8U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa9U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xaaU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xabU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xacU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xadU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xafU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb0U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb2U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb3U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb4U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb5U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb7U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb8U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb9U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xbaU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xbbU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xbcU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xbdU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | (0xbfU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))))))))))))))))))))))))))))))))))))))))))))))))))));
    __PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1166_ 
        = ((0x40U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | ((0x41U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x42U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x43U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x44U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x45U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0x47U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | ((0x48U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                | ((0x49U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                   | ((0x4aU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                      | ((0x4bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                         | ((0x4cU 
                                             == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                            | ((0x4dU 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               | ((0x4fU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  | ((0x50U 
                                                      == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                     | ((0x51U 
                                                         == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                        | ((0x52U 
                                                            == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                           | ((0x53U 
                                                               == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                              | ((0x54U 
                                                                  == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                 | ((0x55U 
                                                                     == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                    | ((0x57U 
                                                                        == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                       | ((0x58U 
                                                                           == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                          | ((0x59U 
                                                                              == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                             | ((0x5aU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x5bU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x5cU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x5dU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x5fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x60U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x61U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x62U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x63U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x64U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x65U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x67U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x68U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x69U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x6aU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x6bU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x6cU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x6dU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | (0x6fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))))))))))))))))))))))))))))))))))))));
    __VdfgTmp_h8a4cccd7__0 = ((0x78U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                              | ((0x79U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                 | ((0x7aU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                    | ((0x7bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                       | ((0x7cU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                          | ((0x7dU 
                                              == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                             | (0x7fU 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_ 
        = ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
           | (7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2019_ 
        = ((0x46U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
           | (0x4eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)));
    vlSelf->__VdfgTmp_hc027efeb__0 = ((0x66U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                      | (0x6eU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)));
    if (vlSymsp->TOP.clk_3m58_en) {
        vlSelf->__PVT__ym2149_audio_inst__DOT___190_ 
            = vlSelf->__PVT__ym2149_audio_inst__DOT___157_;
        vlSelf->__PVT___357_ = (1U & (((IData)(vlSelf->__PVT___181_) 
                                       & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT___63_)) 
                                          & (0x7fU 
                                             == (0xffU 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))))
                                       ? (~ ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_) 
                                             >> 1U))
                                       : (IData)(vlSelf->__PVT___413_)));
        vlSelf->__PVT___368_ = ((IData)(vlSelf->__PVT___043_)
                                 ? (IData)(vlSelf->__PVT___119_)
                                 : (IData)(vlSelf->__PVT___431_));
    } else {
        vlSelf->__PVT__ym2149_audio_inst__DOT___190_ 
            = vlSelf->__PVT__ym2149_audio_inst__DOT___050_;
        vlSelf->__PVT___357_ = (1U & (IData)(vlSelf->__PVT___413_));
        vlSelf->__PVT___368_ = vlSelf->__PVT___431_;
    }
    __Vfunc___03719__43__s = (((3U == (0xfU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 4U))) 
                               << 1U) | (5U == (0xfU 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                   >> 4U))));
    __Vfunc___03719__43__b = vlSelf->__PVT___262_;
    __Vfunc___03719__43__Vfuncout = (1U & ((1U == (1U 
                                                   & (IData)(__Vfunc___03719__43__s)))
                                            ? (IData)(__Vfunc___03719__43__b)
                                            : (IData)(
                                                      (((IData)(__Vfunc___03719__43__s) 
                                                        & (IData)(__Vfunc___03719__43__b)) 
                                                       >> 1U))));
    vlSelf->__PVT___288_ = __Vfunc___03719__43__Vfuncout;
    __Vfunc___03721__44__s = (((3U == (0xfU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 4U))) 
                               << 1U) | (5U == (0xfU 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                   >> 4U))));
    __Vfunc___03721__44__b = vlSelf->__PVT___263_;
    __Vfunc___03721__44__Vfuncout = (1U & ((1U == (1U 
                                                   & (IData)(__Vfunc___03721__44__s)))
                                            ? (IData)(__Vfunc___03721__44__b)
                                            : (IData)(
                                                      (((IData)(__Vfunc___03721__44__s) 
                                                        & (IData)(__Vfunc___03721__44__b)) 
                                                       >> 1U))));
    vlSelf->__PVT___290_ = __Vfunc___03721__44__Vfuncout;
    vlSelf->__PVT__cache_active_s = ((~ (IData)(vlSelf->__PVT___415_)) 
                                     & (IData)(vlSelf->__PVT___039_));
    vlSelf->cache__DOT____VdfgTmp_h64dfa0ff__0 = (0x1ffU 
                                                  & ((IData)(vlSelf->__PVT__cache__DOT__c_init_i) 
                                                     + (IData)(vlSelf->__PVT__cache_n_pages_s)));
    vlSelf->__PVT__cache__DOT__ci_sram = (0x1ffU & 
                                          (((IData)(0x40U) 
                                            - (IData)(vlSelf->__PVT__cache_n_pages_s)) 
                                           + (IData)(vlSelf->__PVT__cache__DOT__c_init_i)));
    vlSelf->__PVT__ym2149_audio_inst__DOT___191_ = 
        (0xffU & (((IData)(vlSymsp->TOP.clk_3m58_en) 
                   & (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___158_))
                   ? ((8U & ((IData)(0xfU) - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                       ? ((4U & ((IData)(0xfU) - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                           ? ((2U & ((IData)(0xfU) 
                                     - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                               ? ((1U & ((IData)(1U) 
                                         - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                                   ? ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[3U] 
                                       << 8U) | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[3U] 
                                                 >> 0x18U))
                                   : ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[3U] 
                                       << 0x10U) | 
                                      (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[3U] 
                                       >> 0x10U))) : 
                              ((1U & ((IData)(1U) - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                                ? ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[3U] 
                                    << 0x18U) | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[3U] 
                                                 >> 8U))
                                : vlSelf->__PVT__ym2149_audio_inst__DOT___057_[3U]))
                           : ((2U & ((IData)(0xfU) 
                                     - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                               ? ((1U & ((IData)(1U) 
                                         - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                                   ? ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[2U] 
                                       << 8U) | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[2U] 
                                                 >> 0x18U))
                                   : ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[2U] 
                                       << 0x10U) | 
                                      (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[2U] 
                                       >> 0x10U))) : 
                              ((1U & ((IData)(1U) - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                                ? ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[2U] 
                                    << 0x18U) | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[2U] 
                                                 >> 8U))
                                : vlSelf->__PVT__ym2149_audio_inst__DOT___057_[2U])))
                       : ((4U & ((IData)(0xfU) - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                           ? ((2U & ((IData)(0xfU) 
                                     - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                               ? ((1U & ((IData)(1U) 
                                         - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                                   ? ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U] 
                                       << 8U) | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U] 
                                                 >> 0x18U))
                                   : ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U] 
                                       << 0x10U) | 
                                      (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U] 
                                       >> 0x10U))) : 
                              ((1U & ((IData)(1U) - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                                ? ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U] 
                                    << 0x18U) | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U] 
                                                 >> 8U))
                                : vlSelf->__PVT__ym2149_audio_inst__DOT___057_[1U]))
                           : ((2U & ((IData)(0xfU) 
                                     - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                               ? ((1U & ((IData)(1U) 
                                         - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                                   ? ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U] 
                                       << 8U) | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U] 
                                                 >> 0x18U))
                                   : ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U] 
                                       << 0x10U) | 
                                      (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U] 
                                       >> 0x10U))) : 
                              ((1U & ((IData)(1U) - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)))
                                ? ((vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U] 
                                    << 0x18U) | (vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U] 
                                                 >> 8U))
                                : vlSelf->__PVT__ym2149_audio_inst__DOT___057_[0U]))))
                   : (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___052_)));
    __Vfunc___03726__48__s = (((3U == (0xfU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 4U))) 
                               << 1U) | (5U == (0xfU 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                   >> 4U))));
    __Vfunc___03726__48__b = (((IData)(vlSelf->__PVT___415_) 
                               << 1U) | (IData)(vlSelf->__PVT___268_));
    __Vfunc___03726__48__a = vlSelf->__PVT___415_;
    __Vfunc___03726__48__Vfuncout = (1U & ((1U == (1U 
                                                   & (IData)(__Vfunc___03726__48__s)))
                                            ? (IData)(__Vfunc___03726__48__b)
                                            : ((2U 
                                                == 
                                                (2U 
                                                 & (IData)(__Vfunc___03726__48__s)))
                                                ? ((IData)(__Vfunc___03726__48__b) 
                                                   >> 1U)
                                                : (IData)(__Vfunc___03726__48__a))));
    vlSelf->__PVT___294_ = __Vfunc___03726__48__Vfuncout;
    __Vfunc___03722__45__s = (((3U == (0xfU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 4U))) 
                               << 1U) | (5U == (0xfU 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                   >> 4U))));
    __Vfunc___03722__45__b = (((IData)(vlSelf->__PVT___412_) 
                               << 1U) | (IData)(vlSelf->__PVT___264_));
    __Vfunc___03722__45__a = vlSelf->__PVT___412_;
    __Vfunc___03722__45__Vfuncout = (1U & ((1U == (1U 
                                                   & (IData)(__Vfunc___03722__45__s)))
                                            ? (IData)(__Vfunc___03722__45__b)
                                            : ((2U 
                                                == 
                                                (2U 
                                                 & (IData)(__Vfunc___03722__45__s)))
                                                ? ((IData)(__Vfunc___03722__45__b) 
                                                   >> 1U)
                                                : (IData)(__Vfunc___03722__45__a))));
    vlSelf->__PVT___291_ = __Vfunc___03722__45__Vfuncout;
    __Vfunc___03729__50__s = (((3U == (0xfU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 4U))) 
                               << 1U) | (5U == (0xfU 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                   >> 4U))));
    __Vfunc___03729__50__b = (((IData)(vlSelf->__PVT___417_) 
                               << 1U) | (IData)(vlSelf->__PVT___270_));
    __Vfunc___03729__50__a = vlSelf->__PVT___417_;
    __Vfunc___03729__50__Vfuncout = (1U & ((1U == (1U 
                                                   & (IData)(__Vfunc___03729__50__s)))
                                            ? (IData)(__Vfunc___03729__50__b)
                                            : ((2U 
                                                == 
                                                (2U 
                                                 & (IData)(__Vfunc___03729__50__s)))
                                                ? ((IData)(__Vfunc___03729__50__b) 
                                                   >> 1U)
                                                : (IData)(__Vfunc___03729__50__a))));
    vlSelf->__PVT___296_ = __Vfunc___03729__50__Vfuncout;
    __Vfunc___03730__51__s = (((3U == (0xfU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 4U))) 
                               << 1U) | (5U == (0xfU 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                   >> 4U))));
    __Vfunc___03730__51__b = (((IData)(vlSelf->__PVT___418_) 
                               << 1U) | (IData)(vlSelf->__PVT___271_));
    __Vfunc___03730__51__a = vlSelf->__PVT___418_;
    __Vfunc___03730__51__Vfuncout = (1U & ((1U == (1U 
                                                   & (IData)(__Vfunc___03730__51__s)))
                                            ? (IData)(__Vfunc___03730__51__b)
                                            : ((2U 
                                                == 
                                                (2U 
                                                 & (IData)(__Vfunc___03730__51__s)))
                                                ? ((IData)(__Vfunc___03730__51__b) 
                                                   >> 1U)
                                                : (IData)(__Vfunc___03730__51__a))));
    vlSelf->__PVT___297_ = __Vfunc___03730__51__Vfuncout;
    __Vfunc___03731__52__s = (((3U == (0xfU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 4U))) 
                               << 1U) | (5U == (0xfU 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                   >> 4U))));
    __Vfunc___03731__52__b = (((IData)(vlSelf->__PVT___427_) 
                               << 1U) | (IData)(vlSelf->__PVT___272_));
    __Vfunc___03731__52__a = vlSelf->__PVT___427_;
    __Vfunc___03731__52__Vfuncout = (1U & ((1U == (1U 
                                                   & (IData)(__Vfunc___03731__52__s)))
                                            ? (IData)(__Vfunc___03731__52__b)
                                            : ((2U 
                                                == 
                                                (2U 
                                                 & (IData)(__Vfunc___03731__52__s)))
                                                ? ((IData)(__Vfunc___03731__52__b) 
                                                   >> 1U)
                                                : (IData)(__Vfunc___03731__52__a))));
    vlSelf->__PVT___298_ = __Vfunc___03731__52__Vfuncout;
    __Vfunc___03732__53__s = (((3U == (0xfU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 4U))) 
                               << 1U) | (5U == (0xfU 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                   >> 4U))));
    __Vfunc___03732__53__b = (((IData)(vlSelf->__PVT___428_) 
                               << 1U) | (IData)(vlSelf->__PVT___273_));
    __Vfunc___03732__53__a = vlSelf->__PVT___428_;
    __Vfunc___03732__53__Vfuncout = (1U & ((1U == (1U 
                                                   & (IData)(__Vfunc___03732__53__s)))
                                            ? (IData)(__Vfunc___03732__53__b)
                                            : ((2U 
                                                == 
                                                (2U 
                                                 & (IData)(__Vfunc___03732__53__s)))
                                                ? ((IData)(__Vfunc___03732__53__b) 
                                                   >> 1U)
                                                : (IData)(__Vfunc___03732__53__a))));
    vlSelf->__PVT___299_ = __Vfunc___03732__53__Vfuncout;
    __Vfunc___03734__54__s = (((3U == (0xfU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 4U))) 
                               << 1U) | (5U == (0xfU 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                   >> 4U))));
    __Vfunc___03734__54__b = (((IData)(vlSelf->__PVT___429_) 
                               << 2U) | (IData)(vlSelf->__PVT___274_));
    __Vfunc___03734__54__a = vlSelf->__PVT___429_;
    __Vfunc___03734__54__Vfuncout = (3U & ((1U == (1U 
                                                   & (IData)(__Vfunc___03734__54__s)))
                                            ? (IData)(__Vfunc___03734__54__b)
                                            : ((2U 
                                                == 
                                                (2U 
                                                 & (IData)(__Vfunc___03734__54__s)))
                                                ? ((IData)(__Vfunc___03734__54__b) 
                                                   >> 2U)
                                                : (IData)(__Vfunc___03734__54__a))));
    vlSelf->__PVT___301_ = __Vfunc___03734__54__Vfuncout;
    __Vfunc___03735__55__s = (((3U == (0xfU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 4U))) 
                               << 1U) | (5U == (0xfU 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                   >> 4U))));
    __Vfunc___03735__55__b = (((IData)(vlSelf->__PVT___430_) 
                               << 8U) | (IData)(vlSelf->__PVT___275_));
    __Vfunc___03735__55__a = vlSelf->__PVT___430_;
    __Vfunc___03735__55__Vfuncout = (0xffU & ((1U == 
                                               (1U 
                                                & (IData)(__Vfunc___03735__55__s)))
                                               ? (IData)(__Vfunc___03735__55__b)
                                               : ((2U 
                                                   == 
                                                   (2U 
                                                    & (IData)(__Vfunc___03735__55__s)))
                                                   ? 
                                                  ((IData)(__Vfunc___03735__55__b) 
                                                   >> 8U)
                                                   : (IData)(__Vfunc___03735__55__a))));
    vlSelf->__PVT___302_ = __Vfunc___03735__55__Vfuncout;
    vlSelf->__PVT__rom_page_s = ((IData)(vlSelf->__PVT___432_)
                                  ? ((0x7eU & (((0x4000U 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))
                                                 ? 
                                                ((IData)(vlSelf->__PVT___431_) 
                                                 & (IData)(vlSelf->__PVT___430_))
                                                 : (IData)(vlSelf->__PVT___430_)) 
                                               << 1U)) 
                                     | (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                              >> 0xdU)))
                                  : ((IData)(vlSelf->__PVT___144_) 
                                     & (IData)(vlSelf->__PVT___430_)));
    __Vfunc___03723__46__s = (((3U == (0xfU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 4U))) 
                               << 1U) | (5U == (0xfU 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                   >> 4U))));
    __Vfunc___03723__46__b = (((IData)(vlSelf->__PVT___414_) 
                               << 4U) | (IData)(vlSelf->__PVT___265_));
    __Vfunc___03723__46__a = vlSelf->__PVT___414_;
    __Vfunc___03723__46__Vfuncout = (0xfU & ((1U == 
                                              (1U & (IData)(__Vfunc___03723__46__s)))
                                              ? (IData)(__Vfunc___03723__46__b)
                                              : ((2U 
                                                  == 
                                                  (2U 
                                                   & (IData)(__Vfunc___03723__46__s)))
                                                  ? 
                                                 ((IData)(__Vfunc___03723__46__b) 
                                                  >> 4U)
                                                  : (IData)(__Vfunc___03723__46__a))));
    vlSelf->__PVT___292_ = __Vfunc___03723__46__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___604_ = 
        ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___711_)) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___756_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__auto_wait 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___711_) 
           & (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    vlSelf->__PVT__ym2149_audio_inst__DOT___112_ = 
        (7U & ((IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___106_) 
               & (((IData)(0xfU) - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)) 
                  >> 1U)));
    vlSelf->__PVT__ym2149_audio_inst__DOT___111_ = 
        ((~ (7U & (((IData)(0xfU) - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)) 
                   >> 1U))) & (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___106_));
    vlSelf->__PVT__ym2149_audio_inst__DOT___114_ = 
        (7U & ((IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___107_) 
               & (((IData)(0xfU) - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)) 
                  >> 1U)));
    vlSelf->__PVT__ym2149_audio_inst__DOT___113_ = 
        ((~ (7U & (((IData)(0xfU) - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)) 
                   >> 1U))) & (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___107_));
    vlSelf->__PVT__ym2149_audio_inst__DOT___116_ = 
        (7U & ((IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___108_) 
               & (((IData)(0xfU) - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)) 
                  >> 1U)));
    vlSelf->__PVT__ym2149_audio_inst__DOT___115_ = 
        ((~ (7U & (((IData)(0xfU) - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)) 
                   >> 1U))) & (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___108_));
    vlSelf->__PVT__ym2149_audio_inst__DOT___118_ = 
        (7U & ((IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___109_) 
               & (((IData)(0xfU) - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)) 
                  >> 1U)));
    vlSelf->__PVT__ym2149_audio_inst__DOT___117_ = 
        ((~ (7U & (((IData)(0xfU) - (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___050_)) 
                   >> 1U))) & (IData)(vlSelf->__PVT__ym2149_audio_inst__DOT___109_));
    __Vfunc_sn76489_audio_inst__DOT____031256__630__s 
        = (((2U == (IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___159_)) 
            << 2U) | (((1U == (IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___159_)) 
                       << 1U) | (0U == (IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___159_))));
    __Vfunc_sn76489_audio_inst__DOT____031256__630__b 
        = (((IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___157_) 
            << 2U) | ((((0U == (IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___161_)) 
                        | (IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___157_)) 
                       << 1U) | ((~ (IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___002_)) 
                                 & (IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___157_))));
    __Vfunc_sn76489_audio_inst__DOT____031256__630__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_sn76489_audio_inst__DOT____031256__630__s)))
                  ? (IData)(__Vfunc_sn76489_audio_inst__DOT____031256__630__b)
                  : ((2U == (2U & (IData)(__Vfunc_sn76489_audio_inst__DOT____031256__630__s)))
                      ? ((IData)(__Vfunc_sn76489_audio_inst__DOT____031256__630__b) 
                         >> 1U) : (IData)((((IData)(__Vfunc_sn76489_audio_inst__DOT____031256__630__s) 
                                            & (IData)(__Vfunc_sn76489_audio_inst__DOT____031256__630__b)) 
                                           >> 2U)))));
    vlSelf->__PVT__sn76489_audio_inst__DOT___016_ = __Vfunc_sn76489_audio_inst__DOT____031256__630__Vfuncout;
    __Vfunc_sn76489_audio_inst__DOT____031260__632__s 
        = (((2U == (IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___159_)) 
            << 2U) | (((1U == (IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___159_)) 
                       << 1U) | (0U == (IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___159_))));
    __Vfunc_sn76489_audio_inst__DOT____031260__632__b 
        = (((IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___161_) 
            << 0xaU) | ((0x3e0U & (((0U == (IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___161_))
                                     ? (IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___161_)
                                     : ((IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___161_) 
                                        - (IData)(1U))) 
                                   << 5U)) | ((IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___002_)
                                               ? 0x1fU
                                               : (IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___161_))));
    __Vfunc_sn76489_audio_inst__DOT____031260__632__Vfuncout 
        = (0x1fU & ((1U == (1U & (IData)(__Vfunc_sn76489_audio_inst__DOT____031260__632__s)))
                     ? (IData)(__Vfunc_sn76489_audio_inst__DOT____031260__632__b)
                     : ((2U == (2U & (IData)(__Vfunc_sn76489_audio_inst__DOT____031260__632__s)))
                         ? ((IData)(__Vfunc_sn76489_audio_inst__DOT____031260__632__b) 
                            >> 5U) : ((4U == (4U & (IData)(__Vfunc_sn76489_audio_inst__DOT____031260__632__s)))
                                       ? ((IData)(__Vfunc_sn76489_audio_inst__DOT____031260__632__b) 
                                          >> 0xaU) : 0U))));
    vlSelf->__PVT__sn76489_audio_inst__DOT___018_ = __Vfunc_sn76489_audio_inst__DOT____031260__632__Vfuncout;
    __Vfunc_sn76489_audio_inst__DOT____031258__631__s 
        = (((2U == (IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___159_)) 
            << 2U) | (((1U == (IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___159_)) 
                       << 1U) | (0U == (IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___159_))));
    __Vfunc_sn76489_audio_inst__DOT____031258__631__b 
        = ((((IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___155_)
              ? 0U : (IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___159_)) 
            << 4U) | ((((0U == (IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___161_))
                         ? 2U : (IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___159_)) 
                       << 2U) | ((IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___002_)
                                  ? 1U : (IData)(vlSelf->__PVT__sn76489_audio_inst__DOT___159_))));
    __Vfunc_sn76489_audio_inst__DOT____031258__631__Vfuncout 
        = (3U & ((1U == (1U & (IData)(__Vfunc_sn76489_audio_inst__DOT____031258__631__s)))
                  ? (IData)(__Vfunc_sn76489_audio_inst__DOT____031258__631__b)
                  : ((2U == (2U & (IData)(__Vfunc_sn76489_audio_inst__DOT____031258__631__s)))
                      ? ((IData)(__Vfunc_sn76489_audio_inst__DOT____031258__631__b) 
                         >> 2U) : ((4U == (4U & (IData)(__Vfunc_sn76489_audio_inst__DOT____031258__631__s)))
                                    ? ((IData)(__Vfunc_sn76489_audio_inst__DOT____031258__631__b) 
                                       >> 4U) : 0U))));
    vlSelf->__PVT__sn76489_audio_inst__DOT___017_ = __Vfunc_sn76489_audio_inst__DOT____031258__631__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033959__81__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___459_;
    __Vfunc_inst_t80__DOT__u0__DOT____033959__81__b 
        = (1U & (~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_)));
    __Vfunc_inst_t80__DOT__u0__DOT____033959__81__Vfuncout 
        = ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033959__81__s) 
           & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033959__81__b));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___460_ = __Vfunc_inst_t80__DOT__u0__DOT____033959__81__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT____033961__82__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT___459_;
    __Vfunc_inst_t80__DOT__u0__DOT____033961__82__b 
        = (1U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___788_));
    __Vfunc_inst_t80__DOT__u0__DOT____033961__82__Vfuncout 
        = ((IData)(__Vfunc_inst_t80__DOT__u0__DOT____033961__82__s) 
           & (IData)(__Vfunc_inst_t80__DOT__u0__DOT____033961__82__b));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___461_ = __Vfunc_inst_t80__DOT__u0__DOT____033961__82__Vfuncout;
    __Vfunc___03725__47__s = (((3U == (0xfU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 4U))) 
                               << 1U) | (5U == (0xfU 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                   >> 4U))));
    __Vfunc___03725__47__b = (((IData)(vlSelf->__PVT___286_) 
                               << 8U) | (IData)(vlSelf->__PVT___266_));
    __Vfunc___03725__47__Vfuncout = (0xffU & ((1U == 
                                               (1U 
                                                & (IData)(__Vfunc___03725__47__s)))
                                               ? (IData)(__Vfunc___03725__47__b)
                                               : ((2U 
                                                   == 
                                                   (2U 
                                                    & (IData)(__Vfunc___03725__47__s)))
                                                   ? 
                                                  ((IData)(__Vfunc___03725__47__b) 
                                                   >> 8U)
                                                   : 0U)));
    vlSelf->__PVT___293_ = __Vfunc___03725__47__Vfuncout;
    __Vfunc___03699__37__s = (((0xeU == (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                               << 0xcU) | (((0xbU == 
                                             (0xfU 
                                              & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                            << 0xbU) 
                                           | (((0xaU 
                                                == 
                                                (0xfU 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                               << 0xaU) 
                                              | (((9U 
                                                   == 
                                                   (0xfU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                  << 9U) 
                                                 | (((8U 
                                                      == 
                                                      (0xfU 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                     << 8U) 
                                                    | (((7U 
                                                         == 
                                                         (0xfU 
                                                          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                        << 7U) 
                                                       | (((6U 
                                                            == 
                                                            (0xfU 
                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                           << 6U) 
                                                          | (((5U 
                                                               == 
                                                               (0xfU 
                                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                              << 5U) 
                                                             | (((4U 
                                                                  == 
                                                                  (0xfU 
                                                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                 << 4U) 
                                                                | (((3U 
                                                                     == 
                                                                     (0xfU 
                                                                      & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                    << 3U) 
                                                                   | (((2U 
                                                                        == 
                                                                        (0xfU 
                                                                         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                       << 2U) 
                                                                      | (((1U 
                                                                           == 
                                                                           (0xfU 
                                                                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                          << 1U) 
                                                                         | (0U 
                                                                            == 
                                                                            (0xfU 
                                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))))))))))))));
    __Vfunc___03699__37__b = ((0x1fc0U & ((- (IData)((IData)(vlSelf->__PVT___432_))) 
                                          << 6U)) | 
                              ((((IData)(vlSelf->__PVT__inst_t80__DOT___63_)
                                  ? (IData)(vlSelf->__PVT___432_)
                                  : (IData)(((1U == 
                                              (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_))) 
                                             & (IData)(vlSelf->__PVT___226_)))) 
                                << 5U) | (0x1fU & (- (IData)((IData)(vlSelf->__PVT___432_))))));
    __Vfunc___03699__37__a = vlSelf->__PVT___432_;
    __Vfunc___03699__37__Vfuncout = (1U & (((((((((1U 
                                                   == 
                                                   (1U 
                                                    & (IData)(__Vfunc___03699__37__s))) 
                                                  | (2U 
                                                     == 
                                                     (2U 
                                                      & (IData)(__Vfunc___03699__37__s)))) 
                                                 | (4U 
                                                    == 
                                                    (4U 
                                                     & (IData)(__Vfunc___03699__37__s)))) 
                                                | (8U 
                                                   == 
                                                   (8U 
                                                    & (IData)(__Vfunc___03699__37__s)))) 
                                               | (0x10U 
                                                  == 
                                                  (0x10U 
                                                   & (IData)(__Vfunc___03699__37__s)))) 
                                              | (0x20U 
                                                 == 
                                                 (0x20U 
                                                  & (IData)(__Vfunc___03699__37__s)))) 
                                             | (0x40U 
                                                == 
                                                (0x40U 
                                                 & (IData)(__Vfunc___03699__37__s)))) 
                                            | (0x80U 
                                               == (0x80U 
                                                   & (IData)(__Vfunc___03699__37__s))))
                                            ? ((1U 
                                                == 
                                                (1U 
                                                 & (IData)(__Vfunc___03699__37__s)))
                                                ? (IData)(__Vfunc___03699__37__b)
                                                : (
                                                   (2U 
                                                    == 
                                                    (2U 
                                                     & (IData)(__Vfunc___03699__37__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03699__37__b) 
                                                    >> 1U)
                                                    : 
                                                   ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03699__37__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03699__37__b) 
                                                     >> 2U)
                                                     : 
                                                    ((8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03699__37__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03699__37__b) 
                                                      >> 3U)
                                                      : 
                                                     ((0x10U 
                                                       == 
                                                       (0x10U 
                                                        & (IData)(__Vfunc___03699__37__s)))
                                                       ? 
                                                      ((IData)(__Vfunc___03699__37__b) 
                                                       >> 4U)
                                                       : 
                                                      ((0x20U 
                                                        == 
                                                        (0x20U 
                                                         & (IData)(__Vfunc___03699__37__s)))
                                                        ? 
                                                       ((IData)(__Vfunc___03699__37__b) 
                                                        >> 5U)
                                                        : 
                                                       ((0x40U 
                                                         == 
                                                         (0x40U 
                                                          & (IData)(__Vfunc___03699__37__s)))
                                                         ? 
                                                        ((IData)(__Vfunc___03699__37__b) 
                                                         >> 6U)
                                                         : 
                                                        ((IData)(__Vfunc___03699__37__b) 
                                                         >> 7U))))))))
                                            : ((0x100U 
                                                == 
                                                (0x100U 
                                                 & (IData)(__Vfunc___03699__37__s)))
                                                ? ((IData)(__Vfunc___03699__37__b) 
                                                   >> 8U)
                                                : (
                                                   (0x200U 
                                                    == 
                                                    (0x200U 
                                                     & (IData)(__Vfunc___03699__37__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03699__37__b) 
                                                    >> 9U)
                                                    : 
                                                   ((0x400U 
                                                     == 
                                                     (0x400U 
                                                      & (IData)(__Vfunc___03699__37__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03699__37__b) 
                                                     >> 0xaU)
                                                     : 
                                                    ((0x800U 
                                                      == 
                                                      (0x800U 
                                                       & (IData)(__Vfunc___03699__37__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03699__37__b) 
                                                      >> 0xbU)
                                                      : 
                                                     ((0x1000U 
                                                       == 
                                                       (0x1000U 
                                                        & (IData)(__Vfunc___03699__37__s)))
                                                       ? 
                                                      ((IData)(__Vfunc___03699__37__b) 
                                                       >> 0xcU)
                                                       : (IData)(__Vfunc___03699__37__a))))))));
    vlSelf->__PVT___276_ = __Vfunc___03699__37__Vfuncout;
    __Vfunc___03700__38__s = (((0xeU == (0xfU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                               << 0xcU) | (((0xbU == 
                                             (0xfU 
                                              & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                            << 0xbU) 
                                           | (((0xaU 
                                                == 
                                                (0xfU 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                               << 0xaU) 
                                              | (((9U 
                                                   == 
                                                   (0xfU 
                                                    & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                  << 9U) 
                                                 | (((8U 
                                                      == 
                                                      (0xfU 
                                                       & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                     << 8U) 
                                                    | (((7U 
                                                         == 
                                                         (0xfU 
                                                          & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                        << 7U) 
                                                       | (((6U 
                                                            == 
                                                            (0xfU 
                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                           << 6U) 
                                                          | (((5U 
                                                               == 
                                                               (0xfU 
                                                                & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                              << 5U) 
                                                             | (((4U 
                                                                  == 
                                                                  (0xfU 
                                                                   & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                 << 4U) 
                                                                | (((3U 
                                                                     == 
                                                                     (0xfU 
                                                                      & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                    << 3U) 
                                                                   | (((2U 
                                                                        == 
                                                                        (0xfU 
                                                                         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                       << 2U) 
                                                                      | (((1U 
                                                                           == 
                                                                           (0xfU 
                                                                            & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                                                          << 1U) 
                                                                         | (0U 
                                                                            == 
                                                                            (0xfU 
                                                                             & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_)))))))))))))));
    __Vfunc___03700__38__b = ((0x1fc0U & ((- (IData)((IData)(vlSelf->__PVT___434_))) 
                                          << 6U)) | 
                              ((((IData)(vlSelf->__PVT__inst_t80__DOT___63_)
                                  ? (IData)(vlSelf->__PVT___434_)
                                  : (IData)(((2U == 
                                              (3U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___814_))) 
                                             & (IData)(vlSelf->__PVT___226_)))) 
                                << 5U) | (0x1fU & (- (IData)((IData)(vlSelf->__PVT___434_))))));
    __Vfunc___03700__38__a = vlSelf->__PVT___434_;
    __Vfunc___03700__38__Vfuncout = (1U & (((((((((1U 
                                                   == 
                                                   (1U 
                                                    & (IData)(__Vfunc___03700__38__s))) 
                                                  | (2U 
                                                     == 
                                                     (2U 
                                                      & (IData)(__Vfunc___03700__38__s)))) 
                                                 | (4U 
                                                    == 
                                                    (4U 
                                                     & (IData)(__Vfunc___03700__38__s)))) 
                                                | (8U 
                                                   == 
                                                   (8U 
                                                    & (IData)(__Vfunc___03700__38__s)))) 
                                               | (0x10U 
                                                  == 
                                                  (0x10U 
                                                   & (IData)(__Vfunc___03700__38__s)))) 
                                              | (0x20U 
                                                 == 
                                                 (0x20U 
                                                  & (IData)(__Vfunc___03700__38__s)))) 
                                             | (0x40U 
                                                == 
                                                (0x40U 
                                                 & (IData)(__Vfunc___03700__38__s)))) 
                                            | (0x80U 
                                               == (0x80U 
                                                   & (IData)(__Vfunc___03700__38__s))))
                                            ? ((1U 
                                                == 
                                                (1U 
                                                 & (IData)(__Vfunc___03700__38__s)))
                                                ? (IData)(__Vfunc___03700__38__b)
                                                : (
                                                   (2U 
                                                    == 
                                                    (2U 
                                                     & (IData)(__Vfunc___03700__38__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03700__38__b) 
                                                    >> 1U)
                                                    : 
                                                   ((4U 
                                                     == 
                                                     (4U 
                                                      & (IData)(__Vfunc___03700__38__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03700__38__b) 
                                                     >> 2U)
                                                     : 
                                                    ((8U 
                                                      == 
                                                      (8U 
                                                       & (IData)(__Vfunc___03700__38__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03700__38__b) 
                                                      >> 3U)
                                                      : 
                                                     ((0x10U 
                                                       == 
                                                       (0x10U 
                                                        & (IData)(__Vfunc___03700__38__s)))
                                                       ? 
                                                      ((IData)(__Vfunc___03700__38__b) 
                                                       >> 4U)
                                                       : 
                                                      ((0x20U 
                                                        == 
                                                        (0x20U 
                                                         & (IData)(__Vfunc___03700__38__s)))
                                                        ? 
                                                       ((IData)(__Vfunc___03700__38__b) 
                                                        >> 5U)
                                                        : 
                                                       ((0x40U 
                                                         == 
                                                         (0x40U 
                                                          & (IData)(__Vfunc___03700__38__s)))
                                                         ? 
                                                        ((IData)(__Vfunc___03700__38__b) 
                                                         >> 6U)
                                                         : 
                                                        ((IData)(__Vfunc___03700__38__b) 
                                                         >> 7U))))))))
                                            : ((0x100U 
                                                == 
                                                (0x100U 
                                                 & (IData)(__Vfunc___03700__38__s)))
                                                ? ((IData)(__Vfunc___03700__38__b) 
                                                   >> 8U)
                                                : (
                                                   (0x200U 
                                                    == 
                                                    (0x200U 
                                                     & (IData)(__Vfunc___03700__38__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03700__38__b) 
                                                    >> 9U)
                                                    : 
                                                   ((0x400U 
                                                     == 
                                                     (0x400U 
                                                      & (IData)(__Vfunc___03700__38__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03700__38__b) 
                                                     >> 0xaU)
                                                     : 
                                                    ((0x800U 
                                                      == 
                                                      (0x800U 
                                                       & (IData)(__Vfunc___03700__38__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03700__38__b) 
                                                      >> 0xbU)
                                                      : 
                                                     ((0x1000U 
                                                       == 
                                                       (0x1000U 
                                                        & (IData)(__Vfunc___03700__38__s)))
                                                       ? 
                                                      ((IData)(__Vfunc___03700__38__b) 
                                                       >> 0xcU)
                                                       : (IData)(__Vfunc___03700__38__a))))))));
    vlSelf->__PVT___277_ = __Vfunc___03700__38__Vfuncout;
    vlSelf->__PVT__ctrl_b__DOT__p2_edge_s = ((IData)(vlSelf->__PVT__ctrl_b__DOT__p2_qa_s) 
                                             & (IData)(vlSelf->__PVT__ctrl_b__DOT___71_));
    vlSelf->__PVT__ctrl_b__DOT__p1_edge_s = ((IData)(vlSelf->__PVT__ctrl_b__DOT__p1_qa_s) 
                                             & (IData)(vlSelf->__PVT__ctrl_b__DOT___69_));
    vlSelf->__PVT___447_ = ((2U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))
                             ? (((IData)(vlSelf->__PVT__ctrl_b__DOT__p2_qa_s) 
                                 << 7U) | (((IData)(vlSelf->__PVT__ctrl_b__DOT__p2_6__DOT___7_) 
                                            << 6U) 
                                           | (((IData)(vlSelf->__PVT__ctrl_b__DOT__p2_7__DOT___7_) 
                                               << 5U) 
                                              | (((IData)(vlSelf->__PVT__ctrl_b__DOT___81_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->__PVT__ctrl_b__DOT__p2_3__DOT___7_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->__PVT__ctrl_b__DOT__p2_2__DOT___7_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->__PVT__ctrl_b__DOT__p2_4__DOT___7_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->__PVT__ctrl_b__DOT__p2_1__DOT___7_))))))))
                             : (((IData)(vlSelf->__PVT__ctrl_b__DOT__p1_qa_s) 
                                 << 7U) | (((IData)(vlSelf->__PVT__ctrl_b__DOT__p1_6__DOT___7_) 
                                            << 6U) 
                                           | (((IData)(vlSelf->__PVT__ctrl_b__DOT__p1_7__DOT___7_) 
                                               << 5U) 
                                              | (((IData)(vlSelf->__PVT__ctrl_b__DOT___77_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->__PVT__ctrl_b__DOT__p1_3__DOT___7_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->__PVT__ctrl_b__DOT__p1_2__DOT___7_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->__PVT__ctrl_b__DOT__p1_4__DOT___7_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->__PVT__ctrl_b__DOT__p1_1__DOT___7_)))))))));
    __Vfunc___03728__49__s = (((3U == (0xfU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 4U))) 
                               << 1U) | (5U == (0xfU 
                                                & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                   >> 4U))));
    __Vfunc___03728__49__b = (2U | (IData)(vlSelf->__PVT___269_));
    __Vfunc___03728__49__Vfuncout = (1U & ((1U == (1U 
                                                   & (IData)(__Vfunc___03728__49__s)))
                                            ? (IData)(__Vfunc___03728__49__b)
                                            : ((2U 
                                                != 
                                                (2U 
                                                 & (IData)(__Vfunc___03728__49__s))) 
                                               | ((IData)(__Vfunc___03728__49__b) 
                                                  >> 1U))));
    vlSelf->__PVT___295_ = __Vfunc___03728__49__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___135_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___806_) 
         & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___621_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__b 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0628_) 
           << 1U);
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__Vfuncout 
        = (1U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__b)
                  : (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__s) 
                              & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__b)) 
                             >> 1U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0632_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036100__237__Vfuncout;
    __Vfunc___03503__17__s = (((6U == (IData)(vlSelf->__PVT__io_decode_s)) 
                               << 5U) | (((4U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                          << 4U) | 
                                         (((3U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                           << 3U) | 
                                          (((2U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                            << 2U) 
                                           | (((1U 
                                                == (IData)(vlSelf->__PVT__io_decode_s)) 
                                               << 1U) 
                                              | (0U 
                                                 == (IData)(vlSelf->__PVT__io_decode_s)))))));
    __Vfunc___03503__17__Vfuncout = (1U & ((0x20U & (IData)(__Vfunc___03503__17__s))
                                            ? ((0x10U 
                                                & (IData)(__Vfunc___03503__17__s))
                                                ? (IData)(
                                                          (8U 
                                                           != 
                                                           (0xfU 
                                                            & (IData)(__Vfunc___03503__17__s))))
                                                : (IData)(
                                                          (8U 
                                                           != 
                                                           (0xfU 
                                                            & (IData)(__Vfunc___03503__17__s)))))
                                            : ((0x10U 
                                                & (IData)(__Vfunc___03503__17__s))
                                                ? (IData)(
                                                          (8U 
                                                           != 
                                                           (0xfU 
                                                            & (IData)(__Vfunc___03503__17__s))))
                                                : (IData)(
                                                          (8U 
                                                           != 
                                                           (0xfU 
                                                            & (IData)(__Vfunc___03503__17__s)))))));
    vlSelf->__PVT___161_ = __Vfunc___03503__17__Vfuncout;
    __Vfunc___03506__18__s = (((6U == (IData)(vlSelf->__PVT__io_decode_s)) 
                               << 5U) | (((4U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                          << 4U) | 
                                         (((3U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                           << 3U) | 
                                          (((2U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                            << 2U) 
                                           | (((1U 
                                                == (IData)(vlSelf->__PVT__io_decode_s)) 
                                               << 1U) 
                                              | (0U 
                                                 == (IData)(vlSelf->__PVT__io_decode_s)))))));
    __Vfunc___03506__18__Vfuncout = (1U & ((0x20U & (IData)(__Vfunc___03506__18__s))
                                            ? ((0x10U 
                                                & (IData)(__Vfunc___03506__18__s))
                                                ? (
                                                   (8U 
                                                    & (IData)(__Vfunc___03506__18__s))
                                                    ? (IData)(
                                                              (4U 
                                                               != 
                                                               (7U 
                                                                & (IData)(__Vfunc___03506__18__s))))
                                                    : (IData)(
                                                              (4U 
                                                               != 
                                                               (7U 
                                                                & (IData)(__Vfunc___03506__18__s)))))
                                                : (
                                                   (8U 
                                                    & (IData)(__Vfunc___03506__18__s))
                                                    ? (IData)(
                                                              (4U 
                                                               != 
                                                               (7U 
                                                                & (IData)(__Vfunc___03506__18__s))))
                                                    : (IData)(
                                                              (4U 
                                                               != 
                                                               (7U 
                                                                & (IData)(__Vfunc___03506__18__s))))))
                                            : ((0x10U 
                                                & (IData)(__Vfunc___03506__18__s))
                                                ? (
                                                   (8U 
                                                    & (IData)(__Vfunc___03506__18__s))
                                                    ? (IData)(
                                                              (4U 
                                                               != 
                                                               (7U 
                                                                & (IData)(__Vfunc___03506__18__s))))
                                                    : (IData)(
                                                              (4U 
                                                               != 
                                                               (7U 
                                                                & (IData)(__Vfunc___03506__18__s)))))
                                                : (
                                                   (8U 
                                                    & (IData)(__Vfunc___03506__18__s))
                                                    ? (IData)(
                                                              (4U 
                                                               != 
                                                               (7U 
                                                                & (IData)(__Vfunc___03506__18__s))))
                                                    : (IData)(
                                                              (4U 
                                                               != 
                                                               (7U 
                                                                & (IData)(__Vfunc___03506__18__s))))))));
    vlSelf->__PVT___162_ = __Vfunc___03506__18__Vfuncout;
    __Vfunc___03509__19__s = (((6U == (IData)(vlSelf->__PVT__io_decode_s)) 
                               << 5U) | (((4U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                          << 4U) | 
                                         (((3U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                           << 3U) | 
                                          (((2U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                            << 2U) 
                                           | (((1U 
                                                == (IData)(vlSelf->__PVT__io_decode_s)) 
                                               << 1U) 
                                              | (0U 
                                                 == (IData)(vlSelf->__PVT__io_decode_s)))))));
    __Vfunc___03509__19__Vfuncout = (IData)((0x20U 
                                             != (IData)(__Vfunc___03509__19__s)));
    vlSelf->__PVT___163_ = __Vfunc___03509__19__Vfuncout;
    __Vfunc___03513__21__s = (((6U == (IData)(vlSelf->__PVT__io_decode_s)) 
                               << 5U) | (((4U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                          << 4U) | 
                                         (((3U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                           << 3U) | 
                                          (((2U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                            << 2U) 
                                           | (((1U 
                                                == (IData)(vlSelf->__PVT__io_decode_s)) 
                                               << 1U) 
                                              | (0U 
                                                 == (IData)(vlSelf->__PVT__io_decode_s)))))));
    __Vfunc___03513__21__Vfuncout = (1U & ((0x20U & (IData)(__Vfunc___03513__21__s))
                                            ? ((0x10U 
                                                & (IData)(__Vfunc___03513__21__s))
                                                ? (
                                                   (8U 
                                                    & (IData)(__Vfunc___03513__21__s))
                                                    ? 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03513__21__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s))))
                                                    : 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03513__21__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s)))))
                                                : (
                                                   (8U 
                                                    & (IData)(__Vfunc___03513__21__s))
                                                    ? 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03513__21__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s))))
                                                    : 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03513__21__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s))))))
                                            : ((0x10U 
                                                & (IData)(__Vfunc___03513__21__s))
                                                ? (
                                                   (8U 
                                                    & (IData)(__Vfunc___03513__21__s))
                                                    ? 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03513__21__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s))))
                                                    : 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03513__21__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s)))))
                                                : (
                                                   (8U 
                                                    & (IData)(__Vfunc___03513__21__s))
                                                    ? 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03513__21__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s))))
                                                    : 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03513__21__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03513__21__s))
                                                      ? 
                                                     (~ (IData)(__Vfunc___03513__21__s))
                                                      : 
                                                     (~ (IData)(__Vfunc___03513__21__s))))))));
    vlSelf->__PVT___165_ = __Vfunc___03513__21__Vfuncout;
    __Vfunc___03516__22__s = (((6U == (IData)(vlSelf->__PVT__io_decode_s)) 
                               << 5U) | (((4U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                          << 4U) | 
                                         (((3U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                           << 3U) | 
                                          (((2U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                            << 2U) 
                                           | (((1U 
                                                == (IData)(vlSelf->__PVT__io_decode_s)) 
                                               << 1U) 
                                              | (0U 
                                                 == (IData)(vlSelf->__PVT__io_decode_s)))))));
    __Vfunc___03516__22__Vfuncout = (1U & ((0x20U & (IData)(__Vfunc___03516__22__s))
                                            ? (IData)(
                                                      (0x10U 
                                                       != 
                                                       (0x1fU 
                                                        & (IData)(__Vfunc___03516__22__s))))
                                            : (IData)(
                                                      (0x10U 
                                                       != 
                                                       (0x1fU 
                                                        & (IData)(__Vfunc___03516__22__s))))));
    vlSelf->__PVT___166_ = __Vfunc___03516__22__Vfuncout;
    __Vfunc___03518__23__s = (((6U == (IData)(vlSelf->__PVT__io_decode_s)) 
                               << 5U) | (((4U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                          << 4U) | 
                                         (((3U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                           << 3U) | 
                                          (((2U == (IData)(vlSelf->__PVT__io_decode_s)) 
                                            << 2U) 
                                           | (((1U 
                                                == (IData)(vlSelf->__PVT__io_decode_s)) 
                                               << 1U) 
                                              | (0U 
                                                 == (IData)(vlSelf->__PVT__io_decode_s)))))));
    __Vfunc___03518__23__b = (((~ (IData)(vlSelf->__PVT__inst_t80__DOT___61_)) 
                               & (IData)(vlSelf->__PVT___427_)) 
                              << 1U);
    __Vfunc___03518__23__Vfuncout = (1U & ((0x20U & (IData)(__Vfunc___03518__23__s))
                                            ? ((0x10U 
                                                & (IData)(__Vfunc___03518__23__s))
                                                ? (
                                                   (8U 
                                                    & (IData)(__Vfunc___03518__23__s))
                                                    ? 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03518__23__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03518__23__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 1U))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 2U)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03518__23__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 1U))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 3U))))
                                                    : 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03518__23__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03518__23__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 1U))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 2U)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03518__23__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 1U))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 4U)))))
                                                : (
                                                   (8U 
                                                    & (IData)(__Vfunc___03518__23__s))
                                                    ? 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03518__23__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03518__23__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 1U))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 2U)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03518__23__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 1U))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 3U))))
                                                    : 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03518__23__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03518__23__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 1U))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 2U)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03518__23__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 1U))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 5U))))))
                                            : ((0x10U 
                                                & (IData)(__Vfunc___03518__23__s))
                                                ? (
                                                   (8U 
                                                    & (IData)(__Vfunc___03518__23__s))
                                                    ? 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03518__23__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03518__23__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 1U))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 2U)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03518__23__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 1U))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 3U))))
                                                    : 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03518__23__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03518__23__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 1U))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 2U)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03518__23__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 1U))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 4U)))))
                                                : (
                                                   (8U 
                                                    & (IData)(__Vfunc___03518__23__s))
                                                    ? 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03518__23__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03518__23__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 1U))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 2U)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03518__23__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 1U))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 3U))))
                                                    : 
                                                   ((4U 
                                                     & (IData)(__Vfunc___03518__23__s))
                                                     ? 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03518__23__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 1U))
                                                      : 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 2U)))
                                                     : 
                                                    ((2U 
                                                      & (IData)(__Vfunc___03518__23__s))
                                                      ? 
                                                     ((1U 
                                                       & (IData)(__Vfunc___03518__23__s))
                                                       ? (IData)(__Vfunc___03518__23__b)
                                                       : 
                                                      ((IData)(__Vfunc___03518__23__b) 
                                                       >> 1U))
                                                      : 
                                                     ((IData)(__Vfunc___03518__23__s) 
                                                      & (IData)(__Vfunc___03518__23__b))))))));
    vlSelf->__PVT___168_ = __Vfunc___03518__23__Vfuncout;
    __Vfunc___03386__3__s = (((7U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                            >> 0xdU))) 
                              << 7U) | (((6U == (7U 
                                                 & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                    >> 0xdU))) 
                                         << 6U) | (
                                                   ((5U 
                                                     == 
                                                     (7U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                         >> 0xdU))) 
                                                    << 5U) 
                                                   | (((4U 
                                                        == 
                                                        (7U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                            >> 0xdU))) 
                                                       << 4U) 
                                                      | (((3U 
                                                           == 
                                                           (7U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                               >> 0xdU))) 
                                                          << 3U) 
                                                         | (((2U 
                                                              == 
                                                              (7U 
                                                               & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                  >> 0xdU))) 
                                                             << 2U) 
                                                            | (((1U 
                                                                 == 
                                                                 (7U 
                                                                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                     >> 0xdU))) 
                                                                << 1U) 
                                                               | (0U 
                                                                  == 
                                                                  (7U 
                                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                      >> 0xdU))))))))));
    __Vfunc___03386__3__b = (8U & (((~ (IData)(vlSelf->__PVT___066_)) 
                                    | (IData)(((0U 
                                                == 
                                                (0x1c00U 
                                                 & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_))) 
                                               & (IData)(vlSelf->__PVT___415_)))) 
                                   << 3U));
    __Vfunc___03386__3__Vfuncout = (((((((((1U == (1U 
                                                   & (IData)(__Vfunc___03386__3__s))) 
                                           | (2U == 
                                              (2U & (IData)(__Vfunc___03386__3__s)))) 
                                          | (4U == 
                                             (4U & (IData)(__Vfunc___03386__3__s)))) 
                                         | (8U == (8U 
                                                   & (IData)(__Vfunc___03386__3__s)))) 
                                        | (0x10U == 
                                           (0x10U & (IData)(__Vfunc___03386__3__s)))) 
                                       | (0x20U == 
                                          (0x20U & (IData)(__Vfunc___03386__3__s)))) 
                                      | (0x40U == (0x40U 
                                                   & (IData)(__Vfunc___03386__3__s)))) 
                                     | (0x80U == (0x80U 
                                                  & (IData)(__Vfunc___03386__3__s)))) 
                                    & ((1U == (1U & (IData)(__Vfunc___03386__3__s)))
                                        ? (IData)(__Vfunc___03386__3__b)
                                        : ((2U == (2U 
                                                   & (IData)(__Vfunc___03386__3__s)))
                                            ? ((IData)(__Vfunc___03386__3__b) 
                                               >> 1U)
                                            : ((4U 
                                                == 
                                                (4U 
                                                 & (IData)(__Vfunc___03386__3__s)))
                                                ? ((IData)(__Vfunc___03386__3__b) 
                                                   >> 2U)
                                                : (
                                                   (8U 
                                                    == 
                                                    (8U 
                                                     & (IData)(__Vfunc___03386__3__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03386__3__b) 
                                                    >> 3U)
                                                    : 
                                                   ((0x10U 
                                                     == 
                                                     (0x10U 
                                                      & (IData)(__Vfunc___03386__3__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03386__3__b) 
                                                     >> 4U)
                                                     : 
                                                    ((0x20U 
                                                      == 
                                                      (0x20U 
                                                       & (IData)(__Vfunc___03386__3__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03386__3__b) 
                                                      >> 5U)
                                                      : 
                                                     ((0x40U 
                                                       == 
                                                       (0x40U 
                                                        & (IData)(__Vfunc___03386__3__s)))
                                                       ? 
                                                      ((IData)(__Vfunc___03386__3__b) 
                                                       >> 6U)
                                                       : 
                                                      ((IData)(__Vfunc___03386__3__b) 
                                                       >> 7U)))))))));
    vlSelf->__PVT___108_ = __Vfunc___03386__3__Vfuncout;
    vlSelf->__PVT___072_ = (1U & ((~ (IData)(vlSelf->__PVT___066_)) 
                                  | (IData)(vlSelf->__PVT__inst_t80__DOT___63_)));
    __Vfunc___03390__6__s = (((7U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                            >> 0xdU))) 
                              << 7U) | (((6U == (7U 
                                                 & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                    >> 0xdU))) 
                                         << 6U) | (
                                                   ((5U 
                                                     == 
                                                     (7U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                         >> 0xdU))) 
                                                    << 5U) 
                                                   | (((4U 
                                                        == 
                                                        (7U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                            >> 0xdU))) 
                                                       << 4U) 
                                                      | (((3U 
                                                           == 
                                                           (7U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                               >> 0xdU))) 
                                                          << 3U) 
                                                         | (((2U 
                                                              == 
                                                              (7U 
                                                               & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                  >> 0xdU))) 
                                                             << 2U) 
                                                            | (((1U 
                                                                 == 
                                                                 (7U 
                                                                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                     >> 0xdU))) 
                                                                << 1U) 
                                                               | (0U 
                                                                  == 
                                                                  (7U 
                                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                      >> 0xdU))))))))));
    __Vfunc___03390__6__b = (((QData)((IData)(((((IData)(vlSelf->__PVT___428_)
                                                  ? (IData)(vlSymsp->TOP__sim_top.__PVT__cart_bus)
                                                  : (IData)(vlSelf->__PVT__ext512__DOT___17_)) 
                                                << 0x18U) 
                                               | ((((IData)(vlSelf->__PVT___428_)
                                                     ? (IData)(vlSymsp->TOP__sim_top.__PVT__cart_bus)
                                                     : (IData)(vlSelf->__PVT__ext512__DOT___17_)) 
                                                   << 0x10U) 
                                                  | ((((IData)(vlSelf->__PVT___428_)
                                                        ? (IData)(vlSymsp->TOP__sim_top.__PVT__cart_bus)
                                                        : (IData)(vlSelf->__PVT__ext512__DOT___17_)) 
                                                      << 8U) 
                                                     | ((IData)(vlSelf->__PVT___428_)
                                                         ? (IData)(vlSymsp->TOP__sim_top.__PVT__cart_bus)
                                                         : (IData)(vlSelf->__PVT__ext512__DOT___17_))))))) 
                              << 0x20U) | (QData)((IData)(
                                                          ((((IData)(vlSelf->__PVT___066_)
                                                              ? (IData)(vlSelf->__PVT__ext512__DOT___17_)
                                                              : (IData)(vlSelf->__PVT___502_)) 
                                                            << 0x18U) 
                                                           | (((IData)(vlSelf->__PVT___059_) 
                                                               << 0x10U) 
                                                              | (((IData)(vlSelf->__PVT___059_) 
                                                                  << 8U) 
                                                                 | ((IData)(vlSelf->__PVT___415_)
                                                                     ? (IData)(vlSelf->__PVT__loader__DOT___0_)
                                                                     : 
                                                                    ((IData)(vlSelf->__PVT___049_)
                                                                      ? (IData)(vlSelf->__PVT__bios__DOT___4_)
                                                                      : (IData)(vlSelf->__PVT__ext512__DOT___17_)))))))));
    __Vfunc___03390__6__a = vlSymsp->TOP__sim_top.__PVT__cart_bus;
    __Vfunc___03390__6__Vfuncout = (0xffU & (((((((
                                                   ((1U 
                                                     == 
                                                     (1U 
                                                      & (IData)(__Vfunc___03390__6__s))) 
                                                    | (2U 
                                                       == 
                                                       (2U 
                                                        & (IData)(__Vfunc___03390__6__s)))) 
                                                   | (4U 
                                                      == 
                                                      (4U 
                                                       & (IData)(__Vfunc___03390__6__s)))) 
                                                  | (8U 
                                                     == 
                                                     (8U 
                                                      & (IData)(__Vfunc___03390__6__s)))) 
                                                 | (0x10U 
                                                    == 
                                                    (0x10U 
                                                     & (IData)(__Vfunc___03390__6__s)))) 
                                                | (0x20U 
                                                   == 
                                                   (0x20U 
                                                    & (IData)(__Vfunc___03390__6__s)))) 
                                               | (0x40U 
                                                  == 
                                                  (0x40U 
                                                   & (IData)(__Vfunc___03390__6__s)))) 
                                              | (0x80U 
                                                 == 
                                                 (0x80U 
                                                  & (IData)(__Vfunc___03390__6__s))))
                                              ? ((1U 
                                                  == 
                                                  (1U 
                                                   & (IData)(__Vfunc___03390__6__s)))
                                                  ? (IData)(__Vfunc___03390__6__b)
                                                  : 
                                                 ((2U 
                                                   == 
                                                   (2U 
                                                    & (IData)(__Vfunc___03390__6__s)))
                                                   ? (IData)(
                                                             (__Vfunc___03390__6__b 
                                                              >> 8U))
                                                   : 
                                                  ((4U 
                                                    == 
                                                    (4U 
                                                     & (IData)(__Vfunc___03390__6__s)))
                                                    ? (IData)(
                                                              (__Vfunc___03390__6__b 
                                                               >> 0x10U))
                                                    : 
                                                   ((8U 
                                                     == 
                                                     (8U 
                                                      & (IData)(__Vfunc___03390__6__s)))
                                                     ? (IData)(
                                                               (__Vfunc___03390__6__b 
                                                                >> 0x18U))
                                                     : 
                                                    ((0x10U 
                                                      == 
                                                      (0x10U 
                                                       & (IData)(__Vfunc___03390__6__s)))
                                                      ? (IData)(
                                                                (__Vfunc___03390__6__b 
                                                                 >> 0x20U))
                                                      : 
                                                     ((0x20U 
                                                       == 
                                                       (0x20U 
                                                        & (IData)(__Vfunc___03390__6__s)))
                                                       ? (IData)(
                                                                 (__Vfunc___03390__6__b 
                                                                  >> 0x28U))
                                                       : 
                                                      ((0x40U 
                                                        == 
                                                        (0x40U 
                                                         & (IData)(__Vfunc___03390__6__s)))
                                                        ? (IData)(
                                                                  (__Vfunc___03390__6__b 
                                                                   >> 0x30U))
                                                        : (IData)(
                                                                  (__Vfunc___03390__6__b 
                                                                   >> 0x38U)))))))))
                                              : (IData)(__Vfunc___03390__6__a)));
    vlSelf->__PVT___113_ = __Vfunc___03390__6__Vfuncout;
    __Vfunc___03387__4__s = (((7U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                            >> 0xdU))) 
                              << 7U) | (((6U == (7U 
                                                 & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                    >> 0xdU))) 
                                         << 6U) | (
                                                   ((5U 
                                                     == 
                                                     (7U 
                                                      & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                         >> 0xdU))) 
                                                    << 5U) 
                                                   | (((4U 
                                                        == 
                                                        (7U 
                                                         & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                            >> 0xdU))) 
                                                       << 4U) 
                                                      | (((3U 
                                                           == 
                                                           (7U 
                                                            & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                               >> 0xdU))) 
                                                          << 3U) 
                                                         | (((2U 
                                                              == 
                                                              (7U 
                                                               & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                  >> 0xdU))) 
                                                             << 2U) 
                                                            | (((1U 
                                                                 == 
                                                                 (7U 
                                                                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                     >> 0xdU))) 
                                                                << 1U) 
                                                               | (0U 
                                                                  == 
                                                                  (7U 
                                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                                      >> 0xdU))))))))));
    __Vfunc___03387__4__b = ((0xf0U & ((- (IData)((IData)(vlSelf->__PVT___046_))) 
                                       << 4U)) | ((
                                                   ((IData)(vlSelf->__PVT___066_) 
                                                    | (IData)(vlSelf->__PVT___046_)) 
                                                   << 3U) 
                                                  | (7U 
                                                     & (- (IData)((IData)(vlSelf->__PVT___046_))))));
    __Vfunc___03387__4__a = vlSelf->__PVT___046_;
    __Vfunc___03387__4__Vfuncout = (1U & (((((((((1U 
                                                  == 
                                                  (1U 
                                                   & (IData)(__Vfunc___03387__4__s))) 
                                                 | (2U 
                                                    == 
                                                    (2U 
                                                     & (IData)(__Vfunc___03387__4__s)))) 
                                                | (4U 
                                                   == 
                                                   (4U 
                                                    & (IData)(__Vfunc___03387__4__s)))) 
                                               | (8U 
                                                  == 
                                                  (8U 
                                                   & (IData)(__Vfunc___03387__4__s)))) 
                                              | (0x10U 
                                                 == 
                                                 (0x10U 
                                                  & (IData)(__Vfunc___03387__4__s)))) 
                                             | (0x20U 
                                                == 
                                                (0x20U 
                                                 & (IData)(__Vfunc___03387__4__s)))) 
                                            | (0x40U 
                                               == (0x40U 
                                                   & (IData)(__Vfunc___03387__4__s)))) 
                                           | (0x80U 
                                              == (0x80U 
                                                  & (IData)(__Vfunc___03387__4__s))))
                                           ? ((1U == 
                                               (1U 
                                                & (IData)(__Vfunc___03387__4__s)))
                                               ? (IData)(__Vfunc___03387__4__b)
                                               : ((2U 
                                                   == 
                                                   (2U 
                                                    & (IData)(__Vfunc___03387__4__s)))
                                                   ? 
                                                  ((IData)(__Vfunc___03387__4__b) 
                                                   >> 1U)
                                                   : 
                                                  ((4U 
                                                    == 
                                                    (4U 
                                                     & (IData)(__Vfunc___03387__4__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03387__4__b) 
                                                    >> 2U)
                                                    : 
                                                   ((8U 
                                                     == 
                                                     (8U 
                                                      & (IData)(__Vfunc___03387__4__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03387__4__b) 
                                                     >> 3U)
                                                     : 
                                                    ((0x10U 
                                                      == 
                                                      (0x10U 
                                                       & (IData)(__Vfunc___03387__4__s)))
                                                      ? 
                                                     ((IData)(__Vfunc___03387__4__b) 
                                                      >> 4U)
                                                      : 
                                                     ((0x20U 
                                                       == 
                                                       (0x20U 
                                                        & (IData)(__Vfunc___03387__4__s)))
                                                       ? 
                                                      ((IData)(__Vfunc___03387__4__b) 
                                                       >> 5U)
                                                       : 
                                                      ((0x40U 
                                                        == 
                                                        (0x40U 
                                                         & (IData)(__Vfunc___03387__4__s)))
                                                        ? 
                                                       ((IData)(__Vfunc___03387__4__b) 
                                                        >> 6U)
                                                        : 
                                                       ((IData)(__Vfunc___03387__4__b) 
                                                        >> 7U))))))))
                                           : (IData)(__Vfunc___03387__4__a)));
    vlSelf->__PVT___109_ = __Vfunc___03387__4__Vfuncout;
    __Vfunc___03407__13__s = (((7U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                             >> 0xdU))) 
                               << 7U) | (((6U == (7U 
                                                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                     >> 0xdU))) 
                                          << 6U) | 
                                         (((5U == (7U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                      >> 0xdU))) 
                                           << 5U) | 
                                          (((4U == 
                                             (7U & 
                                              ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 0xdU))) 
                                            << 4U) 
                                           | (((3U 
                                                == 
                                                (7U 
                                                 & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                    >> 0xdU))) 
                                               << 3U) 
                                              | (((2U 
                                                   == 
                                                   (7U 
                                                    & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                       >> 0xdU))) 
                                                  << 2U) 
                                                 | (((1U 
                                                      == 
                                                      (7U 
                                                       & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                          >> 0xdU))) 
                                                     << 1U) 
                                                    | (0U 
                                                       == 
                                                       (7U 
                                                        & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                           >> 0xdU))))))))));
    __Vfunc___03407__13__b = (((IData)(vlSelf->__PVT___212_) 
                               & (IData)(vlSelf->__PVT___101_)) 
                              << 7U);
    __Vfunc___03407__13__Vfuncout = (((((((((1U == 
                                             (1U & (IData)(__Vfunc___03407__13__s))) 
                                            | (2U == 
                                               (2U 
                                                & (IData)(__Vfunc___03407__13__s)))) 
                                           | (4U == 
                                              (4U & (IData)(__Vfunc___03407__13__s)))) 
                                          | (8U == 
                                             (8U & (IData)(__Vfunc___03407__13__s)))) 
                                         | (0x10U == 
                                            (0x10U 
                                             & (IData)(__Vfunc___03407__13__s)))) 
                                        | (0x20U == 
                                           (0x20U & (IData)(__Vfunc___03407__13__s)))) 
                                       | (0x40U == 
                                          (0x40U & (IData)(__Vfunc___03407__13__s)))) 
                                      | (0x80U == (0x80U 
                                                   & (IData)(__Vfunc___03407__13__s)))) 
                                     & ((1U == (1U 
                                                & (IData)(__Vfunc___03407__13__s)))
                                         ? (IData)(__Vfunc___03407__13__b)
                                         : ((2U == 
                                             (2U & (IData)(__Vfunc___03407__13__s)))
                                             ? ((IData)(__Vfunc___03407__13__b) 
                                                >> 1U)
                                             : ((4U 
                                                 == 
                                                 (4U 
                                                  & (IData)(__Vfunc___03407__13__s)))
                                                 ? 
                                                ((IData)(__Vfunc___03407__13__b) 
                                                 >> 2U)
                                                 : 
                                                ((8U 
                                                  == 
                                                  (8U 
                                                   & (IData)(__Vfunc___03407__13__s)))
                                                  ? 
                                                 ((IData)(__Vfunc___03407__13__b) 
                                                  >> 3U)
                                                  : 
                                                 ((0x10U 
                                                   == 
                                                   (0x10U 
                                                    & (IData)(__Vfunc___03407__13__s)))
                                                   ? 
                                                  ((IData)(__Vfunc___03407__13__b) 
                                                   >> 4U)
                                                   : 
                                                  ((0x20U 
                                                    == 
                                                    (0x20U 
                                                     & (IData)(__Vfunc___03407__13__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03407__13__b) 
                                                    >> 5U)
                                                    : 
                                                   ((0x40U 
                                                     == 
                                                     (0x40U 
                                                      & (IData)(__Vfunc___03407__13__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03407__13__b) 
                                                     >> 6U)
                                                     : 
                                                    ((IData)(__Vfunc___03407__13__b) 
                                                     >> 7U)))))))));
    vlSelf->__PVT___120_ = __Vfunc___03407__13__Vfuncout;
    __Vfunc___03409__14__s = (((7U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                             >> 0xdU))) 
                               << 7U) | (((6U == (7U 
                                                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                     >> 0xdU))) 
                                          << 6U) | 
                                         (((5U == (7U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                      >> 0xdU))) 
                                           << 5U) | 
                                          (((4U == 
                                             (7U & 
                                              ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 0xdU))) 
                                            << 4U) 
                                           | (((3U 
                                                == 
                                                (7U 
                                                 & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                    >> 0xdU))) 
                                               << 3U) 
                                              | (((2U 
                                                   == 
                                                   (7U 
                                                    & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                       >> 0xdU))) 
                                                  << 2U) 
                                                 | (((1U 
                                                      == 
                                                      (7U 
                                                       & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                          >> 0xdU))) 
                                                     << 1U) 
                                                    | (0U 
                                                       == 
                                                       (7U 
                                                        & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                           >> 0xdU))))))))));
    __Vfunc___03409__14__b = (((IData)(vlSelf->__PVT___212_) 
                               & (IData)(vlSelf->__PVT___102_)) 
                              << 7U);
    __Vfunc___03409__14__Vfuncout = (((((((((1U == 
                                             (1U & (IData)(__Vfunc___03409__14__s))) 
                                            | (2U == 
                                               (2U 
                                                & (IData)(__Vfunc___03409__14__s)))) 
                                           | (4U == 
                                              (4U & (IData)(__Vfunc___03409__14__s)))) 
                                          | (8U == 
                                             (8U & (IData)(__Vfunc___03409__14__s)))) 
                                         | (0x10U == 
                                            (0x10U 
                                             & (IData)(__Vfunc___03409__14__s)))) 
                                        | (0x20U == 
                                           (0x20U & (IData)(__Vfunc___03409__14__s)))) 
                                       | (0x40U == 
                                          (0x40U & (IData)(__Vfunc___03409__14__s)))) 
                                      | (0x80U == (0x80U 
                                                   & (IData)(__Vfunc___03409__14__s)))) 
                                     & ((1U == (1U 
                                                & (IData)(__Vfunc___03409__14__s)))
                                         ? (IData)(__Vfunc___03409__14__b)
                                         : ((2U == 
                                             (2U & (IData)(__Vfunc___03409__14__s)))
                                             ? ((IData)(__Vfunc___03409__14__b) 
                                                >> 1U)
                                             : ((4U 
                                                 == 
                                                 (4U 
                                                  & (IData)(__Vfunc___03409__14__s)))
                                                 ? 
                                                ((IData)(__Vfunc___03409__14__b) 
                                                 >> 2U)
                                                 : 
                                                ((8U 
                                                  == 
                                                  (8U 
                                                   & (IData)(__Vfunc___03409__14__s)))
                                                  ? 
                                                 ((IData)(__Vfunc___03409__14__b) 
                                                  >> 3U)
                                                  : 
                                                 ((0x10U 
                                                   == 
                                                   (0x10U 
                                                    & (IData)(__Vfunc___03409__14__s)))
                                                   ? 
                                                  ((IData)(__Vfunc___03409__14__b) 
                                                   >> 4U)
                                                   : 
                                                  ((0x20U 
                                                    == 
                                                    (0x20U 
                                                     & (IData)(__Vfunc___03409__14__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03409__14__b) 
                                                    >> 5U)
                                                    : 
                                                   ((0x40U 
                                                     == 
                                                     (0x40U 
                                                      & (IData)(__Vfunc___03409__14__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03409__14__b) 
                                                     >> 6U)
                                                     : 
                                                    ((IData)(__Vfunc___03409__14__b) 
                                                     >> 7U)))))))));
    vlSelf->__PVT___121_ = __Vfunc___03409__14__Vfuncout;
    __Vfunc___03411__15__s = (((7U == (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                             >> 0xdU))) 
                               << 7U) | (((6U == (7U 
                                                  & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                     >> 0xdU))) 
                                          << 6U) | 
                                         (((5U == (7U 
                                                   & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                      >> 0xdU))) 
                                           << 5U) | 
                                          (((4U == 
                                             (7U & 
                                              ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                               >> 0xdU))) 
                                            << 4U) 
                                           | (((3U 
                                                == 
                                                (7U 
                                                 & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                    >> 0xdU))) 
                                               << 3U) 
                                              | (((2U 
                                                   == 
                                                   (7U 
                                                    & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                       >> 0xdU))) 
                                                  << 2U) 
                                                 | (((1U 
                                                      == 
                                                      (7U 
                                                       & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                          >> 0xdU))) 
                                                     << 1U) 
                                                    | (0U 
                                                       == 
                                                       (7U 
                                                        & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                                           >> 0xdU))))))))));
    __Vfunc___03411__15__b = (((IData)(vlSelf->__PVT___212_) 
                               & (IData)(vlSelf->__PVT___103_)) 
                              << 7U);
    __Vfunc___03411__15__Vfuncout = (((((((((1U == 
                                             (1U & (IData)(__Vfunc___03411__15__s))) 
                                            | (2U == 
                                               (2U 
                                                & (IData)(__Vfunc___03411__15__s)))) 
                                           | (4U == 
                                              (4U & (IData)(__Vfunc___03411__15__s)))) 
                                          | (8U == 
                                             (8U & (IData)(__Vfunc___03411__15__s)))) 
                                         | (0x10U == 
                                            (0x10U 
                                             & (IData)(__Vfunc___03411__15__s)))) 
                                        | (0x20U == 
                                           (0x20U & (IData)(__Vfunc___03411__15__s)))) 
                                       | (0x40U == 
                                          (0x40U & (IData)(__Vfunc___03411__15__s)))) 
                                      | (0x80U == (0x80U 
                                                   & (IData)(__Vfunc___03411__15__s)))) 
                                     & ((1U == (1U 
                                                & (IData)(__Vfunc___03411__15__s)))
                                         ? (IData)(__Vfunc___03411__15__b)
                                         : ((2U == 
                                             (2U & (IData)(__Vfunc___03411__15__s)))
                                             ? ((IData)(__Vfunc___03411__15__b) 
                                                >> 1U)
                                             : ((4U 
                                                 == 
                                                 (4U 
                                                  & (IData)(__Vfunc___03411__15__s)))
                                                 ? 
                                                ((IData)(__Vfunc___03411__15__b) 
                                                 >> 2U)
                                                 : 
                                                ((8U 
                                                  == 
                                                  (8U 
                                                   & (IData)(__Vfunc___03411__15__s)))
                                                  ? 
                                                 ((IData)(__Vfunc___03411__15__b) 
                                                  >> 3U)
                                                  : 
                                                 ((0x10U 
                                                   == 
                                                   (0x10U 
                                                    & (IData)(__Vfunc___03411__15__s)))
                                                   ? 
                                                  ((IData)(__Vfunc___03411__15__b) 
                                                   >> 4U)
                                                   : 
                                                  ((0x20U 
                                                    == 
                                                    (0x20U 
                                                     & (IData)(__Vfunc___03411__15__s)))
                                                    ? 
                                                   ((IData)(__Vfunc___03411__15__b) 
                                                    >> 5U)
                                                    : 
                                                   ((0x40U 
                                                     == 
                                                     (0x40U 
                                                      & (IData)(__Vfunc___03411__15__s)))
                                                     ? 
                                                    ((IData)(__Vfunc___03411__15__b) 
                                                     >> 6U)
                                                     : 
                                                    ((IData)(__Vfunc___03411__15__b) 
                                                     >> 7U)))))))));
    vlSelf->__PVT___122_ = __Vfunc___03411__15__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__regbusc 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___510_) 
            << 8U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___511_));
    if (vlSelf->__PVT__inst_t80__DOT__u0__DOT___806_) {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0544_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0515_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0543_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0514_;
    } else if (vlSelf->__PVT__inst_t80__DOT__u0__DOT___804_) {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0544_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0526_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0543_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0525_;
    } else {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0544_ = 0U;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0543_ = 0U;
    }
    vlSelf->__PVT__io_wr_s = ((~ (IData)(vlSelf->__PVT__inst_t80__DOT___63_)) 
                              & (IData)(vlSelf->__PVT___181_));
    vlSelf->__PVT___150_ = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                             >> 7U) & (IData)(vlSelf->__PVT___181_));
    vlSelf->__PVT__cache_rom_rd_s = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___812_) 
                                      >> 0xfU) & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT___61_)) 
                                                  & (IData)(vlSelf->__PVT___043_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0205_) 
            << 9U) | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0201_) 
                      << 6U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__Vfuncout 
        = (7U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b) 
                                                >> 9U))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__b)
                                             : 0U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1920_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038621__417__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__b 
        = (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0205_) 
            << 3U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0201_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__b) 
                         >> 3U) : 0U)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0210_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035189__147__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__b 
        = (0xd8U | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0791_)
                     ? 3U : 1U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__b) 
                                       >> 6U) : 3U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0797_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036532__299__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__b 
        = (0x1e8U | ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0791_)
                      ? 5U : 7U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__Vfuncout 
        = (7U & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__s)))
                  ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__b)
                  : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__s)))
                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__b) 
                         >> 3U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__s)))
                                    ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__b) 
                                       >> 6U) : 7U))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0800_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036542__302__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___757_ = 
        ((~ (IData)(vlSelf->__PVT__clk_en_cpu_s)) & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___758_));
    if (vlSelf->__PVT__clk_en_cpu_s) {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___763_ 
            = (1U & (~ (IData)(vlSelf->__PVT__ctrl_b__DOT___75_)));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___779_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___778_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___809_ 
            = (1U & (~ (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)) 
                         | (3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_))) 
                        & (1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__clken 
            = (1U & (~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___760_)));
    } else {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___763_ 
            = (1U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___764_));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___779_ 
            = vlSelf->__PVT__inst_t80__DOT__u0__DOT___780_;
        vlSelf->__PVT__inst_t80__DOT__u0__DOT___809_ 
            = (1U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___810_));
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__clken = 0U;
    }
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___174_ 
        = (3U & ((0U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___744_))
                  ? ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___718_) 
                     >> 6U) : (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___161_) 
                                << 1U) | (0U == (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___161_) 
                                                  << 7U) 
                                                 | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___160_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___159_)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT___233_ = 
        ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___082_) 
         & (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___748_)));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__s 
        = (((5U == (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))) 
            << 3U) | (((4U == (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))) 
                       << 2U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___033_) 
                                  << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___026_))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__s)))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__s))
                      ? (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__s))))
                      : (IData)((2U == (3U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__s)))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___040_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039885__106__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038888__451__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038888__451__Vfuncout 
        = (1U & (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038888__451__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2037_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038888__451__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038910__454__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038910__454__Vfuncout 
        = (1U & (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038910__454__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2046_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038910__454__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038970__466__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038970__466__Vfuncout 
        = (1U & (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038970__466__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2071_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038970__466__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038992__469__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038992__469__Vfuncout 
        = (1U & (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038992__469__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2080_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038992__469__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038883__449__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038883__449__Vfuncout 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038883__449__s;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2035_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038883__449__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038905__452__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038905__452__Vfuncout 
        = (1U & (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038905__452__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2044_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038905__452__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038965__464__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038965__464__Vfuncout 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038965__464__s;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2069_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038965__464__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038987__467__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038987__467__Vfuncout 
        = (1U & (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038987__467__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2078_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038987__467__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__b 
        = (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 4U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__Vfuncout 
        = ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__s)
            ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__b)
            : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2036_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038885__450__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__b 
        = (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 4U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__Vfuncout 
        = ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__s)
            ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__b)
            : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2045_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038907__453__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__b 
        = (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 4U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__Vfuncout 
        = ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__s)
            ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__b)
            : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2070_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038967__465__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__b 
        = (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 4U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__Vfuncout 
        = ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__s)
            ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__b)
            : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___2079_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____038989__468__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035928__218__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035928__218__Vfuncout 
        = (1U & (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035928__218__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0560_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035928__218__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035950__221__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035950__221__Vfuncout 
        = (1U & (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035950__221__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0569_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035950__221__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035923__216__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035923__216__Vfuncout 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035923__216__s;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0558_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035923__216__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035945__219__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035945__219__Vfuncout 
        = (1U & (~ (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035945__219__s)));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0567_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035945__219__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__b 
        = (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 4U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__Vfuncout 
        = ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__s)
            ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__b)
            : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0559_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035925__217__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__s 
        = vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0557_;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__b 
        = (3U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 4U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__Vfuncout 
        = ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__s)
            ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__b)
            : 0U);
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0568_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____035947__220__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___149_ 
        = ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___007_)) 
           & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___146_ 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_) 
           | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___007_));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___138_ 
        = ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_) 
           & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___007_));
    if (vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___089_) {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___094_ 
            = (0x1ffU & ((IData)(6U) + (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_)));
        vlSelf->inst_t80__DOT__u0__DOT__alu__DOT____VdfgTmp_h27faa2e2__0 
            = (0xffU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                        - (IData)(6U)));
    } else {
        vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___094_ 
            = (0x1ffU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_));
        vlSelf->inst_t80__DOT__u0__DOT__alu__DOT____VdfgTmp_h27faa2e2__0 
            = (0xffU & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_));
    }
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b 
        = (0xb45U | (((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0736_)
                       ? 5U : 3U) << 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__Vfuncout 
        = (7U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b) 
                                                >> 9U))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__b)
                                             : 5U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0745_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036401__283__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b 
        = (0xf47U | (((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0736_)
                       ? 5U : 7U) << 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__Vfuncout 
        = (7U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b) 
                                                >> 9U))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__b)
                                             : 7U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0750_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036416__288__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b 
        = (0xc00U | (((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0736_)
                       ? 0xdU : 0U) << 4U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__Vfuncout 
        = (0xfU & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                    ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b) 
                                                  >> 0xcU))))
                    : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__b)
                                               : 0U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0749_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036413__287__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b 
        = (0xf00U | (((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0736_)
                       ? 0xfU : 0U) << 4U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__Vfuncout 
        = (0xfU & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                    ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b) 
                                                  >> 0xcU))))
                    : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                        ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b)
                                               : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b) 
                                                  >> 8U)))
                        : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                            ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                                ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b)
                                : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b) 
                                   >> 4U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__s))
                                               ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__b)
                                               : 0U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0748_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036410__286__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s 
        = (((5U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 3U) | (((4U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 2U) | (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                                  << 1U) | (2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b 
        = ((0xfc0U & ((((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                         ? 4U : 3U) << 9U) | (((1U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                ? 4U
                                                : 3U) 
                                              << 6U))) 
           | ((((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0736_)
                 ? 4U : ((1U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                          ? 4U : 3U)) << 3U) | ((1U 
                                                 == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_))
                                                 ? 4U
                                                 : 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__Vfuncout 
        = (7U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b) 
                                                >> 9U))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b) 
                                                >> 6U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b) 
                                 >> 3U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__b)
                                             : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__a))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0746_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036403__284__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__s 
        = (((5U == (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))) 
            << 3U) | (((4U == (7U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))) 
                       << 2U) | (((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___033_) 
                                  << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___026_))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__b 
        = (4U | ((2U & ((~ ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___014_) 
                            >> 5U)) << 1U)) | (1U & 
                                               ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___014_) 
                                                >> 5U))));
    __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__Vfuncout 
        = (1U & ((8U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__s))
                  ? ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__b) 
                                 >> 1U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__b) 
                                                >> 2U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__b) 
                                 >> 1U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__b) 
                                                >> 3U))))
                  : ((4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__s))
                      ? ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__b) 
                                 >> 1U)) : ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__s))
                                             ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__b)
                                             : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__b) 
                                                >> 2U)))
                      : ((2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__s))
                          ? ((1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__s))
                              ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__b)
                              : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__b) 
                                 >> 1U)) : ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__s) 
                                            & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__b))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___042_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__alu__DOT____039888__108__Vfuncout;
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___023_ 
        = (0x3fU & (((0x1eU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                               << 1U)) | (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___014_) 
                                                >> 5U))) 
                    + (1U | (0x1eU & ((~ (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_)) 
                                      << 1U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___017_ 
        = (0x1fU & (((0xeU & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___786_) 
                              >> 3U)) | (1U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__alu__DOT___014_) 
                                               >> 5U))) 
                    + (1U | (0xeU & (((2U & (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___794_))
                                       ? (~ ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_) 
                                             >> 4U))
                                       : ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___784_) 
                                          >> 4U)) << 1U)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1040_ 
        = ((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1559_) 
           | ((7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x10U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x11U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x12U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x13U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0x14U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | ((0x15U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                | ((0x17U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                   | ((8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                      | ((9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                         | ((0xaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                            | ((0xbU 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               | ((0xcU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  | ((0xdU 
                                                      == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                     | ((0xfU 
                                                         == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                        | ((0x18U 
                                                            == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                           | ((0x19U 
                                                               == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                              | ((0x1aU 
                                                                  == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                 | ((0x1bU 
                                                                     == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                    | ((0x1cU 
                                                                        == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                       | ((0x1dU 
                                                                           == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                          | ((0x1fU 
                                                                              == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                             | ((0x20U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x21U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x22U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x23U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x24U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x25U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x27U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x28U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x29U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x2aU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x2bU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x2cU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x2dU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x2fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x30U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x31U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x32U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x33U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x34U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x35U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x37U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x38U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x39U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x3aU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x3bU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x3cU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x3dU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | (0x3fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_))))))))))))))))))))))))))))))))))))))))))))))))))));
    __Vdeeptemp_hed498a0d__0 = ((0x38U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                | ((0x39U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                   | ((0x3aU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                      | ((0x3bU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                         | ((0x3cU 
                                             == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                            | ((0x3dU 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               | ((0x3eU 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  | ((0x3fU 
                                                      == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                     | ((0x80U 
                                                         == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                        | ((0x81U 
                                                            == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                           | ((0x82U 
                                                               == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                              | ((0x83U 
                                                                  == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                 | ((0x84U 
                                                                     == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                    | ((0x85U 
                                                                        == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                       | ((0x86U 
                                                                           == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                          | ((0x87U 
                                                                              == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                             | ((0x88U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x89U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x8aU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x8bU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x8cU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x8dU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x8eU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x8fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x90U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x91U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x92U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x93U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x94U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x95U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x96U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x97U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x98U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x99U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x9aU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x9bU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x9cU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x9dU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x9eU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x9fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa4U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa5U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa6U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xa7U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xacU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xadU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xaeU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xafU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb4U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb5U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb6U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xb7U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xbcU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xbdU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xbeU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xbfU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xc0U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xc1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xc2U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xc3U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xc4U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xc5U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xc6U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xc7U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xc8U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xc9U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xcaU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xcbU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xccU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xcdU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xceU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xcfU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xd0U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xd1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xd2U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xd3U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xd4U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xd5U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xd6U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xd7U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xd8U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xd9U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xdaU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xdbU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xdcU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xddU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xdeU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xdfU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe0U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe2U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe3U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe4U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe5U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe6U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe7U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe8U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xe9U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xeaU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xebU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xecU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xedU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xeeU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xefU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf0U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf1U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf2U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf3U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf4U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf5U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf6U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf7U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf8U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xf9U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xfaU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xfbU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xfcU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xfdU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0xfeU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | (0xffU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1899_ 
        = ((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1559_) 
           | ((6U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((7U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((8U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((9U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0xaU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0xbU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | ((0xcU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                | ((0xdU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                   | ((0xeU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                      | ((0xfU == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                         | ((0x10U 
                                             == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                            | ((0x11U 
                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                               | ((0x12U 
                                                   == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                  | ((0x13U 
                                                      == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                     | ((0x14U 
                                                         == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                        | ((0x15U 
                                                            == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                           | ((0x16U 
                                                               == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                              | ((0x17U 
                                                                  == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                 | ((0x18U 
                                                                     == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                    | ((0x19U 
                                                                        == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                       | ((0x1aU 
                                                                           == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                          | ((0x1bU 
                                                                              == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                             | ((0x1cU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x1dU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x1eU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x1fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x20U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x21U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x22U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x23U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x24U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x25U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x26U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x27U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x28U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x29U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x2aU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x2bU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x2cU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x2dU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x2eU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x2fU 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x30U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x31U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x32U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x33U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x34U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x35U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x36U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | ((0x37U 
                                                                                == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                                                                | __Vdeeptemp_hed498a0d__0)))))))))))))))))))))))))))))))))))))))))))))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1194_ 
        = ((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1166_) 
           | ((0x70U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
              | ((0x71U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                 | ((0x72U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                    | ((0x73U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                       | ((0x74U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                          | ((0x75U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                             | ((0x77U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_)) 
                                | (IData)(__VdfgTmp_h8a4cccd7__0)))))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0098_ 
        = ((IData)(__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1166_) 
           | (IData)(__VdfgTmp_h8a4cccd7__0));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036983__366__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036983__366__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036983__366__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036983__366__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0919_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036983__366__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037192__372__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037192__372__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037192__372__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037192__372__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1049_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037192__372__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037496__384__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037496__384__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037496__384__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037496__384__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1230_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037496__384__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037705__390__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037705__390__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037705__390__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037705__390__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1360_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037705__390__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037768__396__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037768__396__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037768__396__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037768__396__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1391_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037768__396__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037977__402__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037977__402__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037977__402__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037977__402__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1521_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037977__402__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036978__364__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036978__364__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036978__364__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036978__364__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0917_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036978__364__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037187__370__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037187__370__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037187__370__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037187__370__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1047_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037187__370__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037491__382__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037491__382__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037491__382__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037491__382__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1228_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037491__382__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037700__388__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037700__388__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037700__388__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037700__388__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1358_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037700__388__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037763__394__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037763__394__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037763__394__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037763__394__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1389_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037763__394__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037972__400__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037972__400__Vfuncout 
        = (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037972__400__s) 
                    >> 1U) & (1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037972__400__s)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1519_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037972__400__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__b 
        = (0x80U | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                               << 5U)) | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__b) 
                                         >> 8U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0918_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036980__365__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__b 
        = (0x80U | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                               << 5U)) | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__b) 
                                         >> 8U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1048_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037189__371__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__b 
        = (0x90U | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                          >> 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__b) 
                           >> 4U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1076_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037243__376__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__s 
        = (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__b 
        = (0x90U | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                          >> 3U)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__b) 
                           >> 4U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__a))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1200_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037437__379__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__b 
        = (0xa0U | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                               << 5U)) | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__b) 
                                         >> 8U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1229_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037493__383__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__b 
        = (0xa0U | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                               << 5U)) | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__b) 
                                         >> 8U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1359_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037702__389__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__b 
        = (0xb0U | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                               << 5U)) | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__b) 
                                         >> 8U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1390_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037765__395__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__b 
        = (0xb0U | ((0x700U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                               << 5U)) | (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                                                >> 3U))));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__a 
        = (7U & ((IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___742_) 
                 >> 3U));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__Vfuncout 
        = (0xfU & ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__s)))
                    ? (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__b)
                    : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__s)))
                        ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__b) 
                           >> 4U) : ((4U == (4U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__s)))
                                      ? ((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__b) 
                                         >> 8U) : (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__a)))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1520_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037974__401__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036990__368__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036990__368__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036990__368__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036990__368__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036990__368__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0921_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036990__368__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037199__374__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037199__374__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037199__374__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037199__374__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037199__374__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1051_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037199__374__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037503__386__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037503__386__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037503__386__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037503__386__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037503__386__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1232_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037503__386__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037712__392__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037712__392__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037712__392__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037712__392__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037712__392__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1362_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037712__392__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037775__398__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037775__398__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037775__398__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037775__398__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037775__398__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1393_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037775__398__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037984__404__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037984__404__Vfuncout 
        = ((1U != (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037984__404__s))) 
           & (IData)((((IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037984__404__s) 
                       >> 2U) & (2U != (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037984__404__s))))));
    vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___1523_ 
        = __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____037984__404__Vfuncout;
    __Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036987__367__s 
        = (((3U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
            << 2U) | (((2U == (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT___750_)) 
                       << 1U) | (IData)(vlSelf->__PVT__inst_t80__DOT__u0__DOT__mcode__DOT___0913_)));
    vlSelf->__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036987__367__Vfuncout 
        = ((1U == (1U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036987__367__s)))
            ? 2U : ((2U == (2U & (IData)(__Vfunc_inst_t80__DOT__u0__DOT__mcode__DOT____036987__367__s)))
                     ? 2U : 7U));
}
