// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table internal header
//
// Internal details; most calling programs do not need this header,
// unless using verilator public meta comments.

#ifndef VERILATED_VSIM_TOP__SYMS_H_
#define VERILATED_VSIM_TOP__SYMS_H_  // guard

#include "verilated.h"

// INCLUDE MODEL CLASS

#include "Vsim_top.h"

// INCLUDE MODULE CLASSES
#include "Vsim_top___024root.h"
#include "Vsim_top_sim_top.h"
#include "Vsim_top_colecovision.h"
#include "Vsim_top_f18a_core.h"
#include "Vsim_top_vdp_spy.h"

// DPI TYPES for DPI Export callbacks (Internal use)

// SYMS CLASS (contains all model state)
class alignas(VL_CACHE_LINE_BYTES)Vsim_top__Syms final : public VerilatedSyms {
  public:
    // INTERNAL STATE
    Vsim_top* const __Vm_modelp;
    VlDeleter __Vm_deleter;
    bool __Vm_didInit = false;

    // MODULE INSTANCE STATE
    Vsim_top___024root             TOP;
    Vsim_top_sim_top               TOP__sim_top;
    Vsim_top_colecovision          TOP__sim_top__cv;
    Vsim_top_f18a_core             TOP__sim_top__cv__inst_f18a;
    Vsim_top_vdp_spy               TOP__sim_top__cv__inst_f18a__spy;

    // SCOPE NAMES
    VerilatedScope __Vscope_sim_top__cv__inst_f18a__spy;

    // CONSTRUCTORS
    Vsim_top__Syms(VerilatedContext* contextp, const char* namep, Vsim_top* modelp);
    ~Vsim_top__Syms();

    // METHODS
    const char* name() { return TOP.name(); }
};

#endif  // guard
