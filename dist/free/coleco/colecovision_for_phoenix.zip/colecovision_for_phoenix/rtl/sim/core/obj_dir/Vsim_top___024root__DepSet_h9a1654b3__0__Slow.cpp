// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vsim_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vsim_top__Syms.h"
#include "Vsim_top___024root.h"

VL_ATTR_COLD void Vsim_top___024root___eval_final(Vsim_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsim_top___024root___eval_final\n"); );
}

VL_ATTR_COLD void Vsim_top___024root___eval_triggers__stl(Vsim_top___024root* vlSelf);
#ifdef VL_DEBUG
VL_ATTR_COLD void Vsim_top___024root___dump_triggers__stl(Vsim_top___024root* vlSelf);
#endif  // VL_DEBUG
VL_ATTR_COLD void Vsim_top___024root___eval_stl(Vsim_top___024root* vlSelf);

VL_ATTR_COLD void Vsim_top___024root___eval_settle(Vsim_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsim_top___024root___eval_settle\n"); );
    // Init
    CData/*0:0*/ __VstlContinue;
    // Body
    vlSelf->__VstlIterCount = 0U;
    __VstlContinue = 1U;
    while (__VstlContinue) {
        __VstlContinue = 0U;
        Vsim_top___024root___eval_triggers__stl(vlSelf);
        if (vlSelf->__VstlTriggered.any()) {
            __VstlContinue = 1U;
            if (VL_UNLIKELY((0x64U < vlSelf->__VstlIterCount))) {
#ifdef VL_DEBUG
                Vsim_top___024root___dump_triggers__stl(vlSelf);
#endif
                VL_FATAL_MT("sim_top.v", 3, "", "Settle region did not converge.");
            }
            vlSelf->__VstlIterCount = ((IData)(1U) 
                                       + vlSelf->__VstlIterCount);
            Vsim_top___024root___eval_stl(vlSelf);
        }
    }
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vsim_top___024root___dump_triggers__stl(Vsim_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsim_top___024root___dump_triggers__stl\n"); );
    // Body
    if ((1U & (~ (IData)(vlSelf->__VstlTriggered.any())))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelf->__VstlTriggered.word(0U))) {
        VL_DBG_MSGF("         'stl' region trigger index 0 is active: Internal 'stl' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

#ifdef VL_DEBUG
VL_ATTR_COLD void Vsim_top___024root___dump_triggers__ico(Vsim_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsim_top___024root___dump_triggers__ico\n"); );
    // Body
    if ((1U & (~ (IData)(vlSelf->__VicoTriggered.any())))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelf->__VicoTriggered.word(0U))) {
        VL_DBG_MSGF("         'ico' region trigger index 0 is active: Internal 'ico' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

#ifdef VL_DEBUG
VL_ATTR_COLD void Vsim_top___024root___dump_triggers__act(Vsim_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsim_top___024root___dump_triggers__act\n"); );
    // Body
    if ((1U & (~ (IData)(vlSelf->__VactTriggered.any())))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelf->__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 0 is active: @(posedge clk)\n");
    }
    if ((2ULL & vlSelf->__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 1 is active: @(posedge sim_top.cv.inst_t80.u0._071_ or posedge clk)\n");
    }
}
#endif  // VL_DEBUG

#ifdef VL_DEBUG
VL_ATTR_COLD void Vsim_top___024root___dump_triggers__nba(Vsim_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsim_top___024root___dump_triggers__nba\n"); );
    // Body
    if ((1U & (~ (IData)(vlSelf->__VnbaTriggered.any())))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelf->__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 0 is active: @(posedge clk)\n");
    }
    if ((2ULL & vlSelf->__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 1 is active: @(posedge sim_top.cv.inst_t80.u0._071_ or posedge clk)\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vsim_top___024root___ctor_var_reset(Vsim_top___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vsim_top___024root___ctor_var_reset\n"); );
    // Body
    vlSelf->clk = VL_RAND_RESET_I(1);
    vlSelf->clk_3m58_en = VL_RAND_RESET_I(1);
    vlSelf->por_n = VL_RAND_RESET_I(1);
    vlSelf->p1 = VL_RAND_RESET_I(2);
    vlSelf->p2 = VL_RAND_RESET_I(2);
    vlSelf->p3 = VL_RAND_RESET_I(2);
    vlSelf->p4 = VL_RAND_RESET_I(2);
    vlSelf->p6 = VL_RAND_RESET_I(2);
    vlSelf->p7 = VL_RAND_RESET_I(2);
    vlSelf->p9 = VL_RAND_RESET_I(2);
    vlSelf->p5 = VL_RAND_RESET_I(1);
    vlSelf->p8 = VL_RAND_RESET_I(1);
    vlSelf->sd_miso = VL_RAND_RESET_I(1);
    vlSelf->sd_mosi = VL_RAND_RESET_I(1);
    vlSelf->sd_sclk = VL_RAND_RESET_I(1);
    vlSelf->sd_cs_n = VL_RAND_RESET_I(1);
    vlSelf->sram_addr = VL_RAND_RESET_I(19);
    vlSelf->sram_wdata = VL_RAND_RESET_I(8);
    vlSelf->sram_rdata = VL_RAND_RESET_I(8);
    vlSelf->sram_we_n = VL_RAND_RESET_I(1);
    vlSelf->sram_ce_n = VL_RAND_RESET_I(1);
    vlSelf->led = VL_RAND_RESET_I(1);
    vlSelf->cpu_a = VL_RAND_RESET_I(15);
    vlSelf->cart_en_n = VL_RAND_RESET_I(1);
    vlSelf->dbg_m1_n = VL_RAND_RESET_I(1);
    vlSelf->dbg_addr = VL_RAND_RESET_I(16);
    vlSelf->dbg_clken = VL_RAND_RESET_I(1);
    vlSelf->dbg_loader = VL_RAND_RESET_I(1);
    vlSelf->dbg_din = VL_RAND_RESET_I(8);
    vlSelf->dbg_iorq_n = VL_RAND_RESET_I(1);
    vlSelf->dbg_wr_n = VL_RAND_RESET_I(1);
    vlSelf->dbg_sdcs_n = VL_RAND_RESET_I(1);
    vlSelf->dbg_dout = VL_RAND_RESET_I(8);
    vlSelf->dbg_ext = VL_RAND_RESET_I(8);
    vlSelf->dbg_mux = VL_RAND_RESET_I(8);
    vlSelf->dbg_mreq_n = VL_RAND_RESET_I(1);
    vlSelf->dbg_ext_en = VL_RAND_RESET_I(1);
    vlSelf->dbg_mc_bank = VL_RAND_RESET_I(6);
    vlSelf->dbg_rd_n = VL_RAND_RESET_I(1);
    vlSelf->dbg_cwait_n = VL_RAND_RESET_I(1);
    vlSelf->dbg_tstate = VL_RAND_RESET_I(3);
    vlSelf->dbg_mcycle = VL_RAND_RESET_I(3);
    vlSelf->dbg_rom_page = VL_RAND_RESET_I(8);
    vlSelf->dbg_mask = VL_RAND_RESET_I(8);
    vlSelf->dbg_c_line = VL_RAND_RESET_I(6);
    vlSelf->dbg_c_hit = VL_RAND_RESET_I(1);
    vlSelf->__Vtrigprevexpr___TOP__clk__0 = VL_RAND_RESET_I(1);
    vlSelf->__Vtrigprevexpr___TOP__sim_top__cv____PVT__inst_t80__DOT__u0__DOT___071___0 = VL_RAND_RESET_I(1);
}
