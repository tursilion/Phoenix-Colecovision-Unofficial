// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vsim_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vsim_top__Syms.h"
#include "Vsim_top_vdp_spy.h"

VL_INLINE_OPT void Vsim_top_vdp_spy___ico_sequent__TOP__sim_top__cv__inst_f18a__spy__0(Vsim_top_vdp_spy* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vsim_top__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+            Vsim_top_vdp_spy___ico_sequent__TOP__sim_top__cv__inst_f18a__spy__0\n"); );
    // Body
    vlSelf->__PVT__int_n = (1U & (~ ((IData)(vlSelf->__PVT__f_flag) 
                                     & (vlSelf->regs
                                        [1U] >> 5U))));
}
