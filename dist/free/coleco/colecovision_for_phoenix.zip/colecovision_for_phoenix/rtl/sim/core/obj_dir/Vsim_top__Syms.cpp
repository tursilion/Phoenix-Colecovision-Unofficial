// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table implementation internals

#include "Vsim_top__Syms.h"
#include "Vsim_top.h"
#include "Vsim_top___024root.h"
#include "Vsim_top_sim_top.h"
#include "Vsim_top_colecovision.h"
#include "Vsim_top_f18a_core.h"
#include "Vsim_top_vdp_spy.h"

// FUNCTIONS
Vsim_top__Syms::~Vsim_top__Syms()
{
}

Vsim_top__Syms::Vsim_top__Syms(VerilatedContext* contextp, const char* namep, Vsim_top* modelp)
    : VerilatedSyms{contextp}
    // Setup internal state of the Syms class
    , __Vm_modelp{modelp}
    // Setup module instances
    , TOP{this, namep}
    , TOP__sim_top{this, Verilated::catName(namep, "sim_top")}
    , TOP__sim_top__cv{this, Verilated::catName(namep, "sim_top.cv")}
    , TOP__sim_top__cv__inst_f18a{this, Verilated::catName(namep, "sim_top.cv.inst_f18a")}
    , TOP__sim_top__cv__inst_f18a__spy{this, Verilated::catName(namep, "sim_top.cv.inst_f18a.spy")}
{
    // Configure time unit / time precision
    _vm_contextp__->timeunit(-9);
    _vm_contextp__->timeprecision(-12);
    // Setup each module's pointers to their submodules
    TOP.sim_top = &TOP__sim_top;
    TOP__sim_top.cv = &TOP__sim_top__cv;
    TOP__sim_top__cv.inst_f18a = &TOP__sim_top__cv__inst_f18a;
    TOP__sim_top__cv__inst_f18a.spy = &TOP__sim_top__cv__inst_f18a__spy;
    // Setup each module's pointer back to symbol table (for public functions)
    TOP.__Vconfigure(true);
    TOP__sim_top.__Vconfigure(true);
    TOP__sim_top__cv.__Vconfigure(true);
    TOP__sim_top__cv__inst_f18a.__Vconfigure(true);
    TOP__sim_top__cv__inst_f18a__spy.__Vconfigure(true);
    // Setup scopes
    __Vscope_sim_top__cv__inst_f18a__spy.configure(this, name(), "sim_top.cv.inst_f18a.spy", "spy", 0, VerilatedScope::SCOPE_OTHER);
    // Setup export functions
    for (int __Vfinal = 0; __Vfinal < 2; ++__Vfinal) {
        __Vscope_sim_top__cv__inst_f18a__spy.varInsert(__Vfinal,"regs", &(TOP__sim_top__cv__inst_f18a__spy.regs), false, VLVT_UINT8,VLVD_NODIR|VLVF_PUB_RW,2 ,7,0 ,0,7);
        __Vscope_sim_top__cv__inst_f18a__spy.varInsert(__Vfinal,"vram", &(TOP__sim_top__cv__inst_f18a__spy.vram), false, VLVT_UINT8,VLVD_NODIR|VLVF_PUB_RW,2 ,7,0 ,0,16383);
    }
}
