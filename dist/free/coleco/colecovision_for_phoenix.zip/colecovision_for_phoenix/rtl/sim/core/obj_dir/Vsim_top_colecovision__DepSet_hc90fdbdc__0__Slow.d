Vsim_top_colecovision__DepSet_hc90fdbdc__0__Slow.o: \
 Vsim_top_colecovision__DepSet_hc90fdbdc__0__Slow.cpp \
 /mnt/d/work/phoenix/repo/collectorvision-game-system/tools/verilator/include/verilated.h \
 /mnt/d/work/phoenix/repo/collectorvision-game-system/tools/verilator/include/verilatedos.h \
 /mnt/d/work/phoenix/repo/collectorvision-game-system/tools/verilator/include/verilated_config.h \
 /mnt/d/work/phoenix/repo/collectorvision-game-system/tools/verilator/include/verilated_types.h \
 /mnt/d/work/phoenix/repo/collectorvision-game-system/tools/verilator/include/verilated_funcs.h \
 /mnt/d/work/phoenix/repo/collectorvision-game-system/tools/verilator/include/verilated_dpi.h \
 /mnt/d/work/phoenix/repo/collectorvision-game-system/tools/verilator/include/verilated.h \
 /mnt/d/work/phoenix/repo/collectorvision-game-system/tools/verilator/include/verilated_sym_props.h \
 /mnt/d/work/phoenix/repo/collectorvision-game-system/tools/verilator/include/vltstd/svdpi.h \
 Vsim_top__Syms.h Vsim_top.h Vsim_top___024root.h Vsim_top_sim_top.h \
 Vsim_top_colecovision.h Vsim_top_f18a_core.h Vsim_top_vdp_spy.h
