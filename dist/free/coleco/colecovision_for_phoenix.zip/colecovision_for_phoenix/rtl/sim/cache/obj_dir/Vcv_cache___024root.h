// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vcv_cache.h for the primary calling header

#ifndef VERILATED_VCV_CACHE___024ROOT_H_
#define VERILATED_VCV_CACHE___024ROOT_H_  // guard

#include "verilated.h"


class Vcv_cache__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vcv_cache___024root final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    // Anonymous structures to workaround compiler member-count bugs
    struct {
        VL_IN8(clk,0,0);
        VL_IN8(reset,0,0);
        VL_IN8(active,0,0);
        VL_IN8(start,0,0);
        VL_IN8(rom_rd,0,0);
        VL_IN8(rom_page,7,0);
        VL_OUT8(c_hit,0,0);
        VL_OUT8(c_line,5,0);
        VL_OUT8(cpu_wait_n,0,0);
        VL_IN8(sd_wr,0,0);
        VL_IN8(cap_wr,0,0);
        VL_IN8(chk_wr,0,0);
        VL_IN8(end_wr,0,0);
        VL_IN8(cpu_data,7,0);
        VL_OUT8(frag,0,0);
        VL_OUT8(ov_active,0,0);
        VL_OUT8(ov_en,0,0);
        VL_OUT8(ov_we_n,0,0);
        VL_OUT8(ov_data,7,0);
        VL_OUT8(sd_cs_n,0,0);
        VL_OUT8(sd_sclk,0,0);
        VL_OUT8(sd_mosi,0,0);
        VL_IN8(sd_miso,0,0);
        VL_OUT8(led,0,0);
        CData/*0:0*/ cv_cache__DOT__cm_we;
        CData/*7:0*/ cv_cache__DOT__cm_a;
        CData/*6:0*/ cv_cache__DOT__cm_d;
        CData/*0:0*/ cv_cache__DOT__cr_we;
        CData/*5:0*/ cv_cache__DOT__cr_a;
        CData/*0:0*/ cv_cache__DOT__cl_we;
        CData/*7:0*/ cv_cache__DOT__cl_a;
        CData/*7:0*/ cv_cache__DOT__f_page;
        CData/*7:0*/ cv_cache__DOT__chk_page;
        CData/*0:0*/ cv_cache__DOT__lba_rd_chk;
        CData/*2:0*/ cv_cache__DOT__sn_st;
        CData/*0:0*/ cv_cache__DOT__cap_on;
        CData/*0:0*/ cv_cache__DOT__chk_on;
        CData/*7:0*/ cv_cache__DOT__cap_page;
        CData/*0:0*/ cv_cache__DOT__chk_seen;
        CData/*0:0*/ cv_cache__DOT__cap_seen;
        CData/*0:0*/ cv_cache__DOT__spi_busy;
        CData/*0:0*/ cv_cache__DOT__spi_start;
        CData/*7:0*/ cv_cache__DOT__spi_tx;
        CData/*7:0*/ cv_cache__DOT__spi_rx;
        CData/*7:0*/ cv_cache__DOT__spi_txd;
        CData/*2:0*/ cv_cache__DOT__spi_bit;
        CData/*0:0*/ cv_cache__DOT__spi_sclk_r;
        CData/*0:0*/ cv_cache__DOT__f_cs;
        CData/*0:0*/ cv_cache__DOT__ld_pend;
        CData/*7:0*/ cv_cache__DOT__ld_data;
        CData/*1:0*/ cv_cache__DOT__ws;
        CData/*0:0*/ cv_cache__DOT__ld_done;
        CData/*0:0*/ cv_cache__DOT__fill_on;
        CData/*4:0*/ cv_cache__DOT__f_state;
        CData/*4:0*/ cv_cache__DOT__f_next;
        CData/*5:0*/ cv_cache__DOT__f_line;
        CData/*5:0*/ cv_cache__DOT__f_hand;
        CData/*3:0*/ cv_cache__DOT__f_blk;
        CData/*2:0*/ cv_cache__DOT__f_ci;
        CData/*0:0*/ cv_cache__DOT__f_stop;
        CData/*0:0*/ cv_cache__DOT__f_bad;
        CData/*0:0*/ cv_cache__DOT__f_retry;
        CData/*0:0*/ cv_cache__DOT__c_init;
        CData/*2:0*/ cv_cache__DOT__c_settle;
    };
    struct {
        CData/*2:0*/ cv_cache__DOT__ov_settle;
        CData/*0:0*/ cv_cache__DOT__fill_on_d;
        CData/*7:0*/ cv_cache__DOT__f_cmd_byte;
        CData/*0:0*/ cv_cache__DOT__ci_map;
        CData/*0:0*/ cv_cache__DOT__ci_rev;
        CData/*0:0*/ __Vtrigprevexpr___TOP__clk__0;
        CData/*0:0*/ __VactContinue;
        VL_IN16(n_pages,8,0);
        SData/*8:0*/ cv_cache__DOT__cr_d;
        SData/*15:0*/ cv_cache__DOT__f_cnt;
        SData/*8:0*/ cv_cache__DOT__f_byte;
        SData/*15:0*/ cv_cache__DOT__f_crc;
        SData/*8:0*/ cv_cache__DOT__c_init_i;
        SData/*15:0*/ cv_cache__DOT__crc16_byte__Vstatic__r;
        SData/*8:0*/ cv_cache__DOT__ci_sram;
        SData/*8:0*/ cv_cache__DOT____VdfgTmp_h64dfa0ff__0;
        VL_OUT(ov_addr,18,0);
        IData/*31:0*/ cv_cache__DOT__cl_d;
        IData/*31:0*/ cv_cache__DOT__f_arg;
        IData/*31:0*/ cv_cache__DOT__sn_arg;
        IData/*31:0*/ cv_cache__DOT__chk_last;
        IData/*18:0*/ cv_cache__DOT__ld_addr;
        IData/*22:0*/ cv_cache__DOT__led_time;
        IData/*31:0*/ __VstlIterCount;
        IData/*31:0*/ __VicoIterCount;
        IData/*31:0*/ __VactIterCount;
        QData/*63:0*/ cv_cache__DOT__c_ref;
        VlUnpacked<CData/*6:0*/, 256> cv_cache__DOT__c_map;
        VlUnpacked<SData/*8:0*/, 64> cv_cache__DOT__c_rev;
        VlUnpacked<IData/*31:0*/, 256> cv_cache__DOT__c_lba;
    };
    VlTriggerVec<1> __VstlTriggered;
    VlTriggerVec<1> __VicoTriggered;
    VlTriggerVec<1> __VactTriggered;
    VlTriggerVec<1> __VnbaTriggered;

    // INTERNAL VARIABLES
    Vcv_cache__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vcv_cache___024root(Vcv_cache__Syms* symsp, const char* v__name);
    ~Vcv_cache___024root();
    VL_UNCOPYABLE(Vcv_cache___024root);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
