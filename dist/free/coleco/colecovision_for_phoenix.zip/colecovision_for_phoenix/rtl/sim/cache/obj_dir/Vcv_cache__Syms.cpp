// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table implementation internals

#include "Vcv_cache__Syms.h"
#include "Vcv_cache.h"
#include "Vcv_cache___024root.h"

// FUNCTIONS
Vcv_cache__Syms::~Vcv_cache__Syms()
{
}

Vcv_cache__Syms::Vcv_cache__Syms(VerilatedContext* contextp, const char* namep, Vcv_cache* modelp)
    : VerilatedSyms{contextp}
    // Setup internal state of the Syms class
    , __Vm_modelp{modelp}
    // Setup module instances
    , TOP{this, namep}
{
    // Configure time unit / time precision
    _vm_contextp__->timeunit(-9);
    _vm_contextp__->timeprecision(-12);
    // Setup each module's pointers to their submodules
    // Setup each module's pointer back to symbol table (for public functions)
    TOP.__Vconfigure(true);
}
