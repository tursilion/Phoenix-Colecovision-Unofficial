// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Symbol table internal header
//
// Internal details; most calling programs do not need this header,
// unless using verilator public meta comments.

#ifndef VERILATED_VCV_CACHE__SYMS_H_
#define VERILATED_VCV_CACHE__SYMS_H_  // guard

#include "verilated.h"

// INCLUDE MODEL CLASS

#include "Vcv_cache.h"

// INCLUDE MODULE CLASSES
#include "Vcv_cache___024root.h"

// SYMS CLASS (contains all model state)
class alignas(VL_CACHE_LINE_BYTES)Vcv_cache__Syms final : public VerilatedSyms {
  public:
    // INTERNAL STATE
    Vcv_cache* const __Vm_modelp;
    VlDeleter __Vm_deleter;
    bool __Vm_didInit = false;

    // MODULE INSTANCE STATE
    Vcv_cache___024root            TOP;

    // CONSTRUCTORS
    Vcv_cache__Syms(VerilatedContext* contextp, const char* namep, Vcv_cache* modelp);
    ~Vcv_cache__Syms();

    // METHODS
    const char* name() { return TOP.name(); }
};

#endif  // guard
