// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vcv_cache.h for the primary calling header

#include "verilated.h"

#include "Vcv_cache__Syms.h"
#include "Vcv_cache___024root.h"

VL_ATTR_COLD void Vcv_cache___024root___eval_static__TOP(Vcv_cache___024root* vlSelf);

VL_ATTR_COLD void Vcv_cache___024root___eval_static(Vcv_cache___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vcv_cache__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcv_cache___024root___eval_static\n"); );
    // Body
    Vcv_cache___024root___eval_static__TOP(vlSelf);
}

VL_ATTR_COLD void Vcv_cache___024root___eval_static__TOP(Vcv_cache___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vcv_cache__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcv_cache___024root___eval_static__TOP\n"); );
    // Body
    vlSelf->cpu_wait_n = 1U;
    vlSelf->frag = 0U;
    vlSelf->ov_en = 0U;
    vlSelf->ov_we_n = 1U;
    vlSelf->led = 0U;
    vlSelf->cv_cache__DOT__c_ref = 0ULL;
    vlSelf->cv_cache__DOT__cm_we = 0U;
    vlSelf->cv_cache__DOT__cr_we = 0U;
    vlSelf->cv_cache__DOT__cl_we = 0U;
    vlSelf->cv_cache__DOT__lba_rd_chk = 0U;
    vlSelf->cv_cache__DOT__sn_st = 0U;
    vlSelf->cv_cache__DOT__cap_on = 0U;
    vlSelf->cv_cache__DOT__chk_on = 0U;
    vlSelf->cv_cache__DOT__chk_seen = 0U;
    vlSelf->cv_cache__DOT__cap_seen = 0U;
    vlSelf->cv_cache__DOT__spi_busy = 0U;
    vlSelf->cv_cache__DOT__spi_start = 0U;
    vlSelf->cv_cache__DOT__spi_tx = 0xffU;
    vlSelf->cv_cache__DOT__spi_rx = 0xffU;
    vlSelf->cv_cache__DOT__spi_sclk_r = 0U;
    vlSelf->cv_cache__DOT__f_cs = 0U;
    vlSelf->cv_cache__DOT__ld_pend = 0U;
    vlSelf->cv_cache__DOT__ws = 0U;
    vlSelf->cv_cache__DOT__fill_on = 0U;
    vlSelf->cv_cache__DOT__f_state = 0U;
    vlSelf->cv_cache__DOT__f_hand = 4U;
    vlSelf->cv_cache__DOT__f_retry = 0U;
    vlSelf->cv_cache__DOT__led_time = 0U;
    vlSelf->cv_cache__DOT__c_init = 0U;
    vlSelf->cv_cache__DOT__c_settle = 0U;
    vlSelf->cv_cache__DOT__ov_settle = 0U;
    vlSelf->cv_cache__DOT__fill_on_d = 0U;
}

VL_ATTR_COLD void Vcv_cache___024root___eval_initial(Vcv_cache___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vcv_cache__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcv_cache___024root___eval_initial\n"); );
    // Body
    vlSelf->__Vtrigprevexpr___TOP__clk__0 = vlSelf->clk;
}

VL_ATTR_COLD void Vcv_cache___024root___eval_final(Vcv_cache___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vcv_cache__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcv_cache___024root___eval_final\n"); );
}

VL_ATTR_COLD void Vcv_cache___024root___eval_triggers__stl(Vcv_cache___024root* vlSelf);
#ifdef VL_DEBUG
VL_ATTR_COLD void Vcv_cache___024root___dump_triggers__stl(Vcv_cache___024root* vlSelf);
#endif  // VL_DEBUG
VL_ATTR_COLD void Vcv_cache___024root___eval_stl(Vcv_cache___024root* vlSelf);

VL_ATTR_COLD void Vcv_cache___024root___eval_settle(Vcv_cache___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vcv_cache__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcv_cache___024root___eval_settle\n"); );
    // Init
    CData/*0:0*/ __VstlContinue;
    // Body
    vlSelf->__VstlIterCount = 0U;
    __VstlContinue = 1U;
    while (__VstlContinue) {
        __VstlContinue = 0U;
        Vcv_cache___024root___eval_triggers__stl(vlSelf);
        if (vlSelf->__VstlTriggered.any()) {
            __VstlContinue = 1U;
            if (VL_UNLIKELY((0x64U < vlSelf->__VstlIterCount))) {
#ifdef VL_DEBUG
                Vcv_cache___024root___dump_triggers__stl(vlSelf);
#endif
                VL_FATAL_MT("../../cv_cache.v", 27, "", "Settle region did not converge.");
            }
            vlSelf->__VstlIterCount = ((IData)(1U) 
                                       + vlSelf->__VstlIterCount);
            Vcv_cache___024root___eval_stl(vlSelf);
        }
    }
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vcv_cache___024root___dump_triggers__stl(Vcv_cache___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vcv_cache__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcv_cache___024root___dump_triggers__stl\n"); );
    // Body
    if ((1U & (~ (IData)(vlSelf->__VstlTriggered.any())))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelf->__VstlTriggered.word(0U))) {
        VL_DBG_MSGF("         'stl' region trigger index 0 is active: Internal 'stl' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vcv_cache___024root___stl_sequent__TOP__0(Vcv_cache___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vcv_cache__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcv_cache___024root___stl_sequent__TOP__0\n"); );
    // Init
    CData/*6:0*/ cv_cache__DOT__c_map_q;
    cv_cache__DOT__c_map_q = 0;
    // Body
    vlSelf->ov_active = vlSelf->cv_cache__DOT__fill_on;
    vlSelf->sd_cs_n = (1U & (~ (IData)(vlSelf->cv_cache__DOT__f_cs)));
    vlSelf->sd_sclk = vlSelf->cv_cache__DOT__spi_sclk_r;
    vlSelf->sd_mosi = (1U & ((IData)(vlSelf->cv_cache__DOT__spi_tx) 
                             >> 7U));
    vlSelf->cv_cache__DOT__f_cmd_byte = (0xffU & ((0U 
                                                   == (IData)(vlSelf->cv_cache__DOT__f_ci))
                                                   ? 
                                                  ((IData)(vlSelf->cv_cache__DOT__f_stop)
                                                    ? 0x4cU
                                                    : 0x52U)
                                                   : 
                                                  ((5U 
                                                    == (IData)(vlSelf->cv_cache__DOT__f_ci))
                                                    ? 0xffU
                                                    : 
                                                   ((IData)(vlSelf->cv_cache__DOT__f_stop)
                                                     ? 0U
                                                     : 
                                                    ((1U 
                                                      == (IData)(vlSelf->cv_cache__DOT__f_ci))
                                                      ? 
                                                     (vlSelf->cv_cache__DOT__f_arg 
                                                      >> 0x18U)
                                                      : 
                                                     ((2U 
                                                       == (IData)(vlSelf->cv_cache__DOT__f_ci))
                                                       ? 
                                                      (vlSelf->cv_cache__DOT__f_arg 
                                                       >> 0x10U)
                                                       : 
                                                      ((3U 
                                                        == (IData)(vlSelf->cv_cache__DOT__f_ci))
                                                        ? 
                                                       (vlSelf->cv_cache__DOT__f_arg 
                                                        >> 8U)
                                                        : vlSelf->cv_cache__DOT__f_arg)))))));
    vlSelf->cv_cache__DOT____VdfgTmp_h64dfa0ff__0 = 
        (0x1ffU & ((IData)(vlSelf->cv_cache__DOT__c_init_i) 
                   + (IData)(vlSelf->n_pages)));
    vlSelf->cv_cache__DOT__ci_sram = (0x1ffU & (((IData)(0x40U) 
                                                 - (IData)(vlSelf->n_pages)) 
                                                + (IData)(vlSelf->cv_cache__DOT__c_init_i)));
    cv_cache__DOT__c_map_q = vlSelf->cv_cache__DOT__c_map
        [vlSelf->rom_page];
    vlSelf->cv_cache__DOT__ci_rev = ((4U <= (IData)(vlSelf->cv_cache__DOT__c_init_i)) 
                                     & (0x40U <= (IData)(vlSelf->cv_cache__DOT____VdfgTmp_h64dfa0ff__0)));
    vlSelf->cv_cache__DOT__ci_map = (((IData)(vlSelf->cv_cache__DOT__c_init_i) 
                                      < (IData)(vlSelf->n_pages)) 
                                     & ((4U <= (IData)(vlSelf->cv_cache__DOT__ci_sram)) 
                                        & (0x40U > (IData)(vlSelf->cv_cache__DOT__ci_sram))));
    vlSelf->c_hit = (1U & ((IData)(cv_cache__DOT__c_map_q) 
                           >> 6U));
    vlSelf->c_line = (0x3fU & (IData)(cv_cache__DOT__c_map_q));
}

VL_ATTR_COLD void Vcv_cache___024root___eval_stl(Vcv_cache___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vcv_cache__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcv_cache___024root___eval_stl\n"); );
    // Body
    if ((1ULL & vlSelf->__VstlTriggered.word(0U))) {
        Vcv_cache___024root___stl_sequent__TOP__0(vlSelf);
    }
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vcv_cache___024root___dump_triggers__ico(Vcv_cache___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vcv_cache__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcv_cache___024root___dump_triggers__ico\n"); );
    // Body
    if ((1U & (~ (IData)(vlSelf->__VicoTriggered.any())))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelf->__VicoTriggered.word(0U))) {
        VL_DBG_MSGF("         'ico' region trigger index 0 is active: Internal 'ico' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

#ifdef VL_DEBUG
VL_ATTR_COLD void Vcv_cache___024root___dump_triggers__act(Vcv_cache___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vcv_cache__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcv_cache___024root___dump_triggers__act\n"); );
    // Body
    if ((1U & (~ (IData)(vlSelf->__VactTriggered.any())))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelf->__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 0 is active: @(posedge clk)\n");
    }
}
#endif  // VL_DEBUG

#ifdef VL_DEBUG
VL_ATTR_COLD void Vcv_cache___024root___dump_triggers__nba(Vcv_cache___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vcv_cache__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcv_cache___024root___dump_triggers__nba\n"); );
    // Body
    if ((1U & (~ (IData)(vlSelf->__VnbaTriggered.any())))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelf->__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 0 is active: @(posedge clk)\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vcv_cache___024root___ctor_var_reset(Vcv_cache___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vcv_cache__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcv_cache___024root___ctor_var_reset\n"); );
    // Body
    vlSelf->clk = VL_RAND_RESET_I(1);
    vlSelf->reset = VL_RAND_RESET_I(1);
    vlSelf->active = VL_RAND_RESET_I(1);
    vlSelf->start = VL_RAND_RESET_I(1);
    vlSelf->n_pages = VL_RAND_RESET_I(9);
    vlSelf->rom_rd = VL_RAND_RESET_I(1);
    vlSelf->rom_page = VL_RAND_RESET_I(8);
    vlSelf->c_hit = VL_RAND_RESET_I(1);
    vlSelf->c_line = VL_RAND_RESET_I(6);
    vlSelf->cpu_wait_n = VL_RAND_RESET_I(1);
    vlSelf->sd_wr = VL_RAND_RESET_I(1);
    vlSelf->cap_wr = VL_RAND_RESET_I(1);
    vlSelf->chk_wr = VL_RAND_RESET_I(1);
    vlSelf->end_wr = VL_RAND_RESET_I(1);
    vlSelf->cpu_data = VL_RAND_RESET_I(8);
    vlSelf->frag = VL_RAND_RESET_I(1);
    vlSelf->ov_active = VL_RAND_RESET_I(1);
    vlSelf->ov_en = VL_RAND_RESET_I(1);
    vlSelf->ov_we_n = VL_RAND_RESET_I(1);
    vlSelf->ov_addr = VL_RAND_RESET_I(19);
    vlSelf->ov_data = VL_RAND_RESET_I(8);
    vlSelf->sd_cs_n = VL_RAND_RESET_I(1);
    vlSelf->sd_sclk = VL_RAND_RESET_I(1);
    vlSelf->sd_mosi = VL_RAND_RESET_I(1);
    vlSelf->sd_miso = VL_RAND_RESET_I(1);
    vlSelf->led = VL_RAND_RESET_I(1);
    for (int __Vi0 = 0; __Vi0 < 256; ++__Vi0) {
        vlSelf->cv_cache__DOT__c_map[__Vi0] = VL_RAND_RESET_I(7);
    }
    for (int __Vi0 = 0; __Vi0 < 64; ++__Vi0) {
        vlSelf->cv_cache__DOT__c_rev[__Vi0] = VL_RAND_RESET_I(9);
    }
    vlSelf->cv_cache__DOT__c_ref = VL_RAND_RESET_Q(64);
    for (int __Vi0 = 0; __Vi0 < 256; ++__Vi0) {
        vlSelf->cv_cache__DOT__c_lba[__Vi0] = VL_RAND_RESET_I(32);
    }
    vlSelf->cv_cache__DOT__cm_we = VL_RAND_RESET_I(1);
    vlSelf->cv_cache__DOT__cm_a = VL_RAND_RESET_I(8);
    vlSelf->cv_cache__DOT__cm_d = VL_RAND_RESET_I(7);
    vlSelf->cv_cache__DOT__cr_we = VL_RAND_RESET_I(1);
    vlSelf->cv_cache__DOT__cr_a = VL_RAND_RESET_I(6);
    vlSelf->cv_cache__DOT__cr_d = VL_RAND_RESET_I(9);
    vlSelf->cv_cache__DOT__cl_we = VL_RAND_RESET_I(1);
    vlSelf->cv_cache__DOT__cl_a = VL_RAND_RESET_I(8);
    vlSelf->cv_cache__DOT__cl_d = VL_RAND_RESET_I(32);
    vlSelf->cv_cache__DOT__f_page = VL_RAND_RESET_I(8);
    vlSelf->cv_cache__DOT__chk_page = VL_RAND_RESET_I(8);
    vlSelf->cv_cache__DOT__f_arg = VL_RAND_RESET_I(32);
    vlSelf->cv_cache__DOT__lba_rd_chk = VL_RAND_RESET_I(1);
    vlSelf->cv_cache__DOT__sn_st = VL_RAND_RESET_I(3);
    vlSelf->cv_cache__DOT__sn_arg = VL_RAND_RESET_I(32);
    vlSelf->cv_cache__DOT__cap_on = VL_RAND_RESET_I(1);
    vlSelf->cv_cache__DOT__chk_on = VL_RAND_RESET_I(1);
    vlSelf->cv_cache__DOT__cap_page = VL_RAND_RESET_I(8);
    vlSelf->cv_cache__DOT__chk_last = VL_RAND_RESET_I(32);
    vlSelf->cv_cache__DOT__chk_seen = VL_RAND_RESET_I(1);
    vlSelf->cv_cache__DOT__cap_seen = VL_RAND_RESET_I(1);
    vlSelf->cv_cache__DOT__spi_busy = VL_RAND_RESET_I(1);
    vlSelf->cv_cache__DOT__spi_start = VL_RAND_RESET_I(1);
    vlSelf->cv_cache__DOT__spi_tx = VL_RAND_RESET_I(8);
    vlSelf->cv_cache__DOT__spi_rx = VL_RAND_RESET_I(8);
    vlSelf->cv_cache__DOT__spi_txd = VL_RAND_RESET_I(8);
    vlSelf->cv_cache__DOT__spi_bit = VL_RAND_RESET_I(3);
    vlSelf->cv_cache__DOT__spi_sclk_r = VL_RAND_RESET_I(1);
    vlSelf->cv_cache__DOT__f_cs = VL_RAND_RESET_I(1);
    vlSelf->cv_cache__DOT__ld_pend = VL_RAND_RESET_I(1);
    vlSelf->cv_cache__DOT__ld_data = VL_RAND_RESET_I(8);
    vlSelf->cv_cache__DOT__ld_addr = VL_RAND_RESET_I(19);
    vlSelf->cv_cache__DOT__ws = VL_RAND_RESET_I(2);
    vlSelf->cv_cache__DOT__ld_done = VL_RAND_RESET_I(1);
    vlSelf->cv_cache__DOT__fill_on = VL_RAND_RESET_I(1);
    vlSelf->cv_cache__DOT__f_state = VL_RAND_RESET_I(5);
    vlSelf->cv_cache__DOT__f_next = VL_RAND_RESET_I(5);
    vlSelf->cv_cache__DOT__f_line = VL_RAND_RESET_I(6);
    vlSelf->cv_cache__DOT__f_hand = VL_RAND_RESET_I(6);
    vlSelf->cv_cache__DOT__f_cnt = VL_RAND_RESET_I(16);
    vlSelf->cv_cache__DOT__f_blk = VL_RAND_RESET_I(4);
    vlSelf->cv_cache__DOT__f_byte = VL_RAND_RESET_I(9);
    vlSelf->cv_cache__DOT__f_ci = VL_RAND_RESET_I(3);
    vlSelf->cv_cache__DOT__f_stop = VL_RAND_RESET_I(1);
    vlSelf->cv_cache__DOT__f_crc = VL_RAND_RESET_I(16);
    vlSelf->cv_cache__DOT__f_bad = VL_RAND_RESET_I(1);
    vlSelf->cv_cache__DOT__f_retry = VL_RAND_RESET_I(1);
    vlSelf->cv_cache__DOT__led_time = VL_RAND_RESET_I(23);
    vlSelf->cv_cache__DOT__c_init = VL_RAND_RESET_I(1);
    vlSelf->cv_cache__DOT__c_init_i = VL_RAND_RESET_I(9);
    vlSelf->cv_cache__DOT__c_settle = VL_RAND_RESET_I(3);
    vlSelf->cv_cache__DOT__ov_settle = VL_RAND_RESET_I(3);
    vlSelf->cv_cache__DOT__fill_on_d = VL_RAND_RESET_I(1);
    vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r = VL_RAND_RESET_I(16);
    vlSelf->cv_cache__DOT__f_cmd_byte = VL_RAND_RESET_I(8);
    vlSelf->cv_cache__DOT__ci_sram = VL_RAND_RESET_I(9);
    vlSelf->cv_cache__DOT__ci_map = VL_RAND_RESET_I(1);
    vlSelf->cv_cache__DOT__ci_rev = VL_RAND_RESET_I(1);
    vlSelf->cv_cache__DOT____VdfgTmp_h64dfa0ff__0 = 0;
    vlSelf->__Vtrigprevexpr___TOP__clk__0 = VL_RAND_RESET_I(1);
}
