// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vcv_cache.h for the primary calling header

#include "verilated.h"

#include "Vcv_cache__Syms.h"
#include "Vcv_cache___024root.h"

VL_INLINE_OPT void Vcv_cache___024root___ico_sequent__TOP__0(Vcv_cache___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vcv_cache__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcv_cache___024root___ico_sequent__TOP__0\n"); );
    // Init
    CData/*6:0*/ cv_cache__DOT__c_map_q;
    cv_cache__DOT__c_map_q = 0;
    // Body
    vlSelf->cv_cache__DOT____VdfgTmp_h64dfa0ff__0 = 
        (0x1ffU & ((IData)(vlSelf->cv_cache__DOT__c_init_i) 
                   + (IData)(vlSelf->n_pages)));
    vlSelf->cv_cache__DOT__ci_sram = (0x1ffU & (((IData)(0x40U) 
                                                 - (IData)(vlSelf->n_pages)) 
                                                + (IData)(vlSelf->cv_cache__DOT__c_init_i)));
    cv_cache__DOT__c_map_q = vlSelf->cv_cache__DOT__c_map
        [vlSelf->rom_page];
    vlSelf->cv_cache__DOT__ci_rev = ((4U <= (IData)(vlSelf->cv_cache__DOT__c_init_i)) 
                                     & (0x40U <= (IData)(vlSelf->cv_cache__DOT____VdfgTmp_h64dfa0ff__0)));
    vlSelf->cv_cache__DOT__ci_map = (((IData)(vlSelf->cv_cache__DOT__c_init_i) 
                                      < (IData)(vlSelf->n_pages)) 
                                     & ((4U <= (IData)(vlSelf->cv_cache__DOT__ci_sram)) 
                                        & (0x40U > (IData)(vlSelf->cv_cache__DOT__ci_sram))));
    vlSelf->c_hit = (1U & ((IData)(cv_cache__DOT__c_map_q) 
                           >> 6U));
    vlSelf->c_line = (0x3fU & (IData)(cv_cache__DOT__c_map_q));
}

void Vcv_cache___024root___eval_ico(Vcv_cache___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vcv_cache__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcv_cache___024root___eval_ico\n"); );
    // Body
    if ((1ULL & vlSelf->__VicoTriggered.word(0U))) {
        Vcv_cache___024root___ico_sequent__TOP__0(vlSelf);
    }
}

void Vcv_cache___024root___eval_act(Vcv_cache___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vcv_cache__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcv_cache___024root___eval_act\n"); );
}

VL_INLINE_OPT void Vcv_cache___024root___nba_sequent__TOP__0(Vcv_cache___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vcv_cache__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcv_cache___024root___nba_sequent__TOP__0\n"); );
    // Init
    CData/*6:0*/ cv_cache__DOT__c_map_q;
    cv_cache__DOT__c_map_q = 0;
    SData/*15:0*/ __Vfunc_cv_cache__DOT__crc16_byte__0__Vfuncout;
    __Vfunc_cv_cache__DOT__crc16_byte__0__Vfuncout = 0;
    SData/*15:0*/ __Vfunc_cv_cache__DOT__crc16_byte__0__c;
    __Vfunc_cv_cache__DOT__crc16_byte__0__c = 0;
    CData/*7:0*/ __Vfunc_cv_cache__DOT__crc16_byte__0__d;
    __Vfunc_cv_cache__DOT__crc16_byte__0__d = 0;
    CData/*5:0*/ __Vdlyvdim0__cv_cache__DOT__c_rev__v0;
    __Vdlyvdim0__cv_cache__DOT__c_rev__v0 = 0;
    SData/*8:0*/ __Vdlyvval__cv_cache__DOT__c_rev__v0;
    __Vdlyvval__cv_cache__DOT__c_rev__v0 = 0;
    CData/*0:0*/ __Vdlyvset__cv_cache__DOT__c_rev__v0;
    __Vdlyvset__cv_cache__DOT__c_rev__v0 = 0;
    CData/*7:0*/ __Vdlyvdim0__cv_cache__DOT__c_map__v0;
    __Vdlyvdim0__cv_cache__DOT__c_map__v0 = 0;
    CData/*6:0*/ __Vdlyvval__cv_cache__DOT__c_map__v0;
    __Vdlyvval__cv_cache__DOT__c_map__v0 = 0;
    CData/*0:0*/ __Vdlyvset__cv_cache__DOT__c_map__v0;
    __Vdlyvset__cv_cache__DOT__c_map__v0 = 0;
    CData/*7:0*/ __Vdlyvdim0__cv_cache__DOT__c_lba__v0;
    __Vdlyvdim0__cv_cache__DOT__c_lba__v0 = 0;
    IData/*31:0*/ __Vdlyvval__cv_cache__DOT__c_lba__v0;
    __Vdlyvval__cv_cache__DOT__c_lba__v0 = 0;
    CData/*0:0*/ __Vdlyvset__cv_cache__DOT__c_lba__v0;
    __Vdlyvset__cv_cache__DOT__c_lba__v0 = 0;
    CData/*2:0*/ __Vdly__cv_cache__DOT__sn_st;
    __Vdly__cv_cache__DOT__sn_st = 0;
    IData/*31:0*/ __Vdly__cv_cache__DOT__sn_arg;
    __Vdly__cv_cache__DOT__sn_arg = 0;
    CData/*0:0*/ __Vdly__cv_cache__DOT__cap_seen;
    __Vdly__cv_cache__DOT__cap_seen = 0;
    IData/*31:0*/ __Vdly__cv_cache__DOT__chk_last;
    __Vdly__cv_cache__DOT__chk_last = 0;
    CData/*0:0*/ __Vdly__cv_cache__DOT__chk_seen;
    __Vdly__cv_cache__DOT__chk_seen = 0;
    CData/*7:0*/ __Vdly__cv_cache__DOT__spi_tx;
    __Vdly__cv_cache__DOT__spi_tx = 0;
    CData/*0:0*/ __Vdly__cv_cache__DOT__spi_busy;
    __Vdly__cv_cache__DOT__spi_busy = 0;
    CData/*2:0*/ __Vdly__cv_cache__DOT__spi_bit;
    __Vdly__cv_cache__DOT__spi_bit = 0;
    CData/*0:0*/ __Vdly__cv_cache__DOT__spi_sclk_r;
    __Vdly__cv_cache__DOT__spi_sclk_r = 0;
    CData/*7:0*/ __Vdly__cv_cache__DOT__spi_rx;
    __Vdly__cv_cache__DOT__spi_rx = 0;
    CData/*0:0*/ __Vdly__cv_cache__DOT__ld_done;
    __Vdly__cv_cache__DOT__ld_done = 0;
    CData/*1:0*/ __Vdly__cv_cache__DOT__ws;
    __Vdly__cv_cache__DOT__ws = 0;
    CData/*0:0*/ __Vdly__cv_cache__DOT__spi_start;
    __Vdly__cv_cache__DOT__spi_start = 0;
    CData/*0:0*/ __Vdly__cv_cache__DOT__fill_on_d;
    __Vdly__cv_cache__DOT__fill_on_d = 0;
    CData/*2:0*/ __Vdly__cv_cache__DOT__ov_settle;
    __Vdly__cv_cache__DOT__ov_settle = 0;
    IData/*22:0*/ __Vdly__cv_cache__DOT__led_time;
    __Vdly__cv_cache__DOT__led_time = 0;
    CData/*0:0*/ __Vdly__cv_cache__DOT__ld_pend;
    __Vdly__cv_cache__DOT__ld_pend = 0;
    CData/*0:0*/ __Vdly__cv_cache__DOT__c_init;
    __Vdly__cv_cache__DOT__c_init = 0;
    SData/*8:0*/ __Vdly__cv_cache__DOT__c_init_i;
    __Vdly__cv_cache__DOT__c_init_i = 0;
    QData/*63:0*/ __Vdly__cv_cache__DOT__c_ref;
    __Vdly__cv_cache__DOT__c_ref = 0;
    CData/*5:0*/ __Vdly__cv_cache__DOT__f_hand;
    __Vdly__cv_cache__DOT__f_hand = 0;
    CData/*4:0*/ __Vdly__cv_cache__DOT__f_state;
    __Vdly__cv_cache__DOT__f_state = 0;
    CData/*0:0*/ __Vdly__cv_cache__DOT__f_bad;
    __Vdly__cv_cache__DOT__f_bad = 0;
    CData/*3:0*/ __Vdly__cv_cache__DOT__f_blk;
    __Vdly__cv_cache__DOT__f_blk = 0;
    SData/*15:0*/ __Vdly__cv_cache__DOT__f_cnt;
    __Vdly__cv_cache__DOT__f_cnt = 0;
    CData/*4:0*/ __Vdly__cv_cache__DOT__f_next;
    __Vdly__cv_cache__DOT__f_next = 0;
    CData/*2:0*/ __Vdly__cv_cache__DOT__f_ci;
    __Vdly__cv_cache__DOT__f_ci = 0;
    CData/*0:0*/ __Vdly__cv_cache__DOT__f_stop;
    __Vdly__cv_cache__DOT__f_stop = 0;
    SData/*8:0*/ __Vdly__cv_cache__DOT__f_byte;
    __Vdly__cv_cache__DOT__f_byte = 0;
    CData/*7:0*/ __Vdly__cv_cache__DOT__f_page;
    __Vdly__cv_cache__DOT__f_page = 0;
    // Body
    __Vdly__cv_cache__DOT__chk_seen = vlSelf->cv_cache__DOT__chk_seen;
    __Vdly__cv_cache__DOT__chk_last = vlSelf->cv_cache__DOT__chk_last;
    __Vdly__cv_cache__DOT__cap_seen = vlSelf->cv_cache__DOT__cap_seen;
    __Vdly__cv_cache__DOT__sn_arg = vlSelf->cv_cache__DOT__sn_arg;
    __Vdly__cv_cache__DOT__sn_st = vlSelf->cv_cache__DOT__sn_st;
    __Vdly__cv_cache__DOT__f_page = vlSelf->cv_cache__DOT__f_page;
    __Vdly__cv_cache__DOT__f_byte = vlSelf->cv_cache__DOT__f_byte;
    __Vdly__cv_cache__DOT__f_next = vlSelf->cv_cache__DOT__f_next;
    __Vdly__cv_cache__DOT__f_cnt = vlSelf->cv_cache__DOT__f_cnt;
    __Vdly__cv_cache__DOT__f_blk = vlSelf->cv_cache__DOT__f_blk;
    __Vdly__cv_cache__DOT__f_bad = vlSelf->cv_cache__DOT__f_bad;
    __Vdly__cv_cache__DOT__f_state = vlSelf->cv_cache__DOT__f_state;
    __Vdly__cv_cache__DOT__f_hand = vlSelf->cv_cache__DOT__f_hand;
    __Vdly__cv_cache__DOT__c_ref = vlSelf->cv_cache__DOT__c_ref;
    __Vdly__cv_cache__DOT__c_init = vlSelf->cv_cache__DOT__c_init;
    __Vdly__cv_cache__DOT__ld_pend = vlSelf->cv_cache__DOT__ld_pend;
    __Vdly__cv_cache__DOT__led_time = vlSelf->cv_cache__DOT__led_time;
    __Vdly__cv_cache__DOT__ov_settle = vlSelf->cv_cache__DOT__ov_settle;
    __Vdly__cv_cache__DOT__fill_on_d = vlSelf->cv_cache__DOT__fill_on_d;
    if (vlSelf->cv_cache__DOT__spi_start) {
        __Vdly__cv_cache__DOT__spi_start = 1U;
        __Vdly__cv_cache__DOT__f_stop = vlSelf->cv_cache__DOT__f_stop;
        __Vdly__cv_cache__DOT__f_ci = vlSelf->cv_cache__DOT__f_ci;
        __Vdly__cv_cache__DOT__c_init_i = vlSelf->cv_cache__DOT__c_init_i;
        __Vdly__cv_cache__DOT__ws = vlSelf->cv_cache__DOT__ws;
        __Vdly__cv_cache__DOT__ld_done = vlSelf->cv_cache__DOT__ld_done;
        __Vdly__cv_cache__DOT__spi_rx = vlSelf->cv_cache__DOT__spi_rx;
        __Vdly__cv_cache__DOT__spi_bit = vlSelf->cv_cache__DOT__spi_bit;
        __Vdly__cv_cache__DOT__spi_busy = vlSelf->cv_cache__DOT__spi_busy;
        __Vdly__cv_cache__DOT__spi_sclk_r = vlSelf->cv_cache__DOT__spi_sclk_r;
        __Vdly__cv_cache__DOT__spi_tx = vlSelf->cv_cache__DOT__spi_tx;
        __Vdlyvset__cv_cache__DOT__c_lba__v0 = 0U;
        __Vdlyvset__cv_cache__DOT__c_rev__v0 = 0U;
        __Vdlyvset__cv_cache__DOT__c_map__v0 = 0U;
        __Vdly__cv_cache__DOT__spi_tx = vlSelf->cv_cache__DOT__spi_txd;
        __Vdly__cv_cache__DOT__spi_busy = 1U;
        __Vdly__cv_cache__DOT__spi_bit = 0U;
        __Vdly__cv_cache__DOT__spi_sclk_r = 0U;
    } else {
        __Vdly__cv_cache__DOT__spi_start = 0U;
        __Vdly__cv_cache__DOT__f_stop = vlSelf->cv_cache__DOT__f_stop;
        __Vdly__cv_cache__DOT__f_ci = vlSelf->cv_cache__DOT__f_ci;
        __Vdly__cv_cache__DOT__c_init_i = vlSelf->cv_cache__DOT__c_init_i;
        __Vdly__cv_cache__DOT__ws = vlSelf->cv_cache__DOT__ws;
        __Vdly__cv_cache__DOT__ld_done = vlSelf->cv_cache__DOT__ld_done;
        __Vdly__cv_cache__DOT__spi_rx = vlSelf->cv_cache__DOT__spi_rx;
        __Vdly__cv_cache__DOT__spi_bit = vlSelf->cv_cache__DOT__spi_bit;
        if (vlSelf->cv_cache__DOT__spi_busy) {
            __Vdly__cv_cache__DOT__spi_busy = 1U;
            if (vlSelf->cv_cache__DOT__spi_sclk_r) {
                __Vdly__cv_cache__DOT__spi_sclk_r = 1U;
                __Vdly__cv_cache__DOT__spi_tx = vlSelf->cv_cache__DOT__spi_tx;
                __Vdlyvset__cv_cache__DOT__c_lba__v0 = 0U;
                __Vdlyvset__cv_cache__DOT__c_rev__v0 = 0U;
                __Vdlyvset__cv_cache__DOT__c_map__v0 = 0U;
                __Vdly__cv_cache__DOT__spi_tx = (1U 
                                                 | (0xfeU 
                                                    & ((IData)(vlSelf->cv_cache__DOT__spi_tx) 
                                                       << 1U)));
                __Vdly__cv_cache__DOT__spi_bit = (7U 
                                                  & ((IData)(1U) 
                                                     + (IData)(vlSelf->cv_cache__DOT__spi_bit)));
                __Vdly__cv_cache__DOT__spi_sclk_r = 0U;
                if ((7U == (IData)(vlSelf->cv_cache__DOT__spi_bit))) {
                    __Vdly__cv_cache__DOT__spi_busy = 0U;
                }
            } else {
                __Vdly__cv_cache__DOT__spi_sclk_r = 0U;
                __Vdly__cv_cache__DOT__spi_tx = vlSelf->cv_cache__DOT__spi_tx;
                __Vdlyvset__cv_cache__DOT__c_lba__v0 = 0U;
                __Vdlyvset__cv_cache__DOT__c_rev__v0 = 0U;
                __Vdlyvset__cv_cache__DOT__c_map__v0 = 0U;
                __Vdly__cv_cache__DOT__spi_rx = ((0xfeU 
                                                  & ((IData)(vlSelf->cv_cache__DOT__spi_rx) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->sd_miso));
                __Vdly__cv_cache__DOT__spi_sclk_r = 1U;
            }
        } else {
            __Vdly__cv_cache__DOT__spi_busy = 0U;
            __Vdly__cv_cache__DOT__spi_sclk_r = vlSelf->cv_cache__DOT__spi_sclk_r;
            __Vdly__cv_cache__DOT__spi_tx = vlSelf->cv_cache__DOT__spi_tx;
            __Vdlyvset__cv_cache__DOT__c_lba__v0 = 0U;
            __Vdlyvset__cv_cache__DOT__c_rev__v0 = 0U;
            __Vdlyvset__cv_cache__DOT__c_map__v0 = 0U;
        }
    }
    if (vlSelf->cv_cache__DOT__cl_we) {
        __Vdlyvval__cv_cache__DOT__c_lba__v0 = vlSelf->cv_cache__DOT__cl_d;
        __Vdlyvset__cv_cache__DOT__c_lba__v0 = 1U;
        __Vdlyvdim0__cv_cache__DOT__c_lba__v0 = vlSelf->cv_cache__DOT__cl_a;
    }
    if (vlSelf->cv_cache__DOT__cr_we) {
        __Vdlyvval__cv_cache__DOT__c_rev__v0 = vlSelf->cv_cache__DOT__cr_d;
        __Vdlyvset__cv_cache__DOT__c_rev__v0 = 1U;
        __Vdlyvdim0__cv_cache__DOT__c_rev__v0 = vlSelf->cv_cache__DOT__cr_a;
    }
    if (vlSelf->cv_cache__DOT__cm_we) {
        __Vdlyvval__cv_cache__DOT__c_map__v0 = vlSelf->cv_cache__DOT__cm_d;
        __Vdlyvset__cv_cache__DOT__c_map__v0 = 1U;
        __Vdlyvdim0__cv_cache__DOT__c_map__v0 = vlSelf->cv_cache__DOT__cm_a;
    }
    __Vdly__cv_cache__DOT__ld_done = 0U;
    if ((2U & (IData)(vlSelf->cv_cache__DOT__ws))) {
        if ((1U & (IData)(vlSelf->cv_cache__DOT__ws))) {
            __Vdly__cv_cache__DOT__ld_done = 1U;
            __Vdly__cv_cache__DOT__ws = 0U;
        } else {
            vlSelf->ov_we_n = 1U;
            __Vdly__cv_cache__DOT__ws = 3U;
        }
    } else if ((1U & (IData)(vlSelf->cv_cache__DOT__ws))) {
        vlSelf->ov_we_n = 0U;
        __Vdly__cv_cache__DOT__ws = 2U;
    } else if (((IData)(vlSelf->cv_cache__DOT__ld_pend) 
                & (~ (IData)(vlSelf->cv_cache__DOT__ld_done)))) {
        vlSelf->ov_en = 1U;
        vlSelf->ov_we_n = 1U;
        vlSelf->ov_addr = vlSelf->cv_cache__DOT__ld_addr;
        vlSelf->ov_data = vlSelf->cv_cache__DOT__ld_data;
        __Vdly__cv_cache__DOT__ws = 1U;
    }
    if ((1U & (~ (IData)(vlSelf->cv_cache__DOT__fill_on)))) {
        vlSelf->ov_en = 0U;
        vlSelf->ov_we_n = 1U;
    }
    vlSelf->cv_cache__DOT__spi_bit = __Vdly__cv_cache__DOT__spi_bit;
    if (vlSelf->reset) {
        __Vdly__cv_cache__DOT__spi_busy = 0U;
        __Vdly__cv_cache__DOT__spi_sclk_r = 0U;
        __Vdly__cv_cache__DOT__spi_tx = 0xffU;
    }
    vlSelf->cv_cache__DOT__spi_tx = __Vdly__cv_cache__DOT__spi_tx;
    vlSelf->cv_cache__DOT__spi_sclk_r = __Vdly__cv_cache__DOT__spi_sclk_r;
    if (__Vdlyvset__cv_cache__DOT__c_map__v0) {
        vlSelf->cv_cache__DOT__c_map[__Vdlyvdim0__cv_cache__DOT__c_map__v0] 
            = __Vdlyvval__cv_cache__DOT__c_map__v0;
    }
    vlSelf->sd_mosi = (1U & ((IData)(vlSelf->cv_cache__DOT__spi_tx) 
                             >> 7U));
    vlSelf->sd_sclk = vlSelf->cv_cache__DOT__spi_sclk_r;
    vlSelf->cv_cache__DOT__cl_we = 0U;
    if (vlSelf->sd_wr) {
        if ((0U == (IData)(vlSelf->cv_cache__DOT__sn_st))) {
            __Vdly__cv_cache__DOT__sn_st = ((0x51U 
                                             == (IData)(vlSelf->cpu_data))
                                             ? 1U : 0U);
        } else {
            __Vdly__cv_cache__DOT__sn_arg = ((vlSelf->cv_cache__DOT__sn_arg 
                                              << 8U) 
                                             | (IData)(vlSelf->cpu_data));
            if ((4U == (IData)(vlSelf->cv_cache__DOT__sn_st))) {
                __Vdly__cv_cache__DOT__sn_st = 0U;
                if (vlSelf->cv_cache__DOT__cap_on) {
                    __Vdly__cv_cache__DOT__cap_seen = 1U;
                    vlSelf->cv_cache__DOT__cl_we = 1U;
                    vlSelf->cv_cache__DOT__cl_a = vlSelf->cv_cache__DOT__cap_page;
                    vlSelf->cv_cache__DOT__cl_d = (
                                                   (vlSelf->cv_cache__DOT__sn_arg 
                                                    << 8U) 
                                                   | (IData)(vlSelf->cpu_data));
                }
                if (vlSelf->cv_cache__DOT__chk_on) {
                    __Vdly__cv_cache__DOT__chk_last 
                        = ((vlSelf->cv_cache__DOT__sn_arg 
                            << 8U) | (IData)(vlSelf->cpu_data));
                    __Vdly__cv_cache__DOT__chk_seen = 1U;
                }
            } else {
                __Vdly__cv_cache__DOT__sn_st = (7U 
                                                & ((IData)(1U) 
                                                   + (IData)(vlSelf->cv_cache__DOT__sn_st)));
            }
        }
    }
    if ((((((IData)(vlSelf->cap_wr) | (IData)(vlSelf->chk_wr)) 
           | (IData)(vlSelf->end_wr)) & (IData)(vlSelf->cv_cache__DOT__cap_on)) 
         & (~ (IData)(vlSelf->cv_cache__DOT__cap_seen)))) {
        vlSelf->frag = 1U;
    }
    if (((((IData)(vlSelf->cap_wr) | (IData)(vlSelf->chk_wr)) 
          | (IData)(vlSelf->end_wr)) & (IData)(vlSelf->cv_cache__DOT__chk_on))) {
        if ((1U & ((~ (IData)(vlSelf->cv_cache__DOT__chk_seen)) 
                   | ((vlSelf->cv_cache__DOT__chk_last 
                       != ((IData)(0xfU) + vlSelf->cv_cache__DOT__f_arg)) 
                      & (vlSelf->cv_cache__DOT__chk_last 
                         != ((IData)(0x1e00U) + vlSelf->cv_cache__DOT__f_arg)))))) {
            vlSelf->frag = 1U;
        }
    }
    cv_cache__DOT__c_map_q = vlSelf->cv_cache__DOT__c_map
        [vlSelf->rom_page];
    __Vdly__cv_cache__DOT__spi_start = 0U;
    vlSelf->cv_cache__DOT__cm_we = 0U;
    vlSelf->cv_cache__DOT__cr_we = 0U;
    vlSelf->cpu_wait_n = (1U & (~ ((((IData)(vlSelf->cv_cache__DOT__c_init) 
                                     | (IData)(vlSelf->cv_cache__DOT__fill_on)) 
                                    | (0U != (IData)(vlSelf->cv_cache__DOT__ov_settle))) 
                                   | (((IData)(vlSelf->active) 
                                       & (IData)(vlSelf->rom_rd)) 
                                      & ((~ (IData)(vlSelf->c_hit)) 
                                         | (0U != (IData)(vlSelf->cv_cache__DOT__c_settle)))))));
    if ((0U != (IData)(vlSelf->cv_cache__DOT__c_settle))) {
        vlSelf->cv_cache__DOT__c_settle = (7U & ((IData)(vlSelf->cv_cache__DOT__c_settle) 
                                                 - (IData)(1U)));
    }
    __Vdly__cv_cache__DOT__fill_on_d = vlSelf->cv_cache__DOT__fill_on;
    if (((IData)(vlSelf->cv_cache__DOT__fill_on_d) 
         & (~ (IData)(vlSelf->cv_cache__DOT__fill_on)))) {
        __Vdly__cv_cache__DOT__ov_settle = 7U;
    } else if ((0U != (IData)(vlSelf->cv_cache__DOT__ov_settle))) {
        __Vdly__cv_cache__DOT__ov_settle = (7U & ((IData)(vlSelf->cv_cache__DOT__ov_settle) 
                                                  - (IData)(1U)));
    }
    if ((0U != vlSelf->cv_cache__DOT__led_time)) {
        __Vdly__cv_cache__DOT__led_time = (0x7fffffU 
                                           & (vlSelf->cv_cache__DOT__led_time 
                                              - (IData)(1U)));
        if ((1U == vlSelf->cv_cache__DOT__led_time)) {
            vlSelf->led = 0U;
        }
    }
    if (vlSelf->cv_cache__DOT__ld_done) {
        vlSelf->cv_cache__DOT__ld_addr = (0x7ffffU 
                                          & ((IData)(1U) 
                                             + vlSelf->cv_cache__DOT__ld_addr));
        __Vdly__cv_cache__DOT__ld_pend = 0U;
    }
    if (vlSelf->start) {
        __Vdly__cv_cache__DOT__c_init = 1U;
        __Vdly__cv_cache__DOT__c_init_i = 0U;
    } else if (vlSelf->cv_cache__DOT__c_init) {
        vlSelf->cv_cache__DOT__cm_we = 1U;
        vlSelf->cv_cache__DOT__cm_a = (0xffU & (IData)(vlSelf->cv_cache__DOT__c_init_i));
        vlSelf->cv_cache__DOT__cm_d = ((IData)(vlSelf->cv_cache__DOT__ci_map)
                                        ? (0x40U | 
                                           (0x3fU & (IData)(vlSelf->cv_cache__DOT__ci_sram)))
                                        : 0U);
        vlSelf->cv_cache__DOT__cr_d = (((IData)(vlSelf->cv_cache__DOT__ci_rev) 
                                        << 8U) | (0xffU 
                                                  & ((IData)(vlSelf->cv_cache__DOT____VdfgTmp_h64dfa0ff__0) 
                                                     - (IData)(0x40U))));
        __Vdly__cv_cache__DOT__c_ref = 0ULL;
        __Vdly__cv_cache__DOT__f_hand = 4U;
        vlSelf->cv_cache__DOT__cr_we = (0x40U > (IData)(vlSelf->cv_cache__DOT__c_init_i));
        vlSelf->cv_cache__DOT__cr_a = (0x3fU & (IData)(vlSelf->cv_cache__DOT__c_init_i));
        __Vdly__cv_cache__DOT__c_init_i = (0x1ffU & 
                                           ((IData)(1U) 
                                            + (IData)(vlSelf->cv_cache__DOT__c_init_i)));
        if ((0xffU == (IData)(vlSelf->cv_cache__DOT__c_init_i))) {
            __Vdly__cv_cache__DOT__c_init = 0U;
        }
    }
    if ((((IData)(vlSelf->active) & (IData)(vlSelf->rom_rd)) 
         & (IData)(vlSelf->c_hit))) {
        __Vdly__cv_cache__DOT__c_ref = (__Vdly__cv_cache__DOT__c_ref 
                                        | ((QData)((IData)(1U)) 
                                           << (IData)(vlSelf->c_line)));
    }
    if ((1U & ((~ (IData)(vlSelf->active)) | (IData)(vlSelf->cv_cache__DOT__c_init)))) {
        __Vdly__cv_cache__DOT__f_state = 0U;
        vlSelf->cv_cache__DOT__f_cs = 0U;
        vlSelf->cv_cache__DOT__fill_on = 0U;
    } else if ((0x10U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
        if ((8U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
            __Vdly__cv_cache__DOT__f_state = 0U;
        } else if ((4U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
            if ((2U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
                if ((1U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
                    __Vdly__cv_cache__DOT__f_state = 0U;
                } else {
                    if (((IData)(vlSelf->cv_cache__DOT__spi_rx) 
                         != (0xffU & ((1U == (IData)(vlSelf->cv_cache__DOT__f_cnt))
                                       ? ((IData)(vlSelf->cv_cache__DOT__f_crc) 
                                          >> 8U) : (IData)(vlSelf->cv_cache__DOT__f_crc))))) {
                        __Vdly__cv_cache__DOT__f_bad = 1U;
                    }
                    if ((2U == (IData)(vlSelf->cv_cache__DOT__f_cnt))) {
                        __Vdly__cv_cache__DOT__f_blk 
                            = (0xfU & ((IData)(1U) 
                                       + (IData)(vlSelf->cv_cache__DOT__f_blk)));
                        __Vdly__cv_cache__DOT__f_cnt = 0U;
                        __Vdly__cv_cache__DOT__f_state 
                            = ((0xfU == (IData)(vlSelf->cv_cache__DOT__f_blk))
                                ? 0xbU : 6U);
                    } else {
                        __Vdly__cv_cache__DOT__f_state = 0xaU;
                    }
                }
            } else if ((1U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
                vlSelf->cv_cache__DOT__c_settle = 7U;
                __Vdly__cv_cache__DOT__f_state = 0U;
            } else {
                vlSelf->led = 1U;
                __Vdly__cv_cache__DOT__led_time = 0x7fffffU;
                if (vlSelf->cv_cache__DOT__f_retry) {
                    if ((1U & (~ (IData)(vlSelf->cv_cache__DOT__ld_pend)))) {
                        vlSelf->cv_cache__DOT__f_retry = 0U;
                        vlSelf->cv_cache__DOT__f_cs = 0U;
                        vlSelf->cv_cache__DOT__spi_txd = 0xffU;
                        __Vdly__cv_cache__DOT__spi_start = 1U;
                        __Vdly__cv_cache__DOT__f_state = 0x13U;
                        __Vdly__cv_cache__DOT__f_next = 2U;
                    }
                } else {
                    vlSelf->cv_cache__DOT__f_retry = 1U;
                    __Vdly__cv_cache__DOT__f_bad = 1U;
                    vlSelf->cv_cache__DOT__f_cs = 1U;
                    __Vdly__cv_cache__DOT__f_state = 0xbU;
                }
            }
        } else if ((2U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
            if ((1U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
                if ((1U & ((~ (IData)(vlSelf->cv_cache__DOT__spi_start)) 
                           & (~ (IData)(vlSelf->cv_cache__DOT__spi_busy))))) {
                    __Vdly__cv_cache__DOT__f_state 
                        = vlSelf->cv_cache__DOT__f_next;
                }
            } else {
                vlSelf->cv_cache__DOT__cm_we = 1U;
                vlSelf->cv_cache__DOT__cm_a = vlSelf->cv_cache__DOT__f_page;
                vlSelf->cv_cache__DOT__cm_d = (0x40U 
                                               | (IData)(vlSelf->cv_cache__DOT__f_line));
                __Vdly__cv_cache__DOT__c_ref = (__Vdly__cv_cache__DOT__c_ref 
                                                | ((QData)((IData)(1U)) 
                                                   << (IData)(vlSelf->cv_cache__DOT__f_line)));
                __Vdly__cv_cache__DOT__f_state = 0x15U;
            }
        } else if ((1U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
            if (((~ (IData)(vlSelf->cv_cache__DOT__ld_pend)) 
                 & (0U == (IData)(vlSelf->cv_cache__DOT__ws)))) {
                vlSelf->cv_cache__DOT__f_cs = 0U;
                vlSelf->cv_cache__DOT__fill_on = 0U;
                vlSelf->cv_cache__DOT__spi_txd = 0xffU;
                __Vdly__cv_cache__DOT__spi_start = 1U;
                __Vdly__cv_cache__DOT__f_state = 0x13U;
                __Vdly__cv_cache__DOT__f_next = ((IData)(vlSelf->cv_cache__DOT__f_bad)
                                                  ? 0x14U
                                                  : 0x12U);
            }
        } else {
            __Vdly__cv_cache__DOT__f_state = ((0xffU 
                                               == (IData)(vlSelf->cv_cache__DOT__spi_rx))
                                               ? 0x11U
                                               : ((0xffffU 
                                                   == (IData)(vlSelf->cv_cache__DOT__f_cnt))
                                                   ? 0x14U
                                                   : 0xfU));
        }
    } else if ((8U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
        if ((4U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
            if ((2U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
                if ((1U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
                    __Vdly__cv_cache__DOT__f_cnt = 
                        (0xffffU & ((IData)(1U) + (IData)(vlSelf->cv_cache__DOT__f_cnt)));
                    vlSelf->cv_cache__DOT__spi_txd = 0xffU;
                    __Vdly__cv_cache__DOT__spi_start = 1U;
                    __Vdly__cv_cache__DOT__f_state = 0x13U;
                    __Vdly__cv_cache__DOT__f_next = 0x10U;
                } else if (((0xffU == (IData)(vlSelf->cv_cache__DOT__spi_rx)) 
                            & (0x10U != (IData)(vlSelf->cv_cache__DOT__f_cnt)))) {
                    __Vdly__cv_cache__DOT__f_state = 0xdU;
                } else {
                    __Vdly__cv_cache__DOT__f_cnt = 0U;
                    __Vdly__cv_cache__DOT__f_state = 0xfU;
                }
            } else if ((1U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
                __Vdly__cv_cache__DOT__f_cnt = (0xffffU 
                                                & ((IData)(1U) 
                                                   + (IData)(vlSelf->cv_cache__DOT__f_cnt)));
                vlSelf->cv_cache__DOT__spi_txd = 0xffU;
                __Vdly__cv_cache__DOT__spi_start = 1U;
                __Vdly__cv_cache__DOT__f_state = 0x13U;
                __Vdly__cv_cache__DOT__f_next = 0xeU;
            } else {
                vlSelf->cv_cache__DOT__spi_txd = 0xffU;
                __Vdly__cv_cache__DOT__spi_start = 1U;
                __Vdly__cv_cache__DOT__f_state = 0x13U;
                __Vdly__cv_cache__DOT__f_next = 0xdU;
                __Vdly__cv_cache__DOT__f_cnt = 0U;
            }
        } else if ((2U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
            if ((1U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
                __Vdly__cv_cache__DOT__f_ci = 0U;
                __Vdly__cv_cache__DOT__f_stop = 1U;
                __Vdly__cv_cache__DOT__f_state = 3U;
            } else {
                __Vdly__cv_cache__DOT__f_cnt = (0xffffU 
                                                & ((IData)(1U) 
                                                   + (IData)(vlSelf->cv_cache__DOT__f_cnt)));
                vlSelf->cv_cache__DOT__spi_txd = 0xffU;
                __Vdly__cv_cache__DOT__spi_start = 1U;
                __Vdly__cv_cache__DOT__f_state = 0x13U;
                __Vdly__cv_cache__DOT__f_next = 0x16U;
            }
        } else if ((1U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
            if ((1U & (~ (IData)(vlSelf->cv_cache__DOT__ld_pend)))) {
                __Vfunc_cv_cache__DOT__crc16_byte__0__d 
                    = vlSelf->cv_cache__DOT__spi_rx;
                __Vdly__cv_cache__DOT__f_byte = (0x1ffU 
                                                 & ((IData)(1U) 
                                                    + (IData)(vlSelf->cv_cache__DOT__f_byte)));
                __Vfunc_cv_cache__DOT__crc16_byte__0__c 
                    = vlSelf->cv_cache__DOT__f_crc;
                vlSelf->cv_cache__DOT__ld_data = vlSelf->cv_cache__DOT__spi_rx;
                __Vdly__cv_cache__DOT__ld_pend = 1U;
                vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r 
                    = ((IData)(__Vfunc_cv_cache__DOT__crc16_byte__0__c) 
                       ^ ((IData)(__Vfunc_cv_cache__DOT__crc16_byte__0__d) 
                          << 8U));
                __Vdly__cv_cache__DOT__f_cnt = 0U;
                __Vdly__cv_cache__DOT__f_state = ((0x1ffU 
                                                   == (IData)(vlSelf->cv_cache__DOT__f_byte))
                                                   ? 0xaU
                                                   : 8U);
                vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r 
                    = (0xffffU & ((0x8000U & (IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r))
                                   ? (0x1021U ^ ((IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r) 
                                                 << 1U))
                                   : ((IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r) 
                                      << 1U)));
                vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r 
                    = (0xffffU & ((0x8000U & (IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r))
                                   ? (0x1021U ^ ((IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r) 
                                                 << 1U))
                                   : ((IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r) 
                                      << 1U)));
                vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r 
                    = (0xffffU & ((0x8000U & (IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r))
                                   ? (0x1021U ^ ((IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r) 
                                                 << 1U))
                                   : ((IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r) 
                                      << 1U)));
                vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r 
                    = (0xffffU & ((0x8000U & (IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r))
                                   ? (0x1021U ^ ((IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r) 
                                                 << 1U))
                                   : ((IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r) 
                                      << 1U)));
                vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r 
                    = (0xffffU & ((0x8000U & (IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r))
                                   ? (0x1021U ^ ((IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r) 
                                                 << 1U))
                                   : ((IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r) 
                                      << 1U)));
                vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r 
                    = (0xffffU & ((0x8000U & (IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r))
                                   ? (0x1021U ^ ((IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r) 
                                                 << 1U))
                                   : ((IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r) 
                                      << 1U)));
                vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r 
                    = (0xffffU & ((0x8000U & (IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r))
                                   ? (0x1021U ^ ((IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r) 
                                                 << 1U))
                                   : ((IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r) 
                                      << 1U)));
                vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r 
                    = (0xffffU & ((0x8000U & (IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r))
                                   ? (0x1021U ^ ((IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r) 
                                                 << 1U))
                                   : ((IData)(vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r) 
                                      << 1U)));
                __Vfunc_cv_cache__DOT__crc16_byte__0__Vfuncout 
                    = vlSelf->cv_cache__DOT__crc16_byte__Vstatic__r;
                vlSelf->cv_cache__DOT__f_crc = __Vfunc_cv_cache__DOT__crc16_byte__0__Vfuncout;
            }
        } else if ((1U & (~ (IData)(vlSelf->cv_cache__DOT__ld_pend)))) {
            vlSelf->cv_cache__DOT__spi_txd = 0xffU;
            __Vdly__cv_cache__DOT__spi_start = 1U;
            __Vdly__cv_cache__DOT__f_state = 0x13U;
            __Vdly__cv_cache__DOT__f_next = 9U;
        }
    } else if ((4U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
        if ((2U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
            if ((1U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
                if ((0xfeU == (IData)(vlSelf->cv_cache__DOT__spi_rx))) {
                    __Vdly__cv_cache__DOT__f_byte = 0U;
                    vlSelf->cv_cache__DOT__f_crc = 0U;
                    __Vdly__cv_cache__DOT__f_state = 8U;
                } else {
                    __Vdly__cv_cache__DOT__f_state 
                        = (((0xffU != (IData)(vlSelf->cv_cache__DOT__spi_rx)) 
                            | (0xffffU == (IData)(vlSelf->cv_cache__DOT__f_cnt)))
                            ? 0x14U : 6U);
                }
            } else {
                __Vdly__cv_cache__DOT__f_cnt = (0xffffU 
                                                & ((IData)(1U) 
                                                   + (IData)(vlSelf->cv_cache__DOT__f_cnt)));
                vlSelf->cv_cache__DOT__spi_txd = 0xffU;
                __Vdly__cv_cache__DOT__spi_start = 1U;
                __Vdly__cv_cache__DOT__f_state = 0x13U;
                __Vdly__cv_cache__DOT__f_next = 7U;
            }
        } else if ((1U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
            __Vdly__cv_cache__DOT__f_state = ((0xffU 
                                               == (IData)(vlSelf->cv_cache__DOT__spi_rx))
                                               ? ((0x10U 
                                                   == (IData)(vlSelf->cv_cache__DOT__f_cnt))
                                                   ? 0x14U
                                                   : 4U)
                                               : ((0U 
                                                   == (IData)(vlSelf->cv_cache__DOT__spi_rx))
                                                   ? 6U
                                                   : 0x14U));
        } else {
            __Vdly__cv_cache__DOT__f_cnt = (0xffffU 
                                            & ((IData)(1U) 
                                               + (IData)(vlSelf->cv_cache__DOT__f_cnt)));
            vlSelf->cv_cache__DOT__spi_txd = 0xffU;
            __Vdly__cv_cache__DOT__spi_start = 1U;
            __Vdly__cv_cache__DOT__f_state = 0x13U;
            __Vdly__cv_cache__DOT__f_next = 5U;
        }
    } else if ((2U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
        if ((1U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
            __Vdly__cv_cache__DOT__f_ci = (7U & ((IData)(1U) 
                                                 + (IData)(vlSelf->cv_cache__DOT__f_ci)));
            vlSelf->cv_cache__DOT__spi_txd = vlSelf->cv_cache__DOT__f_cmd_byte;
            __Vdly__cv_cache__DOT__spi_start = 1U;
            __Vdly__cv_cache__DOT__f_state = 0x13U;
            __Vdly__cv_cache__DOT__f_next = ((5U != (IData)(vlSelf->cv_cache__DOT__f_ci))
                                              ? 3U : 
                                             ((IData)(vlSelf->cv_cache__DOT__f_stop)
                                               ? 0xcU
                                               : 4U));
            __Vdly__cv_cache__DOT__f_cnt = 0U;
        } else {
            vlSelf->cv_cache__DOT__ld_addr = ((IData)(vlSelf->cv_cache__DOT__f_line) 
                                              << 0xdU);
            vlSelf->cv_cache__DOT__cm_we = (1U & (vlSelf->cv_cache__DOT__c_rev
                                                  [vlSelf->cv_cache__DOT__f_line] 
                                                  >> 8U));
            vlSelf->cv_cache__DOT__cm_a = (0xffU & 
                                           vlSelf->cv_cache__DOT__c_rev
                                           [vlSelf->cv_cache__DOT__f_line]);
            vlSelf->cv_cache__DOT__cm_d = 0U;
            vlSelf->cv_cache__DOT__cr_we = 1U;
            vlSelf->cv_cache__DOT__cr_a = vlSelf->cv_cache__DOT__f_line;
            vlSelf->cv_cache__DOT__cr_d = (0x100U | (IData)(vlSelf->cv_cache__DOT__f_page));
            vlSelf->cv_cache__DOT__fill_on = 1U;
            __Vdly__cv_cache__DOT__f_cnt = 0U;
            __Vdly__cv_cache__DOT__f_blk = 0U;
            __Vdly__cv_cache__DOT__f_ci = 0U;
            __Vdly__cv_cache__DOT__f_stop = 0U;
            __Vdly__cv_cache__DOT__f_bad = 0U;
            vlSelf->cv_cache__DOT__f_cs = 1U;
            vlSelf->cv_cache__DOT__spi_txd = 0xffU;
            __Vdly__cv_cache__DOT__spi_start = 1U;
            __Vdly__cv_cache__DOT__f_state = 0x13U;
            __Vdly__cv_cache__DOT__f_next = 3U;
        }
    } else if ((1U & (IData)(vlSelf->cv_cache__DOT__f_state))) {
        if ((1U & (IData)((vlSelf->cv_cache__DOT__c_ref 
                           >> (IData)(vlSelf->cv_cache__DOT__f_hand))))) {
            __Vdly__cv_cache__DOT__c_ref = ((~ (1ULL 
                                                << (IData)(vlSelf->cv_cache__DOT__f_hand))) 
                                            & __Vdly__cv_cache__DOT__c_ref);
            __Vdly__cv_cache__DOT__f_hand = ((0x3fU 
                                              == (IData)(vlSelf->cv_cache__DOT__f_hand))
                                              ? 4U : 
                                             (0x3fU 
                                              & ((IData)(1U) 
                                                 + (IData)(vlSelf->cv_cache__DOT__f_hand))));
        } else {
            vlSelf->cv_cache__DOT__f_line = vlSelf->cv_cache__DOT__f_hand;
            __Vdly__cv_cache__DOT__f_state = 2U;
            __Vdly__cv_cache__DOT__f_hand = ((0x3fU 
                                              == (IData)(vlSelf->cv_cache__DOT__f_hand))
                                              ? 4U : 
                                             (0x3fU 
                                              & ((IData)(1U) 
                                                 + (IData)(vlSelf->cv_cache__DOT__f_hand))));
        }
    } else if (((IData)(vlSelf->rom_rd) & (~ (IData)(vlSelf->c_hit)))) {
        __Vdly__cv_cache__DOT__f_page = vlSelf->rom_page;
        __Vdly__cv_cache__DOT__f_state = 1U;
    }
    if (vlSelf->reset) {
        __Vdly__cv_cache__DOT__sn_st = 0U;
        vlSelf->frag = 0U;
    }
    vlSelf->cv_cache__DOT__sn_st = __Vdly__cv_cache__DOT__sn_st;
    vlSelf->cv_cache__DOT__sn_arg = __Vdly__cv_cache__DOT__sn_arg;
    if (vlSelf->cap_wr) {
        __Vdly__cv_cache__DOT__cap_seen = 0U;
    }
    vlSelf->cv_cache__DOT__cap_seen = __Vdly__cv_cache__DOT__cap_seen;
    vlSelf->cv_cache__DOT__chk_last = __Vdly__cv_cache__DOT__chk_last;
    if (vlSelf->chk_wr) {
        __Vdly__cv_cache__DOT__chk_seen = 0U;
    }
    vlSelf->cv_cache__DOT__chk_seen = __Vdly__cv_cache__DOT__chk_seen;
    vlSelf->c_hit = (1U & ((IData)(cv_cache__DOT__c_map_q) 
                           >> 6U));
    vlSelf->c_line = (0x3fU & (IData)(cv_cache__DOT__c_map_q));
    vlSelf->cv_cache__DOT__fill_on_d = __Vdly__cv_cache__DOT__fill_on_d;
    vlSelf->cv_cache__DOT__ov_settle = __Vdly__cv_cache__DOT__ov_settle;
    vlSelf->cv_cache__DOT__led_time = __Vdly__cv_cache__DOT__led_time;
    vlSelf->cv_cache__DOT__ld_done = __Vdly__cv_cache__DOT__ld_done;
    if (vlSelf->reset) {
        __Vdly__cv_cache__DOT__c_init = 0U;
        __Vdly__cv_cache__DOT__f_state = 0U;
        vlSelf->cv_cache__DOT__f_cs = 0U;
        vlSelf->cv_cache__DOT__fill_on = 0U;
        __Vdly__cv_cache__DOT__ld_pend = 0U;
    }
    vlSelf->cv_cache__DOT__c_init = __Vdly__cv_cache__DOT__c_init;
    vlSelf->cv_cache__DOT__c_ref = __Vdly__cv_cache__DOT__c_ref;
    vlSelf->cv_cache__DOT__f_hand = __Vdly__cv_cache__DOT__f_hand;
    vlSelf->cv_cache__DOT__f_state = __Vdly__cv_cache__DOT__f_state;
    vlSelf->cv_cache__DOT__spi_rx = __Vdly__cv_cache__DOT__spi_rx;
    vlSelf->cv_cache__DOT__f_bad = __Vdly__cv_cache__DOT__f_bad;
    vlSelf->cv_cache__DOT__f_blk = __Vdly__cv_cache__DOT__f_blk;
    vlSelf->cv_cache__DOT__f_cnt = __Vdly__cv_cache__DOT__f_cnt;
    vlSelf->cv_cache__DOT__ld_pend = __Vdly__cv_cache__DOT__ld_pend;
    vlSelf->cv_cache__DOT__f_next = __Vdly__cv_cache__DOT__f_next;
    vlSelf->cv_cache__DOT__spi_start = __Vdly__cv_cache__DOT__spi_start;
    vlSelf->cv_cache__DOT__spi_busy = __Vdly__cv_cache__DOT__spi_busy;
    vlSelf->cv_cache__DOT__ws = __Vdly__cv_cache__DOT__ws;
    vlSelf->cv_cache__DOT__f_byte = __Vdly__cv_cache__DOT__f_byte;
    if (__Vdlyvset__cv_cache__DOT__c_rev__v0) {
        vlSelf->cv_cache__DOT__c_rev[__Vdlyvdim0__cv_cache__DOT__c_rev__v0] 
            = __Vdlyvval__cv_cache__DOT__c_rev__v0;
    }
    vlSelf->cv_cache__DOT__f_ci = __Vdly__cv_cache__DOT__f_ci;
    vlSelf->cv_cache__DOT__f_stop = __Vdly__cv_cache__DOT__f_stop;
    vlSelf->cv_cache__DOT__c_init_i = __Vdly__cv_cache__DOT__c_init_i;
    if ((((IData)(vlSelf->cap_wr) | (IData)(vlSelf->chk_wr)) 
         | (IData)(vlSelf->end_wr))) {
        vlSelf->cv_cache__DOT__cap_on = 0U;
        vlSelf->cv_cache__DOT__chk_on = 0U;
    }
    if (vlSelf->cap_wr) {
        vlSelf->cv_cache__DOT__cap_page = vlSelf->cpu_data;
        vlSelf->cv_cache__DOT__cap_on = 1U;
    }
    if (vlSelf->reset) {
        vlSelf->cv_cache__DOT__cap_on = 0U;
    }
    if (vlSelf->chk_wr) {
        vlSelf->cv_cache__DOT__chk_on = 1U;
    }
    if (vlSelf->reset) {
        vlSelf->cv_cache__DOT__chk_on = 0U;
    }
    vlSelf->cv_cache__DOT__f_arg = vlSelf->cv_cache__DOT__c_lba
        [((IData)(vlSelf->cv_cache__DOT__lba_rd_chk)
           ? (IData)(vlSelf->cv_cache__DOT__chk_page)
           : (IData)(vlSelf->cv_cache__DOT__f_page))];
    if (vlSelf->chk_wr) {
        vlSelf->cv_cache__DOT__lba_rd_chk = 1U;
        vlSelf->cv_cache__DOT__chk_page = vlSelf->cpu_data;
    }
    if (vlSelf->start) {
        vlSelf->cv_cache__DOT__lba_rd_chk = 0U;
    }
    vlSelf->sd_cs_n = (1U & (~ (IData)(vlSelf->cv_cache__DOT__f_cs)));
    vlSelf->ov_active = vlSelf->cv_cache__DOT__fill_on;
    vlSelf->cv_cache__DOT____VdfgTmp_h64dfa0ff__0 = 
        (0x1ffU & ((IData)(vlSelf->cv_cache__DOT__c_init_i) 
                   + (IData)(vlSelf->n_pages)));
    vlSelf->cv_cache__DOT__ci_sram = (0x1ffU & (((IData)(0x40U) 
                                                 - (IData)(vlSelf->n_pages)) 
                                                + (IData)(vlSelf->cv_cache__DOT__c_init_i)));
    vlSelf->cv_cache__DOT__f_page = __Vdly__cv_cache__DOT__f_page;
    if (__Vdlyvset__cv_cache__DOT__c_lba__v0) {
        vlSelf->cv_cache__DOT__c_lba[__Vdlyvdim0__cv_cache__DOT__c_lba__v0] 
            = __Vdlyvval__cv_cache__DOT__c_lba__v0;
    }
    vlSelf->cv_cache__DOT__ci_rev = ((4U <= (IData)(vlSelf->cv_cache__DOT__c_init_i)) 
                                     & (0x40U <= (IData)(vlSelf->cv_cache__DOT____VdfgTmp_h64dfa0ff__0)));
    vlSelf->cv_cache__DOT__ci_map = (((IData)(vlSelf->cv_cache__DOT__c_init_i) 
                                      < (IData)(vlSelf->n_pages)) 
                                     & ((4U <= (IData)(vlSelf->cv_cache__DOT__ci_sram)) 
                                        & (0x40U > (IData)(vlSelf->cv_cache__DOT__ci_sram))));
    vlSelf->cv_cache__DOT__f_cmd_byte = (0xffU & ((0U 
                                                   == (IData)(vlSelf->cv_cache__DOT__f_ci))
                                                   ? 
                                                  ((IData)(vlSelf->cv_cache__DOT__f_stop)
                                                    ? 0x4cU
                                                    : 0x52U)
                                                   : 
                                                  ((5U 
                                                    == (IData)(vlSelf->cv_cache__DOT__f_ci))
                                                    ? 0xffU
                                                    : 
                                                   ((IData)(vlSelf->cv_cache__DOT__f_stop)
                                                     ? 0U
                                                     : 
                                                    ((1U 
                                                      == (IData)(vlSelf->cv_cache__DOT__f_ci))
                                                      ? 
                                                     (vlSelf->cv_cache__DOT__f_arg 
                                                      >> 0x18U)
                                                      : 
                                                     ((2U 
                                                       == (IData)(vlSelf->cv_cache__DOT__f_ci))
                                                       ? 
                                                      (vlSelf->cv_cache__DOT__f_arg 
                                                       >> 0x10U)
                                                       : 
                                                      ((3U 
                                                        == (IData)(vlSelf->cv_cache__DOT__f_ci))
                                                        ? 
                                                       (vlSelf->cv_cache__DOT__f_arg 
                                                        >> 8U)
                                                        : vlSelf->cv_cache__DOT__f_arg)))))));
}

void Vcv_cache___024root___eval_nba(Vcv_cache___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vcv_cache__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcv_cache___024root___eval_nba\n"); );
    // Body
    if ((1ULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vcv_cache___024root___nba_sequent__TOP__0(vlSelf);
    }
}

void Vcv_cache___024root___eval_triggers__ico(Vcv_cache___024root* vlSelf);
#ifdef VL_DEBUG
VL_ATTR_COLD void Vcv_cache___024root___dump_triggers__ico(Vcv_cache___024root* vlSelf);
#endif  // VL_DEBUG
void Vcv_cache___024root___eval_triggers__act(Vcv_cache___024root* vlSelf);
#ifdef VL_DEBUG
VL_ATTR_COLD void Vcv_cache___024root___dump_triggers__act(Vcv_cache___024root* vlSelf);
#endif  // VL_DEBUG
#ifdef VL_DEBUG
VL_ATTR_COLD void Vcv_cache___024root___dump_triggers__nba(Vcv_cache___024root* vlSelf);
#endif  // VL_DEBUG

void Vcv_cache___024root___eval(Vcv_cache___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vcv_cache__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcv_cache___024root___eval\n"); );
    // Init
    CData/*0:0*/ __VicoContinue;
    VlTriggerVec<1> __VpreTriggered;
    IData/*31:0*/ __VnbaIterCount;
    CData/*0:0*/ __VnbaContinue;
    // Body
    vlSelf->__VicoIterCount = 0U;
    __VicoContinue = 1U;
    while (__VicoContinue) {
        __VicoContinue = 0U;
        Vcv_cache___024root___eval_triggers__ico(vlSelf);
        if (vlSelf->__VicoTriggered.any()) {
            __VicoContinue = 1U;
            if (VL_UNLIKELY((0x64U < vlSelf->__VicoIterCount))) {
#ifdef VL_DEBUG
                Vcv_cache___024root___dump_triggers__ico(vlSelf);
#endif
                VL_FATAL_MT("../../cv_cache.v", 27, "", "Input combinational region did not converge.");
            }
            vlSelf->__VicoIterCount = ((IData)(1U) 
                                       + vlSelf->__VicoIterCount);
            Vcv_cache___024root___eval_ico(vlSelf);
        }
    }
    __VnbaIterCount = 0U;
    __VnbaContinue = 1U;
    while (__VnbaContinue) {
        __VnbaContinue = 0U;
        vlSelf->__VnbaTriggered.clear();
        vlSelf->__VactIterCount = 0U;
        vlSelf->__VactContinue = 1U;
        while (vlSelf->__VactContinue) {
            vlSelf->__VactContinue = 0U;
            Vcv_cache___024root___eval_triggers__act(vlSelf);
            if (vlSelf->__VactTriggered.any()) {
                vlSelf->__VactContinue = 1U;
                if (VL_UNLIKELY((0x64U < vlSelf->__VactIterCount))) {
#ifdef VL_DEBUG
                    Vcv_cache___024root___dump_triggers__act(vlSelf);
#endif
                    VL_FATAL_MT("../../cv_cache.v", 27, "", "Active region did not converge.");
                }
                vlSelf->__VactIterCount = ((IData)(1U) 
                                           + vlSelf->__VactIterCount);
                __VpreTriggered.andNot(vlSelf->__VactTriggered, vlSelf->__VnbaTriggered);
                vlSelf->__VnbaTriggered.thisOr(vlSelf->__VactTriggered);
                Vcv_cache___024root___eval_act(vlSelf);
            }
        }
        if (vlSelf->__VnbaTriggered.any()) {
            __VnbaContinue = 1U;
            if (VL_UNLIKELY((0x64U < __VnbaIterCount))) {
#ifdef VL_DEBUG
                Vcv_cache___024root___dump_triggers__nba(vlSelf);
#endif
                VL_FATAL_MT("../../cv_cache.v", 27, "", "NBA region did not converge.");
            }
            __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
            Vcv_cache___024root___eval_nba(vlSelf);
        }
    }
}

#ifdef VL_DEBUG
void Vcv_cache___024root___eval_debug_assertions(Vcv_cache___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vcv_cache__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vcv_cache___024root___eval_debug_assertions\n"); );
    // Body
    if (VL_UNLIKELY((vlSelf->clk & 0xfeU))) {
        Verilated::overWidthError("clk");}
    if (VL_UNLIKELY((vlSelf->reset & 0xfeU))) {
        Verilated::overWidthError("reset");}
    if (VL_UNLIKELY((vlSelf->active & 0xfeU))) {
        Verilated::overWidthError("active");}
    if (VL_UNLIKELY((vlSelf->start & 0xfeU))) {
        Verilated::overWidthError("start");}
    if (VL_UNLIKELY((vlSelf->n_pages & 0xfe00U))) {
        Verilated::overWidthError("n_pages");}
    if (VL_UNLIKELY((vlSelf->rom_rd & 0xfeU))) {
        Verilated::overWidthError("rom_rd");}
    if (VL_UNLIKELY((vlSelf->sd_wr & 0xfeU))) {
        Verilated::overWidthError("sd_wr");}
    if (VL_UNLIKELY((vlSelf->cap_wr & 0xfeU))) {
        Verilated::overWidthError("cap_wr");}
    if (VL_UNLIKELY((vlSelf->chk_wr & 0xfeU))) {
        Verilated::overWidthError("chk_wr");}
    if (VL_UNLIKELY((vlSelf->end_wr & 0xfeU))) {
        Verilated::overWidthError("end_wr");}
    if (VL_UNLIKELY((vlSelf->sd_miso & 0xfeU))) {
        Verilated::overWidthError("sd_miso");}
}
#endif  // VL_DEBUG
