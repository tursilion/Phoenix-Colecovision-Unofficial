// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Model implementation (design independent parts)

#include "Vcv_cache.h"
#include "Vcv_cache__Syms.h"

//============================================================
// Constructors

Vcv_cache::Vcv_cache(VerilatedContext* _vcontextp__, const char* _vcname__)
    : VerilatedModel{*_vcontextp__}
    , vlSymsp{new Vcv_cache__Syms(contextp(), _vcname__, this)}
    , clk{vlSymsp->TOP.clk}
    , reset{vlSymsp->TOP.reset}
    , active{vlSymsp->TOP.active}
    , start{vlSymsp->TOP.start}
    , rom_rd{vlSymsp->TOP.rom_rd}
    , rom_page{vlSymsp->TOP.rom_page}
    , c_hit{vlSymsp->TOP.c_hit}
    , c_line{vlSymsp->TOP.c_line}
    , cpu_wait_n{vlSymsp->TOP.cpu_wait_n}
    , sd_wr{vlSymsp->TOP.sd_wr}
    , cap_wr{vlSymsp->TOP.cap_wr}
    , chk_wr{vlSymsp->TOP.chk_wr}
    , end_wr{vlSymsp->TOP.end_wr}
    , cpu_data{vlSymsp->TOP.cpu_data}
    , frag{vlSymsp->TOP.frag}
    , ov_active{vlSymsp->TOP.ov_active}
    , ov_en{vlSymsp->TOP.ov_en}
    , ov_we_n{vlSymsp->TOP.ov_we_n}
    , ov_data{vlSymsp->TOP.ov_data}
    , sd_cs_n{vlSymsp->TOP.sd_cs_n}
    , sd_sclk{vlSymsp->TOP.sd_sclk}
    , sd_mosi{vlSymsp->TOP.sd_mosi}
    , sd_miso{vlSymsp->TOP.sd_miso}
    , led{vlSymsp->TOP.led}
    , n_pages{vlSymsp->TOP.n_pages}
    , ov_addr{vlSymsp->TOP.ov_addr}
    , rootp{&(vlSymsp->TOP)}
{
    // Register model with the context
    contextp()->addModel(this);
}

Vcv_cache::Vcv_cache(const char* _vcname__)
    : Vcv_cache(Verilated::threadContextp(), _vcname__)
{
}

//============================================================
// Destructor

Vcv_cache::~Vcv_cache() {
    delete vlSymsp;
}

//============================================================
// Evaluation function

#ifdef VL_DEBUG
void Vcv_cache___024root___eval_debug_assertions(Vcv_cache___024root* vlSelf);
#endif  // VL_DEBUG
void Vcv_cache___024root___eval_static(Vcv_cache___024root* vlSelf);
void Vcv_cache___024root___eval_initial(Vcv_cache___024root* vlSelf);
void Vcv_cache___024root___eval_settle(Vcv_cache___024root* vlSelf);
void Vcv_cache___024root___eval(Vcv_cache___024root* vlSelf);

void Vcv_cache::eval_step() {
    VL_DEBUG_IF(VL_DBG_MSGF("+++++TOP Evaluate Vcv_cache::eval_step\n"); );
#ifdef VL_DEBUG
    // Debug assertions
    Vcv_cache___024root___eval_debug_assertions(&(vlSymsp->TOP));
#endif  // VL_DEBUG
    vlSymsp->__Vm_deleter.deleteAll();
    if (VL_UNLIKELY(!vlSymsp->__Vm_didInit)) {
        vlSymsp->__Vm_didInit = true;
        VL_DEBUG_IF(VL_DBG_MSGF("+ Initial\n"););
        Vcv_cache___024root___eval_static(&(vlSymsp->TOP));
        Vcv_cache___024root___eval_initial(&(vlSymsp->TOP));
        Vcv_cache___024root___eval_settle(&(vlSymsp->TOP));
    }
    // MTask 0 start
    VL_DEBUG_IF(VL_DBG_MSGF("MTask0 starting\n"););
    Verilated::mtaskId(0);
    VL_DEBUG_IF(VL_DBG_MSGF("+ Eval\n"););
    Vcv_cache___024root___eval(&(vlSymsp->TOP));
    // Evaluate cleanup
    Verilated::endOfThreadMTask(vlSymsp->__Vm_evalMsgQp);
    Verilated::endOfEval(vlSymsp->__Vm_evalMsgQp);
}

//============================================================
// Events and timing
bool Vcv_cache::eventsPending() { return false; }

uint64_t Vcv_cache::nextTimeSlot() {
    VL_FATAL_MT(__FILE__, __LINE__, "", "%Error: No delays in the design");
    return 0;
}

//============================================================
// Utilities

const char* Vcv_cache::name() const {
    return vlSymsp->name();
}

//============================================================
// Invoke final blocks

void Vcv_cache___024root___eval_final(Vcv_cache___024root* vlSelf);

VL_ATTR_COLD void Vcv_cache::final() {
    Vcv_cache___024root___eval_final(&(vlSymsp->TOP));
}

//============================================================
// Implementations of abstract methods from VerilatedModel

const char* Vcv_cache::hierName() const { return vlSymsp->name(); }
const char* Vcv_cache::modelName() const { return "Vcv_cache"; }
unsigned Vcv_cache::threads() const { return 1; }
void Vcv_cache::prepareClone() const { contextp()->prepareClone(); }
void Vcv_cache::atClone() const {
    contextp()->threadPoolpOnClone();
}

//============================================================
// Trace configuration

VL_ATTR_COLD void Vcv_cache::trace(VerilatedVcdC* tfp, int levels, int options) {
    vl_fatal(__FILE__, __LINE__, __FILE__,"'Vcv_cache::trace()' called on model that was Verilated without --trace option");
}
