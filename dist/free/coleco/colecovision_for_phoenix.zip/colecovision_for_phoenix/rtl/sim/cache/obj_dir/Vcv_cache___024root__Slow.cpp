// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vcv_cache.h for the primary calling header

#include "verilated.h"

#include "Vcv_cache__Syms.h"
#include "Vcv_cache__Syms.h"
#include "Vcv_cache___024root.h"

void Vcv_cache___024root___ctor_var_reset(Vcv_cache___024root* vlSelf);

Vcv_cache___024root::Vcv_cache___024root(Vcv_cache__Syms* symsp, const char* v__name)
    : VerilatedModule{v__name}
    , vlSymsp{symsp}
 {
    // Reset structure values
    Vcv_cache___024root___ctor_var_reset(this);
}

void Vcv_cache___024root::__Vconfigure(bool first) {
    if (false && first) {}  // Prevent unused
}

Vcv_cache___024root::~Vcv_cache___024root() {
}
