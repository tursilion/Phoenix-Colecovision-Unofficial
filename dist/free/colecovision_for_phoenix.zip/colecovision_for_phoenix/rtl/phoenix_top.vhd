--
-- Phoenix ColecoVision Top
-- Released under the 3-Clause BSD License:
--
-- Copyright 2019 - 2020
-- Matthew Hagerty, Brian Burney
--
-- This core started as a mix of the ColecoFPGA core and a CV core designed and
-- written by Matthew.  By the time of the first release, this CV core has been
-- completely rewritten several times over, and nothing of either original core
-- remains. However, both systems provided information and a starting point for
-- this implementation, and credit is always due.
--
-- The SNES and PS2 Keyboard components remain mostly intact from the previous
-- core.
--
-- Attribution for the ColecoFPGA project:
--
-------------------------------------------------------------------------------
--
-- ColecoFPGA project
--
-- Copyright (c) 2016, Fabio Belavenuto (belavenuto@gmail.com)
--
-- All rights reserved
--
-- Redistribution and use in source and synthezised forms, with or without
-- modification, are permitted provided that the following conditions are met:
--
-- Redistributions of source code must retain the above copyright notice,
-- this list of conditions and the following disclaimer.
--
-- Redistributions in synthesized form must reproduce the above copyright
-- notice, this list of conditions and the following disclaimer in the
-- documentation and/or other materials provided with the distribution.
--
-- Neither the name of the author nor the names of other contributors may
-- be used to endorse or promote products derived from this software without
-- specific prior written permission.
--
-- THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
-- AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
-- THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
-- PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE
-- LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
-- CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
-- SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
-- INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
-- CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
-- ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
-- POSSIBILITY OF SUCH DAMAGE.
--
-- Please report bugs to the author, but before you do so, please
-- make sure that this is not a derivative work and that
-- you have the latest version of this file.
--
-------------------------------------------------------------------------------

--
-- Change log:
--
-- July 2020, Matthew Hagerty
--
--   * Fixed flag bug in Z80 core.
--   * Added new YM-2149 core.
--   * Added new SN-76489 core.
--   * Fixed audio mixing to correct signed 16-bit PCM.
--   * Fixed info-frame data in TMDS core.
--   * Added Phoenix build system for merging bit-streams with the CV menu code.
--   * Added missing bin2phx utility and created makefile for it.
--   * Added missing bit2bin utility and created makefile for it.
--   * Added missing makemem utility and created makefile for it.
--   * Included data2mem.exe as part of the included utilities.
--   * Included the needed SDCC compiler as part of the repo.
--   * Fixed the clock generation, fixing all failed timing constraints.
--   * Changed system clock to 25MHz.
--   * Corrected the 3.579MHz clock-enable generation.
--   * Fixed wait-state circuit.
--   * Updated UCF file to support the new LVDS level-shifter.
--   * Cleaned up most code files for consistency and removed unused signals.
--   * Updated all comments to ensure accuracy with existing code.
--   * Tursi updated the CV menu to compile with SDCC 4.0.
--
--   Games known to have been fixed by these changes:
--
--     Sound and speech problems fixed:
--     * EggerLand
--     * QBIQS
--     * Squish'Em Sam
--     * Side Trak
--     * Children of the Night
--     * Wizard of Wor
--
--     Games not previously working, that now work:
--     * Sky Jaguar
--     * Magical Tree
--     * Road Fighter
--

library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

entity phoenix_top is
port
   ( clock_50m0_i_net   : in     std_logic

   -- Buttons
   ; btn_reset_n_i      : in     std_logic -- Active low, pull-up with RC time of ~10ms

   -- External IO port
--   ; exp_io1_net        : inout  std_logic_vector(12 downto 2) := (others => 'Z')
--   ; exp_io2_net        : inout  std_logic_vector(24 downto 15):= (others => 'Z')

   -- SRAM
   ; sram_addr_o        : out    std_logic_vector(18 downto 0) := (others => '0')
   ; sram_data_io       : inout  std_logic_vector(7 downto 0)  := (others => 'Z')
   ; sram_ce_n_o        : out    std_logic := '1'
   ; sram_oe_n_o        : out    std_logic := '1'
   ; sram_we_n_o        : out    std_logic := '1'

   -- PS2
   ; ps2_clk_io         : inout  std_logic := 'Z'
   ; ps2_data_io        : inout  std_logic := 'Z'

   -- SD Card
   ; sd_cs_n_o          : out    std_logic := '1'
   ; sd_sclk_o          : out    std_logic := '0'
   ; sd_mosi_o          : out    std_logic := 'Z'
   ; sd_miso_i          : in     std_logic
   ; sd_cd_n_i          : in     std_logic -- Card detect, active low, ext pull-up

   -- Flash
-- Unused. MH June 2020.
--   ; flash_cs_n_o       : out    std_logic := '1'
--   ; flash_sclk_o       : out    std_logic := '0'
--   ; flash_mosi_o       : out    std_logic := '0'
--   ; flash_miso_i       : in     std_logic
--   ; flash_wp_o         : out    std_logic := '0'
--   ; flash_hold_o       : out    std_logic := '1'

   -- Joystick
   ; joy_p5_o           : out    std_logic
   ; joy_p8_o           : out    std_logic
   ; joy1_p1_i          : in     std_logic
   ; joy1_p2_i          : in     std_logic
   ; joy1_p3_i          : in     std_logic
   ; joy1_p4_i          : in     std_logic
   ; joy1_p6_i          : in     std_logic
   ; joy1_p7_i          : in     std_logic
   ; joy1_p9_i          : in     std_logic
   ; joy2_p1_i          : in     std_logic
   ; joy2_p2_i          : in     std_logic
   ; joy2_p3_i          : in     std_logic
   ; joy2_p4_i          : in     std_logic
   ; joy2_p6_i          : in     std_logic
   ; joy2_p7_i          : in     std_logic
   ; joy2_p9_i          : in     std_logic

   -- SNES controller
   ; snesjoy_clock_o    : out    std_logic := '1'
   ; snesjoy_latch_o    : out    std_logic := '1'
   ; snesjoy_data_i     : in     std_logic

   -- LVDS
   ; lvds_p_o           : out    std_logic_vector(3 downto 0)
   ; lvds_n_o           : out    std_logic_vector(3 downto 0)

   -- Cartridge
   ; cart_addr_o        : out    std_logic_vector(14 downto 0) := (others => '0')
   ; cart_data_io       : inout  std_logic_vector( 7 downto 0)
   ; cart_dir_o         : out    std_logic := '0' --Rev6 PCB
   ; cart_oe_n_o        : out    std_logic := '1'
   ; cart_en_80_n_o     : out    std_logic := '1'
   ; cart_en_A0_n_o     : out    std_logic := '1'
   ; cart_en_C0_n_o     : out    std_logic := '1'
   ; cart_en_E0_n_o     : out    std_logic := '1'

   -- LED and RGB-LED
   ; led_o              : out    std_logic := '0'
   ; rgb_led_o          : out    std_logic_vector(2 downto 0) := (others => '1')
);
end entity;


use work.cv_keys_pack.all;

architecture rtl of phoenix_top is

   -- Clocks and enables
   signal clk_25m0_s       : std_logic;
   signal clk_100m0_s      : std_logic;
   signal clock_tmds_s     : std_logic;
   signal clock_tmds_n_s   : std_logic;

   signal clk_3m58_en_s    : std_logic;
   signal clk_3m58_en_r    : std_logic := '0';
   signal cnt3m58_r        : unsigned(2 downto 0) := "000";
   signal cnt3m58_x        : unsigned(2 downto 0);

   -- Resets
   signal rst_cnt_r        : unsigned(7 downto 0) := (others => '1');
   signal rst_cnt_x        : unsigned(7 downto 0);
   signal rst_zero_s       : std_logic;
   signal rst_trig_s       : std_logic;
   signal rst_en_s         : std_logic;
   signal por_n_r          : std_logic := '0';
   signal reset_r          : std_logic := '1';
   signal ps2_reset_s      : std_logic;
   signal core_reload_s    : std_logic;

   -- Audio
   signal pcm16_s          : std_logic_vector(15 downto 0);

   -- Video
   signal vga_hsync_n_s    : std_logic;
   signal vga_vsync_n_s    : std_logic;
   signal vga_blank_s      : std_logic;
   signal vga_r_s          : std_logic_vector( 3 downto 0);
   signal vga_g_s          : std_logic_vector( 3 downto 0);
   signal vga_b_s          : std_logic_vector( 3 downto 0);
   signal tmds_r_s         : std_logic_vector( 9 downto 0);
   signal tmds_g_s         : std_logic_vector( 9 downto 0);
   signal tmds_b_s         : std_logic_vector( 9 downto 0);

   signal red_8bit_s       : std_logic_vector( 7 downto 0);
   signal grn_8bit_s       : std_logic_vector( 7 downto 0);
   signal blu_8bit_s       : std_logic_vector( 7 downto 0);

   -- Keyboard
   signal ps2_keys_s       : std_logic_vector(15 downto 0);
   signal ps2_joy_s        : std_logic_vector(15 downto 0);
   signal homekey_s        : std_logic;
   signal kbd_raw_keys_s   : std_logic_vector(15 downto 0);
   signal kbd_raw_joy_s    : std_logic_vector(15 downto 0);
   signal kbd_byte_s       : std_logic_vector( 7 downto 0);
   signal kbd_stb_s        : std_logic;
   signal kbd_mode_s       : std_logic;

   -- Controller
   signal ctrl_p1_s        : std_logic_vector( 2 downto 1);
   signal ctrl_p2_s        : std_logic_vector( 2 downto 1);
   signal ctrl_p3_s        : std_logic_vector( 2 downto 1);
   signal ctrl_p4_s        : std_logic_vector( 2 downto 1);
   signal ctrl_p5_s        : std_logic;
   signal ctrl_p6_s        : std_logic_vector( 2 downto 1);
   signal ctrl_p7_s        : std_logic_vector( 2 downto 1);
   signal ctrl_p8_s        : std_logic;
   signal ctrl_p9_s        : std_logic_vector( 2 downto 1);

   -- SNES
   signal but_a_s          : std_logic_vector( 0 downto 0);
   signal but_b_s          : std_logic_vector( 0 downto 0);
   signal but_x_s          : std_logic_vector( 0 downto 0);
   signal but_y_s          : std_logic_vector( 0 downto 0);
   signal but_start_s      : std_logic_vector( 0 downto 0);
   signal but_sel_s        : std_logic_vector( 0 downto 0);
   signal but_tl_s         : std_logic_vector( 0 downto 0);
   signal but_tr_s         : std_logic_vector( 0 downto 0);
   signal but_up_s         : std_logic_vector( 0 downto 0);
   signal but_down_s       : std_logic_vector( 0 downto 0);
   signal but_left_s       : std_logic_vector( 0 downto 0);
   signal but_right_s      : std_logic_vector( 0 downto 0);
   signal but_0_s          : std_logic_vector( 0 downto 0);
   signal but_1_s          : std_logic_vector( 0 downto 0);
   signal but_2_s          : std_logic_vector( 0 downto 0);
   signal but_3_s          : std_logic_vector( 0 downto 0);
   signal but_4_s          : std_logic_vector( 0 downto 0);
   signal but_5_s          : std_logic_vector( 0 downto 0);
   signal but_6_s          : std_logic_vector( 0 downto 0);
   signal but_7_s          : std_logic_vector( 0 downto 0);
   signal but_8_s          : std_logic_vector( 0 downto 0);
   signal but_9_s          : std_logic_vector( 0 downto 0);
   signal but_star_s       : std_logic_vector( 0 downto 0);
   signal but_num_s        : std_logic_vector( 0 downto 0);
   signal but_dot_s        : std_logic_vector( 0 downto 0);
   signal but_clear_s      : std_logic_vector( 0 downto 0);
   signal but_equal_s      : std_logic_vector( 0 downto 0);

   -- CV core debug LED.
   signal cv_led_s         : std_logic;

begin

   --
   -- Clocking for the CV core, F18A, and TMDS Video.
   --
   -- The original CV clock is based on a 7.15909MHz crystal, divided by two
   -- which yields the 3.579545MHz CPU clock (generally rounded to 3.58MHz).
   --
   -- The 25MHz video clock divided by 7 is 3.571428MHz, which is only slightly
   -- slower and will not affect the system.
   --
   -- Deriving all the clock signals from the same PLL, and generating the CPU
   -- clock as a clock-enable signal, keeps the whole system synchronous.
   --
   clock_system : entity work.clk_sys_pll
   port map
   ( clk_50m0_i         => clock_50m0_i_net
   , clk_25m0_o         => clk_25m0_s
   , clk_100m0_o        => clk_100m0_s
   , clk_125m0_o        => clock_tmds_s
   , clk_125m0_n_o      => clock_tmds_n_s
   );


   -- Create a registered CPU clock-enable by dividing the 25MHz video clock
   -- by 7.
   --
   -- TODO
   -- Depending on what the video clock changes to when the new F18A MK2 core
   -- is done, there will be an error-correction to reduce the slightly faster
   -- clock-enable closer to the desired 3.579MHz:
   --
   -- 25.175MHz = 640x480p @ 59.94Hz
   -- 27.000MHz = 720x480p @ 59.94Hz
   --
   -- Pixel clock                          Error                    Skip count
   -- 25.175MHz / 7 = 3596428 - 3579545 =  16883, 3596428 /  16883 = 213.0
   -- 27.000MHz / 7 = 3857142 - 3579545 = 277597, 3857142 / 277597 =  13.89
   --
   -- TODO
   -- The SD-Card slow clock divider will need to be adjusted if a 27MHz system
   -- clock is used.

   cnt3m58_x <= "000" when cnt3m58_r = 6 else cnt3m58_r + 1;
   clk_3m58_en_s <= clk_3m58_en_r;

   process ( clk_25m0_s )
   begin
   if rising_edge(clk_25m0_s) then
      cnt3m58_r <= cnt3m58_x;
      if cnt3m58_r = 6 then
         clk_3m58_en_r <= '1';
      else
         clk_3m58_en_r <= '0';
      end if;
   end if;
   end process;


   --
   -- The System Reset has multiple sources:
   --
   --  1. Power-On Reset (PoR)
   --  2. Push-Button Reset, does not PoR signal
   --  3. Soft Reset via PS2 keyboard
   --
   -- Some devices do not get reset with the button, like the VDP.
   -- This is accurate to the real ColecoVision.
   --

   -- Soft reset trigger can be the PS2 keyboard ESC key or
   -- the reset button input.
   rst_trig_s <= ps2_reset_s or (not btn_reset_n_i);

   rst_zero_s <= '1' when rst_cnt_r = 0 else '0';

   rst_en_s <= rst_trig_s or (not rst_zero_s);

   rst_cnt_x <= rst_cnt_r - 1;

   process(clk_25m0_s)
   begin if rising_edge(clk_25m0_s) then
      if rst_en_s = '1' then
         rst_cnt_r <= rst_cnt_x;
      end if;

      -- PoR is a one-time event at power-on (hence the name).
      if por_n_r = '0' then
         por_n_r <= rst_zero_s;
      end if;

      -- Soft reset any time the reset counter is not zero.
      reset_r <= not rst_zero_s;

   end if;
   end process;


   --
   -- General purpose LED and RGB LED.
   --

   -- LED, as wired, do not set FPGA output high!  That would cause
   -- a path from ground, through the LED, directly to 3.3V.  The
   -- only safe signals are '0' and 'Z' (tri-state floating).
   --
   -- When the FPGA output is 'Z', the LED current will be through the
   -- resistor to 3.3V and it will turn on.
   --
   -- When the FPGA output is '0', the ground is applied to both sides
   -- of the LED and it will be off, but the FPGA output will sink 10mA
   -- through the resistor to 3.3V.
   --
   -- GND---|<|----+---/\/\/---3.3V
   --       led    |    330
   --        __    |
   -- GND---o  o---+
   --     FPGA out, '0' or 'Z' only! Never output a '1'.

   -- Indicate reset with the LED.
   led_o <= 'Z' when reset_r = '1' or cv_led_s = '1' else '0';

   -- RGB-LED, set to yellow
   rgb_led_o <= "001";


   --
   -- ColecoVision Core
   --
   coleco : entity work.colecovision
   generic map
   ( mach_id_g       => 8 -- Phoenix board machine ID for port read.
   )
   port map
   ( clk_25m0_i      => clk_25m0_s
   , clk_100m0_i     => clk_100m0_s
   , clk_3m58_en_i   => clk_3m58_en_s
   , reset_i         => reset_r -- active high
   , por_n_i         => por_n_r -- active low
   -- Physical controller interface
   , ctrl_p1_i       => ctrl_p1_s
   , ctrl_p2_i       => ctrl_p2_s
   , ctrl_p3_i       => ctrl_p3_s
   , ctrl_p4_i       => ctrl_p4_s
   , ctrl_p5_o       => ctrl_p5_s
   , ctrl_p6_i       => ctrl_p6_s
   , ctrl_p7_i       => ctrl_p7_s
   , ctrl_p8_o       => ctrl_p8_s
   , ctrl_p9_i       => ctrl_p9_s
   -- Physical cartridge interface
   , cart_addr_o     => cart_addr_o
   , cart_dir_o      => cart_dir_o
   , cart_data_io    => cart_data_io
   , cart_oe_n_o     => cart_oe_n_o
   , cart_en_80_n_o  => cart_en_80_n_o
   , cart_en_a0_n_o  => cart_en_A0_n_o
   , cart_en_c0_n_o  => cart_en_C0_n_o
   , cart_en_e0_n_o  => cart_en_E0_n_o
   -- Audio output
   , pcm16_o         => pcm16_s
   -- VGA output
   , blank_o         => vga_blank_s
   , hsync_n_o       => vga_hsync_n_s
   , vsync_n_o       => vga_vsync_n_s
   , red_o           => vga_r_s
   , grn_o           => vga_g_s
   , blu_o           => vga_b_s
   -- External SRAM
   , sram_addr_o     => sram_addr_o
   , sram_data_io    => sram_data_io
   , sram_ce_n_o     => sram_ce_n_o
   , sram_oe_n_o     => sram_oe_n_o
   , sram_we_n_o     => sram_we_n_o
   -- SD-card SPI
   , sd_miso_i       => sd_miso_i
   , sd_mosi_o       => sd_mosi_o
   , sd_sclk_o       => sd_sclk_o
   , sd_cs_n_o       => sd_cs_n_o
   , sd_cd_n_i       => sd_cd_n_i -- Card detect, active low.
   -- PS/2 keyboard
   , kbd_byte_i      => kbd_byte_s
   , kbd_stb_i       => kbd_stb_s
   , kbd_mode_o      => kbd_mode_s
   -- Indication
   , led_o           => cv_led_s
   );


   --
   -- PS/2 keyboard interface
   --
   ps2if_inst : entity work.colecoKeyboard
   port map
   ( clk             => clk_25m0_s
   , reset           => reset_r -- active high
   -- inputs from PS/2 port
   , ps2_clk         => ps2_clk_io
   , ps2_data        => ps2_data_io
   -- user outputs
   , keys            => kbd_raw_keys_s
   , joy             => kbd_raw_joy_s
   , core_reload_o   => core_reload_s
   , home_o          => homekey_s
   , rx_byte_o       => kbd_byte_s
   , rx_stb_o        => kbd_stb_s
   );

   -- In keyboard mode (port >53 bit >04) the keyboard no longer emulates
   -- controller 1 or soft resets with ESC; the scan codes go to port >80.
   ps2_keys_s <= kbd_raw_keys_s when kbd_mode_s = '0' else (others => '0');
   ps2_joy_s  <= kbd_raw_joy_s  when kbd_mode_s = '0' else (others => '0');


   --
   -- SNES Gamepad (TODO: implement NTT)
   --
   snespads_b : entity work.snespad
   generic map
   ( num_pads_g         => 1
   , reset_level_g      => 0
   , button_level_g     => 0
   , clocks_per_6us_g   => 150 -- 6us @ 25MHz = 150
   )
   port map
   ( clk_i              => clk_25m0_s
   , reset_i            => por_n_r -- active low
   , pad_clk_o          => snesjoy_clock_o
   , pad_latch_o        => snesjoy_latch_o
   , pad_data_i(0)      => snesjoy_data_i
   , but_a_o            => but_a_s
   , but_b_o            => but_b_s
   , but_x_o            => but_x_s
   , but_y_o            => but_y_s
   , but_start_o        => but_start_s
   , but_sel_o          => but_sel_s
   , but_tl_o           => but_tl_s
   , but_tr_o           => but_tr_s
   , but_up_o           => but_up_s
   , but_down_o         => but_down_s
   , but_left_o         => but_left_s
   , but_right_o        => but_right_s
   , but_0_o            => but_0_s
   , but_1_o            => but_1_s
   , but_2_o            => but_2_s
   , but_3_o            => but_3_s
   , but_4_o            => but_4_s
   , but_5_o            => but_5_s
   , but_6_o            => but_6_s
   , but_7_o            => but_7_s
   , but_8_o            => but_8_s
   , but_9_o            => but_9_s
   , but_star_o         => but_star_s
   , but_num_o          => but_num_s
   , but_dot_o          => but_dot_s
   , but_clear_o        => but_clear_s
   , but_equal_o        => but_equal_s
   );


   --
   -- Mix the NES GamePad and PS2 keyboard signals to CV Controller 1.
   -- The GamePad and keyboard do not provide quadrature signals, those
   -- inputs are wired directly below this process.
   --
   pad_ctrl: process
   ( ctrl_p5_s, ctrl_p8_s, ps2_keys_s, ps2_joy_s
   , joy1_p1_i, joy1_p2_i, joy1_p3_i, joy1_p4_i, joy1_p6_i
   , but_a_s, but_b_s, but_up_s, but_down_s, but_left_s, but_right_s
   , but_x_s, but_y_s, but_sel_s, but_start_s, but_tl_s, but_tr_s, but_0_s
   , but_1_s, but_2_s, but_3_s, but_4_s, but_5_s, but_6_s, but_7_s, but_8_s
   , but_9_s, but_star_s, but_num_s, but_dot_s, but_clear_s, but_equal_s
   )
      variable key_v   : natural range cv_keys_t'range;
      variable fire1_v : std_logic;
      variable fire2_v : std_logic;

   begin

      -- Joy 1
      if ctrl_p5_s = '0' and ctrl_p8_s = '1' then
         -- keys and right button enabled
         -- keys not fully implemented

         key_v := cv_key_none_c;

         -- PS/2 Keyboard
         if ps2_keys_s(13) = '1' then
            -- KEY 1
            key_v := cv_key_1_c;
         elsif ps2_keys_s(7) = '1' then
            -- KEY 2
            key_v := cv_key_2_c;
         elsif ps2_keys_s(12) = '1' then
            -- KEY 3
            key_v := cv_key_3_c;
         elsif ps2_keys_s(2) = '1' then
            -- KEY 4
            key_v := cv_key_4_c;
         elsif ps2_keys_s(3) = '1' then
            -- KEY 5
            key_v := cv_key_5_c;
         elsif ps2_keys_s(14) = '1' then
            -- KEY 6
            key_v := cv_key_6_c;
         elsif ps2_keys_s(5) = '1' then
            -- KEY 7
            key_v := cv_key_7_c;
         elsif ps2_keys_s(1) = '1' then
            -- KEY 8
            key_v := cv_key_8_c;
         elsif ps2_keys_s(11) = '1' then
            -- KEY 9
            key_v := cv_key_9_c;
         elsif ps2_keys_s(10) = '1' then
            -- KEY 0
            key_v := cv_key_0_c;
         elsif ps2_keys_s(6) = '1' then
            -- KEY *
            key_v := cv_key_asterisk_c;
         elsif ps2_keys_s(9) = '1' then
            -- KEY #
            key_v := cv_key_number_c;
         end if;

         -- SNES joypad
         if but_tl_s(0) = '0' then           -- TL button pressed, numbers 1 to 6
            if    but_y_s(0) = '0' then
               -- KEY 1
               key_v := cv_key_1_c;
            elsif but_x_s(0) = '0' then
               -- KEY 2
               key_v := cv_key_2_c;
            elsif but_b_s(0) = '0' then
               -- KEY 3
               key_v := cv_key_3_c;
            elsif but_a_s(0) = '0' then
               -- KEY 4
               key_v := cv_key_4_c;
            elsif but_sel_s(0) = '0' then
               -- KEY 5
               key_v := cv_key_5_c;
            elsif but_start_s(0) = '0' then
               -- KEY 6
               key_v := cv_key_6_c;
            end if;
         elsif but_tr_s(0) = '0' then        -- TR button pressed, 7 at 0, * and #
            if    but_y_s(0) = '0' then
               -- KEY 7
               key_v := cv_key_7_c;
            elsif but_x_s(0) = '0' then
               -- KEY 8
               key_v := cv_key_8_c;
            elsif but_b_s(0) = '0' then
               -- KEY 9
               key_v := cv_key_9_c;
            elsif but_a_s(0) = '0' then
               -- KEY 0
               key_v := cv_key_0_c;
            elsif but_sel_s(0) = '0' then
               -- KEY *
               key_v := cv_key_asterisk_c;
            elsif but_start_s(0) = '0' then
               -- KEY #
               key_v := cv_key_number_c;
            end if;
         end if;
         -- NTT data
         if    but_1_s(0) = '0' then
            -- KEY 1
            key_v := cv_key_1_c;
         elsif but_2_s(0) = '0' then
            -- KEY 2
            key_v := cv_key_2_c;
         elsif but_3_s(0) = '0' then
            -- KEY 3
            key_v := cv_key_3_c;
         elsif but_4_s(0) = '0' then
            -- KEY 4
            key_v := cv_key_4_c;
         elsif but_5_s(0) = '0' then
            -- KEY 5
            key_v := cv_key_5_c;
         elsif but_6_s(0) = '0' then
            -- KEY 6
            key_v := cv_key_6_c;
         elsif but_7_s(0) = '0' then
            -- KEY 7
            key_v := cv_key_7_c;
         elsif but_8_s(0) = '0' then
            -- KEY 8
            key_v := cv_key_8_c;
         elsif but_9_s(0) = '0' then
            -- KEY 9
            key_v := cv_key_9_c;
         elsif but_0_s(0) = '0' then
            -- KEY 0
            key_v := cv_key_0_c;
         elsif but_star_s(0) = '0' then
            -- KEY star
            key_v := cv_key_asterisk_c;
         elsif but_num_s(0) = '0' then
            -- KEY #
            key_v := cv_key_number_c;
         end if;

         if but_tl_s(0) = '1' and but_tr_s(0) = '1' then
            if but_y_s(0) = '0' then
               --KEY F3
               key_v := cv_key_f3_c;
            elsif but_x_s(0) = '0' then
               --KEY F4
               key_v := cv_key_f4_c;
            end if;
         end if;

         ctrl_p1_s(1) <= cv_keys_c(key_v)(1) and joy1_p1_i;
         ctrl_p2_s(1) <= cv_keys_c(key_v)(2) and joy1_p2_i;
         ctrl_p3_s(1) <= cv_keys_c(key_v)(3) and joy1_p3_i;
         ctrl_p4_s(1) <= cv_keys_c(key_v)(4) and joy1_p4_i;

         if but_tl_s(0) = '1' and but_tr_s(0) = '1' then    -- fire 2 only if the TL and TR buttons are not pressed
            fire2_v := but_a_s(0) and joy1_p6_i;
         else
            fire2_v := '1';
         end if;

         ctrl_p6_s(1) <= not ps2_keys_s(0) and fire2_v and joy1_p6_i; -- button right (fire 2)

      elsif ctrl_p5_s = '1' and ctrl_p8_s = '0' then
         -- joystick and left button enabled
         ctrl_p1_s(1) <= not ps2_joy_s(0) and but_up_s(0) and but_dot_s(0) and joy1_p1_i;    -- up
         ctrl_p2_s(1) <= not ps2_joy_s(1) and but_down_s(0) and joy1_p2_i; -- down
         ctrl_p3_s(1) <= not ps2_joy_s(2) and but_left_s(0) and joy1_p3_i; -- left
         ctrl_p4_s(1) <= not ps2_joy_s(3) and but_right_s(0) and joy1_p4_i;   -- right

         if but_tl_s(0) = '1' and but_tr_s(0) = '1' then    -- fire 1 only if the TL and TR buttons are not pressed
            fire1_v := but_b_s(0) and joy1_p6_i;
         else
            fire1_v := '1';
         end if;

         ctrl_p6_s(1) <= not ps2_joy_s(4) and fire1_v;   -- button left (fire 1)
      else
         -- nothing active
         ctrl_p1_s(1)   <= joy1_p1_i;
         ctrl_p2_s(1)   <= joy1_p2_i;
         ctrl_p3_s(1)   <= joy1_p3_i;
         ctrl_p4_s(1)   <= joy1_p4_i;
         ctrl_p6_s(1)   <= joy1_p6_i;
      end if;

   end process pad_ctrl;

   -- PS2 system soft reset signal via the ESC key.
   ps2_reset_s <= ps2_keys_s(8);

   -- Controller 2, straight input signals.
   ctrl_p1_s(2) <= joy2_p1_i;
   ctrl_p2_s(2) <= joy2_p2_i;
   ctrl_p3_s(2) <= joy2_p3_i;
   ctrl_p4_s(2) <= joy2_p4_i;
   ctrl_p6_s(2) <= joy2_p6_i;

   -- Quadrature inputs for both controllers.
   ctrl_p7_s <= joy2_p7_i & joy1_p7_i;
   ctrl_p9_s <= joy2_p9_i & joy1_p9_i;

   -- Output stick vs keypad selection.
   joy_p5_o <= ctrl_p5_s;
   joy_p8_o <= ctrl_p8_s;


   --
   -- TMDS
   --

   red_8bit_s <= vga_r_s & vga_r_s;
   grn_8bit_s <= vga_g_s & vga_g_s;
   blu_8bit_s <= vga_b_s & vga_b_s;

   tmds : entity work.hdmi
   generic map
            -- Pixel clock frequency in Hertz
   ( FREQ   => 25000000
            -- Audio sample rate in Hertz, should be 32000, 41000 or 48000
   , FS     => 48000
            -- CTS = Freq(pixclk) * N / (128 * Fs)
   , CTS    => 25000
            -- N = 128 * Fs /1000,  128 * Fs /1500 <= N <= 128 * Fs /300
            -- (Check specification section 7.2 for details)
   , N      => 6144
   )
   port map
   ( I_CLK_PIXEL     => clk_25m0_s
   , I_R             => red_8bit_s
   , I_G             => grn_8bit_s
   , I_B             => blu_8bit_s
   , I_BLANK         => vga_blank_s
   , I_HSYNC         => vga_hsync_n_s
   , I_VSYNC         => vga_vsync_n_s
   -- PCM audio
   , I_AUDIO_ENABLE  => '1'
   , I_AUDIO_PCM_L   => pcm16_s
   , I_AUDIO_PCM_R   => pcm16_s
   -- TMDS parallel pixel synchronous outputs (serialize LSB first)
   , O_RED           => tmds_r_s
   , O_GREEN         => tmds_g_s
   , O_BLUE          => tmds_b_s
   );


   tmds_out : entity work.hdmi_out_xilinx
   port map
   ( clock_pixel_i   => clk_25m0_s
   , clock_tdms_i    => clock_tmds_s
   , clock_tdms_n_i  => clock_tmds_n_s
   , red_i           => tmds_r_s
   , green_i         => tmds_g_s
   , blue_i          => tmds_b_s
   , tmds_out_p      => lvds_p_o
   , tmds_out_n      => lvds_n_o
   );

end rtl;
