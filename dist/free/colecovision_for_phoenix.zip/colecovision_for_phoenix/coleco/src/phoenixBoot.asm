;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module phoenixBoot
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _main
	.globl _runCartHeader
	.globl _startCartridge
	.globl _startTitle
	.globl _centerString
	.globl _displayLogo
	.globl _textout
	.globl _cfgMenu
	.globl _waitVblanks
	.globl _unrle
	.globl _my_set_graphics
	.globl _menu
	.globl _vdpmemcpyfast
	.globl _inc_palette
	.globl _readinputs
	.globl _prepare_f18a
	.globl _unlock_f18a
	.globl _reset_f18a
	.globl _vdpmemread
	.globl _vdpmemset
	.globl _memmove
	.globl _memcpy
	.globl _memset
	.globl _text_width
	.globl _useFlicker
	.globl _usePattern
	.globl _lineBuffer
	.globl _copyright
	.globl _readkeypad
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_VDPRD	=	0x00be
_VDPST	=	0x00bf
_VDPWA	=	0x00bf
_VDPWD	=	0x00be
_sgmPSGAddressWrite	=	0x0050
_sgmPSGDataWrite	=	0x0051
_sgmPSGDataRead	=	0x0052
_sgmConfig	=	0x0053
_phRAMBankSelect	=	0x0054
_phBankingScheme	=	0x0055
_phSDControl	=	0x0056
_phSDData	=	0x0057
_phMachineID	=	0x0058
_phCartMask	=	0x0059
_phCachePage	=	0x005c
_phCacheCheck	=	0x005d
_phCacheStatus	=	0x005e
_sgmBIOSMap	=	0x007f
_port3	=	0x00c0
_AY_REGISTER	=	0x0050
_AY_DATA_WRITE	=	0x0051
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_copyright::
	.ds 65
_lineBuffer::
	.ds 640
_readkeypad_lastret_65536_108:
	.ds 1
_readkeypad_inCfg_65536_108:
	.ds 1
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
_usePattern::
	.ds 1
_useFlicker::
	.ds 1
_text_width::
	.ds 1
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;phoenixBoot.c:275: static unsigned char lastret = 0xff;
	ld	iy, #_readkeypad_lastret_65536_108
	ld	0 (iy), #0xff
;phoenixBoot.c:276: static unsigned char inCfg = 0;
	ld	iy, #_readkeypad_inCfg_65536_108
	ld	0 (iy), #0x00
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;phoenixBoot.c:98: unsigned char my_set_graphics(unsigned char sprite_mode) {
;	---------------------------------
; Function my_set_graphics
; ---------------------------------
_my_set_graphics::
;../libti99coleco/vdp.h:72: inline void VDP_SET_REGISTER(unsigned char r, unsigned char v)		{	VDPWA=(v); VDPWA=(0x80|(r)); }
	ld	a, #0x80
	out	(_VDPWA), a
	ld	a, #0x81
	out	(_VDPWA), a
	ld	a, #0x00
	out	(_VDPWA), a
	ld	a, #0x80
	out	(_VDPWA), a
	ld	a, #0x00
	out	(_VDPWA), a
	ld	a, #0x82
	out	(_VDPWA), a
	ld	a, #0x40
	out	(_VDPWA), a
	ld	a, #0x83
	out	(_VDPWA), a
	ld	a, #0x01
	out	(_VDPWA), a
	ld	a, #0x84
	out	(_VDPWA), a
	ld	a, #0x0e
	out	(_VDPWA), a
	ld	a, #0x85
	out	(_VDPWA), a
	ld	a, #0x03
	out	(_VDPWA), a
	ld	a, #0x86
	out	(_VDPWA), a
	ld	a, #0xe1
	out	(_VDPWA), a
	ld	a, #0x87
	out	(_VDPWA), a
;phoenixBoot.c:108: text_width = 32;
	ld	hl,#_text_width + 0
	ld	(hl), #0x20
;phoenixBoot.c:109: return VDP_MODE1_16K | VDP_MODE1_UNBLANK | VDP_MODE1_INT | sprite_mode;
	ld	hl, #2+0
	add	hl, sp
	ld	a, (hl)
	or	a, #0xe0
	ld	l, a
;phoenixBoot.c:110: }
	ret
_colorTable:
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0xf0	; 240
	.db #0xd0	; 208
	.db #0x80	; 128
	.db #0x90	; 144
	.db #0xb0	; 176
	.db #0x30	; 48	'0'
	.db #0x40	; 64
_regTable:
	.db #0x00	; 0
	.db #0x1b	; 27
	.db #0x00	; 0
	.db #0x38	; 56	'8'
	.db #0x00	; 0
	.db #0x18	; 24
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x00	; 0
	.db #0x20	; 32
_trampoline:
	.db #0xdb	; 219
	.db #0x55	; 85	'U'
	.db #0x31	; 49	'1'
	.db #0xb9	; 185
	.db #0x73	; 115	's'
	.db #0x2a	; 42
	.db #0x0a	; 10
	.db #0x80	; 128
	.db #0xe9	; 233
;phoenixBoot.c:121: void unrle(unsigned int vdpAdr, unsigned char *pSrc, unsigned int rleCnt) {
;	---------------------------------
; Function unrle
; ---------------------------------
_unrle::
	call	___sdcc_enter_ix
	push	af
	push	af
;phoenixBoot.c:124: VDP_SET_ADDRESS_WRITE(vdpAdr);
;../libti99coleco/vdp.h:65: inline void VDP_SET_ADDRESS_WRITE(unsigned int x)					{	VDPWA=((x)&0xff); VDPWA=(((x)>>8)|0x40); }
	ld	a, 4 (ix)
	ld	c, 5 (ix)
	out	(_VDPWA), a
	ld	a, c
	or	a, #0x40
	out	(_VDPWA), a
;phoenixBoot.c:125: pEnd = pSrc + rleCnt;
	ld	a, 6 (ix)
	add	a, 8 (ix)
	ld	c, a
	ld	a, 7 (ix)
	adc	a, 9 (ix)
	ld	b, a
	inc	sp
	inc	sp
	push	bc
;phoenixBoot.c:127: while (pSrc < pEnd) {
00112$:
	ld	a, 6 (ix)
	sub	a, -4 (ix)
	ld	a, 7 (ix)
	sbc	a, -3 (ix)
	jp	NC, 00116$
;phoenixBoot.c:128: unsigned char cnt = *(pSrc++);
	ld	l, 6 (ix)
	ld	h, 7 (ix)
	ld	c, (hl)
	inc	hl
	ld	6 (ix), l
	ld	7 (ix), h
;phoenixBoot.c:129: unsigned char byte = 0;
	ld	e, #0x00
;phoenixBoot.c:130: switch (cnt&0xc0) {
	ld	a, c
	and	a, #0xc0
	ld	-2 (ix), a
	ld	-1 (ix), #0x00
;phoenixBoot.c:148: cnt = (cnt & 0x3f) + 1;
	ld	a, c
	and	a, #0x3f
	ld	c, a
	inc	c
;phoenixBoot.c:130: switch (cnt&0xc0) {
	ld	a, -2 (ix)
	or	a, a
	or	a, -1 (ix)
	jr	Z,00101$
	ld	a, -2 (ix)
	sub	a, #0x40
	or	a, -1 (ix)
	jr	Z,00102$
;phoenixBoot.c:128: unsigned char cnt = *(pSrc++);
	ld	l, 6 (ix)
	ld	h, 7 (ix)
;phoenixBoot.c:130: switch (cnt&0xc0) {
	ld	a, -2 (ix)
	sub	a, #0x80
	or	a, -1 (ix)
	jr	Z,00103$
	ld	a, -2 (ix)
	sub	a, #0xc0
	or	a, -1 (ix)
	jr	Z,00104$
	jr	00108$
;phoenixBoot.c:131: case 0x00:
00101$:
;phoenixBoot.c:133: byte = 0;
	ld	e, #0x00
;phoenixBoot.c:134: break;
	jr	00108$
;phoenixBoot.c:136: case 0x40:
00102$:
;phoenixBoot.c:138: byte = 0xff;
	ld	e, #0xff
;phoenixBoot.c:139: break;
	jr	00108$
;phoenixBoot.c:141: case 0x80:
00103$:
;phoenixBoot.c:143: byte = *(pSrc++);
	ld	e, (hl)
	inc	hl
	ld	6 (ix), l
	ld	7 (ix), h
;phoenixBoot.c:144: break;
	jr	00108$
;phoenixBoot.c:146: case 0xc0:
00104$:
;phoenixBoot.c:148: cnt = (cnt & 0x3f) + 1;
;phoenixBoot.c:149: while (cnt--) {
	ex	de,hl
00105$:
	ld	a, c
	dec	c
	or	a, a
	jr	Z,00112$
;phoenixBoot.c:150: VDPWD = *(pSrc++);
	ld	a, (de)
	out	(_VDPWD), a
	inc	de
	ld	6 (ix), e
	ld	7 (ix), d
	jr	00105$
;phoenixBoot.c:153: }
00108$:
;phoenixBoot.c:155: cnt = (cnt & 0x3f) + 1;
;phoenixBoot.c:156: while (cnt--) {
00109$:
	ld	a, c
	dec	c
	or	a, a
	jp	Z, 00112$
;phoenixBoot.c:157: VDPWD = byte;
	ld	a, e
	out	(_VDPWD), a
	jr	00109$
00116$:
;phoenixBoot.c:160: }
	ld	sp, ix
	pop	ix
	ret
;phoenixBoot.c:167: void waitVblanks(unsigned char cnt) {
;	---------------------------------
; Function waitVblanks
; ---------------------------------
_waitVblanks::
;phoenixBoot.c:169: VDP_CLEAR_VBLANK;
	ld	hl,#_vdpLimi + 0
	ld	(hl), #0x00
	in	a, (_VDPST)
	ld	(_VDP_STATUS_MIRROR+0), a
;phoenixBoot.c:171: while (cnt-- > 0) {
	ld	hl, #2+0
	add	hl, sp
	ld	c, (hl)
00104$:
	ld	a, c
	dec	c
	or	a, a
	ret	Z
;phoenixBoot.c:173: VDP_WAIT_VBLANK_CRU;
00101$:
	ld	a,(#_vdpLimi + 0)
	rlca
	jr	NC,00101$
;phoenixBoot.c:174: VDP_CLEAR_VBLANK;
	ld	hl,#_vdpLimi + 0
	ld	(hl), #0x00
	in	a, (_VDPST)
	ld	(_VDP_STATUS_MIRROR+0), a
;phoenixBoot.c:176: }
	jr	00104$
;phoenixBoot.c:180: void cfgMenu() {
;	---------------------------------
; Function cfgMenu
; ---------------------------------
_cfgMenu::
	call	___sdcc_enter_ix
	ld	hl, #-10
	add	hl, sp
	ld	sp, hl
;phoenixBoot.c:181: unsigned char lastkey = 0xff;
	ld	-10 (ix), #0xff
;phoenixBoot.c:182: unsigned int pos = GIMAGE+8*40;
	ld	-5 (ix), #0x40
	ld	-4 (ix), #0x01
;phoenixBoot.c:184: unsigned char de1 = 0, de2 = 0, de3 = 0;
	xor	a, a
	ld	-3 (ix), a
	xor	a, a
	ld	-2 (ix), a
	xor	a, a
	ld	-1 (ix), a
;phoenixBoot.c:191: if (text_width == 32) {
	ld	a,(#_text_width + 0)
	sub	a, #0x20
	jr	NZ,00102$
;phoenixBoot.c:192: vdpmemread(GIMAGE+8*32, lineBuffer, 16*32);		// backup screen
	ld	hl, #0x0200
	push	hl
	ld	hl, #_lineBuffer
	push	hl
	ld	hl, #0x0100
	push	hl
	call	_vdpmemread
	pop	af
	pop	af
	pop	af
;phoenixBoot.c:193: vdpmemset(GIMAGE+8*32, 0x18, 16*32);			// clear it
	ld	hl, #0x0200
	push	hl
	ld	a, #0x18
	push	af
	inc	sp
	ld	h, #0x01
	push	hl
	call	_vdpmemset
	pop	af
;phoenixBoot.c:194: vdpmemcpy(GPATTERN+' '*8, &FATFONT[(' '-29)*8], ('X'-' '+1)*8);		// fix char set
	inc	sp
	ld	hl,#0x01c8
	ex	(sp),hl
	ld	hl, #(_FATFONT + 0x0018)
	push	hl
	ld	hl, #0x0900
	push	hl
	call	_vdpmemcpyfast
	pop	af
	pop	af
	pop	af
;phoenixBoot.c:195: pos = GIMAGE+8*32;
	ld	-5 (ix), #0x00
	ld	-4 (ix), #0x01
	jr	00103$
00102$:
;phoenixBoot.c:197: vdpmemread(GIMAGE+8*40, lineBuffer, 9*40);		// backup screen
	ld	hl, #0x0168
	push	hl
	ld	hl, #_lineBuffer
	push	hl
	ld	hl, #0x0140
	push	hl
	call	_vdpmemread
	pop	af
	pop	af
	pop	af
;phoenixBoot.c:198: vdpmemset(GIMAGE+8*40, ' ', 9*40);				// clear it
	ld	hl, #0x0168
	push	hl
	ld	a, #0x20
	push	af
	inc	sp
	ld	l, #0x40
	push	hl
	call	_vdpmemset
	pop	af
	pop	af
	inc	sp
00103$:
;phoenixBoot.c:202: pos += text_width+3;
	ld	hl,#_text_width + 0
	ld	c, (hl)
	ld	b, #0x00
	inc	bc
	inc	bc
	inc	bc
	ld	a, -5 (ix)
	add	a, c
	ld	c, a
	ld	a, -4 (ix)
	adc	a, b
	ld	b, a
;phoenixBoot.c:203: vdpmemcpy(pos, "PRESS:", 6);
	push	bc
	ld	hl, #0x0006
	push	hl
	ld	hl, #___str_0
	push	hl
	push	bc
	call	_vdpmemcpyfast
	pop	af
	pop	af
	pop	af
	pop	bc
;phoenixBoot.c:204: pos += text_width+2;
	ld	iy, #_text_width
	ld	l, 0 (iy)
	ld	h, #0x00
	inc	hl
	inc	hl
	add	hl, bc
	ex	de, hl
;phoenixBoot.c:205: vdpmemcpy(pos, "1 TOGGLE SCANLINES", 18);
	push	de
	ld	hl, #0x0012
	push	hl
	ld	hl, #___str_1
	push	hl
	push	de
	call	_vdpmemcpyfast
	pop	af
	pop	af
	pop	af
	pop	de
;phoenixBoot.c:206: pos += text_width;
	ld	iy, #_text_width
	ld	l, 0 (iy)
	ld	h, #0x00
	add	hl, de
	ex	de, hl
;phoenixBoot.c:207: vdpmemcpy(pos, "2 TOGGLE FLICKER (OFF)", 22);
	push	de
	ld	hl, #0x0016
	push	hl
	ld	hl, #___str_2
	push	hl
	push	de
	call	_vdpmemcpyfast
	pop	af
	pop	af
	pop	af
	pop	de
;phoenixBoot.c:208: onoff = pos+18;
	ld	hl, #0x0012
	add	hl, de
	ld	-9 (ix), l
	ld	-8 (ix), h
;phoenixBoot.c:209: pos += text_width;
	ld	iy, #_text_width
	ld	l, 0 (iy)
	ld	h, #0x00
	add	hl, de
	ex	de, hl
;phoenixBoot.c:210: vdpmemcpy(pos, "3 DRAM PATTERN (0000)", 21);
	push	de
	ld	hl, #0x0015
	push	hl
	ld	hl, #___str_3
	push	hl
	push	de
	call	_vdpmemcpyfast
	pop	af
	pop	af
	pop	af
	pop	de
;phoenixBoot.c:211: mempat = pos+18;
	ld	hl, #0x0012
	add	hl, de
	ld	-7 (ix), l
	ld	-6 (ix), h
;phoenixBoot.c:212: pos += text_width;
	ld	iy, #_text_width
	ld	l, 0 (iy)
	ld	h, #0x00
	add	hl, de
	ex	de, hl
;phoenixBoot.c:213: vdpmemcpy(pos, "0 SOFT RESET", 12);
	push	de
	ld	hl, #0x000c
	push	hl
	ld	hl, #___str_4
	push	hl
	push	de
	call	_vdpmemcpyfast
	pop	af
	pop	af
	pop	af
	pop	de
;phoenixBoot.c:214: pos += text_width + text_width;
	ld	iy, #_text_width
	ld	l, 0 (iy)
	ld	h, #0x00
	add	hl, hl
	add	hl, de
;phoenixBoot.c:215: vdpmemcpy(pos, "9 EXIT MENU", 11);
	ld	bc, #___str_5+0
	ld	de, #0x000b
	push	de
	push	bc
	push	hl
	call	_vdpmemcpyfast
	pop	af
	pop	af
	pop	af
00137$:
;phoenixBoot.c:218: waitVblanks(1);
	ld	a, #0x01
	push	af
	inc	sp
	call	_waitVblanks
	inc	sp
;phoenixBoot.c:219: vdpmemcpy(onoff, useFlicker? "ON ":"OFF", 3);
	ld	a,(#_useFlicker + 0)
	or	a, a
	jr	Z,00141$
	ld	-5 (ix), #<(___str_6)
	ld	-4 (ix), #>(___str_6)
	jr	00142$
00141$:
	ld	-5 (ix), #<(___str_7)
	ld	-4 (ix), #>(___str_7)
00142$:
	ld	c, -5 (ix)
	ld	b, -4 (ix)
	ld	hl, #0x0003
	push	hl
	push	bc
	ld	l, -9 (ix)
	ld	h, -8 (ix)
	push	hl
	call	_vdpmemcpyfast
	pop	af
	pop	af
	pop	af
;phoenixBoot.c:220: vdpmemcpy(mempat, usePattern?"FF":"00", 2);
	ld	a,(#_usePattern + 0)
	or	a, a
	jr	Z,00143$
	ld	bc, #___str_8
	jr	00144$
00143$:
	ld	bc, #___str_9
00144$:
	ld	hl, #0x0002
	push	hl
	push	bc
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	push	hl
	call	_vdpmemcpyfast
	pop	af
	pop	af
	pop	af
;phoenixBoot.c:222: if (de1) --de1;
	ld	a, -3 (ix)
	or	a, a
	jr	Z,00105$
	dec	-3 (ix)
00105$:
;phoenixBoot.c:223: if (de2) --de2;
	ld	a, -2 (ix)
	or	a, a
	jr	Z,00107$
	dec	-2 (ix)
00107$:
;phoenixBoot.c:224: if (de3) --de3;
	ld	a, -1 (ix)
	or	a, a
	jr	Z,00109$
	dec	-1 (ix)
00109$:
;phoenixBoot.c:226: readkeypad();
	call	_readkeypad
;phoenixBoot.c:227: if (MY_KEY != lastkey) {
	ld	iy, #_MY_KEY
	ld	a, 0 (iy)
	sub	a, -10 (ix)
	jp	Z,00137$
;phoenixBoot.c:228: lastkey = MY_KEY;
	ld	a, 0 (iy)
;phoenixBoot.c:230: if (lastkey == '9') {
	ld	-10 (ix), a
	sub	a, #0x39
	jr	Z,00132$
;phoenixBoot.c:232: } else if (lastkey == '1') {
	ld	a, -10 (ix)
	sub	a, #0x31
	jr	NZ,00125$
;phoenixBoot.c:233: if (de1 == 0) {
	ld	a, -3 (ix)
	or	a, a
	jp	NZ, 00137$
;phoenixBoot.c:235: useScanlines ^= SCANLINES_ON;
	ld	iy, #_useScanlines
	ld	a, 0 (iy)
	xor	a, #0x04
	ld	0 (iy), a
;phoenixBoot.c:236: VDP_SET_REGISTER(0x32, useScanlines);
	ld	a, 0 (iy)
	out	(_VDPWA), a
;../libti99coleco/vdp.h:72: inline void VDP_SET_REGISTER(unsigned char r, unsigned char v)		{	VDPWA=(v); VDPWA=(0x80|(r)); }
	ld	a, #0xb2
	out	(_VDPWA), a
;phoenixBoot.c:237: de1 = 15;
	ld	-3 (ix), #0x0f
	jp	00137$
00125$:
;phoenixBoot.c:239: } else if (lastkey == '2') {
	ld	a, -10 (ix)
	sub	a, #0x32
	jr	NZ,00122$
;phoenixBoot.c:240: if (de2 == 0) {
	ld	a, -2 (ix)
	or	a, a
	jp	NZ, 00137$
;phoenixBoot.c:242: useFlicker = !useFlicker;
	ld	a,(#_useFlicker + 0)
	sub	a,#0x01
	ld	a, #0x00
	rla
	ld	(_useFlicker+0), a
;phoenixBoot.c:243: de2 = 15;
	ld	-2 (ix), #0x0f
	jp	00137$
00122$:
;phoenixBoot.c:245: } else if (lastkey == '3') {
	ld	a, -10 (ix)
	sub	a, #0x33
	jr	NZ,00119$
;phoenixBoot.c:246: if (de3 == 0) {
	ld	a, -1 (ix)
	or	a, a
	jp	NZ, 00137$
;phoenixBoot.c:248: usePattern = !usePattern;
	ld	a,(#_usePattern + 0)
	sub	a,#0x01
	ld	a, #0x00
	rla
	ld	(_usePattern+0), a
;phoenixBoot.c:249: de3 = 15;
	ld	-1 (ix), #0x0f
	jp	00137$
00119$:
;phoenixBoot.c:251: } else if (lastkey == '0') {
	ld	a, -10 (ix)
	sub	a, #0x30
	jp	NZ,00137$
;phoenixBoot.c:253: pf();
	call	0x0000
	jp	00137$
00132$:
;phoenixBoot.c:262: if (text_width == 32) {
	ld	a,(#_text_width + 0)
	sub	a, #0x20
	jr	NZ,00134$
;phoenixBoot.c:263: vdpmemset(GIMAGE+8*32, 0x18, 16*32);		// clear it
	ld	hl, #0x0200
	push	hl
	ld	a, #0x18
	push	af
	inc	sp
	ld	h, #0x01
	push	hl
	call	_vdpmemset
	pop	af
;phoenixBoot.c:264: unrle(GPATTERN, PAT0, SIZE_OF_PAT0RLE);		// reload character set
	inc	sp
	ld	hl,#0x0513
	ex	(sp),hl
	ld	hl, #_PAT0
	push	hl
	ld	hl, #0x0800
	push	hl
	call	_unrle
	pop	af
	pop	af
;phoenixBoot.c:265: vdpmemcpy(GIMAGE+8*32, lineBuffer, 16*32);	// restore display
	ld	hl, #0x0200
	ex	(sp),hl
	ld	hl, #_lineBuffer
	push	hl
	ld	hl, #0x0100
	push	hl
	call	_vdpmemcpyfast
	pop	af
	pop	af
	pop	af
	jr	00139$
00134$:
;phoenixBoot.c:267: vdpmemcpy(GIMAGE+8*40, lineBuffer, 9*40);	// restore display
	ld	hl, #0x0168
	push	hl
	ld	hl, #_lineBuffer
	push	hl
	ld	hl, #0x0140
	push	hl
	call	_vdpmemcpyfast
	pop	af
	pop	af
	pop	af
00139$:
;phoenixBoot.c:269: }
	ld	sp, ix
	pop	ix
	ret
___str_0:
	.ascii "PRESS:"
	.db 0x00
___str_1:
	.ascii "1 TOGGLE SCANLINES"
	.db 0x00
___str_2:
	.ascii "2 TOGGLE FLICKER (OFF)"
	.db 0x00
___str_3:
	.ascii "3 DRAM PATTERN (0000)"
	.db 0x00
___str_4:
	.ascii "0 SOFT RESET"
	.db 0x00
___str_5:
	.ascii "9 EXIT MENU"
	.db 0x00
___str_6:
	.ascii "ON "
	.db 0x00
___str_7:
	.ascii "OFF"
	.db 0x00
___str_8:
	.ascii "FF"
	.db 0x00
___str_9:
	.ascii "00"
	.db 0x00
;phoenixBoot.c:274: void readkeypad() {
;	---------------------------------
; Function readkeypad
; ---------------------------------
_readkeypad::
;phoenixBoot.c:278: readinputs(1);
	ld	a, #0x01
	push	af
	inc	sp
	call	_readinputs
	inc	sp
;phoenixBoot.c:279: if ((MY_KEY == 0xff)&&(MY_JOYX==0)&&(MY_JOYY==0)) {
	ld	a,(#_MY_KEY + 0)
	inc	a
	jr	NZ,00102$
	ld	a,(#_MY_JOYX + 0)
	or	a, a
	jr	NZ,00102$
	ld	a,(#_MY_JOYY + 0)
	or	a, a
	jr	NZ,00102$
;phoenixBoot.c:281: readinputs(2);
	ld	a, #0x02
	push	af
	inc	sp
	call	_readinputs
	inc	sp
00102$:
;phoenixBoot.c:285: if ((!inCfg) && (lastret != MY_KEY)) {
	ld	a,(#_readkeypad_inCfg_65536_108 + 0)
	or	a, a
	ret	NZ
	ld	a,(#_readkeypad_lastret_65536_108 + 0)
	ld	iy, #_MY_KEY
	sub	a, 0 (iy)
	ret	Z
;phoenixBoot.c:286: lastret = MY_KEY;
	ld	a, 0 (iy)
	ld	iy, #_readkeypad_lastret_65536_108
	ld	0 (iy), a
;phoenixBoot.c:287: if ((MY_KEY == '*')||(MY_KEY == '#')) {
	ld	iy, #_MY_KEY
	ld	a, 0 (iy)
	sub	a, #0x2a
	jr	Z,00110$
	ld	a, 0 (iy)
	sub	a, #0x23
	jr	NZ,00111$
00110$:
;phoenixBoot.c:288: inCfg = 1;
	ld	hl,#_readkeypad_inCfg_65536_108 + 0
	ld	(hl), #0x01
;phoenixBoot.c:289: cfgMenu();
	call	_cfgMenu
;phoenixBoot.c:290: inCfg = 0;
	ld	hl,#_readkeypad_inCfg_65536_108 + 0
	ld	(hl), #0x00
	ret
00111$:
;phoenixBoot.c:291: } else if (MY_KEY == '0') {
	ld	iy, #_MY_KEY
	ld	a, 0 (iy)
	sub	a, #0x30
	jp	Z,_inc_palette
	jr	00108$
;phoenixBoot.c:293: inc_palette();
	jp	_inc_palette
00108$:
;phoenixBoot.c:294: } else if (MY_KEY == '1') {
	ld	a,(#_MY_KEY + 0)
	sub	a, #0x31
	ret	NZ
;phoenixBoot.c:296: showExt = ! showExt;
	ld	a,(#_showExt + 0)
	sub	a,#0x01
	ld	a, #0x00
	rla
	ld	(_showExt+0), a
;phoenixBoot.c:298: MY_JOYX = 0x80;
	ld	hl,#_MY_JOYX + 0
	ld	(hl), #0x80
;phoenixBoot.c:301: }
	ret
;phoenixBoot.c:306: void textout(unsigned int vdp, const char *p) {
;	---------------------------------
; Function textout
; ---------------------------------
_textout::
	call	___sdcc_enter_ix
	push	af
;phoenixBoot.c:307: while (*p) {
	ld	c, 6 (ix)
	ld	b, 7 (ix)
	ld	e, 4 (ix)
	ld	d, 5 (ix)
00101$:
	ld	a, (bc)
	or	a, a
	jr	Z,00104$
;phoenixBoot.c:308: unsigned char c = (*(p++))-' '+3;
	inc	bc
	add	a, #0xe3
;phoenixBoot.c:309: unsigned int off = c*8;
	ld	l, a
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	add	hl, hl
;phoenixBoot.c:310: vdpmemcpy(vdp, &FATFONT[off], 8);
	push	de
	ld	de, #_FATFONT
	add	hl, de
	pop	de
	inc	sp
	inc	sp
	push	hl
	push	bc
	push	de
	ld	hl, #0x0008
	push	hl
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	push	hl
	push	de
	call	_vdpmemcpyfast
	pop	af
	pop	af
	pop	af
	pop	de
	pop	bc
;phoenixBoot.c:311: vdp+=16;
	ld	hl, #0x0010
	add	hl, de
	ex	de, hl
	jr	00101$
00104$:
;phoenixBoot.c:313: }
	pop	af
	pop	ix
	ret
;phoenixBoot.c:317: void displayLogo() {
;	---------------------------------
; Function displayLogo
; ---------------------------------
_displayLogo::
	call	___sdcc_enter_ix
	push	af
;phoenixBoot.c:325: vdpmemset(GCOLOR+3, 0xf0, 10);
	ld	hl, #0x000a
	push	hl
	ld	a, #0xf0
	push	af
	inc	sp
	ld	hl, #0x1003
	push	hl
	call	_vdpmemset
	pop	af
;phoenixBoot.c:328: vdpmemset(GCOLOR+13, COLOR_DKRED<<4, 19);
	inc	sp
	ld	hl,#0x0013
	ex	(sp),hl
	ld	a, #0x60
	push	af
	inc	sp
	ld	hl, #0x100d
	push	hl
	call	_vdpmemset
	pop	af
	pop	af
	inc	sp
;phoenixBoot.c:335: p = MD0_LOGO;
	ld	bc, #_MD0_LOGO+0
;phoenixBoot.c:336: for (idx = 16; idx > 0; --idx) {
	ld	-1 (ix), #0x10
00102$:
;phoenixBoot.c:339: off = (idx-1)*32+(*(p++));
	ld	l, -1 (ix)
	ld	h, #0x00
	dec	hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ex	de,hl
	ld	a, (bc)
	inc	bc
	ld	l, a
	ld	h, #0x00
	add	hl, de
	ex	de, hl
;phoenixBoot.c:340: len = *(p++);
	ld	a, (bc)
	ld	-2 (ix), a
	inc	bc
;phoenixBoot.c:341: vdpmemcpy(GIMAGE+off, p, len);
	ld	l, -2 (ix)
	ld	h, #0x00
	push	bc
	push	hl
	push	bc
	push	de
	call	_vdpmemcpyfast
	pop	af
	pop	af
	pop	af
	pop	bc
;phoenixBoot.c:342: p+=len;
	ld	a, c
	add	a, -2 (ix)
	ld	c, a
	jr	NC,00119$
	inc	b
00119$:
;phoenixBoot.c:336: for (idx = 16; idx > 0; --idx) {
	dec	-1 (ix)
	ld	a, -1 (ix)
	or	a, a
	jr	NZ,00102$
;phoenixBoot.c:346: vdpmemcpy(GIMAGE+(18*32), MD0_PHOENIX, 4*32);
	ld	hl, #0x0080
	push	hl
	ld	hl, #_MD0_PHOENIX
	push	hl
	ld	hl, #0x0240
	push	hl
	call	_vdpmemcpyfast
	pop	af
	pop	af
	pop	af
;phoenixBoot.c:347: }
	pop	af
	pop	ix
	ret
;phoenixBoot.c:353: void centerString(unsigned char line, char *p) {
;	---------------------------------
; Function centerString
; ---------------------------------
_centerString::
	call	___sdcc_enter_ix
	push	af
;phoenixBoot.c:354: unsigned int vdp = GSPRITEPAT + (line*8);
	ld	l, 4 (ix)
	ld	h, #0x00
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	-2 (ix), l
	ld	a, h
	add	a, #0x18
	ld	-1 (ix), a
;phoenixBoot.c:356: char *pp = p;
	ld	c, 5 (ix)
	ld	b, 6 (ix)
;phoenixBoot.c:358: while (*pp) {
	ld	e, c
	ld	d, b
00103$:
	ld	a, (de)
	or	a, a
	jr	Z,00105$
;phoenixBoot.c:359: ++pp;
	inc	de
;phoenixBoot.c:360: if (pp - p > 31) {
	ld	a,e
	ld	c,a
	sub	a, 5 (ix)
	ld	l, a
	ld	a, d
	sbc	a, 6 (ix)
	ld	h, a
	ld	a, #0x1f
	cp	a, l
	ld	a, #0x00
	sbc	a, h
	jp	PO, 00129$
	xor	a, #0x80
00129$:
	jp	P, 00103$
;phoenixBoot.c:361: *pp='\0';
	xor	a, a
	ld	(de), a
;phoenixBoot.c:362: break;
00105$:
;phoenixBoot.c:365: len = pp-p;
	ld	a, c
	ld	c, 5 (ix)
	sub	a, c
;phoenixBoot.c:366: vdp += (16-(len/2))*16;
	ld	c, a
	ld	b, #0x00
	ld	e, c
	ld	d, b
	bit	7, b
	jr	Z,00108$
	ld	e, c
	ld	d, b
	inc	de
00108$:
	sra	d
	rr	e
	ld	hl, #0x0010
	cp	a, a
	sbc	hl, de
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	pop	de
	push	de
	add	hl, de
;phoenixBoot.c:369: textout(vdp, p);
	ld	c, 5 (ix)
	ld	b, 6 (ix)
	push	bc
	push	hl
	call	_textout
	pop	af
	pop	af
;phoenixBoot.c:370: }
	pop	af
	pop	ix
	ret
;phoenixBoot.c:377: void startTitle() {
;	---------------------------------
; Function startTitle
; ---------------------------------
_startTitle::
	call	___sdcc_enter_ix
	dec	sp
;phoenixBoot.c:385: useScanlines &= SCANLINES_ON;  // turn off every bit except scanline selection
	ld	a,(#_useScanlines + 0)
	and	a, #0x04
	ld	(_useScanlines+0), a
;phoenixBoot.c:386: prepare_f18a();   // also locks
	call	_prepare_f18a
;phoenixBoot.c:394: if (usePattern) {
	ld	a,(#_usePattern + 0)
	or	a, a
	jr	Z,00126$
;phoenixBoot.c:395: for (idx=0x6000; idx<0x6400; idx+=2) {
	ld	bc, #0x6000
00117$:
;phoenixBoot.c:396: *((volatile unsigned int*)(idx)) = 0x00ff;
	ld	l, c
	ld	h, b
	ld	(hl), #0xff
	inc	hl
	ld	(hl), #0x00
;phoenixBoot.c:395: for (idx=0x6000; idx<0x6400; idx+=2) {
	inc	bc
	inc	bc
	ld	a, b
	sub	a, #0x64
	jr	C,00117$
	jr	00105$
;phoenixBoot.c:400: for (idx=0x6000; idx<0x6400; idx+=2) {
00126$:
	ld	bc, #0x6000
00119$:
;phoenixBoot.c:401: *((volatile unsigned int*)(idx)) = 0x0;
	ld	e, c
	ld	d, b
	xor	a, a
	ld	(de), a
	inc	de
	ld	(de), a
;phoenixBoot.c:400: for (idx=0x6000; idx<0x6400; idx+=2) {
	inc	bc
	inc	bc
	ld	a, b
	sub	a, #0x64
	jr	C,00119$
00105$:
;phoenixBoot.c:408: if (pRom(0x8000) == 0xaa) {
	ld	a, (#0x8000)
	sub	a, #0xaa
	jp	NZ,00109$
;phoenixBoot.c:415: pRom(0x63c8) = 0x33;
	ld	hl, #0x63c8
	ld	(hl), #0x33
;phoenixBoot.c:420: port3 = 0xff;
	ld	a, #0xff
	out	(_port3), a
;phoenixBoot.c:442: unsigned char *pDst = (unsigned char*)(((*((volatile unsigned int*)0x8008)) + 2)&0xEFFF);
	ld	hl, #0x8008
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	inc	bc
	inc	bc
	res	4, b
	ld	e, c
;phoenixBoot.c:443: if (pDst) memset(pDst, 0, 10);
	ld	a,b
	ld	d,a
	or	a, c
	jr	Z,00107$
	ld	hl, #0x000a
	push	hl
	ld	l, #0x00
	push	hl
	push	de
	call	_memset
	pop	af
	pop	af
	pop	af
00107$:
;phoenixBoot.c:444: memset((void*)0x6307, 0, 20);
	ld	hl, #0x0014
	push	hl
	ld	l, #0x00
	push	hl
	ld	hl, #0x6307
	push	hl
	call	_memset
	pop	af
	pop	af
	pop	af
;phoenixBoot.c:455: memset((void*)0x63eb, 0, 6);
	ld	hl, #0x0006
	push	hl
	ld	l, #0x00
	push	hl
	ld	hl, #0x63eb
	push	hl
	call	_memset
	pop	af
	pop	af
	pop	af
;phoenixBoot.c:460: pRom(0x63c6) = 0;
	ld	hl, #0x63c6
	ld	(hl), #0x00
;phoenixBoot.c:464: pRom(0x63c7) = 0;
	ld	l, #0xc7
	ld	(hl), #0x00
;phoenixBoot.c:483: vdpmemset(0, 0, 16384);
	ld	hl, #0x4000
	push	hl
	xor	a, a
	push	af
	inc	sp
	ld	h, #0x00
	push	hl
	call	_vdpmemset
	pop	af
	pop	af
	inc	sp
;phoenixBoot.c:490: volatile unsigned char x = VDPST;
	in	a, (_VDPST)
	ld	-1 (ix), a
;../libti99coleco/vdp.h:72: inline void VDP_SET_REGISTER(unsigned char r, unsigned char v)		{	VDPWA=(v); VDPWA=(0x80|(r)); }
	ld	a, #0x00
	out	(_VDPWA), a
	ld	a, #0x80
	out	(_VDPWA), a
;phoenixBoot.c:517: pRom(0x63c3) = 0;
	ld	hl, #0x63c3
	ld	(hl), #0x00
;../libti99coleco/vdp.h:72: inline void VDP_SET_REGISTER(unsigned char r, unsigned char v)		{	VDPWA=(v); VDPWA=(0x80|(r)); }
	ld	a, #0x80
	out	(_VDPWA), a
	ld	a, #0x81
	out	(_VDPWA), a
;phoenixBoot.c:523: pRom(0x63c4) = 0x80;
	ld	l, #0xc4
	ld	(hl), #0x80
;../libti99coleco/vdp.h:72: inline void VDP_SET_REGISTER(unsigned char r, unsigned char v)		{	VDPWA=(v); VDPWA=(0x80|(r)); }
	ld	a, #0x06
	out	(_VDPWA), a
	ld	a, #0x82
	out	(_VDPWA), a
	ld	a, #0x80
	out	(_VDPWA), a
	ld	a, #0x83
	out	(_VDPWA), a
	ld	a, #0x00
	out	(_VDPWA), a
	ld	a, #0x84
	out	(_VDPWA), a
	ld	a, #0x36
	out	(_VDPWA), a
	ld	a, #0x85
	out	(_VDPWA), a
	ld	a, #0x07
	out	(_VDPWA), a
	ld	a, #0x86
	out	(_VDPWA), a
;phoenixBoot.c:620: memcpy((unsigned char*)0x63f2, regTable, 10);
	ld	hl, #0x000a
	push	hl
	ld	hl, #_regTable
	push	hl
	ld	hl, #0x63f2
	push	hl
	call	_memcpy
	pop	af
	pop	af
;phoenixBoot.c:636: vdpmemcpy(0x0000+0x1d*8, (void*)FATFONT, 96*8);
	ld	hl, #0x0300
	ex	(sp),hl
	ld	hl, #_FATFONT
	push	hl
	ld	hl, #0x00e8
	push	hl
	call	_vdpmemcpyfast
	pop	af
	pop	af
;phoenixBoot.c:644: vdpmemcpy(0x0000, (void*)(FATFONT+3*8), 8);      // space is after copyright, T, and M
	ld	hl, #0x0008
	ex	(sp),hl
	ld	hl, #(_FATFONT + 0x0018)
	push	hl
	ld	hl, #0x0000
	push	hl
	call	_vdpmemcpyfast
	pop	af
	pop	af
;phoenixBoot.c:648: vdpmemcpy(0x2003, colorTable, sizeof(colorTable));
	ld	hl, #0x000f
	ex	(sp),hl
	ld	hl, #_colorTable
	push	hl
	ld	hl, #0x2003
	push	hl
	call	_vdpmemcpyfast
	pop	af
	pop	af
	pop	af
00109$:
;phoenixBoot.c:664: memcpy((void*)0x6000, trampoline, sizeof(trampoline));
	ld	hl, #0x0009
	push	hl
	ld	hl, #_trampoline
	push	hl
	ld	hl, #0x6000
	push	hl
	call	_memcpy
	pop	af
	pop	af
	pop	af
;phoenixBoot.c:665: ((void(*)())0x6000)();
	call	0x6000
;phoenixBoot.c:666: }
	inc	sp
	pop	ix
	ret
;phoenixBoot.c:669: void startCartridge() {
;	---------------------------------
; Function startCartridge
; ---------------------------------
_startCartridge::
;phoenixBoot.c:671: phBankingScheme = PH_BANK_CART | PH_UPPER_CART;
	ld	a, #0x30
	out	(_phBankingScheme), a
;phoenixBoot.c:674: startTitle();
;phoenixBoot.c:675: }
	jp	_startTitle
;phoenixBoot.c:679: void runCartHeader() {
;	---------------------------------
; Function runCartHeader
; ---------------------------------
_runCartHeader::
	call	___sdcc_enter_ix
	push	af
	push	af
;phoenixBoot.c:696: unsigned char *o = copyright;
;phoenixBoot.c:697: const unsigned char *sk = "PRESENTS";
;phoenixBoot.c:703: readkeypad();   // read joystick fire buttons
	call	_readkeypad
;phoenixBoot.c:704: if (MY_KEY == JOY_FIRE) {     
	ld	a,(#_MY_KEY + 0)
	sub	a, #0x12
	jr	NZ,00102$
;phoenixBoot.c:705: startCartridge();      // never returns
	call	_startCartridge
00102$:
;phoenixBoot.c:709: memset(copyright, 0, sizeof(copyright));
	ld	hl, #0x0041
	push	hl
	ld	l, #0x00
	push	hl
	ld	hl, #_copyright
	push	hl
	call	_memset
	pop	af
	pop	af
	pop	af
;phoenixBoot.c:715: while ((*p != '/')&&(--cntdown > 0)) ++p;
	ld	e, #0x20
	ld	bc, #0x8024
00104$:
	ld	a, (bc)
	sub	a, #0x2f
	jr	Z,00221$
	dec	e
	jr	Z,00221$
	inc	bc
	jr	00104$
00221$:
;phoenixBoot.c:716: if (cntdown == 0) {
	ld	a, e
	or	a, a
	jr	NZ,00108$
;phoenixBoot.c:718: startCartridge();   // never returns
	push	bc
	call	_startCartridge
	pop	bc
00108$:
;phoenixBoot.c:720: ++p;
	inc	bc
;phoenixBoot.c:723: while ((*p == ' ')&&(--cntdown > 0)) {
	ld	e, #0x20
00110$:
	ld	a, (bc)
	sub	a, #0x20
	jr	NZ,00184$
	dec	e
	jr	Z,00184$
;phoenixBoot.c:724: ++p;
	inc	bc
	jr	00110$
;phoenixBoot.c:728: while ((*sk)&&(*sk == *p)) { ++p; ++sk; }
00184$:
	ld	de, #___str_10
00114$:
	ld	a, (de)
	ld	-2 (ix), a
	or	a, a
	jr	Z,00116$
	ld	a, (bc)
	ld	-1 (ix), a
	ld	a, -2 (ix)
	sub	a, -1 (ix)
	jr	NZ,00116$
	inc	bc
	inc	de
	jr	00114$
00116$:
;phoenixBoot.c:732: while ((*p == ' ')&&(--cntdown > 0)) {
	ld	e, #0x20
00118$:
	ld	a, (bc)
	sub	a, #0x20
	jr	NZ,00120$
	dec	e
	jr	Z,00120$
;phoenixBoot.c:733: ++p;
	inc	bc
	jr	00118$
00120$:
;phoenixBoot.c:738: while ((*p != '/')&&(--cntdown > 0)) {
	ld	-3 (ix), #0x20
	ld	de, #_copyright
00122$:
	ld	a, (bc)
	ld	l, a
;phoenixBoot.c:739: *(o++) = *(p++);
	ld	a, e
	add	a, #0x01
	ld	-2 (ix), a
	ld	a, d
	adc	a, #0x00
	ld	-1 (ix), a
;phoenixBoot.c:738: while ((*p != '/')&&(--cntdown > 0)) {
	ld	a, l
	sub	a, #0x2f
	jr	Z,00124$
	dec	-3 (ix)
	ld	a, -3 (ix)
	or	a, a
	jr	Z,00124$
;phoenixBoot.c:739: *(o++) = *(p++);
	ld	a, l
	inc	bc
	ld	(de), a
	ld	e, -2 (ix)
	ld	d, -1 (ix)
	jr	00122$
00124$:
;phoenixBoot.c:742: pYr = p;
	inc	sp
	inc	sp
	push	bc
;phoenixBoot.c:745: *(o++)=' ';
	ld	a, #0x20
	ld	(de), a
;phoenixBoot.c:752: while ((*p == ' ')&&(--cntdown > 0)) {
	ld	c, #0x20
	ld	de, #0x8024
00126$:
	ld	a, (de)
	sub	a, #0x20
	jr	NZ,00128$
	dec	c
	jr	Z,00128$
;phoenixBoot.c:753: ++p;
	inc	de
	jr	00126$
00128$:
;phoenixBoot.c:758: cntdown = 63-(o-copyright)-6;
	ld	a, -2 (ix)
	ld	c, #<(_copyright)
	sub	a, c
	ld	c, a
	ld	a, #0x39
	sub	a, c
	ld	c, a
;phoenixBoot.c:761: while ((*p != '/')&&(--cntdown > 0)) {
00130$:
	ld	a, (de)
	ld	b, a
	sub	a, #0x2f
	jr	Z,00227$
	dec	c
	jr	Z,00227$
;phoenixBoot.c:762: *(o++) = *(p++);
	inc	de
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	(hl), b
	inc	-2 (ix)
	jr	NZ,00130$
	inc	-1 (ix)
	jr	00130$
00227$:
	pop	de
	pop	bc
	push	bc
	push	de
;phoenixBoot.c:768: while ((*pYr != '/')&&(--cntdown > 0)) {
	ld	-1 (ix), #0x20
	pop	de
	push	de
00134$:
	ld	a, (de)
;phoenixBoot.c:769: ++pYr;
	inc	de
;phoenixBoot.c:768: while ((*pYr != '/')&&(--cntdown > 0)) {
	sub	a, #0x2f
	ld	a, #0x01
	jr	Z,00437$
	xor	a, a
00437$:
	ld	l, a
	bit	0, l
	jr	NZ,00136$
	dec	-1 (ix)
	ld	a, -1 (ix)
	or	a, a
;phoenixBoot.c:769: ++pYr;
	jr	NZ,00134$
00136$:
;phoenixBoot.c:771: if (*pYr == '/') {
	ld	a, l
	or	a, a
	jr	Z,00202$
;phoenixBoot.c:773: ++pYr;
;phoenixBoot.c:775: *(o++) = ' ';
	ld	a, #0x20
	ld	(bc), a
	inc	bc
;phoenixBoot.c:776: *(o++) = 0x1d;  // (C)
	ld	a, #0x1d
	ld	(bc), a
	inc	bc
;phoenixBoot.c:777: *(o++) = *(pYr++);
	ld	a, (de)
	inc	de
	ld	(bc), a
	inc	bc
;phoenixBoot.c:778: *(o++) = *(pYr++);
	ld	a, (de)
	inc	de
	ld	(bc), a
	inc	bc
;phoenixBoot.c:779: *(o++) = *(pYr++);
	ld	a, (de)
	inc	de
	ld	(bc), a
	inc	bc
;phoenixBoot.c:780: *(o++) = *(pYr++);
	ld	a, (de)
	ld	(bc), a
	inc	bc
;phoenixBoot.c:781: *(o) = '\0';        // total max of 63 printable, 64 bytes
	xor	a, a
	ld	(bc), a
;phoenixBoot.c:786: while (--o >= copyright) {
00202$:
00141$:
	dec	bc
	ld	e, c
	ld	d, b
	ld	a, e
	sub	a, #<(_copyright)
	ld	a, d
	sbc	a, #>(_copyright)
	jr	C,00143$
;phoenixBoot.c:787: if (*o == 0) *o=' ';
	ld	a, (bc)
	or	a, a
	jr	NZ,00141$
	ld	a, #0x20
	ld	(bc), a
	jr	00141$
00143$:
;phoenixBoot.c:791: copyright[64]='\0';
	ld	hl, #(_copyright + 0x0040)
	ld	(hl), #0x00
;phoenixBoot.c:794: while (copyright[0] == ' ') {
00144$:
	ld	a, (#_copyright + 0)
	sub	a, #0x20
	jr	NZ,00146$
;phoenixBoot.c:795: memmove(copyright, copyright+1, sizeof(copyright)-1);
	ld	hl, #0x0040
	push	hl
	ld	hl, #(_copyright + 0x0001)
	push	hl
	ld	hl, #_copyright
	push	hl
	call	_memmove
	pop	af
	pop	af
	pop	af
	jr	00144$
00146$:
;phoenixBoot.c:799: p = copyright;
	ld	bc, #_copyright
;phoenixBoot.c:800: while (*p) {
00151$:
	ld	a, (bc)
	or	a, a
	jr	Z,00153$
;phoenixBoot.c:801: if ((*p == ' ') && (*(p+1) == ' ')) {
	ld	e, c
	ld	d, b
	inc	de
	sub	a, #0x20
	jr	NZ,00148$
	ld	a, (de)
	sub	a, #0x20
	jr	NZ,00148$
;phoenixBoot.c:802: memmove(p, p+1, sizeof(copyright)-(p-copyright)-1);
	ld	a, c
	sub	a, #<(_copyright)
	ld	l, a
	ld	a, b
	sbc	a, #>(_copyright)
	ld	h, a
	ld	a, #0x40
	sub	a, l
	ld	l, a
	ld	a, #0x00
	sbc	a, h
	ld	h, a
	ld	-2 (ix), c
	ld	-1 (ix), b
	push	bc
	push	hl
	push	de
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	push	hl
	call	_memmove
	pop	af
	pop	af
	pop	af
	pop	bc
	jr	00151$
00148$:
;phoenixBoot.c:804: ++p;
	ld	c, e
	ld	b, d
	jr	00151$
00153$:
;phoenixBoot.c:809: p = copyright + sizeof(copyright) - 1;
	ld	de, #(_copyright + 0x0040)
;phoenixBoot.c:810: while ((p >= copyright) && (*p == '\0')) {
00155$:
	ld	c, e
	ld	b, d
	ld	a, c
	sub	a, #<(_copyright)
	ld	a, b
	sbc	a, #>(_copyright)
	jr	C,00157$
	ld	a, (de)
	or	a, a
	jr	NZ,00157$
;phoenixBoot.c:811: --p;
	dec	de
	jr	00155$
00157$:
;phoenixBoot.c:815: if (p-copyright > 31) {
	ld	a, e
	sub	a, #<(_copyright)
	ld	c, a
	ld	a, d
	sbc	a, #>(_copyright)
	ld	b, a
	ld	a, #0x1f
	cp	a, c
	ld	a, #0x00
	sbc	a, b
	jp	PO, 00444$
	xor	a, #0x80
00444$:
	jp	P, 00165$
;phoenixBoot.c:817: p = copyright+30;
	ld	de, #_copyright + 30
;phoenixBoot.c:818: while ((p > copyright) && (*p != ' ')) {
00159$:
	ld	c, e
	ld	b, d
	ld	a, (de)
	sub	a, #0x20
	ld	a, #0x01
	jr	Z,00446$
	xor	a, a
00446$:
	ld	l, a
	ld	a, #<(_copyright)
	sub	a, c
	ld	a, #>(_copyright)
	sbc	a, b
	jr	NC,00161$
	bit	0, l
	jr	NZ,00161$
;phoenixBoot.c:819: --p;
	dec	de
	jr	00159$
00161$:
;phoenixBoot.c:823: if (*p == ' ') {
	ld	a, l
	or	a, a
	jr	Z,00220$
;phoenixBoot.c:824: *p = '\0';
	xor	a, a
	ld	(de), a
;phoenixBoot.c:825: centerString(0, copyright);
	push	de
	ld	hl, #_copyright
	push	hl
	xor	a, a
	push	af
	inc	sp
	call	_centerString
	pop	af
	inc	sp
	pop	de
;phoenixBoot.c:826: ++p;
	inc	de
;phoenixBoot.c:827: centerString(1, p);
	push	de
	ld	a, #0x01
	push	af
	inc	sp
	call	_centerString
	pop	af
	inc	sp
	jr	00220$
00165$:
;phoenixBoot.c:831: centerString(1, copyright);
	ld	hl, #_copyright
	push	hl
	ld	a, #0x01
	push	af
	inc	sp
	call	_centerString
	pop	af
	inc	sp
;phoenixBoot.c:836: while (cntdown-- > 0) {
00220$:
	ld	c, #0xff
00169$:
	ld	a, c
	dec	c
	or	a, a
	jr	Z,00171$
;phoenixBoot.c:837: readkeypad();   // read joystick fire buttons
	push	bc
	call	_readkeypad
	pop	bc
;phoenixBoot.c:838: if (MY_KEY == JOY_FIRE) break;
	ld	a,(#_MY_KEY + 0)
	sub	a, #0x12
	jr	Z,00171$
;phoenixBoot.c:839: waitVblanks(1);
	push	bc
	ld	a, #0x01
	push	af
	inc	sp
	call	_waitVblanks
	inc	sp
	pop	bc
	jr	00169$
00171$:
;phoenixBoot.c:843: startCartridge();
	call	_startCartridge
;phoenixBoot.c:844: }
	ld	sp, ix
	pop	ix
	ret
___str_10:
	.ascii "PRESENTS"
	.db 0x00
;phoenixBoot.c:852: void main() {
;	---------------------------------
; Function main
; ---------------------------------
_main::
	dec	sp
;phoenixBoot.c:856: VDP_INT_DISABLE;
	push	hl
	ld	hl,#_vdpLimi
	res	0,(hl)
	pop	hl
;phoenixBoot.c:859: vdpmemset(0, 0, 16384);
	ld	hl, #0x4000
	push	hl
	xor	a, a
	push	af
	inc	sp
	ld	h, #0x00
	push	hl
	call	_vdpmemset
	pop	af
	pop	af
	inc	sp
;phoenixBoot.c:865: for (x=0; x<16; ++x) {
	ld	c, #0x00
00112$:
;phoenixBoot.c:866: AY_REGISTER=x;
	ld	a, c
	out	(_AY_REGISTER), a
;phoenixBoot.c:867: AY_DATA_WRITE=0;
	ld	a, #0x00
	out	(_AY_DATA_WRITE), a
;phoenixBoot.c:865: for (x=0; x<16; ++x) {
	inc	c
	ld	a, c
	sub	a, #0x10
	jr	C,00112$
;phoenixBoot.c:873: reset_f18a();
	call	_reset_f18a
;phoenixBoot.c:874: unlock_f18a();
	call	_unlock_f18a
;../libti99coleco/vdp.h:72: inline void VDP_SET_REGISTER(unsigned char r, unsigned char v)		{	VDPWA=(v); VDPWA=(0x80|(r)); }
	ld	a, #0x20
	out	(_VDPWA), a
	ld	a, #0x9e
	out	(_VDPWA), a
;phoenixBoot.c:882: x = my_set_graphics(VDP_SPR_16x16);
	ld	a, #0x02
	push	af
	inc	sp
	call	_my_set_graphics
	inc	sp
	ld	iy, #0
	add	iy, sp
	ld	0 (iy), l
;../libti99coleco/vdp.h:65: inline void VDP_SET_ADDRESS_WRITE(unsigned int x)					{	VDPWA=((x)&0xff); VDPWA=(((x)>>8)|0x40); }
	ld	a, #0x00
	out	(_VDPWA), a
	ld	a, #0x07
	or	a, #0x40
	out	(_VDPWA), a
;phoenixBoot.c:893: for (idx=0; idx<16; ++idx) {
	ld	c, #0x00
00114$:
;phoenixBoot.c:895: VDPWD = (unsigned char)(22*8-1); // Y
	ld	a, #0xaf
	out	(_VDPWD), a
;phoenixBoot.c:896: VDPWD = idx*16; // X
	ld	a, c
	add	a, a
	add	a, a
	add	a, a
	add	a, a
	out	(_VDPWD), a
;phoenixBoot.c:897: VDPWD = idx*4;  // char
	ld	a, c
	add	a, a
	add	a, a
	out	(_VDPWD), a
;phoenixBoot.c:898: VDPWD = 15;     // color
	ld	a, #0x0f
	out	(_VDPWD), a
;phoenixBoot.c:893: for (idx=0; idx<16; ++idx) {
	inc	c
	ld	a, c
	sub	a, #0x10
	jr	C,00114$
;phoenixBoot.c:900: VDPWD = 0xd0;      // terminator
	ld	a, #0xd0
	out	(_VDPWD), a
;phoenixBoot.c:903: vdpmemset(GIMAGE, 0x18, 768);
	ld	hl, #0x0300
	push	hl
	ld	a, #0x18
	push	af
	inc	sp
	ld	h, #0x00
	push	hl
	call	_vdpmemset
	pop	af
;phoenixBoot.c:905: vdpmemset(GCOLOR, 0xF0, 32);
	inc	sp
	ld	hl,#0x0020
	ex	(sp),hl
	ld	a, #0xf0
	push	af
	inc	sp
	ld	hl, #0x1000
	push	hl
	call	_vdpmemset
	pop	af
;phoenixBoot.c:908: unrle(GPATTERN, PAT0, SIZE_OF_PAT0RLE);
	inc	sp
	ld	hl,#0x0513
	ex	(sp),hl
	ld	hl, #_PAT0
	push	hl
	ld	hl, #0x0800
	push	hl
	call	_unrle
	pop	af
	pop	af
	pop	af
;../libti99coleco/vdp.h:72: inline void VDP_SET_REGISTER(unsigned char r, unsigned char v)		{	VDPWA=(v); VDPWA=(0x80|(r)); }
	ld	hl, #0+0
	add	hl, sp
	ld	a, (hl)
	out	(_VDPWA), a
	ld	a, #0x81
	out	(_VDPWA), a
;phoenixBoot.c:914: waitVblanks(2);
	ld	a, #0x02
	push	af
	inc	sp
	call	_waitVblanks
	inc	sp
;phoenixBoot.c:919: if ((pRom(0x8000)==0x55)&&(pRom(0x8001)==0xaa)) {
	ld	a, (#0x8000)
	sub	a, #0x55
	jr	NZ,00104$
	ld	a, (#0x8001)
	sub	a, #0xaa
	jr	NZ,00104$
;phoenixBoot.c:921: readkeypad();
	call	_readkeypad
;phoenixBoot.c:923: startCartridge();
	call	_startCartridge
00104$:
;phoenixBoot.c:927: displayLogo();
	call	_displayLogo
;phoenixBoot.c:932: if ((pRom(0x8000)==0xaa)&&(pRom(0x8001)==0x55)) {
	ld	hl, #0x8000
	ld	a, (hl)
	sub	a, #0xaa
	jr	NZ,00107$
	ld	hl, #0x8001
	ld	a, (hl)
	sub	a, #0x55
	jr	NZ,00107$
;phoenixBoot.c:933: runCartHeader();    // never returns
	call	_runCartHeader
00107$:
;phoenixBoot.c:938: menu();
	inc	sp
	jp	_menu
;phoenixBoot.c:939: }
	inc	sp
	ret
	.area _CODE
	.area _INITIALIZER
__xinit__usePattern:
	.db #0x00	; 0
__xinit__useFlicker:
	.db #0x00	; 0
__xinit__text_width:
	.db #0x20	; 32
	.area _CABS (ABS)
