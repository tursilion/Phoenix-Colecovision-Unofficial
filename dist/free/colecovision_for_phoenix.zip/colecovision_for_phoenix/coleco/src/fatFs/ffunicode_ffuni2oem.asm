;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ffunicode_ffuni2oem
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ff_uni2oem_unused
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ffunicode_ffuni2oem.c:52: WCHAR ff_uni2oem (	/* Returns OEM code character, zero on error */
;	---------------------------------
; Function ff_uni2oem_unused
; ---------------------------------
_ff_uni2oem_unused::
	call	___sdcc_enter_ix
	push	af
	push	af
;fatFs\ffunicode_ffuni2oem.c:57: WCHAR c = 0;
	ld	bc, #0x0000
;fatFs\ffunicode_ffuni2oem.c:58: const WCHAR *p = CVTBL(uc, FF_CODE_PAGE);
;fatFs\ffunicode_ffuni2oem.c:61: if (uni < 0x80) {	/* ASCII? */
	ld	a, 4 (ix)
	sub	a, #0x80
	ld	a, 5 (ix)
	sbc	a, #0x00
	ld	a, 6 (ix)
	sbc	a, #0x00
	ld	a, 7 (ix)
	sbc	a, #0x00
	jr	NC,00106$
;fatFs\ffunicode_ffuni2oem.c:62: c = (WCHAR)uni;
	ld	c, 4 (ix)
	ld	b, 5 (ix)
	jr	00107$
00106$:
;fatFs\ffunicode_ffuni2oem.c:65: if (uni < 0x10000 && cp == FF_CODE_PAGE) {	/* Is it in BMP and valid code page? */
	ld	a, 6 (ix)
	sub	a, #0x01
	ld	a, 7 (ix)
	sbc	a, #0x00
	jr	NC,00107$
	ld	a, 8 (ix)
	ld	d, 9 (ix)
	sub	a, #0xb5
	jr	NZ,00107$
	dec	d
	jr	NZ,00107$
;fatFs\ffunicode_ffuni2oem.c:66: for (c = 0; c < 0x80 && uni != p[c]; c++) ;
	ld	bc, #0x0000
00110$:
	ld	e, c
	ld	d, b
	ld	a, e
	sub	a, #0x80
	ld	a, d
	sbc	a, #0x00
	jr	NC,00101$
	ld	l, c
	ld	h, b
	add	hl, hl
	push	de
	ld	de, #_uc437
	add	hl, de
	pop	de
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	-4 (ix), a
	ld	-3 (ix), h
	xor	a, a
	ld	-2 (ix), a
	ld	-1 (ix), a
	ld	a, 4 (ix)
	sub	a, -4 (ix)
	jr	NZ,00147$
	ld	a, 5 (ix)
	sub	a, -3 (ix)
	jr	NZ,00147$
	ld	a, 6 (ix)
	sub	a, -2 (ix)
	jr	NZ,00147$
	ld	a, 7 (ix)
	sub	a, -1 (ix)
	jr	Z,00101$
00147$:
	inc	bc
	jr	00110$
00101$:
;fatFs\ffunicode_ffuni2oem.c:67: c = (c + 0x80) & 0xFF;
	ld	hl, #0x0080
	add	hl, de
	ld	a, l
	ld	b, #0x00
	ld	c, a
00107$:
;fatFs\ffunicode_ffuni2oem.c:71: return c;
	ld	l, c
	ld	h, b
;fatFs\ffunicode_ffuni2oem.c:72: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
