;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_chkchr
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _chk_chr
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_chkchr.c:39: int chk_chr (const char* str, int chr)	/* NZ:contained, ZR:not contained */
;	---------------------------------
; Function chk_chr
; ---------------------------------
_chk_chr::
;fatFs\ff_chkchr.c:41: while (*str && *str != chr) str++;
	pop	de
	pop	bc
	push	bc
	push	de
00102$:
	ld	a, (bc)
	push	af
	ld	e, a
	rla
	sbc	a, a
	ld	d, a
	pop	af
	or	a, a
	jr	Z,00104$
	ld	iy, #4
	add	iy, sp
	ld	l, 0 (iy)
	ld	h, 1 (iy)
	cp	a, a
	sbc	hl, de
	jr	Z,00104$
	inc	bc
	jr	00102$
00104$:
;fatFs\ff_chkchr.c:42: return *str;
	ex	de,hl
;fatFs\ff_chkchr.c:43: }
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
