;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_fopen
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _find_volume
	.globl _follow_path
	.globl _ld_clust
	.globl _ld_dword
	.globl _f_open
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFS/ff_fopen.c:43: FRESULT f_open (
;	---------------------------------
; Function f_open
; ---------------------------------
_f_open::
	call	___sdcc_enter_ix
	ld	hl, #-53
	add	hl, sp
	ld	sp, hl
;fatFS/ff_fopen.c:61: if (!fp) return FR_INVALID_OBJECT;
	ld	a, 5 (ix)
	or	a, 4 (ix)
	jr	NZ,00102$
	ld	l, #0x09
	jp	00116$
00102$:
;fatFS/ff_fopen.c:76: );
	ld	hl, #44
	add	hl, sp
	push	hl
	call	_find_volume
	pop	af
	ld	-7 (ix), l
;fatFS/ff_fopen.c:192: fp->obj.sclust = ld_clust(fs, dj.dir);					/* Get object allocation info */
	ld	c, 4 (ix)
	ld	b, 5 (ix)
;fatFS/ff_fopen.c:78: if (res == FR_OK) {
	ld	a, -7 (ix)
	or	a, a
	jp	NZ, 00113$
;fatFS/ff_fopen.c:79: dj.obj.fs = fs;
	ld	hl, #0
	add	hl, sp
	ld	a, -9 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -8 (ix)
	ld	(hl), a
;fatFS/ff_fopen.c:81: res = follow_path(&dj, path);	/* Follow the file path */
	ld	hl, #0
	add	hl, sp
	ex	de, hl
	ld	-2 (ix), e
	ld	-1 (ix), d
	push	bc
	push	de
	ld	l, 6 (ix)
	ld	h, 7 (ix)
	push	hl
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	push	hl
	call	_follow_path
	pop	af
	pop	af
	pop	de
	pop	bc
;fatFS/ff_fopen.c:171: if (res == FR_OK) {
	ld	-7 (ix), l
	ld	a, l
	or	a, a
	jr	NZ,00109$
;fatFS/ff_fopen.c:172: if (dj.fn[NSFLAG] & NS_NONAME) {	/* Is it origin directory itself? */
	ld	l, e
	ld	h, d
	push	bc
	ld	bc, #0x0027
	add	hl, bc
	pop	bc
	ld	a, (hl)
	rlca
	jr	NC,00106$
;fatFS/ff_fopen.c:173: res = FR_INVALID_NAME;
	ld	-7 (ix), #0x06
	jr	00109$
00106$:
;fatFS/ff_fopen.c:175: if (dj.obj.attr & AM_DIR) {		/* Is it a directory? */
	ld	l, e
	ld	h, d
	inc	hl
	inc	hl
	inc	hl
	inc	hl
	bit	4, (hl)
	jr	Z,00109$
;fatFS/ff_fopen.c:176: res = FR_NO_FILE;
	ld	-7 (ix), #0x04
00109$:
;fatFS/ff_fopen.c:182: if (res == FR_OK) {
	ld	a, -7 (ix)
	or	a, a
	jp	NZ, 00113$
;fatFS/ff_fopen.c:192: fp->obj.sclust = ld_clust(fs, dj.dir);					/* Get object allocation info */
	ld	hl, #0x0006
	add	hl, bc
	ld	-6 (ix), l
	ld	-5 (ix), h
	ld	hl, #0x001a
	add	hl, de
	ex	de, hl
	ld	l, e
	ld	h, d
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	push	bc
	push	de
	push	hl
	ld	l, -9 (ix)
	ld	h, -8 (ix)
	push	hl
	call	_ld_clust
	pop	af
	pop	af
	ld	-4 (ix), l
	ld	-3 (ix), h
	ld	-2 (ix), e
	ld	-1 (ix), d
	pop	de
	pop	bc
	push	de
	push	bc
	ld	e, -6 (ix)
	ld	d, -5 (ix)
	ld	hl, #0x0035
	add	hl, sp
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
;fatFS/ff_fopen.c:193: fp->obj.objsize = ld_dword(dj.dir + DIR_FileSize);
	ld	hl, #0x000a
	add	hl, bc
	ld	-6 (ix), l
	ld	-5 (ix), h
	ex	de,hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	hl, #0x001c
	add	hl, de
	push	bc
	push	hl
	call	_ld_dword
	pop	af
	ld	-4 (ix), l
	ld	-3 (ix), h
	ld	-2 (ix), e
	ld	-1 (ix), d
	ld	e, -6 (ix)
	ld	d, -5 (ix)
	ld	hl, #0x0033
	add	hl, sp
	ld	bc, #0x0004
	ldir
	pop	bc
;fatFS/ff_fopen.c:198: fp->obj.fs = fs;	 	/* Validate the file object */
	ld	l, c
	ld	h, b
	ld	a, -9 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -8 (ix)
	ld	(hl), a
;fatFS/ff_fopen.c:199: fp->obj.id = fs->id;
	ld	hl, #0x0002
	add	hl, bc
	ld	-2 (ix), l
	ld	-1 (ix), h
	ld	l, -9 (ix)
	ld	h, -8 (ix)
	ld	de, #0x0004
	add	hl, de
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	(hl), e
	inc	hl
	ld	(hl), d
;fatFS/ff_fopen.c:201: fp->flag = FA_READ;		/* Set file access mode */
	ld	hl, #0x000e
	add	hl, bc
	ld	(hl), #0x01
;fatFS/ff_fopen.c:205: fp->err = 0;			/* Clear error flag */
	ld	hl, #0x000f
	add	hl, bc
	ld	(hl), #0x00
;fatFS/ff_fopen.c:206: fp->sect = 0;			/* Invalidate current data sector */
	ld	hl, #0x0018
	add	hl, bc
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	ld	(hl), a
;fatFS/ff_fopen.c:207: fp->fptr = 0;			/* Set file pointer top of the file */
	ld	hl, #0x0010
	add	hl, bc
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	ld	(hl), a
00113$:
;fatFS/ff_fopen.c:243: if (res != FR_OK) fp->obj.fs = 0;	/* Invalidate file object on error */
	ld	a, -7 (ix)
	or	a, a
	jr	Z,00115$
	xor	a, a
	ld	(bc), a
	inc	bc
	ld	(bc), a
00115$:
;fatFS/ff_fopen.c:245: LEAVE_FF(fs, res);
	ld	l, -7 (ix)
00116$:
;fatFS/ff_fopen.c:246: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
