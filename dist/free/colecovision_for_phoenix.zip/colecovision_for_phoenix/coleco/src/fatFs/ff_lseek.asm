;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_lseek
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _disk_read
	.globl _validate
	.globl _get_fat
	.globl _clst2sect
	.globl _f_lseek
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFS/ff_lseek.c:43: FRESULT f_lseek (
;	---------------------------------
; Function f_lseek
; ---------------------------------
_f_lseek::
	call	___sdcc_enter_ix
	ld	hl, #-35
	add	hl, sp
	ld	sp, hl
;fatFS/ff_lseek.c:57: res = validate(&fp->obj, &fs);		/* Check validity of the file object */
	ld	hl, #0
	add	hl, sp
	ld	a, 4 (ix)
	ld	-33 (ix), a
	ld	a, 5 (ix)
	ld	-32 (ix), a
	push	hl
	ld	l, -33 (ix)
	ld	h, -32 (ix)
	push	hl
	call	_validate
	pop	af
	pop	af
	ld	-31 (ix), l
;fatFS/ff_lseek.c:58: if (res == FR_OK) res = (FRESULT)fp->err;
	ld	a, -33 (ix)
	add	a, #0x0f
	ld	-30 (ix), a
	ld	a, -32 (ix)
	adc	a, #0x00
	ld	-29 (ix), a
	ld	a, -31 (ix)
	or	a, a
	jr	NZ,00102$
	ld	l, -30 (ix)
	ld	h, -29 (ix)
	ld	a, (hl)
	ld	-31 (ix), a
00102$:
;fatFS/ff_lseek.c:64: if (res != FR_OK) LEAVE_FF(fs, res);
	ld	a, -31 (ix)
	or	a, a
	jr	Z,00104$
	ld	l, -31 (ix)
	jp	00137$
00104$:
;fatFS/ff_lseek.c:131: if (ofs > fp->obj.objsize && (FF_FS_READONLY || !(fp->flag & FA_WRITE))) {	/* In read-only mode, clip offset with the file size */
	ld	a, -33 (ix)
	ld	-28 (ix), a
	ld	a, -32 (ix)
	ld	-27 (ix), a
	pop	bc
	pop	hl
	push	hl
	push	bc
	ld	de, #0x000a
	add	hl, de
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	inc	hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	a, c
	sub	a, 6 (ix)
	ld	a, b
	sbc	a, 7 (ix)
	ld	a, e
	sbc	a, 8 (ix)
	ld	a, d
	sbc	a, 9 (ix)
	jr	NC,00106$
;fatFS/ff_lseek.c:132: ofs = fp->obj.objsize;
	ld	6 (ix), c
	ld	7 (ix), b
	ld	8 (ix), e
	ld	9 (ix), d
00106$:
;fatFS/ff_lseek.c:134: ifptr = fp->fptr;
	ld	a, -33 (ix)
	add	a, #0x10
	ld	-26 (ix), a
	ld	a, -32 (ix)
	adc	a, #0x00
	ld	-25 (ix), a
	ld	a, -26 (ix)
	ld	-24 (ix), a
	ld	a, -25 (ix)
	ld	-23 (ix), a
	ld	e, -26 (ix)
	ld	d, -25 (ix)
	ld	hl, #0x000d
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
;fatFS/ff_lseek.c:135: fp->fptr = nsect = 0;
	xor	a, a
	ld	-18 (ix), a
	ld	-17 (ix), a
	ld	-16 (ix), a
	ld	-15 (ix), a
	ld	l, -26 (ix)
	ld	h, -25 (ix)
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	ld	(hl), a
;fatFS/ff_lseek.c:136: if (ofs > 0) {
	ld	a, 9 (ix)
	or	a, 8 (ix)
	or	a, 7 (ix)
	or	a, 6 (ix)
	jp	Z, 00130$
;fatFS/ff_lseek.c:137: bcs = (DWORD)fs->csize * SS(fs);	/* Cluster size (byte) */
	pop	hl
	push	hl
	ld	de, #0x0008
	add	hl, de
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	e, #0x00
	ld	-13 (ix), c
	ld	-12 (ix), b
	ld	-11 (ix), e
	xor	a, a
	ld	-14 (ix), a
	sla	-13 (ix)
	rl	-12 (ix)
	rl	-11 (ix)
;fatFS/ff_lseek.c:142: clst = fp->clust;
	ld	a, -33 (ix)
	add	a, #0x14
	ld	-10 (ix), a
	ld	a, -32 (ix)
	adc	a, #0x00
	ld	-9 (ix), a
;fatFS/ff_lseek.c:138: if (ifptr > 0 &&
	ld	a, -19 (ix)
	or	a, -20 (ix)
	or	a, -21 (ix)
	or	a, -22 (ix)
	jp	Z, 00110$
;fatFS/ff_lseek.c:139: (ofs - 1) / bcs >= (ifptr - 1) / bcs) {	/* When seek to same or following cluster, */
	ld	a, 6 (ix)
	add	a, #0xff
	ld	c, a
	ld	a, 7 (ix)
	adc	a, #0xff
	ld	b, a
	ld	a, 8 (ix)
	adc	a, #0xff
	ld	e, a
	ld	a, 9 (ix)
	adc	a, #0xff
	ld	d, a
	ld	l, -12 (ix)
	ld	h, -11 (ix)
	push	hl
	ld	l, -14 (ix)
	ld	h, -13 (ix)
	push	hl
	push	de
	push	bc
	call	__divulong
	pop	af
	pop	af
	pop	af
	pop	af
	ld	-8 (ix), l
	ld	-7 (ix), h
	ld	-6 (ix), e
	ld	-5 (ix), d
	ld	a, -22 (ix)
	add	a, #0xff
	ld	-4 (ix), a
	ld	a, -21 (ix)
	adc	a, #0xff
	ld	-3 (ix), a
	ld	a, -20 (ix)
	adc	a, #0xff
	ld	-2 (ix), a
	ld	a, -19 (ix)
	adc	a, #0xff
	ld	-1 (ix), a
	ld	l, -12 (ix)
	ld	h, -11 (ix)
	push	hl
	ld	l, -14 (ix)
	ld	h, -13 (ix)
	push	hl
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	push	hl
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	push	hl
	call	__divulong
	pop	af
	pop	af
	pop	af
	pop	af
	ld	a, -8 (ix)
	sub	a, l
	ld	a, -7 (ix)
	sbc	a, h
	ld	a, -6 (ix)
	sbc	a, e
	ld	a, -5 (ix)
	sbc	a, d
	jr	C,00110$
;fatFS/ff_lseek.c:140: fp->fptr = (ifptr - 1) & ~(FSIZE_t)(bcs - 1);	/* start from the current cluster */
	ld	a, -14 (ix)
	add	a, #0xff
	ld	c, a
	ld	a, -13 (ix)
	adc	a, #0xff
	ld	b, a
	ld	a, -12 (ix)
	adc	a, #0xff
	ld	e, a
	ld	a, -11 (ix)
	adc	a, #0xff
	cpl
	ld	h, a
	ld	a, c
	cpl
	push	af
	ld	a, b
	cpl
	ld	c, a
	ld	a, e
	cpl
	ld	l, a
	pop	af
	and	a, -4 (ix)
	ld	e, a
	ld	a, c
	and	a, -3 (ix)
	ld	d, a
	ld	a, l
	and	a, -2 (ix)
	ld	c, a
	ld	a, h
	and	a, -1 (ix)
	ld	b, a
	ld	l, -26 (ix)
	ld	h, -25 (ix)
	ld	(hl), e
	inc	hl
	ld	(hl), d
	inc	hl
	ld	(hl), c
	inc	hl
	ld	(hl), b
;fatFS/ff_lseek.c:141: ofs -= fp->fptr;
	ld	a, 6 (ix)
	sub	a, e
	ld	6 (ix), a
	ld	a, 7 (ix)
	sbc	a, d
	ld	7 (ix), a
	ld	a, 8 (ix)
	sbc	a, c
	ld	8 (ix), a
	ld	a, 9 (ix)
	sbc	a, b
	ld	9 (ix), a
;fatFS/ff_lseek.c:142: clst = fp->clust;
	ld	e, -10 (ix)
	ld	d, -9 (ix)
	ld	hl, #0x001f
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	jr	00111$
00110$:
;fatFS/ff_lseek.c:144: clst = fp->obj.sclust;					/* start from the first cluster */
	pop	bc
	pop	hl
	push	hl
	push	bc
	ld	de, #0x0006
	add	hl, de
	ld	a, (hl)
	ld	-4 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-3 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-2 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-1 (ix), a
;fatFS/ff_lseek.c:153: fp->clust = clst;
	ld	e, -10 (ix)
	ld	d, -9 (ix)
	ld	hl, #0x001f
	add	hl, sp
	ld	bc, #0x0004
	ldir
00111$:
;fatFS/ff_lseek.c:155: if (clst != 0) {
	ld	a, -1 (ix)
	or	a, -2 (ix)
	or	a, -3 (ix)
	or	a, -4 (ix)
	jp	Z, 00130$
;fatFS/ff_lseek.c:156: while (ofs > bcs) {						/* Cluster following loop */
	ld	a, -33 (ix)
	ld	-6 (ix), a
	ld	a, -32 (ix)
	ld	-5 (ix), a
00118$:
	ld	a, -14 (ix)
	sub	a, 6 (ix)
	ld	a, -13 (ix)
	sbc	a, 7 (ix)
	ld	a, -12 (ix)
	sbc	a, 8 (ix)
	ld	a, -11 (ix)
	sbc	a, 9 (ix)
	jp	NC, 00120$
;fatFS/ff_lseek.c:157: ofs -= bcs; fp->fptr += bcs;
	ld	a, 6 (ix)
	sub	a, -14 (ix)
	ld	6 (ix), a
	ld	a, 7 (ix)
	sbc	a, -13 (ix)
	ld	7 (ix), a
	ld	a, 8 (ix)
	sbc	a, -12 (ix)
	ld	8 (ix), a
	ld	a, 9 (ix)
	sbc	a, -11 (ix)
	ld	9 (ix), a
	ld	l, -24 (ix)
	ld	h, -23 (ix)
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	inc	hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	a, c
	add	a, -14 (ix)
	ld	c, a
	ld	a, b
	adc	a, -13 (ix)
	ld	b, a
	ld	a, e
	adc	a, -12 (ix)
	ld	e, a
	ld	a, d
	adc	a, -11 (ix)
	ld	d, a
	ld	l, -24 (ix)
	ld	h, -23 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
	inc	hl
	ld	(hl), e
	inc	hl
	ld	(hl), d
;fatFS/ff_lseek.c:171: clst = get_fat(&fp->obj, clst);	/* Follow cluster chain if not in write mode */
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	push	hl
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	push	hl
	ld	l, -28 (ix)
	ld	h, -27 (ix)
	push	hl
	call	_get_fat
	pop	af
	pop	af
	pop	af
	ld	-4 (ix), l
	ld	-3 (ix), h
	ld	-2 (ix), e
	ld	-1 (ix), d
;fatFS/ff_lseek.c:173: if (clst == 0xFFFFFFFF) { ABORT(fs, FR_DISK_ERR); }
	ld	a, -4 (ix)
	and	a, -3 (ix)
	and	a, -2 (ix)
	and	a, -1 (ix)
	inc	a
	jr	NZ,00114$
	ld	l, -30 (ix)
	ld	h, -29 (ix)
	ld	(hl), #0x01
	ld	l, #0x01
	jp	00137$
00114$:
;fatFS/ff_lseek.c:174: if (clst <= 1 || clst >= fs->n_fatent) { ABORT(fs, FR_INT_ERR); }
	ld	a, #0x01
	cp	a, -4 (ix)
	ld	a, #0x00
	sbc	a, -3 (ix)
	ld	a, #0x00
	sbc	a, -2 (ix)
	ld	a, #0x00
	sbc	a, -1 (ix)
	jr	NC,00115$
	pop	hl
	push	hl
	ld	de, #0x000c
	add	hl, de
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	inc	hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	a, -4 (ix)
	sub	a, c
	ld	a, -3 (ix)
	sbc	a, b
	ld	a, -2 (ix)
	sbc	a, e
	ld	a, -1 (ix)
	sbc	a, d
	jr	C,00116$
00115$:
	ld	l, -30 (ix)
	ld	h, -29 (ix)
	ld	(hl), #0x02
	ld	l, #0x02
	jp	00137$
00116$:
;fatFS/ff_lseek.c:175: fp->clust = clst;
	ld	a, -6 (ix)
	add	a, #0x14
	ld	e, a
	ld	a, -5 (ix)
	adc	a, #0x00
	ld	d, a
	ld	hl, #0x001f
	add	hl, sp
	ld	bc, #0x0004
	ldir
	jp	00118$
00120$:
;fatFS/ff_lseek.c:177: fp->fptr += ofs;
	ld	l, -26 (ix)
	ld	h, -25 (ix)
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	inc	hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	a, c
	add	a, 6 (ix)
	ld	c, a
	ld	a, b
	adc	a, 7 (ix)
	ld	b, a
	ld	a, e
	adc	a, 8 (ix)
	ld	e, a
	ld	a, d
	adc	a, 9 (ix)
	ld	d, a
	ld	l, -26 (ix)
	ld	h, -25 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
	inc	hl
	ld	(hl), e
	inc	hl
	ld	(hl), d
;fatFS/ff_lseek.c:178: if (ofs % SS(fs)) {
	ld	a, 6 (ix)
	or	a, a
	jr	NZ,00222$
	bit	0, 7 (ix)
	jp	Z,00130$
00222$:
;fatFS/ff_lseek.c:179: nsect = clst2sect(fs, clst);	/* Current sector */
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	push	hl
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	push	hl
	ld	l, -35 (ix)
	ld	h, -34 (ix)
	push	hl
	call	_clst2sect
	pop	af
	pop	af
	pop	af
	ld	-4 (ix), l
	ld	-3 (ix), h
	ld	-2 (ix), e
	ld	-1 (ix), d
	ld	hl, #27
	add	hl, sp
	ex	de, hl
	ld	hl, #31
	add	hl, sp
	ld	bc, #4
	ldir
;fatFS/ff_lseek.c:180: if (nsect == 0) { ABORT(fs, FR_INT_ERR); }
	ld	a, -5 (ix)
	or	a, -6 (ix)
	or	a, -7 (ix)
	or	a, -8 (ix)
	jr	NZ,00122$
	ld	l, -30 (ix)
	ld	h, -29 (ix)
	ld	(hl), #0x02
	ld	l, #0x02
	jp	00137$
00122$:
;fatFS/ff_lseek.c:181: nsect += (DWORD)(ofs / SS(fs));
	ld	a, 7 (ix)
	ld	-4 (ix), a
	ld	a, 8 (ix)
	ld	-3 (ix), a
	ld	a, 9 (ix)
	ld	-2 (ix), a
	xor	a, a
	ld	-1 (ix), a
	srl	-2 (ix)
	rr	-3 (ix)
	rr	-4 (ix)
	ld	a, -4 (ix)
	add	a, -8 (ix)
	ld	-18 (ix), a
	ld	a, -3 (ix)
	adc	a, -7 (ix)
	ld	-17 (ix), a
	ld	a, -2 (ix)
	adc	a, -6 (ix)
	ld	-16 (ix), a
	ld	a, -1 (ix)
	adc	a, -5 (ix)
	ld	-15 (ix), a
;fatFS/ff_lseek.c:187: fp->flag |= FA_MODIFIED;
00130$:
;fatFS/ff_lseek.c:189: if (fp->fptr % SS(fs) && nsect != fp->sect) {	/* Fill sector cache if needed */
	ld	e, -26 (ix)
	ld	d, -25 (ix)
	ld	hl, #0x001f
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	ld	a, -4 (ix)
	or	a, a
	jr	NZ,00225$
	bit	0, -3 (ix)
	jp	Z,00135$
00225$:
	ld	a, -33 (ix)
	add	a, #0x18
	ld	-4 (ix), a
	ld	a, -32 (ix)
	adc	a, #0x00
	ld	-3 (ix), a
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	inc	hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	a, -18 (ix)
	sub	a, c
	jr	NZ,00226$
	ld	a, -17 (ix)
	sub	a, b
	jr	NZ,00226$
	ld	l, -16 (ix)
	ld	h, -15 (ix)
	cp	a, a
	sbc	hl, de
	jr	Z,00135$
00226$:
;fatFS/ff_lseek.c:204: if (disk_read(fp->buf, nsect, 1) != RES_OK) { ABORT(fs, FR_DISK_ERR); }	/* Fill sector cache */
	ld	a, -33 (ix)
	add	a, #0x1c
	ld	-2 (ix), a
	ld	a, -32 (ix)
	adc	a, #0x00
	ld	-1 (ix), a
	ld	hl, #0x0001
	push	hl
	ld	l, -16 (ix)
	ld	h, -15 (ix)
	push	hl
	ld	l, -18 (ix)
	ld	h, -17 (ix)
	push	hl
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	push	hl
	call	_disk_read
	pop	af
	pop	af
	pop	af
	pop	af
	ld	-1 (ix), l
	ld	a, l
	or	a, a
	jr	Z,00133$
	ld	l, -30 (ix)
	ld	h, -29 (ix)
	ld	(hl), #0x01
	ld	l, #0x01
	jr	00137$
00133$:
;fatFS/ff_lseek.c:207: fp->sect = nsect;
	ld	e, -4 (ix)
	ld	d, -3 (ix)
	ld	hl, #0x0011
	add	hl, sp
	ld	bc, #0x0004
	ldir
00135$:
;fatFS/ff_lseek.c:211: LEAVE_FF(fs, res);
	ld	l, -31 (ix)
00137$:
;fatFS/ff_lseek.c:212: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
