;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_getfat
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _move_window
	.globl _ld_dword
	.globl _get_fat
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_getfat.c:42: DWORD get_fat (		/* 0xFFFFFFFF:Disk error, 1:Internal error, 2..0x7FFFFFFF:Cluster status */
;	---------------------------------
; Function get_fat
; ---------------------------------
_get_fat::
	call	___sdcc_enter_ix
	push	af
	push	af
	push	af
	push	af
;fatFs\ff_getfat.c:51: FATFS *fs = obj->fs;
	ld	l, 4 (ix)
	ld	h, 5 (ix)
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
;fatFs\ff_getfat.c:54: if (clst < 2 || clst >= fs->n_fatent) {	/* Check if in valid range */
	ld	a, 6 (ix)
	sub	a, #0x02
	ld	a, 7 (ix)
	sbc	a, #0x00
	ld	a, 8 (ix)
	sbc	a, #0x00
	ld	a, 9 (ix)
	sbc	a, #0x00
	jr	C,00109$
	ld	l, c
	ld	h, b
	ld	de, #0x000c
	add	hl, de
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	inc	hl
	inc	hl
	ld	a, (hl)
	dec	hl
	ld	l, (hl)
	ld	h, a
	ld	a, 6 (ix)
	sub	a, e
	ld	a, 7 (ix)
	sbc	a, d
	ld	a, 8 (ix)
	sbc	a, l
	ld	a, 9 (ix)
	sbc	a, h
	jr	C,00110$
00109$:
;fatFs\ff_getfat.c:55: val = 1;	/* Internal error */
	ld	-8 (ix), #0x01
	xor	a, a
	ld	-7 (ix), a
	ld	-6 (ix), a
	ld	-5 (ix), a
	jp	00111$
00110$:
;fatFs\ff_getfat.c:58: val = 0xFFFFFFFF;	/* Default value falls on disk error */
	ld	-8 (ix), #0xff
	ld	-7 (ix), #0xff
	ld	-6 (ix), #0xff
	ld	-5 (ix), #0xff
;fatFs\ff_getfat.c:60: switch (fs->fs_type) {
	ld	a, (bc)
	ld	l, a
;fatFs\ff_getfat.c:73: if (move_window(fs, fs->fatbase + (clst / (SS(fs) / 2))) != FR_OK) break;
	ld	a, c
	add	a, #0x18
	ld	e, a
	ld	a, b
	adc	a, #0x00
	ld	d, a
;fatFs\ff_getfat.c:60: switch (fs->fs_type) {
	ld	a,l
	cp	a,#0x02
	jr	Z,00101$
	sub	a, #0x03
	jr	Z,00104$
	jp	00107$
;fatFs\ff_getfat.c:72: case FS_FAT16 :
00101$:
;fatFs\ff_getfat.c:73: if (move_window(fs, fs->fatbase + (clst / (SS(fs) / 2))) != FR_OK) break;
	push	bc
	ld	hl, #0x0006
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	ld	e, 7 (ix)
	ld	d, 8 (ix)
	ld	l, 9 (ix)
	ld	h, #0x00
	ld	a, -4 (ix)
	add	a, e
	ld	e, a
	ld	a, -3 (ix)
	adc	a, d
	ld	d, a
	ld	a, -2 (ix)
	adc	a, l
	ld	l, a
	ld	a, -1 (ix)
	adc	a, h
	ld	h, a
	push	bc
	push	hl
	push	de
	push	bc
	call	_move_window
	pop	af
	pop	af
	pop	af
	ld	a, l
	pop	bc
	or	a, a
	jp	NZ, 00111$
;fatFs\ff_getfat.c:74: val = ld_word(fs->win + clst * 2 % SS(fs));		/* Simple WORD array */
	ld	hl, #0x0028
	add	hl, bc
	ex	de, hl
	ld	l, 6 (ix)
	ld	h, 7 (ix)
	ld	c, 8 (ix)
	ld	b, 9 (ix)
	add	hl, hl
	rl	c
	rl	b
	ld	a, h
	and	a, #0x01
	ld	h, a
	add	hl, de
	ex	de, hl
	ld	l, e
	ld	h, d
	inc	hl
	ld	b, (hl)
	ld	c, #0x00
	ld	a, (de)
	ld	e, a
	ld	d, #0x00
	ld	a, c
	or	a, e
	ld	c, a
	ld	a, b
	or	a, d
	ld	b, a
	ld	-8 (ix), c
	ld	a, b
	ld	-7 (ix), a
	rla
	sbc	a, a
	ld	-6 (ix), a
	ld	-5 (ix), a
;fatFs\ff_getfat.c:75: break;
	jp	00111$
;fatFs\ff_getfat.c:77: case FS_FAT32 :
00104$:
;fatFs\ff_getfat.c:78: if (move_window(fs, fs->fatbase + (clst / (SS(fs) / 4))) != FR_OK) break;
	push	bc
	ld	hl, #0x0006
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	ld	e, 6 (ix)
	ld	d, 7 (ix)
	ld	l, 8 (ix)
	ld	h, 9 (ix)
	ld	a, #0x07
00146$:
	srl	h
	rr	l
	rr	d
	rr	e
	dec	a
	jr	NZ, 00146$
	ld	a, -4 (ix)
	add	a, e
	ld	e, a
	ld	a, -3 (ix)
	adc	a, d
	ld	d, a
	ld	a, -2 (ix)
	adc	a, l
	ld	l, a
	ld	a, -1 (ix)
	adc	a, h
	ld	h, a
	push	bc
	push	hl
	push	de
	push	bc
	call	_move_window
	pop	af
	pop	af
	pop	af
	ld	a, l
	pop	bc
	or	a, a
	jr	NZ,00111$
;fatFs\ff_getfat.c:79: val = ld_dword(fs->win + clst * 4 % SS(fs)) & 0x0FFFFFFF;	/* Simple DWORD array but mask out upper 4 bits */
	ld	hl, #0x0028
	add	hl, bc
	ex	de, hl
	ld	l, 6 (ix)
	ld	h, 7 (ix)
	ld	c, 8 (ix)
	ld	b, 9 (ix)
	ld	a, #0x02
00148$:
	add	hl, hl
	rl	c
	rl	b
	dec	a
	jr	NZ,00148$
	ld	a, h
	and	a, #0x01
	ld	h, a
	add	hl, de
	push	hl
	call	_ld_dword
	pop	af
	ld	-8 (ix), l
	ld	-7 (ix), h
	ld	-6 (ix), e
	ld	a, d
	and	a, #0x0f
	ld	-5 (ix), a
;fatFs\ff_getfat.c:80: break;
	jr	00111$
;fatFs\ff_getfat.c:107: default:
00107$:
;fatFs\ff_getfat.c:108: val = 1;	/* Internal error */
	ld	-8 (ix), #0x01
	xor	a, a
	ld	-7 (ix), a
	ld	-6 (ix), a
	ld	-5 (ix), a
;fatFs\ff_getfat.c:109: }
00111$:
;fatFs\ff_getfat.c:112: return val;
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	ld	e, -6 (ix)
	ld	d, -5 (ix)
;fatFs\ff_getfat.c:113: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
