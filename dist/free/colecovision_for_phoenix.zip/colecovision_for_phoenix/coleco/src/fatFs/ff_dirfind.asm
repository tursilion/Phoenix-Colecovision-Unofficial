;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_dirfind
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _sum_sfn
	.globl _cmp_lfn
	.globl _dir_next
	.globl _dir_sdi
	.globl _move_window
	.globl _mem_cmp
	.globl _dir_find
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_dirfind.c:42: FRESULT dir_find (	/* FR_OK(0):succeeded, !=0:error */
;	---------------------------------
; Function dir_find
; ---------------------------------
_dir_find::
	call	___sdcc_enter_ix
	ld	hl, #-27
	add	hl, sp
	ld	sp, hl
;fatFs\ff_dirfind.c:47: FATFS *fs = dp->obj.fs;
	ld	a, 4 (ix)
	ld	-2 (ix), a
	ld	a, 5 (ix)
	ld	-1 (ix), a
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	a, (hl)
	ld	-23 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-22 (ix), a
;fatFs\ff_dirfind.c:53: res = dir_sdi(dp, 0);			/* Rewind directory object */
	ld	hl, #0x0000
	push	hl
	ld	hl, #0x0000
	push	hl
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	push	hl
	call	_dir_sdi
	pop	af
	pop	af
	pop	af
;fatFs\ff_dirfind.c:54: if (res != FR_OK) return res;
	ld	-3 (ix), l
	ld	a, l
	or	a, a
	jr	Z,00102$
	ld	l, -3 (ix)
	jp	00128$
00102$:
;fatFs\ff_dirfind.c:77: ord = sum = 0xFF; dp->blk_ofs = 0xFFFFFFFF;	/* Reset LFN sequence */
	ld	-21 (ix), #0xff
	ld	-20 (ix), #0xff
	ld	a, -2 (ix)
	ld	-19 (ix), a
	ld	a, -1 (ix)
	ld	-18 (ix), a
	ld	a, -2 (ix)
	add	a, #0x28
	ld	-17 (ix), a
	ld	a, -1 (ix)
	adc	a, #0x00
	ld	-16 (ix), a
	ld	l, -17 (ix)
	ld	h, -16 (ix)
	ld	(hl), #0xff
	inc	hl
	ld	(hl), #0xff
	inc	hl
	ld	(hl), #0xff
	inc	hl
	ld	(hl), #0xff
;fatFs\ff_dirfind.c:79: do {
	ld	a, -2 (ix)
	ld	-15 (ix), a
	ld	a, -1 (ix)
	ld	-14 (ix), a
	ld	a, -23 (ix)
	ld	-13 (ix), a
	ld	a, -22 (ix)
	ld	-12 (ix), a
	ld	a, -2 (ix)
	add	a, #0x1c
	ld	-11 (ix), a
	ld	a, -1 (ix)
	adc	a, #0x00
	ld	-10 (ix), a
	ld	a, -2 (ix)
	add	a, #0x27
	ld	-9 (ix), a
	ld	a, -1 (ix)
	adc	a, #0x00
	ld	-8 (ix), a
	ld	a, -9 (ix)
	ld	-7 (ix), a
	ld	a, -8 (ix)
	ld	-6 (ix), a
	ld	a, -2 (ix)
	ld	-5 (ix), a
	ld	a, -1 (ix)
	ld	-4 (ix), a
00125$:
;fatFs\ff_dirfind.c:80: res = move_window(fs, dp->sect);
	ld	l, -5 (ix)
	ld	h, -4 (ix)
	ld	de, #0x0016
	add	hl, de
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	inc	hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	push	de
	push	bc
	ld	l, -23 (ix)
	ld	h, -22 (ix)
	push	hl
	call	_move_window
	pop	af
	pop	af
	pop	af
;fatFs\ff_dirfind.c:81: if (res != FR_OK) break;
	ld	-3 (ix), l
	ld	a, l
	or	a, a
	jp	NZ, 00127$
;fatFs\ff_dirfind.c:82: c = dp->dir[DIR_Name];
	ld	a, -19 (ix)
	add	a, #0x1a
	ld	c, a
	ld	a, -18 (ix)
	adc	a, #0x00
	ld	b, a
	ld	l, c
	ld	h, b
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	ld	e, (hl)
;fatFs\ff_dirfind.c:83: if (c == 0) { res = FR_NO_FILE; break; }	/* Reached to end of table */
	ld	a, e
	or	a, a
	jr	NZ,00106$
	ld	-3 (ix), #0x04
	jp	00127$
00106$:
;fatFs\ff_dirfind.c:85: dp->obj.attr = a = dp->dir[DIR_Attr] & AM_MASK;
	ld	a, -19 (ix)
	add	a, #0x04
	ld	-2 (ix), a
	ld	a, -18 (ix)
	adc	a, #0x00
	ld	-1 (ix), a
	push	bc
	ld	bc, #0x000b
	add	hl, bc
	pop	bc
	ld	a, (hl)
	and	a, #0x3f
	ld	d, a
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	(hl), a
;fatFs\ff_dirfind.c:86: if (c == DDEM || ((a & AM_VOL) && a != AM_LFN)) {	/* An entry without valid data */
	ld	a, e
	sub	a, #0xe5
	jr	Z,00120$
	ld	a, d
	sub	a, #0x0f
	ld	a, #0x01
	jr	Z,00208$
	xor	a, a
00208$:
	bit	3, d
	jr	Z,00121$
	bit	0, a
	jr	NZ,00121$
00120$:
;fatFs\ff_dirfind.c:87: ord = 0xFF; dp->blk_ofs = 0xFFFFFFFF;	/* Reset LFN sequence */
	ld	-20 (ix), #0xff
	ld	l, -17 (ix)
	ld	h, -16 (ix)
	ld	(hl), #0xff
	inc	hl
	ld	(hl), #0xff
	inc	hl
	ld	(hl), #0xff
	inc	hl
	ld	(hl), #0xff
	jp	00122$
00121$:
;fatFs\ff_dirfind.c:89: if (a == AM_LFN) {			/* An LFN entry is found */
	or	a, a
	jp	Z, 00118$
;fatFs\ff_dirfind.c:90: if (!(dp->fn[NSFLAG] & NS_NOLFN)) {
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	bit	6, (hl)
	jp	NZ,00122$
;fatFs\ff_dirfind.c:91: if (c & LLEF) {		/* Is it start of LFN sequence? */
	bit	6, e
	jr	Z,00108$
;fatFs\ff_dirfind.c:92: sum = dp->dir[LDIR_Chksum];
	ld	l, c
	ld	h, b
	ld	d, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, d
	push	bc
	ld	bc, #0x000d
	add	hl, bc
	pop	bc
	ld	a, (hl)
	ld	-21 (ix), a
;fatFs\ff_dirfind.c:93: c &= (BYTE)~LLEF; ord = c;	/* LFN start order */
	res	6, e
	ld	-20 (ix), e
;fatFs\ff_dirfind.c:94: dp->blk_ofs = dp->dptr;	/* Start offset of LFN */
	ld	l, -15 (ix)
	ld	h, -14 (ix)
	push	bc
	ld	bc, #0x000e
	add	hl, bc
	pop	bc
	ld	a, (hl)
	ld	-27 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-26 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-25 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-24 (ix), a
	push	de
	push	bc
	ld	e, -17 (ix)
	ld	d, -16 (ix)
	ld	hl, #0x0004
	add	hl, sp
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
00108$:
;fatFs\ff_dirfind.c:97: ord = (c == ord && sum == dp->dir[LDIR_Chksum] && cmp_lfn(fs->lfnbuf, dp->dir)) ? ord - 1 : 0xFF;
	ld	a, -20 (ix)
	sub	a, e
	jr	NZ,00130$
	ld	l, c
	ld	h, b
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	l, e
	ld	h, d
	ld	bc, #0x000d
	add	hl, bc
	ld	a,-21 (ix)
	sub	a,(hl)
	jr	NZ,00130$
	ld	l, -13 (ix)
	ld	h, -12 (ix)
	ld	bc, #0x000a
	add	hl, bc
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	push	de
	push	bc
	call	_cmp_lfn
	pop	af
	pop	af
	ld	a, h
	or	a, l
	jr	Z,00130$
	ld	a, -20 (ix)
	dec	a
	ld	c, a
	rla
	sbc	a, a
	jr	00131$
00130$:
	ld	bc, #0x00ff
00131$:
	ld	-20 (ix), c
	jr	00122$
00118$:
;fatFs\ff_dirfind.c:100: if (ord == 0 && sum == sum_sfn(dp->dir)) break;	/* LFN matched? */
	ld	a, -20 (ix)
	or	a, a
	jr	NZ,00112$
	ld	l, c
	ld	h, b
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	push	bc
	push	de
	call	_sum_sfn
	pop	af
	ld	e, l
	pop	bc
	ld	a, -21 (ix)
	sub	a, e
	jr	Z,00127$
00112$:
;fatFs\ff_dirfind.c:101: if (!(dp->fn[NSFLAG] & NS_LOSS) && !mem_cmp(dp->dir, dp->fn, 11)) break;	/* SFN matched? */
	ld	l, -9 (ix)
	ld	h, -8 (ix)
	ld	a, (hl)
	rrca
	jr	C,00115$
	ld	e, -11 (ix)
	ld	d, -10 (ix)
	ld	l, c
	ld	h, b
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	hl, #0x000b
	push	hl
	push	de
	push	bc
	call	_mem_cmp
	pop	af
	pop	af
	pop	af
	ld	a, h
	or	a, l
	jr	Z,00127$
00115$:
;fatFs\ff_dirfind.c:102: ord = 0xFF; dp->blk_ofs = 0xFFFFFFFF;	/* Reset LFN sequence */
	ld	-20 (ix), #0xff
	ld	l, -17 (ix)
	ld	h, -16 (ix)
	ld	(hl), #0xff
	inc	hl
	ld	(hl), #0xff
	inc	hl
	ld	(hl), #0xff
	inc	hl
	ld	(hl), #0xff
00122$:
;fatFs\ff_dirfind.c:109: res = dir_next(dp, 0);	/* Next entry */
	ld	hl, #0x0000
	push	hl
	ld	l, -19 (ix)
	ld	h, -18 (ix)
	push	hl
	call	_dir_next
	pop	af
	pop	af
;fatFs\ff_dirfind.c:110: } while (res == FR_OK);
	ld	-3 (ix), l
	ld	a, l
	or	a, a
	jp	Z, 00125$
00127$:
;fatFs\ff_dirfind.c:112: return res;
	ld	l, -3 (ix)
00128$:
;fatFs\ff_dirfind.c:113: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
