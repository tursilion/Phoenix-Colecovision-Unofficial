;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_pututf
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _put_utf
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_pututf.c:41: BYTE put_utf (	/* Returns number of encoding units written (0:buffer overflow or wrong encoding) */
;	---------------------------------
; Function put_utf
; ---------------------------------
_put_utf::
	call	___sdcc_enter_ix
	push	af
;fatFs\ff_pututf.c:111: wc = ff_uni2oem(chr, CODEPAGE);
	ld	c, 4 (ix)
	ld	b, 5 (ix)
;fatFs\ff_pututf.c:112: if (wc >= 0x100) {	/* Is this a DBC? */
	inc	sp
	inc	sp
	push	bc
;fatFs\ff_pututf.c:114: *buf++ = (char)(wc >> 8);	/* Store DBC 1st byte */
	ld	l, 8 (ix)
	ld	h, 9 (ix)
;fatFs\ff_pututf.c:115: *buf++ = (TCHAR)wc;			/* Store DBC 2nd byte */
	ld	e, c
;fatFs\ff_pututf.c:112: if (wc >= 0x100) {	/* Is this a DBC? */
	ld	a, -1 (ix)
	sub	a, #0x01
	jr	C,00104$
;fatFs\ff_pututf.c:113: if (szb < 2) return 0;
	ld	a, 10 (ix)
	sub	a, #0x02
	ld	a, 11 (ix)
	sbc	a, #0x00
	jr	NC,00102$
	ld	l, #0x00
	jr	00108$
00102$:
;fatFs\ff_pututf.c:114: *buf++ = (char)(wc >> 8);	/* Store DBC 1st byte */
	ld	(hl), b
	inc	hl
;fatFs\ff_pututf.c:115: *buf++ = (TCHAR)wc;			/* Store DBC 2nd byte */
	ld	8 (ix), l
	ld	9 (ix), h
	ld	(hl), e
;fatFs\ff_pututf.c:116: return 2;
	ld	l, #0x02
	jr	00108$
00104$:
;fatFs\ff_pututf.c:118: if (wc == 0 || szb < 1) return 0;	/* Invalid char or buffer overflow? */
	ld	a, b
	or	a, c
	jr	Z,00105$
	ld	a, 10 (ix)
	sub	a, #0x01
	ld	a, 11 (ix)
	sbc	a, #0x00
	jr	NC,00106$
00105$:
	ld	l, #0x00
	jr	00108$
00106$:
;fatFs\ff_pututf.c:119: *buf++ = (TCHAR)wc;					/* Store the character */
	ld	(hl), e
;fatFs\ff_pututf.c:120: return 1;
	ld	l, #0x01
00108$:
;fatFs\ff_pututf.c:122: }
	pop	af
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
