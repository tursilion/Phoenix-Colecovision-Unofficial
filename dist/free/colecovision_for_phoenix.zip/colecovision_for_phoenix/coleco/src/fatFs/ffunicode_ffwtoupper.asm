;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ffunicode_ffwtoupper
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ff_wtoupper_unused
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ffunicode_ffwtoupper.c:46: DWORD ff_wtoupper (	/* Returns up-converted code point */
;	---------------------------------
; Function ff_wtoupper_unused
; ---------------------------------
_ff_wtoupper_unused::
;fatFs\ffunicode_ffwtoupper.c:51: return uni;
	ld	iy, #2
	add	iy, sp
	ld	e, 2 (iy)
	ld	d, 3 (iy)
	ld	l, 0 (iy)
	ld	h, 1 (iy)
;fatFs\ffunicode_ffwtoupper.c:176: }
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
