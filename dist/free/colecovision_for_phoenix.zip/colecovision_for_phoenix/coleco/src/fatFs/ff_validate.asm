;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_validate
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _disk_status
	.globl _validate
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_validate.c:42: FRESULT validate (	/* Returns FR_OK or FR_INVALID_OBJECT */
;	---------------------------------
; Function validate
; ---------------------------------
_validate::
	call	___sdcc_enter_ix
	push	af
	dec	sp
;fatFs\ff_validate.c:47: FRESULT res = FR_INVALID_OBJECT;
	ld	-3 (ix), #0x09
;fatFs\ff_validate.c:50: if (obj && obj->fs && obj->fs->fs_type && obj->id == obj->fs->id) {	/* Test if the object is valid */
	ld	e, 4 (ix)
	ld	d, 5 (ix)
	ld	a, 5 (ix)
	or	a, 4 (ix)
	jr	Z,00104$
	ld	l, e
	ld	h, d
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	a, b
	or	a, c
	jr	Z,00104$
	ld	a, (bc)
	or	a, a
	jr	Z,00104$
	ld	l, e
	ld	h, d
	inc	hl
	inc	hl
	ld	a, (hl)
	ld	-2 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-1 (ix), a
	ld	l, c
	ld	h, b
	ld	bc, #0x0004
	add	hl, bc
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	cp	a, a
	sbc	hl, bc
	jr	NZ,00104$
;fatFs\ff_validate.c:69: if (!(disk_status() & STA_NOINIT)) { /* Test if the phsical drive is kept initialized */
	push	de
	call	_disk_status
	ld	a, l
	pop	de
	rrca
	jr	C,00104$
;fatFs\ff_validate.c:71: res = FR_OK;
	xor	a, a
	ld	-3 (ix), a
00104$:
;fatFs\ff_validate.c:75: *rfs = (res == FR_OK) ? obj->fs : 0;	/* Corresponding filesystem object */
	ld	c, 6 (ix)
	ld	b, 7 (ix)
	ld	a, -3 (ix)
	or	a, a
	jr	NZ,00110$
	ex	de,hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	jr	00111$
00110$:
	ld	de, #0x0000
00111$:
	ld	a, e
	ld	(bc), a
	inc	bc
	ld	a, d
	ld	(bc), a
;fatFs\ff_validate.c:76: return res;
	ld	l, -3 (ix)
;fatFs\ff_validate.c:77: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
