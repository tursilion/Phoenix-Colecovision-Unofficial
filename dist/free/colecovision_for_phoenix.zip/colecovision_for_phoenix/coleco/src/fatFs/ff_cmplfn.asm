;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_cmplfn
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _cmp_lfn
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_cmplfn.c:43: int cmp_lfn (		/* 1:matched, 0:not matched */
;	---------------------------------
; Function cmp_lfn
; ---------------------------------
_cmp_lfn::
	call	___sdcc_enter_ix
	ld	hl, #-11
	add	hl, sp
	ld	sp, hl
;fatFs\ff_cmplfn.c:52: if (ld_word(dir + LDIR_FstClusLO) != 0) return 0;	/* Check LDIR_FstClusLO */
	ld	a, 6 (ix)
	add	a, #0x1a
	ld	e, a
	ld	a, 7 (ix)
	adc	a, #0x00
	ld	d, a
	ld	l, e
	ld	h, d
	inc	hl
	ld	b, (hl)
	ld	c, #0x00
	ld	a, (de)
	ld	e, a
	ld	d, #0x00
	ld	a, c
	or	a, e
	ld	c, a
	ld	a, b
	or	a, d
	or	a, c
	jr	Z,00102$
	ld	hl, #0x0000
	jp	00119$
00102$:
;fatFs\ff_cmplfn.c:54: i = ((dir[LDIR_Ord] & 0x3F) - 1) * 13;	/* Offset in the LFN buffer */
	ld	c, 6 (ix)
	ld	b, 7 (ix)
	ld	a, (bc)
	ld	-11 (ix), a
	and	a, #0x3f
	ld	e, a
	ld	d, #0x00
	dec	de
	ld	l, e
	ld	h, d
	add	hl, hl
	add	hl, de
	add	hl, hl
	add	hl, hl
	add	hl, de
	ld	-10 (ix), l
	ld	-9 (ix), h
;fatFs\ff_cmplfn.c:56: for (wc = 1, s = 0; s < 13; s++) {		/* Process all characters in the entry */
	ld	de, #0x0001
	ld	a, -10 (ix)
	ld	-4 (ix), a
	ld	a, -9 (ix)
	ld	-3 (ix), a
	xor	a, a
	ld	-2 (ix), a
	ld	-1 (ix), a
00117$:
	ld	a, -2 (ix)
	sub	a, #0x0d
	ld	a, -1 (ix)
	sbc	a, #0x00
	jp	NC, 00111$
;fatFs\ff_cmplfn.c:57: uc = ld_word(dir + LfnOfs[s]);		/* Pick an LFN character */
	ld	a, #<(_LfnOfs)
	add	a, -2 (ix)
	ld	l, a
	ld	a, #>(_LfnOfs)
	adc	a, -1 (ix)
	ld	h, a
	ld	a, (hl)
	add	a, c
	ld	-8 (ix), a
	ld	a, #0x00
	adc	a, b
	ld	-7 (ix), a
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	inc	hl
	ld	l, (hl)
	ld	-5 (ix), l
	ld	-6 (ix), #0x00
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	ld	l, (hl)
	ld	h, #0x00
	ld	a, l
	or	a, -6 (ix)
	ld	l, a
	ld	a, h
	or	a, -5 (ix)
	ld	h, a
	ld	-6 (ix), l
	ld	-5 (ix), h
;fatFs\ff_cmplfn.c:58: if (wc != 0) {
	ld	a, d
	or	a, e
	jr	Z,00109$
;fatFs\ff_cmplfn.c:59: if (i >= FF_MAX_LFN || ff_wtoupper(uc) != ff_wtoupper(lfnbuf[i++])) {	/* Compare it */
	ld	a, -4 (ix)
	sub	a, #0x7f
	ld	a, -3 (ix)
	sbc	a, #0x00
	jr	NC,00103$
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	inc	-4 (ix)
	jr	NZ,00166$
	inc	-3 (ix)
00166$:
	ld	a, -4 (ix)
	ld	-10 (ix), a
	ld	a, -3 (ix)
	ld	-9 (ix), a
	add	hl, hl
	ex	de,hl
	ld	l, 4 (ix)
	ld	h, 5 (ix)
	add	hl, de
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	cp	a, a
	sbc	hl, de
	jr	Z,00104$
00103$:
;fatFs\ff_cmplfn.c:60: return 0;					/* Not matched */
	ld	hl, #0x0000
	jr	00119$
00104$:
;fatFs\ff_cmplfn.c:62: wc = uc;
	ld	e, -6 (ix)
	ld	d, -5 (ix)
	jr	00118$
00109$:
;fatFs\ff_cmplfn.c:64: if (uc != 0xFFFF) return 0;		/* Check filler */
	ld	a, -6 (ix)
	ld	h, -5 (ix)
	and	a, h
	inc	a
	jr	Z,00118$
	ld	hl, #0x0000
	jr	00119$
00118$:
;fatFs\ff_cmplfn.c:56: for (wc = 1, s = 0; s < 13; s++) {		/* Process all characters in the entry */
	inc	-2 (ix)
	jp	NZ,00117$
	inc	-1 (ix)
	jp	00117$
00111$:
;fatFs\ff_cmplfn.c:68: if ((dir[LDIR_Ord] & LLEF) && wc && lfnbuf[i]) return 0;	/* Last segment matched but different length */
	bit	6, -11 (ix)
	jr	Z,00113$
	ld	a, d
	or	a, e
	jr	Z,00113$
	ld	c, -10 (ix)
	ld	b, -9 (ix)
	sla	c
	rl	b
	ld	l, 4 (ix)
	ld	h, 5 (ix)
	add	hl, bc
	ld	a, (hl)
	inc	hl
	ld	c, (hl)
	or	a, c
	jr	Z,00113$
	ld	hl, #0x0000
	jr	00119$
00113$:
;fatFs\ff_cmplfn.c:70: return 1;		/* The part of LFN matched */
	ld	hl, #0x0001
00119$:
;fatFs\ff_cmplfn.c:71: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
