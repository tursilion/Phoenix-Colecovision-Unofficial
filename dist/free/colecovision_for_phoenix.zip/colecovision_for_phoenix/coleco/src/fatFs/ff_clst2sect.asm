;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_clst2sect
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _clst2sect
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_clst2sect.c:42: DWORD clst2sect (	/* !=0:Sector number, 0:Failed (invalid cluster#) */
;	---------------------------------
; Function clst2sect
; ---------------------------------
_clst2sect::
	call	___sdcc_enter_ix
	push	af
	push	af
;fatFs\ff_clst2sect.c:47: clst -= 2;		/* Cluster number is origin from 2 */
	ld	a, 6 (ix)
	add	a, #0xfe
	ld	6 (ix), a
	ld	a, 7 (ix)
	adc	a, #0xff
	ld	7 (ix), a
	ld	a, 8 (ix)
	adc	a, #0xff
	ld	8 (ix), a
	ld	a, 9 (ix)
	adc	a, #0xff
	ld	9 (ix), a
;fatFs\ff_clst2sect.c:48: if (clst >= fs->n_fatent - 2) return 0;		/* Is it invalid cluster number? */
	ld	c, 4 (ix)
	ld	b, 5 (ix)
	ld	l, c
	ld	h, b
	ld	de, #0x000c
	add	hl, de
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	inc	hl
	inc	hl
	ld	a, (hl)
	dec	hl
	ld	l, (hl)
	ld	h, a
	ld	a, e
	add	a, #0xfe
	ld	e, a
	ld	a, d
	adc	a, #0xff
	ld	d, a
	ld	a, l
	adc	a, #0xff
	ld	l, a
	ld	a, h
	adc	a, #0xff
	ld	h, a
	ld	a, 6 (ix)
	sub	a, e
	ld	a, 7 (ix)
	sbc	a, d
	ld	a, 8 (ix)
	sbc	a, l
	ld	a, 9 (ix)
	sbc	a, h
	jr	C,00102$
	ld	hl,#0x0000
	ld	e,l
	ld	d,h
	jr	00103$
00102$:
;fatFs\ff_clst2sect.c:49: return fs->database + fs->csize * clst;		/* Start sector number of the cluster */
	ld	l, c
	ld	h, b
	ld	de, #0x0020
	add	hl, de
	ld	a, (hl)
	ld	-4 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-3 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-2 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-1 (ix), a
	ld	l, c
	ld	h, b
	ld	de, #0x0008
	add	hl, de
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	de, #0x0000
	ld	l, 8 (ix)
	ld	h, 9 (ix)
	push	hl
	ld	l, 6 (ix)
	ld	h, 7 (ix)
	push	hl
	push	de
	push	bc
	call	__mullong
	pop	af
	pop	af
	pop	af
	pop	af
	ld	a, l
	add	a, -4 (ix)
	ld	l, a
	ld	a, h
	adc	a, -3 (ix)
	ld	h, a
	ld	a, e
	adc	a, -2 (ix)
	ld	e, a
	ld	a, d
	adc	a, -1 (ix)
	ld	d, a
00103$:
;fatFs\ff_clst2sect.c:50: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
