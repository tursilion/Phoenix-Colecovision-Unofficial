;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_dirsdi
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _get_fat
	.globl _clst2sect
	.globl _dir_sdi
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_dirsdi.c:42: FRESULT dir_sdi (	/* FR_OK(0):succeeded, !=0:error */
;	---------------------------------
; Function dir_sdi
; ---------------------------------
_dir_sdi::
	call	___sdcc_enter_ix
	ld	hl, #-20
	add	hl, sp
	ld	sp, hl
;fatFs\ff_dirsdi.c:48: FATFS *fs = dp->obj.fs;
	ld	a, 4 (ix)
	ld	-16 (ix), a
	ld	a, 5 (ix)
	ld	-15 (ix), a
	ld	a, -16 (ix)
	ld	-14 (ix), a
	ld	a, -15 (ix)
	ld	-13 (ix), a
	ld	l, -16 (ix)
	ld	h, -15 (ix)
	ld	a, (hl)
	ld	-12 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-11 (ix), a
;fatFs\ff_dirsdi.c:51: if (ofs >= (DWORD)((FF_FS_EXFAT && fs->fs_type == FS_EXFAT) ? MAX_DIR_EX : MAX_DIR) || ofs % SZDIRE) {	/* Check range of offset and alignment */
	ld	a, 8 (ix)
	sub	a, #0x20
	ld	a, 9 (ix)
	sbc	a, #0x00
	jr	NC,00101$
	ld	a, 6 (ix)
	and	a, #0x1f
	jr	Z,00102$
00101$:
;fatFs\ff_dirsdi.c:52: return FR_INT_ERR;
	ld	l, #0x02
	jp	00124$
00102$:
;fatFs\ff_dirsdi.c:54: dp->dptr = ofs;				/* Set current offset */
	ld	a, -16 (ix)
	add	a, #0x0e
	ld	e, a
	ld	a, -15 (ix)
	adc	a, #0x00
	ld	d, a
	ld	hl, #0x001a
	add	hl, sp
	ld	bc, #0x0004
	ldir
;fatFs\ff_dirsdi.c:55: clst = dp->obj.sclust;		/* Table start cluster (0:root) */
	ld	l, -16 (ix)
	ld	h, -15 (ix)
	ld	de, #0x0006
	add	hl, de
	ld	a, (hl)
	ld	-10 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-9 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-8 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-7 (ix), a
;fatFs\ff_dirsdi.c:57: clst = fs->dirbase;
	ld	a, -12 (ix)
	add	a, #0x1c
	ld	-2 (ix), a
	ld	a, -11 (ix)
	adc	a, #0x00
	ld	-1 (ix), a
;fatFs\ff_dirsdi.c:56: if (clst == 0 && fs->fs_type >= FS_FAT32) {	/* Replace cluster# 0 with root cluster# */
	ld	a, -7 (ix)
	or	a, -8 (ix)
	or	a, -9 (ix)
	or	a, -10 (ix)
	jr	NZ,00107$
	ld	l, -12 (ix)
	ld	h, -11 (ix)
	ld	a, (hl)
	sub	a, #0x03
	jr	C,00107$
;fatFs\ff_dirsdi.c:57: clst = fs->dirbase;
	ld	e, -2 (ix)
	ld	d, -1 (ix)
	ld	hl, #0x000a
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
;fatFs\ff_dirsdi.c:58: if (FF_FS_EXFAT) dp->obj.stat = 0;	/* exFAT: Root dir has an FAT chain */
00107$:
;fatFs\ff_dirsdi.c:63: dp->sect = fs->dirbase;
	ld	a, -16 (ix)
	add	a, #0x16
	ld	-6 (ix), a
	ld	a, -15 (ix)
	adc	a, #0x00
	ld	-5 (ix), a
;fatFs\ff_dirsdi.c:61: if (clst == 0) {	/* table (root-directory on the FAT volume) */
	ld	a, -7 (ix)
	or	a, -8 (ix)
	or	a, -9 (ix)
	or	a, -10 (ix)
	jr	NZ,00120$
;fatFs\ff_dirsdi.c:62: if (ofs / SZDIRE >= fs->n_rootdir) return FR_INT_ERR;	/* Is index out of range? */
	ld	c, 6 (ix)
	ld	b, 7 (ix)
	ld	e, 8 (ix)
	ld	d, 9 (ix)
	ld	a, #0x05
00183$:
	srl	d
	rr	e
	rr	b
	rr	c
	dec	a
	jr	NZ, 00183$
	ld	l, -12 (ix)
	ld	h, -11 (ix)
	push	bc
	ld	bc, #0x0006
	add	hl, bc
	pop	bc
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	-20 (ix), a
	ld	-19 (ix), h
	xor	a, a
	ld	-18 (ix), a
	ld	-17 (ix), a
	ld	a, c
	sub	a, -20 (ix)
	ld	a, b
	sbc	a, -19 (ix)
	ld	a, e
	sbc	a, -18 (ix)
	ld	a, d
	sbc	a, -17 (ix)
	jr	C,00110$
	ld	l, #0x02
	jp	00124$
00110$:
;fatFs\ff_dirsdi.c:63: dp->sect = fs->dirbase;
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	inc	hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
	inc	hl
	ld	(hl), e
	inc	hl
	ld	(hl), d
	jp	00121$
00120$:
;fatFs\ff_dirsdi.c:65: csz = (DWORD)fs->csize * SS(fs);	/* Bytes per cluster */
	ld	l, -12 (ix)
	ld	h, -11 (ix)
	ld	de, #0x0008
	add	hl, de
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	e, #0x00
	ld	-3 (ix), c
	ld	-2 (ix), b
	ld	-1 (ix), e
	xor	a, a
	ld	-4 (ix), a
	sla	-3 (ix)
	rl	-2 (ix)
	rl	-1 (ix)
;fatFs\ff_dirsdi.c:66: while (ofs >= csz) {				/* Follow cluster chain */
	ld	c, -12 (ix)
	ld	b, -11 (ix)
00116$:
	ld	a, 6 (ix)
	sub	a, -4 (ix)
	ld	a, 7 (ix)
	sbc	a, -3 (ix)
	ld	a, 8 (ix)
	sbc	a, -2 (ix)
	ld	a, 9 (ix)
	sbc	a, -1 (ix)
	jp	C, 00118$
;fatFs\ff_dirsdi.c:67: clst = get_fat(&dp->obj, clst);				/* Get next cluster */
	push	bc
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	push	hl
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	push	hl
	ld	l, -14 (ix)
	ld	h, -13 (ix)
	push	hl
	call	_get_fat
	pop	af
	pop	af
	pop	af
	pop	bc
	ld	-10 (ix), l
	ld	-9 (ix), h
	ld	-8 (ix), e
	ld	-7 (ix), d
;fatFs\ff_dirsdi.c:68: if (clst == 0xFFFFFFFF) return FR_DISK_ERR;	/* Disk error */
	ld	a, -10 (ix)
	and	a, -9 (ix)
	and	a, -8 (ix)
	and	a, -7 (ix)
	inc	a
	jr	NZ,00112$
	ld	l, #0x01
	jp	00124$
00112$:
;fatFs\ff_dirsdi.c:69: if (clst < 2 || clst >= fs->n_fatent) return FR_INT_ERR;	/* Reached to end of table or internal error */
	ld	a, -10 (ix)
	sub	a, #0x02
	ld	a, -9 (ix)
	sbc	a, #0x00
	ld	a, -8 (ix)
	sbc	a, #0x00
	ld	a, -7 (ix)
	sbc	a, #0x00
	jr	C,00113$
	ld	l, c
	ld	h, b
	ld	de, #0x000c
	add	hl, de
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	inc	hl
	inc	hl
	ld	a, (hl)
	dec	hl
	ld	l, (hl)
	ld	h, a
	ld	a, -10 (ix)
	sub	a, e
	ld	a, -9 (ix)
	sbc	a, d
	ld	a, -8 (ix)
	sbc	a, l
	ld	a, -7 (ix)
	sbc	a, h
	jr	C,00114$
00113$:
	ld	l, #0x02
	jp	00124$
00114$:
;fatFs\ff_dirsdi.c:70: ofs -= csz;
	ld	a, 6 (ix)
	sub	a, -4 (ix)
	ld	6 (ix), a
	ld	a, 7 (ix)
	sbc	a, -3 (ix)
	ld	7 (ix), a
	ld	a, 8 (ix)
	sbc	a, -2 (ix)
	ld	8 (ix), a
	ld	a, 9 (ix)
	sbc	a, -1 (ix)
	ld	9 (ix), a
	jp	00116$
00118$:
;fatFs\ff_dirsdi.c:72: dp->sect = clst2sect(fs, clst);
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	push	hl
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	push	hl
	ld	l, -12 (ix)
	ld	h, -11 (ix)
	push	hl
	call	_clst2sect
	pop	af
	pop	af
	pop	af
	ld	c, l
	ld	b, h
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
	inc	hl
	ld	(hl), e
	inc	hl
	ld	(hl), d
00121$:
;fatFs\ff_dirsdi.c:74: dp->clust = clst;					/* Current cluster# */
	ld	a, -16 (ix)
	add	a, #0x12
	ld	e, a
	ld	a, -15 (ix)
	adc	a, #0x00
	ld	d, a
	ld	hl, #0x000a
	add	hl, sp
	ld	bc, #0x0004
	ldir
;fatFs\ff_dirsdi.c:75: if (dp->sect == 0) return FR_INT_ERR;
	ld	e, -6 (ix)
	ld	d, -5 (ix)
	ld	hl, #0x0010
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	ld	a, -1 (ix)
	or	a, -2 (ix)
	or	a, -3 (ix)
	or	a, -4 (ix)
	jr	NZ,00123$
	ld	l, #0x02
	jp	00124$
00123$:
;fatFs\ff_dirsdi.c:76: dp->sect += ofs / SS(fs);			/* Sector# of the directory entry */
	ld	c, 7 (ix)
	ld	b, 8 (ix)
	ld	e, 9 (ix)
	ld	d, #0x00
	srl	e
	rr	b
	rr	c
	ld	a, c
	add	a, -4 (ix)
	ld	c, a
	ld	a, b
	adc	a, -3 (ix)
	ld	b, a
	ld	a, e
	adc	a, -2 (ix)
	ld	e, a
	ld	a, d
	adc	a, -1 (ix)
	ld	d, a
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
	inc	hl
	ld	(hl), e
	inc	hl
	ld	(hl), d
;fatFs\ff_dirsdi.c:77: dp->dir = fs->win + (ofs % SS(fs));	/* Pointer to the entry in the win[] */
	ld	a, -16 (ix)
	add	a, #0x1a
	ld	-2 (ix), a
	ld	a, -15 (ix)
	adc	a, #0x00
	ld	-1 (ix), a
	ld	a, -12 (ix)
	add	a, #0x28
	ld	-4 (ix), a
	ld	a, -11 (ix)
	adc	a, #0x00
	ld	-3 (ix), a
	ld	a, 6 (ix)
	ld	-10 (ix), a
	ld	a, 7 (ix)
	and	a, #0x01
	ld	-9 (ix), a
	ld	-8 (ix), #0x00
	ld	-7 (ix), #0x00
	ld	a, -10 (ix)
	add	a, -4 (ix)
	ld	-6 (ix), a
	ld	a, -9 (ix)
	adc	a, -3 (ix)
	ld	-5 (ix), a
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	a, -6 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -5 (ix)
	ld	(hl), a
;fatFs\ff_dirsdi.c:79: return FR_OK;
	ld	l, #0x00
00124$:
;fatFs\ff_dirsdi.c:80: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
