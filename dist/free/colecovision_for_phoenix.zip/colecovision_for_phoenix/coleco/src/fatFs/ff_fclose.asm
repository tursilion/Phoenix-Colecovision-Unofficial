;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_fclose
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _validate
	.globl _f_close
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_fclose.c:42: FRESULT f_close (
;	---------------------------------
; Function f_close
; ---------------------------------
_f_close::
	push	af
;fatFs\ff_fclose.c:54: res = validate(&fp->obj, &fs);	/* Lock volume */
	ld	hl, #0
	add	hl, sp
	ld	iy, #4
	add	iy, sp
	ld	c, 0 (iy)
	ld	b, 1 (iy)
	push	bc
	push	hl
	push	bc
	call	_validate
	pop	af
	pop	af
	ld	a, l
	pop	bc
	ld	e, a
;fatFs\ff_fclose.c:55: if (res == FR_OK) {
	or	a, a
	jr	NZ,00102$
;fatFs\ff_fclose.c:60: fp->obj.fs = 0;	/* Invalidate file object */
	xor	a, a
	ld	(bc), a
	inc	bc
	ld	(bc), a
00102$:
;fatFs\ff_fclose.c:67: return res;
	ld	l, e
;fatFs\ff_fclose.c:68: }
	pop	af
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
