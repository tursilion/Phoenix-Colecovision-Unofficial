;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_tchar2uni
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _tchar2uni
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_tchar2uni.c:41: DWORD tchar2uni (	/* Returns character in UTF-16 encoding (>=0x10000 on double encoding unit, 0xFFFFFFFF on decode error) */
;	---------------------------------
; Function tchar2uni
; ---------------------------------
_tchar2uni::
	call	___sdcc_enter_ix
	push	af
	push	af
;fatFs\ff_tchar2uni.c:46: const TCHAR *p = *str;
	ld	c, 4 (ix)
	ld	b, 5 (ix)
	ld	l, c
	ld	h, b
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
;fatFs\ff_tchar2uni.c:95: wc = (BYTE)*p++;			/* Get a byte */
	ld	a, (de)
	inc	de
	ld	l, a
	ld	h, #0x00
;fatFs\ff_tchar2uni.c:101: if (wc != 0) {
	ld	a, h
	or	a, l
	jr	Z,00108$
;fatFs\ff_tchar2uni.c:103: if (wc == 0) return 0xFFFFFFFF;	/* Invalid code? */
	ld	a, h
	or	a, l
	jr	NZ,00108$
	ld	hl,#0xffff
	ld	e,l
	ld	d,h
	jr	00109$
00108$:
;fatFs\ff_tchar2uni.c:105: uc = wc;
	ld	-4 (ix), l
	ld	-3 (ix), h
	xor	a, a
	ld	-2 (ix), a
	ld	-1 (ix), a
;fatFs\ff_tchar2uni.c:108: *str = p;	/* Next read pointer */
	ld	a, e
	ld	(bc), a
	inc	bc
	ld	a, d
	ld	(bc), a
;fatFs\ff_tchar2uni.c:109: return uc;
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	e, -2 (ix)
	ld	d, -1 (ix)
00109$:
;fatFs\ff_tchar2uni.c:110: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
