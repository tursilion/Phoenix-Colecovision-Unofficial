;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_opendir
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _find_volume
	.globl _follow_path
	.globl _ld_clust
	.globl _dir_sdi
	.globl _f_opendir
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFS/ff_opendir.c:45: FRESULT f_opendir (
;	---------------------------------
; Function f_opendir
; ---------------------------------
_f_opendir::
	call	___sdcc_enter_ix
	push	af
	push	af
	push	af
	push	af
;fatFS/ff_opendir.c:54: if (!dp) return FR_INVALID_OBJECT;
	ld	a, 5 (ix)
	or	a, 4 (ix)
	jr	NZ,00102$
	ld	l, #0x09
	jp	00118$
00102$:
;fatFS/ff_opendir.c:65: );
	ld	hl, #0
	add	hl, sp
	push	hl
	call	_find_volume
	pop	af
	ld	c, l
;fatFS/ff_opendir.c:67: dp->obj.fs = fs;
	ld	e, 4 (ix)
	ld	d, 5 (ix)
;fatFS/ff_opendir.c:66: if (res == FR_OK) {
	ld	a, c
	or	a, a
	jp	NZ, 00115$
;fatFS/ff_opendir.c:67: dp->obj.fs = fs;
	ld	l, e
	ld	h, d
	ld	a, -8 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -7 (ix)
	ld	(hl), a
;fatFS/ff_opendir.c:69: res = follow_path(dp, path);			/* Follow the path to the directory */
	push	de
	ld	l, 6 (ix)
	ld	h, 7 (ix)
	push	hl
	push	de
	call	_follow_path
	pop	af
	pop	af
	ld	a, l
	pop	de
;fatFS/ff_opendir.c:70: if (res == FR_OK) {						/* Follow completed */
	ld	c, a
	or	a, a
	jp	NZ, 00111$
;fatFS/ff_opendir.c:71: if (!(dp->fn[NSFLAG] & NS_NONAME)) {	/* It is not the origin directory itself */
	ld	l, e
	ld	h, d
	push	bc
	ld	bc, #0x0027
	add	hl, bc
	pop	bc
	ld	a, (hl)
	rlca
	jr	C,00107$
;fatFS/ff_opendir.c:72: if (dp->obj.attr & AM_DIR) {		/* This object is a sub-directory */
	ld	l, e
	ld	h, d
	inc	hl
	inc	hl
	inc	hl
	inc	hl
	bit	4, (hl)
	jr	Z,00104$
;fatFS/ff_opendir.c:82: dp->obj.sclust = ld_clust(fs, dp->dir);	/* Get object allocation info */
	ld	hl, #0x0006
	add	hl, de
	ld	-6 (ix), l
	ld	-5 (ix), h
	ld	l, e
	ld	h, d
	push	bc
	ld	bc, #0x001a
	add	hl, bc
	pop	bc
	ld	b, (hl)
	inc	hl
	ld	h, (hl)
	push	bc
	push	de
	ld	l, b
	push	hl
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	push	hl
	call	_ld_clust
	pop	af
	pop	af
	ld	-4 (ix), l
	ld	-3 (ix), h
	ld	-2 (ix), e
	ld	-1 (ix), d
	pop	de
	pop	bc
	push	de
	push	bc
	ld	e, -6 (ix)
	ld	d, -5 (ix)
	ld	hl, #0x0008
	add	hl, sp
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
	jr	00107$
00104$:
;fatFS/ff_opendir.c:85: res = FR_NO_PATH;
	ld	c, #0x05
00107$:
;fatFS/ff_opendir.c:88: if (res == FR_OK) {
	ld	a, c
	or	a, a
	jr	NZ,00111$
;fatFS/ff_opendir.c:89: dp->obj.id = fs->id;
	ld	hl, #0x0002
	add	hl, de
	ld	-2 (ix), l
	ld	-1 (ix), h
	pop	hl
	push	hl
	ld	bc, #0x0004
	add	hl, bc
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
;fatFS/ff_opendir.c:90: res = dir_sdi(dp, 0);			/* Rewind directory */
	push	de
	ld	hl, #0x0000
	push	hl
	ld	hl, #0x0000
	push	hl
	push	de
	call	_dir_sdi
	pop	af
	pop	af
	pop	af
	ld	a, l
	pop	de
	ld	c, a
00111$:
;fatFS/ff_opendir.c:104: if (res == FR_NO_FILE) res = FR_NO_PATH;
	ld	a, c
	sub	a, #0x04
	jr	NZ,00115$
	ld	c, #0x05
00115$:
;fatFS/ff_opendir.c:106: if (res != FR_OK) dp->obj.fs = 0;		/* Invalidate the directory object if function faild */
	ld	a, c
	or	a, a
	jr	Z,00117$
	xor	a, a
	ld	(de), a
	inc	de
	ld	(de), a
00117$:
;fatFS/ff_opendir.c:108: LEAVE_FF(fs, res);
	ld	l, c
00118$:
;fatFS/ff_opendir.c:109: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
