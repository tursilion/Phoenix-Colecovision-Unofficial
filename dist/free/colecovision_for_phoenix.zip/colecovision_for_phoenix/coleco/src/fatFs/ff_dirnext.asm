;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_dirnext
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _get_fat
	.globl _clst2sect
	.globl _dir_next
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_dirnext.c:42: FRESULT dir_next (	/* FR_OK(0):succeeded, FR_NO_FILE:End of table, FR_DENIED:Could not stretch */
;	---------------------------------
; Function dir_next
; ---------------------------------
_dir_next::
	call	___sdcc_enter_ix
	ld	hl, #-26
	add	hl, sp
	ld	sp, hl
;fatFs\ff_dirnext.c:48: FATFS *fs = dp->obj.fs;
	ld	a, 4 (ix)
	ld	-26 (ix), a
	ld	a, 5 (ix)
	ld	-25 (ix), a
	pop	hl
	push	hl
	ld	a, (hl)
	ld	-24 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-23 (ix), a
;fatFs\ff_dirnext.c:51: ofs = dp->dptr + SZDIRE;	/* Next entry */
	ld	a, -26 (ix)
	add	a, #0x0e
	ld	-22 (ix), a
	ld	a, -25 (ix)
	adc	a, #0x00
	ld	-21 (ix), a
	ld	l, -22 (ix)
	ld	h, -21 (ix)
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	inc	hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	a, c
	add	a, #0x20
	ld	-20 (ix), a
	ld	a, b
	adc	a, #0x00
	ld	-19 (ix), a
	ld	a, e
	adc	a, #0x00
	ld	-18 (ix), a
	ld	a, d
	adc	a, #0x00
	ld	-17 (ix), a
;fatFs\ff_dirnext.c:52: if (ofs >= (DWORD)((FF_FS_EXFAT && fs->fs_type == FS_EXFAT) ? MAX_DIR_EX : MAX_DIR)) dp->sect = 0;	/* Disable it if the offset reached the max value */
	ld	a, -26 (ix)
	add	a, #0x16
	ld	-16 (ix), a
	ld	a, -25 (ix)
	adc	a, #0x00
	ld	-15 (ix), a
	ld	a, -18 (ix)
	sub	a, #0x20
	ld	a, -17 (ix)
	sbc	a, #0x00
	jr	C,00102$
	ld	l, -16 (ix)
	ld	h, -15 (ix)
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	ld	(hl), a
00102$:
;fatFs\ff_dirnext.c:53: if (dp->sect == 0) return FR_NO_FILE;	/* Report EOT if it has been disabled */
	ld	e, -16 (ix)
	ld	d, -15 (ix)
	ld	hl, #0x0016
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	ld	a, -1 (ix)
	or	a, -2 (ix)
	or	a, -3 (ix)
	or	a, -4 (ix)
	jr	NZ,00104$
	ld	l, #0x04
	jp	00122$
00104$:
;fatFs\ff_dirnext.c:55: if (ofs % SS(fs) == 0) {	/* Sector changed? */
	ld	a, -20 (ix)
	ld	-14 (ix), a
	ld	a, -19 (ix)
	and	a, #0x01
	ld	-13 (ix), a
	ld	-12 (ix), #0x00
	ld	-11 (ix), #0x00
	ld	a, #0x00
	or	a, -12 (ix)
	or	a, -13 (ix)
	or	a, -14 (ix)
	jp	NZ, 00121$
;fatFs\ff_dirnext.c:56: dp->sect++;				/* Next sector */
	ld	a, -4 (ix)
	add	a, #0x01
	ld	c, a
	ld	a, -3 (ix)
	adc	a, #0x00
	ld	b, a
	ld	a, -2 (ix)
	adc	a, #0x00
	ld	e, a
	ld	a, -1 (ix)
	adc	a, #0x00
	ld	d, a
	ld	l, -16 (ix)
	ld	h, -15 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
	inc	hl
	ld	(hl), e
	inc	hl
	ld	(hl), d
;fatFs\ff_dirnext.c:58: if (dp->clust == 0) {	/* table */
	ld	a, -26 (ix)
	add	a, #0x12
	ld	-10 (ix), a
	ld	a, -25 (ix)
	adc	a, #0x00
	ld	-9 (ix), a
	ld	e, -10 (ix)
	ld	d, -9 (ix)
	ld	hl, #0x0012
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	ld	a, -5 (ix)
	or	a, -6 (ix)
	or	a, -7 (ix)
	or	a, -8 (ix)
	jr	NZ,00118$
;fatFs\ff_dirnext.c:59: if (ofs / SZDIRE >= fs->n_rootdir) {	/* Report EOT if it reached end of table */
	ld	c, -20 (ix)
	ld	b, -19 (ix)
	ld	e, -18 (ix)
	ld	d, -17 (ix)
	ld	a, #0x05
00180$:
	srl	d
	rr	e
	rr	b
	rr	c
	dec	a
	jr	NZ, 00180$
	ld	l, -24 (ix)
	ld	h, -23 (ix)
	push	bc
	ld	bc, #0x0006
	add	hl, bc
	pop	bc
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	-4 (ix), a
	ld	-3 (ix), h
	xor	a, a
	ld	-2 (ix), a
	ld	-1 (ix), a
	ld	a, c
	sub	a, -4 (ix)
	ld	a, b
	sbc	a, -3 (ix)
	ld	a, e
	sbc	a, -2 (ix)
	ld	a, d
	sbc	a, -1 (ix)
	jp	C, 00121$
;fatFs\ff_dirnext.c:60: dp->sect = 0; return FR_NO_FILE;
	ld	l, -16 (ix)
	ld	h, -15 (ix)
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	ld	(hl), a
	ld	l, #0x04
	jp	00122$
00118$:
;fatFs\ff_dirnext.c:64: if ((ofs / SS(fs) & (fs->csize - 1)) == 0) {	/* Cluster changed? */
	ld	c, -19 (ix)
	ld	b, -18 (ix)
	ld	e, -17 (ix)
	ld	d, #0x00
	srl	e
	rr	b
	rr	c
	ld	l, -24 (ix)
	ld	h, -23 (ix)
	push	bc
	ld	bc, #0x0009
	add	hl, bc
	pop	bc
	ld	a, (hl)
	dec	hl
	ld	l, (hl)
	ld	h, a
	dec	hl
	ld	-4 (ix), l
	ld	-3 (ix), h
	xor	a, a
	ld	-2 (ix), a
	ld	-1 (ix), a
	ld	a, c
	and	a, -4 (ix)
	push	af
	ld	a, b
	and	a, -3 (ix)
	ld	c, a
	ld	a, e
	and	a, -2 (ix)
	ld	l, a
	ld	a, d
	and	a, -1 (ix)
	ld	h, a
	pop	af
	or	a, h
	or	a, l
	or	a, c
	jp	NZ, 00121$
;fatFs\ff_dirnext.c:65: clst = get_fat(&dp->obj, dp->clust);		/* Get next cluster */
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	push	hl
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	push	hl
	ld	l, -26 (ix)
	ld	h, -25 (ix)
	push	hl
	call	_get_fat
	pop	af
	pop	af
	pop	af
	ld	-4 (ix), l
	ld	-3 (ix), h
	ld	-2 (ix), e
	ld	-1 (ix), d
;fatFs\ff_dirnext.c:66: if (clst <= 1) return FR_INT_ERR;			/* Internal error */
	ld	a, #0x01
	cp	a, -4 (ix)
	ld	a, #0x00
	sbc	a, -3 (ix)
	ld	a, #0x00
	sbc	a, -2 (ix)
	ld	a, #0x00
	sbc	a, -1 (ix)
	jr	C,00108$
	ld	l, #0x02
	jp	00122$
00108$:
;fatFs\ff_dirnext.c:67: if (clst == 0xFFFFFFFF) return FR_DISK_ERR;	/* Disk error */
	ld	a, -4 (ix)
	and	a, -3 (ix)
	and	a, -2 (ix)
	and	a, -1 (ix)
	inc	a
	jr	NZ,00110$
	ld	l, #0x01
	jp	00122$
00110$:
;fatFs\ff_dirnext.c:68: if (clst >= fs->n_fatent) {					/* It reached end of dynamic table */
	pop	bc
	pop	hl
	push	hl
	push	bc
	ld	de, #0x000c
	add	hl, de
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	inc	hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	a, -4 (ix)
	sub	a, c
	ld	a, -3 (ix)
	sbc	a, b
	ld	a, -2 (ix)
	sbc	a, e
	ld	a, -1 (ix)
	sbc	a, d
	jr	C,00114$
;fatFs\ff_dirnext.c:80: if (!stretch) dp->sect = 0;					/* (this line is to suppress compiler warning) */
	ld	a, 7 (ix)
	or	a, 6 (ix)
	jr	NZ,00112$
	ld	l, -16 (ix)
	ld	h, -15 (ix)
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	ld	(hl), a
00112$:
;fatFs\ff_dirnext.c:81: dp->sect = 0; return FR_NO_FILE;			/* Report EOT */
	ld	l, -16 (ix)
	ld	h, -15 (ix)
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	ld	(hl), a
	ld	l, #0x04
	jp	00122$
00114$:
;fatFs\ff_dirnext.c:84: dp->clust = clst;		/* Initialize data for new cluster */
	ld	e, -10 (ix)
	ld	d, -9 (ix)
	ld	hl, #0x0016
	add	hl, sp
	ld	bc, #0x0004
	ldir
;fatFs\ff_dirnext.c:85: dp->sect = clst2sect(fs, clst);
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	push	hl
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	push	hl
	ld	l, -24 (ix)
	ld	h, -23 (ix)
	push	hl
	call	_clst2sect
	pop	af
	pop	af
	pop	af
	ld	c, l
	ld	b, h
	ld	l, -16 (ix)
	ld	h, -15 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
	inc	hl
	ld	(hl), e
	inc	hl
	ld	(hl), d
00121$:
;fatFs\ff_dirnext.c:89: dp->dptr = ofs;						/* Current entry */
	ld	e, -22 (ix)
	ld	d, -21 (ix)
	ld	hl, #0x0006
	add	hl, sp
	ld	bc, #0x0004
	ldir
;fatFs\ff_dirnext.c:90: dp->dir = fs->win + ofs % SS(fs);	/* Pointer to the entry in the win[] */
	ld	a, -26 (ix)
	add	a, #0x1a
	ld	-2 (ix), a
	ld	a, -25 (ix)
	adc	a, #0x00
	ld	-1 (ix), a
	ld	a, -24 (ix)
	add	a, #0x28
	ld	-4 (ix), a
	ld	a, -23 (ix)
	adc	a, #0x00
	ld	-3 (ix), a
	ld	a, -4 (ix)
	add	a, -14 (ix)
	ld	-6 (ix), a
	ld	a, -3 (ix)
	adc	a, -13 (ix)
	ld	-5 (ix), a
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	a, -6 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -5 (ix)
	ld	(hl), a
;fatFs\ff_dirnext.c:92: return FR_OK;
	ld	l, #0x00
00122$:
;fatFs\ff_dirnext.c:93: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
