;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_closedir
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _validate
	.globl _f_closedir
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_closedir.c:42: FRESULT f_closedir (
;	---------------------------------
; Function f_closedir
; ---------------------------------
_f_closedir::
	push	af
;fatFs\ff_closedir.c:50: res = validate(&dp->obj, &fs);	/* Check validity of the file object */
	ld	hl, #0
	add	hl, sp
	ld	iy, #4
	add	iy, sp
	ld	c, 0 (iy)
	ld	b, 1 (iy)
	push	bc
	push	hl
	push	bc
	call	_validate
	pop	af
	pop	af
	ld	a, l
	pop	bc
	ld	e, a
;fatFs\ff_closedir.c:51: if (res == FR_OK) {
	or	a, a
	jr	NZ,00102$
;fatFs\ff_closedir.c:56: dp->obj.fs = 0;	/* Invalidate directory object */
	xor	a, a
	ld	(bc), a
	inc	bc
	ld	(bc), a
00102$:
;fatFs\ff_closedir.c:62: return res;
	ld	l, e
;fatFs\ff_closedir.c:63: }
	pop	af
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
