;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_fmount
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _find_volume
	.globl _f_mount
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFS/ff_fmount.c:42: FRESULT f_mount (
;	---------------------------------
; Function f_mount
; ---------------------------------
_f_mount::
	call	___sdcc_enter_ix
;fatFS/ff_fmount.c:62: cfs = FatFs[vol];					/* Pointer to fs object */
	ld	hl, (#_FatFs + 0)
	ld	c, l
;fatFS/ff_fmount.c:64: if (cfs) {
	ld	a,h
	ld	b,a
	or	a, l
	jr	Z,00102$
;fatFS/ff_fmount.c:71: cfs->fs_type = 0;				/* Clear old fs object */
	xor	a, a
	ld	(bc), a
00102$:
;fatFS/ff_fmount.c:74: if (fs) {
	ld	a, 5 (ix)
	or	a, 4 (ix)
	jr	Z,00104$
;fatFS/ff_fmount.c:75: fs->fs_type = 0;				/* Clear new fs object */
	ld	c, 4 (ix)
	ld	b, 5 (ix)
	xor	a, a
	ld	(bc), a
00104$:
;fatFS/ff_fmount.c:80: FatFs[vol] = fs;					/* Register new fs object */
	ld	hl, #_FatFs
	ld	a, 4 (ix)
	ld	(hl), a
	inc	hl
	ld	a, 5 (ix)
	ld	(hl), a
;fatFS/ff_fmount.c:82: if (opt == 0) return FR_OK;			/* Do not mount now, it will be mounted later */
	ld	a, 8 (ix)
	or	a,a
	jr	NZ,00106$
	ld	l,a
	jr	00107$
00106$:
;fatFS/ff_fmount.c:92: );
	ld	hl, #4
	add	hl, sp
	push	hl
	call	_find_volume
	pop	af
;fatFS/ff_fmount.c:94: LEAVE_FF(fs, res);
00107$:
;fatFS/ff_fmount.c:95: }
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
