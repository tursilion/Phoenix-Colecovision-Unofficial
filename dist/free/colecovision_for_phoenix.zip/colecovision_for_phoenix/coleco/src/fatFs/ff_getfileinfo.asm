;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_getfileinfo
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ld_dword
	.globl _get_fileinfo
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_getfileinfo.c:44: void get_fileinfo (
;	---------------------------------
; Function get_fileinfo
; ---------------------------------
_get_fileinfo::
	call	___sdcc_enter_ix
	ld	hl, #-17
	add	hl, sp
	ld	sp, hl
;fatFs\ff_getfileinfo.c:58: FATFS *fs = dp->obj.fs;
	ld	a, 4 (ix)
	ld	-17 (ix), a
	ld	a, 5 (ix)
	ld	-16 (ix), a
	pop	hl
	push	hl
	ld	a, (hl)
	ld	-2 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-1 (ix), a
;fatFs\ff_getfileinfo.c:64: fno->fname[0] = 0;			/* Invaidate file info */
	ld	a, 6 (ix)
	ld	-15 (ix), a
	ld	a, 7 (ix)
	ld	-14 (ix), a
	ld	a, -15 (ix)
	add	a, #0x05
	ld	-13 (ix), a
	ld	a, -14 (ix)
	adc	a, #0x00
	ld	-12 (ix), a
	ld	l, -13 (ix)
	ld	h, -12 (ix)
	ld	(hl), #0x00
;fatFs\ff_getfileinfo.c:65: if (dp->sect == 0) return;	/* Exit if read pointer has reached end of directory */
	pop	hl
	push	hl
	ld	de, #0x0016
	add	hl, de
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	inc	hl
	ld	a, (hl)
	inc	hl
	or	a, (hl)
	or	a, b
	or	a, c
	jp	Z,00130$
;fatFs\ff_getfileinfo.c:75: if (dp->blk_ofs != 0xFFFFFFFF) {	/* Get LFN if available */
	pop	hl
	push	hl
	ld	de, #0x0028
	add	hl, de
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	inc	hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
;fatFs\ff_getfileinfo.c:77: while (fs->lfnbuf[si] != 0) {
	ld	a, -15 (ix)
	add	a, #0x05
	ld	-11 (ix), a
	ld	a, -14 (ix)
	adc	a, #0x00
	ld	-10 (ix), a
;fatFs\ff_getfileinfo.c:75: if (dp->blk_ofs != 0xFFFFFFFF) {	/* Get LFN if available */
	ld	a, c
	and	a, b
	and	a, e
	and	a, d
	inc	a
	jp	Z,00113$
;fatFs\ff_getfileinfo.c:76: si = di = hs = 0;
	xor	a, a
	ld	-9 (ix), a
	ld	c, #0x00
;fatFs\ff_getfileinfo.c:77: while (fs->lfnbuf[si] != 0) {
	ld	a, -11 (ix)
	ld	-8 (ix), a
	ld	a, -10 (ix)
	ld	-7 (ix), a
	ld	a, -2 (ix)
	ld	-6 (ix), a
	ld	a, -1 (ix)
	ld	-5 (ix), a
	xor	a, a
	ld	-2 (ix), a
	xor	a, a
	ld	-1 (ix), a
00107$:
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	de, #0x000a
	add	hl, de
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	l, -2 (ix)
	ld	h, #0x00
	add	hl, hl
	add	hl, de
	ld	a, (hl)
	ld	-4 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-3 (ix), a
	or	a, -4 (ix)
	jr	Z,00109$
;fatFs\ff_getfileinfo.c:79: if (di >= FF_LFN_BUF) { di = 0; break; }
	ld	a, -1 (ix)
	sub	a, #0xfe
	jr	C,00104$
	ld	c, #0x00
	jr	00109$
00104$:
;fatFs\ff_getfileinfo.c:80: wc = fs->lfnbuf[si++];
	inc	-2 (ix)
	ld	b, -4 (ix)
;fatFs\ff_getfileinfo.c:81: fno->fname[di++] = wc;
	ld	e, -1 (ix)
	inc	-1 (ix)
	ld	c, -1 (ix)
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	ld	d, #0x00
	add	hl, de
;fatFs\ff_getfileinfo.c:82: if (wc == 0) {di = 0; break; }
	ld	a,b
	ld	(hl),a
	or	a,a
	jr	NZ,00106$
	ld	c,a
	jr	00109$
00106$:
;fatFs\ff_getfileinfo.c:92: hs = 0;
	xor	a, a
	ld	-9 (ix), a
	jr	00107$
00109$:
;fatFs\ff_getfileinfo.c:94: if (hs != 0) di = 0;	/* Broken surrogate pair? */
	ld	a, -9 (ix)
	or	a, a
	jr	Z,00111$
	ld	c, #0x00
00111$:
;fatFs\ff_getfileinfo.c:95: fno->fname[di] = 0;		/* Terminate the LFN (null string means LFN is invalid) */
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	ld	b, #0x00
	add	hl, bc
	ld	(hl), #0x00
00113$:
;fatFs\ff_getfileinfo.c:99: si = di = 0;
	ld	c, #0x00
;fatFs\ff_getfileinfo.c:101: if (fno->fname[0] == 0) {
	ld	l, -13 (ix)
	ld	h, -12 (ix)
	ld	b, (hl)
;fatFs\ff_getfileinfo.c:103: while (si < 11) {		/* Get SFN from SFN entry */
	ld	a, -17 (ix)
	add	a, #0x1a
	ld	e, a
	ld	a, -16 (ix)
	adc	a, #0x00
	ld	d, a
;fatFs\ff_getfileinfo.c:101: if (fno->fname[0] == 0) {
	ld	a, b
	or	a, a
	jp	NZ, 00125$
;fatFs\ff_getfileinfo.c:103: while (si < 11) {		/* Get SFN from SFN entry */
	ld	-7 (ix), e
	ld	-6 (ix), d
	ld	a, -11 (ix)
	ld	-5 (ix), a
	ld	a, -10 (ix)
	ld	-4 (ix), a
	ld	a, -11 (ix)
	ld	-3 (ix), a
	ld	a, -10 (ix)
	ld	-2 (ix), a
	xor	a, a
	ld	-1 (ix), a
00121$:
	ld	a, -1 (ix)
	sub	a, #0x0b
	jr	NC,00123$
;fatFs\ff_getfileinfo.c:105: wc = dp->dir[si++];			/* Get a char */
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	ld	b, (hl)
	inc	hl
	ld	h, (hl)
	ld	a, b
	add	a, -1 (ix)
	ld	l, a
	jr	NC,00213$
	inc	h
00213$:
	inc	-1 (ix)
	ld	b, (hl)
;fatFs\ff_getfileinfo.c:106: if (wc == ' ') continue;	/* Skip padding spaces */
;fatFs\ff_getfileinfo.c:107: if (wc == RDDEM) wc = DDEM;	/* Restore replaced DDEM character */
	ld	a,b
	cp	a,#0x20
	jr	Z,00121$
	sub	a, #0x05
	jr	NZ,00117$
	ld	b, #0xe5
00117$:
;fatFs\ff_getfileinfo.c:109: if (si == 9 && di < FF_SFN_BUF) fno->fname[di++] = (TCHAR)'.';	/* Insert a . if extension is exist */
	ld	a, -1 (ix)
	sub	a, #0x09
	jr	NZ,00119$
	ld	a,c
	cp	a,#0x0c
	jr	NC,00119$
	inc	c
	add	a, -5 (ix)
	ld	l, a
	ld	a, #0x00
	adc	a, -4 (ix)
	ld	h, a
	ld	(hl), #0x2e
00119$:
;fatFs\ff_getfileinfo.c:130: fno->fname[di++] = (TCHAR)wc;	/* Store it without any conversion */
	ld	a, c
	inc	c
	add	a, -3 (ix)
	ld	l, a
	ld	a, #0x00
	adc	a, -2 (ix)
	ld	h, a
	ld	(hl), b
	jr	00121$
00123$:
;fatFs\ff_getfileinfo.c:137: fno->fname[di] = 0;	/* Terminate the SFN  (null string means SFN is invalid) */
	ld	l, -5 (ix)
	ld	h, -4 (ix)
	ld	b, #0x00
	add	hl, bc
	ld	(hl), #0x00
00125$:
;fatFs\ff_getfileinfo.c:143: if (fno->fname[0] == 0) {	/* If LFN is invalid, altname[] needs to be copied to fname[] */
	ld	l, -13 (ix)
	ld	h, -12 (ix)
	ld	a, (hl)
;fatFs\ff_getfileinfo.c:144: if (di == 0) {	/* If LFN and SFN both are invalid, this object is inaccesible */
	or	a,a
	jr	NZ,00129$
	or	a,c
	jr	NZ,00127$
;fatFs\ff_getfileinfo.c:145: fno->fname[di++] = '?';
	ld	a, c
	inc	c
	add	a, -11 (ix)
	ld	l, a
	ld	a, #0x00
	adc	a, -10 (ix)
	ld	h, a
	ld	(hl), #0x3f
00127$:
;fatFs\ff_getfileinfo.c:157: fno->fname[di] = 0;	/* Terminate the LFN */
	ld	l, -11 (ix)
	ld	h, -10 (ix)
	ld	b, #0x00
	add	hl, bc
	ld	(hl), #0x00
00129$:
;fatFs\ff_getfileinfo.c:175: fno->fattrib = dp->dir[DIR_Attr];					/* Attribute */
	ld	a, -15 (ix)
	add	a, #0x04
	ld	c, a
	ld	a, -14 (ix)
	adc	a, #0x00
	ld	b, a
	ld	l, e
	ld	h, d
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	push	bc
	ld	bc, #0x000b
	add	hl, bc
	pop	bc
	ld	a, (hl)
	ld	(bc), a
;fatFs\ff_getfileinfo.c:176: fno->fsize = ld_dword(dp->dir + DIR_FileSize);		/* Size */
	ex	de,hl
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	hl, #0x001c
	add	hl, bc
	push	hl
	call	_ld_dword
	pop	af
	ld	c, l
	ld	b, h
	ld	l, -15 (ix)
	ld	h, -14 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
	inc	hl
	ld	(hl), e
	inc	hl
	ld	(hl), d
00130$:
;fatFs\ff_getfileinfo.c:181: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
