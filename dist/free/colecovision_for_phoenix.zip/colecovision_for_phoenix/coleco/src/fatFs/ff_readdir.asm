;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_readdir
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _validate
	.globl _get_fileinfo
	.globl _dir_read
	.globl _dir_next
	.globl _dir_sdi
	.globl _f_readdir
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_readdir.c:45: FRESULT f_readdir (
;	---------------------------------
; Function f_readdir
; ---------------------------------
_f_readdir::
	push	af
;fatFs\ff_readdir.c:54: res = validate(&dp->obj, &fs);	/* Check validity of the directory object */
	ld	hl, #0
	add	hl, sp
	ld	iy, #4
	add	iy, sp
	ld	c, 0 (iy)
	ld	b, 1 (iy)
	push	bc
	push	hl
	push	bc
	call	_validate
	pop	af
	pop	af
	pop	bc
;fatFs\ff_readdir.c:55: if (res == FR_OK) {
	ld	a, l
	or	a, a
	jr	NZ,00111$
;fatFs\ff_readdir.c:56: if (!fno) {
	ld	hl, #6+1
	add	hl, sp
	ld	a, (hl)
	dec	hl
	or	a, (hl)
	jr	NZ,00108$
;fatFs\ff_readdir.c:57: res = dir_sdi(dp, 0);			/* Rewind the directory object */
	ld	hl, #0x0000
	push	hl
	ld	hl, #0x0000
	push	hl
	push	bc
	call	_dir_sdi
	pop	af
	pop	af
	pop	af
	jr	00111$
00108$:
;fatFs\ff_readdir.c:60: res = DIR_READ_FILE(dp);		/* Read an item */
	push	bc
	ld	hl, #0x0000
	push	hl
	push	bc
	call	_dir_read
	pop	af
	pop	af
	pop	bc
;fatFs\ff_readdir.c:61: if (res == FR_NO_FILE) res = FR_OK;	/* Ignore end of directory */
	ld	a, l
	sub	a,#0x04
	jr	NZ,00102$
	ld	l,a
00102$:
;fatFs\ff_readdir.c:62: if (res == FR_OK) {				/* A valid entry is found */
	ld	a, l
	or	a, a
	jr	NZ,00111$
;fatFs\ff_readdir.c:63: get_fileinfo(dp, fno);		/* Get the object information */
	ld	hl, #6
	add	hl, sp
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	push	hl
	push	bc
	call	_get_fileinfo
	pop	af
;fatFs\ff_readdir.c:64: res = dir_next(dp, 0);		/* Increment index for next */
	ld	hl, #0x0000
	ex	(sp),hl
	ld	hl, #6
	add	hl, sp
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	push	bc
	call	_dir_next
	pop	af
	pop	af
;fatFs\ff_readdir.c:65: if (res == FR_NO_FILE) res = FR_OK;	/* Ignore end of directory now */
	ld	a, l
	sub	a,#0x04
	jr	NZ,00111$
	ld	l,a
00111$:
;fatFs\ff_readdir.c:70: LEAVE_FF(fs, res);
;fatFs\ff_readdir.c:71: }
	pop	af
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
