;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module diskio_diskinit
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _dly_50us
	.globl _send_cmd
	.globl _deselect
	.globl _rcvr_mmc
	.globl _Stat
	.globl _CardType
	.globl _csLow
	.globl _csHigh
	.globl _disk_initialize
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_sgmPSGAddressWrite	=	0x0050
_sgmPSGDataWrite	=	0x0051
_sgmPSGDataRead	=	0x0052
_sgmConfig	=	0x0053
_phRAMBankSelect	=	0x0054
_phBankingScheme	=	0x0055
_phSDControl	=	0x0056
_phSDData	=	0x0057
_phMachineID	=	0x0058
_phCartMask	=	0x0059
_sgmBIOSMap	=	0x007f
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_csHigh::
	.ds 1
_csLow::
	.ds 1
_CardType::
	.ds 1
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
_Stat::
	.ds 1
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\diskio_diskinit.c:38: DSTATUS disk_initialize (
;	---------------------------------
; Function disk_initialize
; ---------------------------------
_disk_initialize::
	call	___sdcc_enter_ix
	push	af
	push	af
	dec	sp
;fatFs\diskio_diskinit.c:52: csHigh = PH_SD_CE_OFF | PH_SD_LOW_SPEED;
	ld	hl,#_csHigh + 0
	ld	(hl), #0x03
;fatFs\diskio_diskinit.c:53: csLow = PH_SD_LOW_SPEED;
	ld	hl,#_csLow + 0
	ld	(hl), #0x02
;fatFs\diskio_diskinit.c:55: dly_50us(200);			/* 10ms */
	ld	a, #0xc8
	push	af
	inc	sp
	call	_dly_50us
	inc	sp
;fatFs\diskio_diskinit.c:56: CS_H();		            /* Deselect CS */
	ld	a,(#_csHigh + 0)
	out	(_phSDControl), a
;fatFs\diskio_diskinit.c:58: for (n = 10; n; n--) rcvr_mmc(buf, 1);	/* Apply 80 dummy clocks and the card gets ready to receive command */
	ld	c, #0x0a
	ld	hl, #0
	add	hl, sp
	ex	de, hl
00125$:
	push	de
	pop	iy
	push	bc
	push	de
	ld	hl, #0x0001
	push	hl
	push	iy
	call	_rcvr_mmc
	pop	af
	pop	af
	pop	de
	pop	bc
	ld	a, c
	dec	a
	ld	c, a
	or	a, a
	jr	NZ,00125$
;fatFs\diskio_diskinit.c:60: ty = 0;
	xor	a, a
	ld	-1 (ix), a
;fatFs\diskio_diskinit.c:61: if (send_cmd(CMD0, 0) == 1) {			/* Enter Idle state */
	push	de
	ld	hl, #0x0000
	push	hl
	ld	hl, #0x0000
	push	hl
	xor	a, a
	push	af
	inc	sp
	call	_send_cmd
	pop	af
	pop	af
	inc	sp
	pop	de
	dec	l
	jp	NZ,00124$
;fatFs\diskio_diskinit.c:63: csHigh = PH_SD_CE_OFF;
	ld	hl,#_csHigh + 0
	ld	(hl), #0x01
;fatFs\diskio_diskinit.c:64: csLow = 0;
	ld	hl,#_csLow + 0
	ld	(hl), #0x00
;fatFs\diskio_diskinit.c:67: if (send_cmd(CMD8, 0x1AA) == 1) {	/* SDv2? */
	push	de
	ld	hl, #0x0000
	push	hl
	ld	hl, #0x01aa
	push	hl
	ld	a, #0x08
	push	af
	inc	sp
	call	_send_cmd
	pop	af
	pop	af
	inc	sp
	pop	de
	dec	l
	jp	NZ,00121$
;fatFs\diskio_diskinit.c:68: rcvr_mmc(buf, 4);							/* Get trailing return value of R7 resp */
	ld	c, e
	ld	b, d
	push	de
	ld	hl, #0x0004
	push	hl
	push	bc
	call	_rcvr_mmc
	pop	af
	pop	af
	pop	de
;fatFs\diskio_diskinit.c:69: if (buf[2] == 0x01 && buf[3] == 0xAA) {		/* The card can work at vdd range of 2.7-3.6V */
	ld	l, e
	ld	h, d
	inc	hl
	inc	hl
	ld	a, (hl)
	dec	a
	jp	NZ,00124$
	ld	l, e
	ld	h, d
	inc	hl
	inc	hl
	inc	hl
	ld	a, (hl)
	sub	a, #0xaa
	jp	NZ,00124$
;fatFs\diskio_diskinit.c:70: for (tmr = 1000; tmr; tmr--) {			/* Wait for leaving idle state (ACMD41 with HCS bit) */
	ld	bc, #0x03e8
00127$:
;fatFs\diskio_diskinit.c:71: if (send_cmd(ACMD41, 1UL << 30) == 0) break;
	push	bc
	push	de
	ld	hl, #0x4000
	push	hl
	ld	hl, #0x0000
	push	hl
	ld	a, #0xa9
	push	af
	inc	sp
	call	_send_cmd
	pop	af
	pop	af
	inc	sp
	ld	a, l
	pop	de
	pop	bc
	or	a, a
	jr	Z,00104$
;fatFs\diskio_diskinit.c:72: dly_50us(20);
	push	bc
	push	de
	ld	a, #0x14
	push	af
	inc	sp
	call	_dly_50us
	inc	sp
	pop	de
	pop	bc
;fatFs\diskio_diskinit.c:70: for (tmr = 1000; tmr; tmr--) {			/* Wait for leaving idle state (ACMD41 with HCS bit) */
	dec	bc
	ld	a, b
	or	a, c
	jr	NZ,00127$
00104$:
;fatFs\diskio_diskinit.c:74: if (tmr && send_cmd(CMD58, 0) == 0) {	/* Check CCS bit in the OCR */
	ld	a, b
	or	a, c
	jp	Z, 00124$
	push	de
	ld	hl, #0x0000
	push	hl
	ld	hl, #0x0000
	push	hl
	ld	a, #0x3a
	push	af
	inc	sp
	call	_send_cmd
	pop	af
	pop	af
	inc	sp
	ld	a, l
	pop	de
	or	a, a
	jp	NZ, 00124$
;fatFs\diskio_diskinit.c:75: rcvr_mmc(buf, 4);
	ld	c, e
	ld	b, d
	push	de
	ld	hl, #0x0004
	push	hl
	push	bc
	call	_rcvr_mmc
	pop	af
	pop	af
	pop	de
;fatFs\diskio_diskinit.c:76: ty = (buf[0] & 0x40) ? CT_SD2 | CT_BLOCK : CT_SD2;	/* SDv2 */
	ld	a, (de)
	bit	6, a
	jr	Z,00133$
	ld	bc, #0x000c
	jr	00134$
00133$:
	ld	bc, #0x0004
00134$:
	ld	-1 (ix), c
	jr	00124$
00121$:
;fatFs\diskio_diskinit.c:80: if (send_cmd(ACMD41, 0) <= 1) 	{
	ld	hl, #0x0000
	push	hl
	ld	hl, #0x0000
	push	hl
	ld	a, #0xa9
	push	af
	inc	sp
	call	_send_cmd
	pop	af
	pop	af
	inc	sp
	ld	a, #0x01
	sub	a, l
	jr	C,00112$
;fatFs\diskio_diskinit.c:81: ty = CT_SD1; cmd = ACMD41;	/* SDv1 */
	ld	-1 (ix), #0x02
	ld	b, #0xa9
	jr	00150$
00112$:
;fatFs\diskio_diskinit.c:83: ty = CT_MMC; cmd = CMD1;	/* MMCv3 */
	ld	-1 (ix), #0x01
	ld	b, #0x01
;fatFs\diskio_diskinit.c:85: for (tmr = 1000; tmr; tmr--) {			/* Wait for leaving idle state */
00150$:
	ld	de, #0x03e8
00129$:
;fatFs\diskio_diskinit.c:86: if (send_cmd(cmd, 0) == 0) break;
	push	bc
	push	de
	ld	hl, #0x0000
	push	hl
	ld	hl, #0x0000
	push	hl
	push	bc
	inc	sp
	call	_send_cmd
	pop	af
	pop	af
	inc	sp
	ld	a, l
	pop	de
	pop	bc
	or	a, a
	jr	Z,00116$
;fatFs\diskio_diskinit.c:87: dly_50us(20);
	push	bc
	push	de
	ld	a, #0x14
	push	af
	inc	sp
	call	_dly_50us
	inc	sp
	pop	de
	pop	bc
;fatFs\diskio_diskinit.c:85: for (tmr = 1000; tmr; tmr--) {			/* Wait for leaving idle state */
	dec	de
	ld	a, d
	or	a, e
	jr	NZ,00129$
00116$:
;fatFs\diskio_diskinit.c:89: if (!tmr || send_cmd(CMD16, 512) != 0) {/* Set R/W block length to 512 */
	ld	a, d
	or	a, e
	jr	Z,00117$
	ld	hl, #0x0000
	push	hl
	ld	hl, #0x0200
	push	hl
	ld	a, #0x10
	push	af
	inc	sp
	call	_send_cmd
	pop	af
	pop	af
	inc	sp
	ld	a, l
	or	a, a
	jr	Z,00124$
00117$:
;fatFs\diskio_diskinit.c:90: ty = 0;
	xor	a, a
	ld	-1 (ix), a
00124$:
;fatFs\diskio_diskinit.c:94: CardType = ty;
	ld	a, -1 (ix)
	ld	(#_CardType + 0),a
;fatFs\diskio_diskinit.c:95: s = ty ? 0 : STA_NOINIT;
	ld	a, -1 (ix)
	or	a, a
	jr	Z,00135$
	ld	bc, #0x0000
	jr	00136$
00135$:
	ld	bc, #0x0001
00136$:
;fatFs\diskio_diskinit.c:96: Stat = s;
	ld	hl,#_Stat + 0
	ld	(hl), c
;fatFs\diskio_diskinit.c:98: deselect();
	push	bc
	call	_deselect
	pop	bc
;fatFs\diskio_diskinit.c:100: return s;
	ld	l, c
;fatFs\diskio_diskinit.c:101: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
__xinit__Stat:
	.db #0x01	; 1
	.area _CABS (ABS)
