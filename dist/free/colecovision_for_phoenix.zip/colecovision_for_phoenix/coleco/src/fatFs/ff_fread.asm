;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_fread
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _memcpy
	.globl _disk_read
	.globl _validate
	.globl _get_fat
	.globl _clst2sect
	.globl _f_read
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_fread.c:43: FRESULT f_read (
;	---------------------------------
; Function f_read
; ---------------------------------
_f_read::
	call	___sdcc_enter_ix
	ld	hl, #-32
	add	hl, sp
	ld	sp, hl
;fatFs\ff_fread.c:55: BYTE *rbuff = (BYTE*)buff;
	ld	a, 6 (ix)
	ld	-2 (ix), a
	ld	a, 7 (ix)
	ld	-1 (ix), a
;fatFs\ff_fread.c:58: *br = 0;	/* Clear read byte counter */
	ld	a, 10 (ix)
	ld	-30 (ix), a
	ld	a, 11 (ix)
	ld	-29 (ix), a
	pop	bc
	pop	hl
	push	hl
	push	bc
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
;fatFs\ff_fread.c:59: res = validate(&fp->obj, &fs);				/* Check validity of the file object */
	ld	hl, #0
	add	hl, sp
	ld	a, 4 (ix)
	ld	-28 (ix), a
	ld	a, 5 (ix)
	ld	-27 (ix), a
	push	hl
	ld	l, -28 (ix)
	ld	h, -27 (ix)
	push	hl
	call	_validate
	pop	af
	pop	af
	ld	c, l
	ld	-3 (ix), c
;fatFs\ff_fread.c:60: if (res != FR_OK || (res = (FRESULT)fp->err) != FR_OK) LEAVE_FF(fs, res);	/* Check validity */
	ld	a, c
	or	a, a
	jr	NZ,00101$
;fatFs\ff_fread.c:87: if (sect == 0) ABORT(fs, FR_INT_ERR);
	ld	a, -28 (ix)
	add	a, #0x0f
	ld	-26 (ix), a
	ld	a, -27 (ix)
	adc	a, #0x00
	ld	-25 (ix), a
;fatFs\ff_fread.c:60: if (res != FR_OK || (res = (FRESULT)fp->err) != FR_OK) LEAVE_FF(fs, res);	/* Check validity */
	ld	l, -26 (ix)
	ld	h, -25 (ix)
	ld	a, (hl)
	ld	-3 (ix), a
	or	a, a
	jr	Z,00102$
00101$:
	ld	l, -3 (ix)
	jp	00137$
00102$:
;fatFs\ff_fread.c:61: if (!(fp->flag & FA_READ)) LEAVE_FF(fs, FR_DENIED); /* Check access mode */
	ld	a, -28 (ix)
	ld	-24 (ix), a
	ld	a, -27 (ix)
	ld	-23 (ix), a
	ld	l, -28 (ix)
	ld	h, -27 (ix)
	ld	de, #0x000e
	add	hl, de
	ld	a, (hl)
	rrca
	jr	C,00105$
	ld	l, #0x07
	jp	00137$
00105$:
;fatFs\ff_fread.c:62: remain = fp->obj.objsize - fp->fptr;
	ld	l, -28 (ix)
	ld	h, -27 (ix)
	ld	de, #0x000a
	add	hl, de
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	inc	hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	a, -28 (ix)
	add	a, #0x10
	ld	-22 (ix), a
	ld	a, -27 (ix)
	adc	a, #0x00
	ld	-21 (ix), a
	push	de
	push	bc
	ld	e, -22 (ix)
	ld	d, -21 (ix)
	ld	hl, #0x001e
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
	ld	a, c
	sub	a, -6 (ix)
	ld	c, a
	ld	a, b
	sbc	a, -5 (ix)
	ld	b, a
	ld	a, e
	sbc	a, -4 (ix)
	ld	e, a
	ld	a, d
	sbc	a, -3 (ix)
	ld	d, a
;fatFs\ff_fread.c:63: if (btr > remain) btr = (UINT)remain;		/* Truncate btr by remaining bytes */
	ld	a, 8 (ix)
	ld	-6 (ix), a
	ld	a, 9 (ix)
	ld	-5 (ix), a
	xor	a, a
	ld	-4 (ix), a
	ld	-3 (ix), a
	ld	a, c
	sub	a, -6 (ix)
	ld	a, b
	sbc	a, -5 (ix)
	ld	a, e
	sbc	a, -4 (ix)
	ld	a, d
	sbc	a, -3 (ix)
	jr	NC,00155$
	ld	8 (ix), c
	ld	9 (ix), b
00155$:
	ld	a, -28 (ix)
	ld	-20 (ix), a
	ld	a, -27 (ix)
	ld	-19 (ix), a
	ld	a, -28 (ix)
	ld	-18 (ix), a
	ld	a, -27 (ix)
	ld	-17 (ix), a
	ld	a, -22 (ix)
	ld	-16 (ix), a
	ld	a, -21 (ix)
	ld	-15 (ix), a
	ld	a, -28 (ix)
	add	a, #0x1c
	ld	-14 (ix), a
	ld	a, -27 (ix)
	adc	a, #0x00
	ld	-13 (ix), a
	ld	a, -28 (ix)
	ld	-12 (ix), a
	ld	a, -27 (ix)
	ld	-11 (ix), a
00136$:
;fatFs\ff_fread.c:65: for ( ;  btr;								/* Repeat until btr bytes read */
	ld	a, 9 (ix)
	or	a, 8 (ix)
	jp	Z, 00134$
;fatFs\ff_fread.c:67: if (fp->fptr % SS(fs) == 0) {			/* On the sector boundary? */
	ld	l, -22 (ix)
	ld	h, -21 (ix)
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	inc	hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	a, c
	or	a, a
	jp	NZ,00130$
	bit	0, b
	jp	NZ,00130$
;fatFs\ff_fread.c:68: csect = (UINT)(fp->fptr / SS(fs) & (fs->csize - 1));	/* Sector offset in the cluster */
	ld	-6 (ix), b
	ld	-5 (ix), e
	ld	-4 (ix), d
	xor	a, a
	ld	-3 (ix), a
	srl	-4 (ix)
	rr	-5 (ix)
	rr	-6 (ix)
	pop	hl
	push	hl
	push	bc
	ld	bc, #0x0009
	add	hl, bc
	pop	bc
	ld	a, (hl)
	dec	hl
	ld	l, (hl)
	ld	h, a
	dec	hl
	ld	a, -6 (ix)
	ld	-4 (ix), a
	ld	a, -5 (ix)
	ld	-3 (ix), a
	ld	a, l
	and	a, -4 (ix)
	ld	l, a
	ld	a, h
	and	a, -3 (ix)
	ld	h, a
	ld	-4 (ix), l
;fatFs\ff_fread.c:69: if (csect == 0) {					/* On the cluster boundary? */
	ld	-3 (ix), h
	ld	a, h
	or	a, -4 (ix)
	jp	NZ, 00116$
;fatFs\ff_fread.c:70: if (fp->fptr == 0) {			/* On the top of the file? */
	ld	a, d
	or	a, e
	or	a, b
	or	a, c
	jr	NZ,00109$
;fatFs\ff_fread.c:71: clst = fp->obj.sclust;		/* Follow cluster chain from the origin */
	ld	l, -20 (ix)
	ld	h, -19 (ix)
	ld	de, #0x0006
	add	hl, de
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	inc	hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	jr	00110$
00109$:
;fatFs\ff_fread.c:79: clst = get_fat(&fp->obj, fp->clust);	/* Follow cluster chain on the FAT */
	ld	a, -24 (ix)
	ld	-6 (ix), a
	ld	a, -23 (ix)
	ld	-5 (ix), a
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	de, #0x0014
	add	hl, de
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	inc	hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	push	de
	push	bc
	ld	l, -24 (ix)
	ld	h, -23 (ix)
	push	hl
	call	_get_fat
	pop	af
	pop	af
	pop	af
	ld	c, l
	ld	b, h
00110$:
;fatFs\ff_fread.c:82: if (clst < 2) ABORT(fs, FR_INT_ERR);
	ld	a, c
	sub	a, #0x02
	ld	a, b
	sbc	a, #0x00
	ld	a, e
	sbc	a, #0x00
	ld	a, d
	sbc	a, #0x00
	jr	NC,00112$
	ld	l, -26 (ix)
	ld	h, -25 (ix)
	ld	(hl), #0x02
	ld	l, #0x02
	jp	00137$
00112$:
;fatFs\ff_fread.c:83: if (clst == 0xFFFFFFFF) ABORT(fs, FR_DISK_ERR);
	ld	a, c
	and	a, b
	and	a, e
	and	a, d
	inc	a
	jr	NZ,00114$
	ld	l, -26 (ix)
	ld	h, -25 (ix)
	ld	(hl), #0x01
	ld	l, #0x01
	jp	00137$
00114$:
;fatFs\ff_fread.c:84: fp->clust = clst;				/* Update current cluster */
	ld	a, -18 (ix)
	add	a, #0x14
	ld	l, a
	ld	a, -17 (ix)
	adc	a, #0x00
	ld	h, a
	ld	(hl), c
	inc	hl
	ld	(hl), b
	inc	hl
	ld	(hl), e
	inc	hl
	ld	(hl), d
00116$:
;fatFs\ff_fread.c:86: sect = clst2sect(fs, fp->clust);	/* Get current sector */
	ld	l, -28 (ix)
	ld	h, -27 (ix)
	ld	de, #0x0014
	add	hl, de
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	inc	hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	push	de
	push	bc
	ld	l, -32 (ix)
	ld	h, -31 (ix)
	push	hl
	call	_clst2sect
	pop	af
	pop	af
	pop	af
;fatFs\ff_fread.c:87: if (sect == 0) ABORT(fs, FR_INT_ERR);
	ld	a, d
	or	a, e
	or	a, h
	or	a, l
	jr	NZ,00118$
	ld	l, -26 (ix)
	ld	h, -25 (ix)
	ld	(hl), #0x02
	ld	l, #0x02
	jp	00137$
00118$:
;fatFs\ff_fread.c:88: sect += csect;
	ld	a, -4 (ix)
	ld	-8 (ix), a
	ld	a, -3 (ix)
	ld	-7 (ix), a
	xor	a, a
	ld	-6 (ix), a
	ld	-5 (ix), a
	ld	a, l
	add	a, -8 (ix)
	ld	c, a
	ld	a, h
	adc	a, -7 (ix)
	ld	b, a
	ld	a, e
	adc	a, -6 (ix)
	ld	e, a
	ld	a, d
	adc	a, -5 (ix)
	ld	d, a
	ld	-8 (ix), c
	ld	-7 (ix), b
	ld	-6 (ix), e
	ld	-5 (ix), d
;fatFs\ff_fread.c:89: cc = btr / SS(fs);					/* When remaining bytes >= sector size, */
	ld	a, 9 (ix)
	srl	a
	ld	c, a
	ld	b, #0x00
;fatFs\ff_fread.c:90: if (cc > 0) {						/* Read maximum contiguous sectors directly */
	ld	a, b
	or	a, c
	jr	Z,00124$
;fatFs\ff_fread.c:91: if (csect + cc > fs->csize) {	/* Clip at cluster boundary */
	ld	a, -4 (ix)
	add	a, c
	ld	e, a
	ld	a, -3 (ix)
	adc	a, b
	ld	d, a
	pop	hl
	push	hl
	push	bc
	ld	bc, #0x0008
	add	hl, bc
	pop	bc
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	sub	a, e
	ld	a, h
	sbc	a, d
	jr	NC,00120$
;fatFs\ff_fread.c:92: cc = fs->csize - csect;
	ld	a, l
	sub	a, -4 (ix)
	ld	c, a
	ld	a, h
	sbc	a, -3 (ix)
	ld	b, a
00120$:
;fatFs\ff_fread.c:97: if (disk_read(rbuff, sect, cc) != RES_OK) ABORT(fs, FR_DISK_ERR);
	push	bc
	push	bc
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	push	hl
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	push	hl
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	push	hl
	call	_disk_read
	pop	af
	pop	af
	pop	af
	pop	af
	ld	a, l
	pop	bc
	or	a, a
	jr	Z,00122$
	ld	l, -26 (ix)
	ld	h, -25 (ix)
	ld	(hl), #0x01
	ld	l, #0x01
	jp	00137$
00122$:
;fatFs\ff_fread.c:110: rcnt = SS(fs) * cc;				/* Number of bytes transferred */
	ld	a, c
	add	a, a
	ld	b, a
	ld	c, #0x00
;fatFs\ff_fread.c:111: continue;
	jp	00133$
00124$:
;fatFs\ff_fread.c:114: if (fp->sect != sect) {			/* Load data sector if not in cache */
	ld	a, -28 (ix)
	add	a, #0x18
	ld	-4 (ix), a
	ld	a, -27 (ix)
	adc	a, #0x00
	ld	-3 (ix), a
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	inc	hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	a, -8 (ix)
	sub	a, c
	jr	NZ,00232$
	ld	a, -7 (ix)
	sub	a, b
	jr	NZ,00232$
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	cp	a, a
	sbc	hl, de
	jr	Z,00128$
00232$:
;fatFs\ff_fread.c:128: if (disk_read(fp->buf, sect, 1) != RES_OK)	ABORT(fs, FR_DISK_ERR);	/* Fill sector cache */
	ld	a, -28 (ix)
	add	a, #0x1c
	ld	c, a
	ld	a, -27 (ix)
	adc	a, #0x00
	ld	b, a
	ld	hl, #0x0001
	push	hl
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	push	hl
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	push	hl
	push	bc
	call	_disk_read
	pop	af
	pop	af
	pop	af
	pop	af
	ld	a, l
	or	a, a
	jr	Z,00128$
	ld	l, -26 (ix)
	ld	h, -25 (ix)
	ld	(hl), #0x01
	ld	l, #0x01
	jp	00137$
00128$:
;fatFs\ff_fread.c:132: fp->sect = sect;
	ld	e, -4 (ix)
	ld	d, -3 (ix)
	ld	hl, #0x0018
	add	hl, sp
	ld	bc, #0x0004
	ldir
00130$:
;fatFs\ff_fread.c:134: rcnt = SS(fs) - (UINT)fp->fptr % SS(fs);	/* Number of bytes left in the sector */
	ld	e, -16 (ix)
	ld	d, -15 (ix)
	ld	hl, #0x001a
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	ld	c, -6 (ix)
	ld	a, -5 (ix)
	and	a, #0x01
	ld	b, a
	xor	a, a
	sub	a, c
	ld	c, a
	ld	a, #0x02
	sbc	a, b
	ld	b, a
;fatFs\ff_fread.c:135: if (rcnt > btr) rcnt = btr;					/* Clip it by btr if needed */
	ld	a, 8 (ix)
	sub	a, c
	ld	a, 9 (ix)
	sbc	a, b
	jr	NC,00132$
	ld	c, 8 (ix)
	ld	b, 9 (ix)
00132$:
;fatFs\ff_fread.c:140: memcpy(rbuff, fp->buf + fp->fptr % SS(fs), rcnt);	/* Extract partial sector */
	ld	e, -6 (ix)
	ld	a, -5 (ix)
	and	a, #0x01
	ld	d, a
	ld	a, e
	add	a, -14 (ix)
	ld	e, a
	ld	a, d
	adc	a, -13 (ix)
	ld	d, a
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	push	bc
	push	bc
	push	de
	push	hl
	call	_memcpy
	pop	af
	pop	af
	pop	af
	pop	bc
00133$:
;fatFs\ff_fread.c:66: btr -= rcnt, *br += rcnt, rbuff += rcnt, fp->fptr += rcnt) {
	ld	a, 8 (ix)
	sub	a, c
	ld	8 (ix), a
	ld	a, 9 (ix)
	sbc	a, b
	ld	9 (ix), a
	ld	l, -30 (ix)
	ld	h, -29 (ix)
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	add	hl, bc
	ex	de, hl
	ld	l, -30 (ix)
	ld	h, -29 (ix)
	ld	(hl), e
	inc	hl
	ld	(hl), d
	ld	a, -2 (ix)
	add	a, c
	ld	-2 (ix), a
	ld	a, -1 (ix)
	adc	a, b
	ld	-1 (ix), a
	ld	a, -12 (ix)
	add	a, #0x10
	ld	e, a
	ld	a, -11 (ix)
	adc	a, #0x00
	ld	d, a
	push	de
	push	bc
	ld	hl, #0x001a
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
	ld	hl, #0x0000
	ld	a, c
	add	a, -10 (ix)
	ld	-6 (ix), a
	ld	a, b
	adc	a, -9 (ix)
	ld	-5 (ix), a
	ld	a, l
	adc	a, -8 (ix)
	ld	-4 (ix), a
	ld	a, h
	adc	a, -7 (ix)
	ld	-3 (ix), a
	ld	hl, #0x001a
	add	hl, sp
	ld	bc, #0x0004
	ldir
	jp	00136$
00134$:
;fatFs\ff_fread.c:144: LEAVE_FF(fs, FR_OK);
	ld	l, #0x00
00137$:
;fatFs\ff_fread.c:145: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
