;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ffunicode_ffoem2uni
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ff_oem2uni_unused
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ffunicode_ffoem2uni.c:54: WCHAR ff_oem2uni (	/* Returns Unicode character, zero on error */
;	---------------------------------
; Function ff_oem2uni_unused
; ---------------------------------
_ff_oem2uni_unused::
	call	___sdcc_enter_ix
;fatFs\ffunicode_ffoem2uni.c:59: WCHAR c = 0;
	ld	bc, #0x0000
;fatFs\ffunicode_ffoem2uni.c:60: const WCHAR *p = CVTBL(uc, FF_CODE_PAGE);
;fatFs\ffunicode_ffoem2uni.c:63: if (oem < 0x80) {	/* ASCII? */
	ld	e, 4 (ix)
	ld	d, 5 (ix)
	ld	a, e
	sub	a, #0x80
	ld	a, d
	sbc	a, #0x00
	jr	NC,00106$
;fatFs\ffunicode_ffoem2uni.c:64: c = oem;
	ld	c, 4 (ix)
	ld	b, 5 (ix)
	jr	00107$
00106$:
;fatFs\ffunicode_ffoem2uni.c:67: if (cp == FF_CODE_PAGE) {	/* Is it a valid code page? */
	ld	a, 6 (ix)
	ld	h, 7 (ix)
	sub	a, #0xb5
	jr	NZ,00107$
	dec	h
	jr	NZ,00107$
;fatFs\ffunicode_ffoem2uni.c:68: if (oem < 0x100) c = p[oem - 0x80];
	ld	a, d
	sub	a, #0x01
	jr	NC,00107$
	ld	a, e
	add	a, #0x80
	ld	l, a
	ld	a, d
	adc	a, #0xff
	ld	h, a
	add	hl, hl
	ld	de, #_uc437
	add	hl, de
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
00107$:
;fatFs\ffunicode_ffoem2uni.c:72: return c;
	ld	l, c
	ld	h, b
;fatFs\ffunicode_ffoem2uni.c:73: }
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
