;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_findvolume
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _disk_status
	.globl _disk_initialize
	.globl _check_fs
	.globl _ld_dword
	.globl _find_volume
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFS/ff_findvolume.c:42: FRESULT find_volume (	    /* FR_OK(0): successful, !=0: an error occurred */
;	---------------------------------
; Function find_volume
; ---------------------------------
_find_volume::
	call	___sdcc_enter_ix
	ld	hl, #-51
	add	hl, sp
	ld	sp, hl
;fatFS/ff_findvolume.c:71: *rfs = 0;
	ld	c, 4 (ix)
	ld	b, 5 (ix)
	ld	l, c
	ld	h, b
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
;fatFS/ff_findvolume.c:79: fs = FatFs[vol];					/* Get pointer to the filesystem object */
	ld	hl, #_FatFs + 0
	ld	a, (hl)
	ld	-27 (ix), a
	inc	hl
	ld	a, (hl)
;fatFS/ff_findvolume.c:80: if (!fs) return FR_NOT_ENABLED;		/* Is the filesystem object available? */
	ld	-26 (ix), a
	or	a, -27 (ix)
	jr	NZ,00102$
	ld	l, #0x0c
	jp	00166$
00102$:
;fatFS/ff_findvolume.c:84: *rfs = fs;							/* Return pointer to the filesystem object */
	ld	a, -27 (ix)
	ld	(bc), a
	inc	bc
	ld	a, -26 (ix)
	ld	(bc), a
;fatFS/ff_findvolume.c:89: if (fs->fs_type != 0) {				/* If the volume has been mounted */
	ld	l, -27 (ix)
	ld	h, -26 (ix)
	ld	a, (hl)
	or	a, a
	jr	Z,00106$
;fatFS/ff_findvolume.c:93: stat = disk_status();
	call	_disk_status
	ld	a, l
;fatFS/ff_findvolume.c:95: if (!(stat & STA_NOINIT)) {		/* and the physical drive is kept initialized */
	rrca
	jr	C,00106$
;fatFS/ff_findvolume.c:101: return FR_OK;				/* The filesystem object is valid */
	ld	l, #0x00
	jp	00166$
00106$:
;fatFS/ff_findvolume.c:108: fs->fs_type = 0;					/* Clear the filesystem object */
	ld	l, -27 (ix)
	ld	h, -26 (ix)
	ld	(hl), #0x00
;fatFS/ff_findvolume.c:113: stat = disk_initialize();	        /* Initialize the physical drive */
	call	_disk_initialize
	ld	a, l
;fatFS/ff_findvolume.c:115: if (stat & STA_NOINIT) { 			/* Check if the initialization succeeded */
	rrca
	jr	NC,00108$
;fatFS/ff_findvolume.c:116: return FR_NOT_READY;			/* Failed to initialize due to no medium or hard error */
	ld	l, #0x03
	jp	00166$
00108$:
;fatFS/ff_findvolume.c:133: bsect = 0;
	xor	a, a
	ld	-25 (ix), a
	ld	-24 (ix), a
	ld	-23 (ix), a
	ld	-22 (ix), a
;fatFS/ff_findvolume.c:134: fmt = check_fs(fs, bsect);			/* Load sector 0 and check if it is an FAT-VBR as SFD */
	ld	hl, #0x0000
	push	hl
	ld	hl, #0x0000
	push	hl
	ld	l, -27 (ix)
	ld	h, -26 (ix)
	push	hl
	call	_check_fs
	pop	af
	pop	af
	pop	af
;fatFS/ff_findvolume.c:135: if (fmt == 2 || (fmt < 2 && LD2PT(vol) != 0)) {	/* Not an FAT-VBR or forced partition number */
	ld	-2 (ix), l
	ld	a, l
	sub	a, #0x02
	jp	NZ,00118$
;fatFS/ff_findvolume.c:136: for (i = 0; i < 4; i++) {		/* Get partition offset */
	ld	a, -27 (ix)
	add	a, #0x28
	ld	-7 (ix), a
	ld	a, -26 (ix)
	adc	a, #0x00
	ld	-6 (ix), a
	ld	hl, #8
	add	hl, sp
	ld	-5 (ix), l
	ld	-4 (ix), h
	xor	a, a
	ld	-1 (ix), a
00164$:
;fatFS/ff_findvolume.c:137: pt = fs->win + (MBR_Table + i * SZ_PTE);
	ld	e, -1 (ix)
	ld	d, #0x00
	ld	l, e
	ld	h, d
	add	hl, hl
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	bc, #0x01be
	add	hl, bc
	ld	c, -7 (ix)
	ld	b, -6 (ix)
	add	hl, bc
	ld	c, l
	ld	b, h
;fatFS/ff_findvolume.c:138: br[i] = pt[PTE_System] ? ld_dword(pt + PTE_StLba) : 0;
	ex	de,hl
	add	hl, hl
	add	hl, hl
	ld	a, -5 (ix)
	add	a, l
	ld	-3 (ix), a
	ld	a, -4 (ix)
	adc	a, h
	ld	-2 (ix), a
	ld	l, c
	ld	h, b
	ld	de, #0x0004
	add	hl, de
	ld	a, (hl)
	or	a, a
	jr	Z,00168$
	ld	hl, #0x0008
	add	hl, bc
	push	hl
	call	_ld_dword
	pop	af
	ld	c, l
	ld	b, h
	jr	00169$
00168$:
	ld	bc, #0x0000
	ld	de, #0x0000
00169$:
	ld	l, -3 (ix)
	ld	h, -2 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
	inc	hl
	ld	(hl), e
	inc	hl
	ld	(hl), d
;fatFS/ff_findvolume.c:136: for (i = 0; i < 4; i++) {		/* Get partition offset */
	inc	-1 (ix)
	ld	a, -1 (ix)
	sub	a, #0x04
	jr	C,00164$
;fatFS/ff_findvolume.c:142: do {							/* Find an FAT volume */
	xor	a, a
	ld	-1 (ix), a
00114$:
;fatFS/ff_findvolume.c:143: bsect = br[i];
	ld	a, -1 (ix)
	ld	-3 (ix), a
	xor	a, a
	ld	-2 (ix), a
	ld	a, -3 (ix)
	ld	-7 (ix), a
	ld	a, -2 (ix)
	ld	-6 (ix), a
	ld	a, #0x02+1
	jr	00341$
00340$:
	sla	-7 (ix)
	rl	-6 (ix)
00341$:
	dec	a
	jr	NZ,00340$
	ld	a, -5 (ix)
	add	a, -7 (ix)
	ld	-3 (ix), a
	ld	a, -4 (ix)
	adc	a, -6 (ix)
	ld	-2 (ix), a
	ld	e, -3 (ix)
	ld	d, -2 (ix)
	ld	hl, #0x001a
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
;fatFS/ff_findvolume.c:144: fmt = bsect ? check_fs(fs, bsect) : 3;	/* Check the partition */
	ld	a, -22 (ix)
	or	a, -23 (ix)
	or	a, -24 (ix)
	or	a, -25 (ix)
	jr	Z,00170$
	ld	l, -23 (ix)
	ld	h, -22 (ix)
	push	hl
	ld	l, -25 (ix)
	ld	h, -24 (ix)
	push	hl
	ld	l, -27 (ix)
	ld	h, -26 (ix)
	push	hl
	call	_check_fs
	pop	af
	pop	af
	pop	af
	jr	00171$
00170$:
	ld	hl, #0x0003
00171$:
;fatFS/ff_findvolume.c:145: } while (LD2PT(vol) == 0 && fmt >= 2 && ++i < 4);
	ld	-2 (ix), l
	ld	a, l
	sub	a, #0x02
	jr	C,00118$
	inc	-1 (ix)
	ld	a, -1 (ix)
	sub	a, #0x04
	jp	C, 00114$
00118$:
;fatFS/ff_findvolume.c:147: if (fmt == 4) {
	ld	a, -2 (ix)
	sub	a, #0x04
	jr	NZ,00122$
;fatFS/ff_findvolume.c:148: return FR_DISK_ERR;		/* An error occured in the disk I/O layer */
	ld	l, #0x01
	jp	00166$
00122$:
;fatFS/ff_findvolume.c:150: if (fmt >= 2) {
	ld	a, -2 (ix)
	sub	a, #0x02
	jr	C,00124$
;fatFS/ff_findvolume.c:151: return FR_NO_FILESYSTEM;	/* No FAT volume is found */
	ld	l, #0x0d
	jp	00166$
00124$:
;fatFS/ff_findvolume.c:220: if (ld_word(fs->win + BPB_BytsPerSec) != SS(fs)) {
	ld	a, -27 (ix)
	add	a, #0x28
	ld	-21 (ix), a
	ld	a, -26 (ix)
	adc	a, #0x00
	ld	-20 (ix), a
	ld	e, -21 (ix)
	ld	d, -20 (ix)
	ld	l, -21 (ix)
	ld	h, -20 (ix)
	ld	bc, #0x000c
	add	hl, bc
	ld	b, (hl)
	ld	c, #0x00
	ex	de,hl
	ld	de, #0x000b
	add	hl, de
	ld	e, (hl)
	ld	d, #0x00
	ld	a, c
	or	a, e
	ld	c, a
	ld	a, b
	or	a, d
	ld	b, a
	ld	a, c
	or	a, a
	jr	NZ,00344$
	ld	a, b
	sub	a, #0x02
	jr	Z,00126$
00344$:
;fatFS/ff_findvolume.c:221: return FR_NO_FILESYSTEM;	/* (BPB_BytsPerSec must be equal to the physical sector size) */
	ld	l, #0x0d
	jp	00166$
00126$:
;fatFS/ff_findvolume.c:224: fasize = ld_word(fs->win + BPB_FATSz16);		/* Number of sectors per FAT */
	ld	e, -21 (ix)
	ld	d, -20 (ix)
	ld	l, -21 (ix)
	ld	h, -20 (ix)
	ld	bc, #0x0017
	add	hl, bc
	ld	b, (hl)
	ld	c, #0x00
	ex	de,hl
	ld	de, #0x0016
	add	hl, de
	ld	e, (hl)
	ld	d, #0x00
	ld	a, c
	or	a, e
	ld	c, a
	ld	a, b
	or	a, d
	ld	b, a
	rla
	sbc	a, a
	ld	e, a
;fatFS/ff_findvolume.c:225: if (fasize == 0) fasize = ld_dword(fs->win + BPB_FATSz32);
	ld	d, a
	or	a, e
	or	a, b
	or	a, c
	jr	NZ,00128$
	ld	a, -21 (ix)
	add	a, #0x24
	ld	c, a
	ld	a, -20 (ix)
	adc	a, #0x00
	ld	b, a
	push	bc
	call	_ld_dword
	pop	af
	ld	c, l
	ld	b, h
00128$:
;fatFS/ff_findvolume.c:226: fs->fsize = fasize;
	ld	a, -27 (ix)
	add	a, #0x10
	ld	-19 (ix), a
	ld	a, -26 (ix)
	adc	a, #0x00
	ld	-18 (ix), a
	ld	l, -19 (ix)
	ld	h, -18 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
	inc	hl
	ld	(hl), e
	inc	hl
	ld	(hl), d
;fatFS/ff_findvolume.c:228: fs->n_fats = fs->win[BPB_NumFATs];				/* Number of FATs */
	ld	a, -27 (ix)
	add	a, #0x01
	ld	-2 (ix), a
	ld	a, -26 (ix)
	adc	a, #0x00
	ld	-1 (ix), a
	ld	l, -21 (ix)
	ld	h, -20 (ix)
	push	bc
	ld	bc, #0x0010
	add	hl, bc
	pop	bc
	ld	a, (hl)
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	(hl), a
;fatFS/ff_findvolume.c:229: if (fs->n_fats != 1 && fs->n_fats != 2) {
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	l, (hl)
	dec	a
	jr	Z,00130$
	ld	a, l
	sub	a, #0x02
	jr	Z,00130$
;fatFS/ff_findvolume.c:230: return FR_NO_FILESYSTEM;	/* (Must be 1 or 2) */
	ld	l, #0x0d
	jp	00166$
00130$:
;fatFS/ff_findvolume.c:232: fasize *= fs->n_fats;							/* Number of sectors for FAT area */
	ld	-4 (ix), l
	xor	a, a
	ld	-3 (ix), a
	ld	-2 (ix), a
	ld	-1 (ix), a
	ld	l, a
	ld	h, a
	push	hl
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	push	hl
	push	de
	push	bc
	call	__mullong
	pop	af
	pop	af
	pop	af
	pop	af
	ld	-17 (ix), l
	ld	-16 (ix), h
	ld	-15 (ix), e
	ld	-14 (ix), d
;fatFS/ff_findvolume.c:234: fs->csize = fs->win[BPB_SecPerClus];			/* Cluster size */
	ld	a, -27 (ix)
	add	a, #0x08
	ld	-6 (ix), a
	ld	a, -26 (ix)
	adc	a, #0x00
	ld	-5 (ix), a
	ld	l, -21 (ix)
	ld	h, -20 (ix)
	ld	de, #0x000d
	add	hl, de
	ld	e, (hl)
	ld	d, #0x00
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	(hl), e
	inc	hl
	ld	(hl), d
;fatFS/ff_findvolume.c:235: if (fs->csize == 0 || (fs->csize & (fs->csize - 1))) {
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	a, d
	or	a, e
	jr	Z,00132$
	ld	e, c
	ld	d, b
	dec	de
	ld	a, c
	and	a, e
	ld	c, a
	ld	a, b
	and	a, d
	or	a, c
	jr	Z,00133$
00132$:
;fatFS/ff_findvolume.c:236: return FR_NO_FILESYSTEM;	/* (Must be power of 2) */
	ld	l, #0x0d
	jp	00166$
00133$:
;fatFS/ff_findvolume.c:239: fs->n_rootdir = ld_word(fs->win + BPB_RootEntCnt);	/* Number of root directory entries */
	ld	a, -27 (ix)
	add	a, #0x06
	ld	-13 (ix), a
	ld	a, -26 (ix)
	adc	a, #0x00
	ld	-12 (ix), a
	ld	e, -21 (ix)
	ld	d, -20 (ix)
	ld	l, -21 (ix)
	ld	h, -20 (ix)
	ld	bc, #0x0012
	add	hl, bc
	ld	b, (hl)
	ld	c, #0x00
	ex	de,hl
	ld	de, #0x0011
	add	hl, de
	ld	e, (hl)
	ld	d, #0x00
	ld	a, c
	or	a, e
	ld	c, a
	ld	a, b
	or	a, d
	ld	b, a
	ld	l, -13 (ix)
	ld	h, -12 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
;fatFS/ff_findvolume.c:240: if (fs->n_rootdir % (SS(fs) / SZDIRE)) {
	ld	a, c
	and	a, #0x0f
	jr	Z,00136$
;fatFS/ff_findvolume.c:241: return FR_NO_FILESYSTEM;	/* (Must be sector aligned) */
	ld	l, #0x0d
	jp	00166$
00136$:
;fatFS/ff_findvolume.c:244: tsect = ld_word(fs->win + BPB_TotSec16);		/* Number of sectors on the volume */
	ld	e, -21 (ix)
	ld	d, -20 (ix)
	ld	l, -21 (ix)
	ld	h, -20 (ix)
	ld	bc, #0x0014
	add	hl, bc
	ld	b, (hl)
	ld	c, #0x00
	ex	de,hl
	ld	de, #0x0013
	add	hl, de
	ld	e, (hl)
	ld	d, #0x00
	ld	a, c
	or	a, e
	ld	c, a
	ld	a, b
	or	a, d
	ld	b, a
	ld	-51 (ix), c
	ld	a, b
	ld	-50 (ix), a
	rla
	sbc	a, a
	ld	-49 (ix), a
;fatFS/ff_findvolume.c:245: if (tsect == 0) tsect = ld_dword(fs->win + BPB_TotSec32);
	ld	-48 (ix), a
	or	a, -49 (ix)
	or	a, -50 (ix)
	or	a, -51 (ix)
	jr	NZ,00138$
	ld	a, -21 (ix)
	add	a, #0x20
	ld	-2 (ix), a
	ld	a, -20 (ix)
	adc	a, #0x00
	ld	-1 (ix), a
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	push	hl
	call	_ld_dword
	pop	af
	ld	-4 (ix), l
	ld	-3 (ix), h
	ld	-2 (ix), e
	ld	-1 (ix), d
	ld	hl, #0
	add	hl, sp
	ex	de, hl
	ld	hl, #47
	add	hl, sp
	ld	bc, #4
	ldir
00138$:
;fatFS/ff_findvolume.c:247: nrsv = ld_word(fs->win + BPB_RsvdSecCnt);		/* Number of reserved sectors */
	ld	e, -21 (ix)
	ld	d, -20 (ix)
	ld	l, -21 (ix)
	ld	h, -20 (ix)
	ld	bc, #0x000f
	add	hl, bc
	ld	b, (hl)
	ld	c, #0x00
	ex	de,hl
	ld	de, #0x000e
	add	hl, de
	ld	e, (hl)
	ld	d, #0x00
	ld	a, c
	or	a, e
	ld	e, a
	ld	a, b
	or	a, d
	ld	d, a
	ld	c, e
;fatFS/ff_findvolume.c:248: if (nrsv == 0) {
	ld	a,d
	ld	b,a
	or	a, e
	jr	NZ,00140$
;fatFS/ff_findvolume.c:249: return FR_NO_FILESYSTEM;			/* (Must not be 0) */
	ld	l, #0x0d
	jp	00166$
00140$:
;fatFS/ff_findvolume.c:253: sysect = nrsv + fasize + fs->n_rootdir / (SS(fs) / SZDIRE);	/* RSV + FAT + DIR */
	ld	-47 (ix), c
	ld	-46 (ix), b
	xor	a, a
	ld	-45 (ix), a
	ld	-44 (ix), a
	ld	a, -47 (ix)
	add	a, -17 (ix)
	ld	-4 (ix), a
	ld	a, -46 (ix)
	adc	a, -16 (ix)
	ld	-3 (ix), a
	ld	a, -45 (ix)
	adc	a, -15 (ix)
	ld	-2 (ix), a
	ld	a, -44 (ix)
	adc	a, -14 (ix)
	ld	-1 (ix), a
	ld	l, -13 (ix)
	ld	h, -12 (ix)
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	b, #0x04
00348$:
	srl	d
	rr	e
	djnz	00348$
	ld	hl, #0x0000
	ld	a, -4 (ix)
	add	a, e
	ld	c, a
	ld	a, -3 (ix)
	adc	a, d
	ld	b, a
	ld	a, -2 (ix)
	adc	a, l
	ld	e, a
	ld	a, -1 (ix)
	adc	a, h
	ld	d, a
	ld	-11 (ix), c
	ld	-10 (ix), b
	ld	-9 (ix), e
	ld	-8 (ix), d
;fatFS/ff_findvolume.c:254: if (tsect < sysect) {
	ld	a, -51 (ix)
	sub	a, -11 (ix)
	ld	a, -50 (ix)
	sbc	a, -10 (ix)
	ld	a, -49 (ix)
	sbc	a, -9 (ix)
	ld	a, -48 (ix)
	sbc	a, -8 (ix)
	jr	NC,00142$
;fatFS/ff_findvolume.c:255: return FR_NO_FILESYSTEM;	/* (Invalid volume size) */
	ld	l, #0x0d
	jp	00166$
00142$:
;fatFS/ff_findvolume.c:257: nclst = (tsect - sysect) / fs->csize;			/* Number of clusters */
	ld	a, -51 (ix)
	sub	a, -11 (ix)
	ld	-4 (ix), a
	ld	a, -50 (ix)
	sbc	a, -10 (ix)
	ld	-3 (ix), a
	ld	a, -49 (ix)
	sbc	a, -9 (ix)
	ld	-2 (ix), a
	ld	a, -48 (ix)
	sbc	a, -8 (ix)
	ld	-1 (ix), a
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	de, #0x0000
	push	de
	push	bc
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	push	hl
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	push	hl
	call	__divulong
	pop	af
	pop	af
	pop	af
	pop	af
;fatFS/ff_findvolume.c:258: if (nclst == 0) {
	ld	a, d
	or	a, e
	or	a, h
	or	a, l
	jr	NZ,00144$
;fatFS/ff_findvolume.c:259: return FR_NO_FILESYSTEM;		/* (Invalid volume size) */
	ld	l, #0x0d
	jp	00166$
00144$:
;fatFS/ff_findvolume.c:261: fmt = 0;
	xor	a, a
	ld	-7 (ix), a
;fatFS/ff_findvolume.c:262: if (nclst <= MAX_FAT32) {
	ld	a, #0xf5
	cp	a, l
	ld	a, #0xff
	sbc	a, h
	ld	a, #0xff
	sbc	a, e
	ld	a, #0x0f
	sbc	a, d
	jr	C,00146$
;fatFS/ff_findvolume.c:263: fmt = FS_FAT32;
	ld	-7 (ix), #0x03
00146$:
;fatFS/ff_findvolume.c:265: if (nclst <= MAX_FAT16) {
	ld	a, #0xf5
	cp	a, l
	ld	a, #0xff
	sbc	a, h
	ld	a, #0x00
	sbc	a, e
	ld	a, #0x00
	sbc	a, d
	jr	C,00148$
;fatFS/ff_findvolume.c:266: fmt = FS_FAT16;
	ld	-7 (ix), #0x02
00148$:
;fatFS/ff_findvolume.c:273: if (nclst <= MAX_FAT12) {
	ld	a, #0xf5
	cp	a, l
	ld	a, #0x0f
	sbc	a, h
	ld	a, #0x00
	sbc	a, e
	ld	a, #0x00
	sbc	a, d
	jr	C,00150$
;fatFS/ff_findvolume.c:274: fmt = 0;
	xor	a, a
	ld	-7 (ix), a
00150$:
;fatFS/ff_findvolume.c:277: if (fmt == 0) {
	ld	a, -7 (ix)
	or	a, a
	jr	NZ,00152$
;fatFS/ff_findvolume.c:278: return FR_NO_FILESYSTEM;
	ld	l, #0x0d
	jp	00166$
00152$:
;fatFS/ff_findvolume.c:282: fs->n_fatent = nclst + 2;						/* Number of FAT entries */
	ld	a, -27 (ix)
	add	a, #0x0c
	ld	-6 (ix), a
	ld	a, -26 (ix)
	adc	a, #0x00
	ld	-5 (ix), a
	ld	bc, #0x0002
	add	hl,bc
	ld	c, l
	ld	b, h
	jr	NC,00349$
	inc	de
00349$:
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
	inc	hl
	ld	(hl), e
	inc	hl
	ld	(hl), d
;fatFS/ff_findvolume.c:283: fs->volbase = bsect;							/* Volume start sector */
	ld	a, -27 (ix)
	add	a, #0x14
	ld	e, a
	ld	a, -26 (ix)
	adc	a, #0x00
	ld	d, a
	ld	hl, #0x001a
	add	hl, sp
	ld	bc, #0x0004
	ldir
;fatFS/ff_findvolume.c:284: fs->fatbase = bsect + nrsv; 					/* FAT start sector */
	ld	a, -27 (ix)
	add	a, #0x18
	ld	-4 (ix), a
	ld	a, -26 (ix)
	adc	a, #0x00
	ld	-3 (ix), a
	ld	a, -47 (ix)
	add	a, -25 (ix)
	ld	c, a
	ld	a, -46 (ix)
	adc	a, -24 (ix)
	ld	b, a
	ld	a, -45 (ix)
	adc	a, -23 (ix)
	ld	e, a
	ld	a, -44 (ix)
	adc	a, -22 (ix)
	ld	d, a
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
	inc	hl
	ld	(hl), e
	inc	hl
	ld	(hl), d
;fatFS/ff_findvolume.c:285: fs->database = bsect + sysect;					/* Data start sector */
	ld	a, -27 (ix)
	add	a, #0x20
	ld	-2 (ix), a
	ld	a, -26 (ix)
	adc	a, #0x00
	ld	-1 (ix), a
	ld	a, -25 (ix)
	add	a, -11 (ix)
	ld	c, a
	ld	a, -24 (ix)
	adc	a, -10 (ix)
	ld	b, a
	ld	a, -23 (ix)
	adc	a, -9 (ix)
	ld	e, a
	ld	a, -22 (ix)
	adc	a, -8 (ix)
	ld	d, a
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
	inc	hl
	ld	(hl), e
	inc	hl
	ld	(hl), d
;fatFS/ff_findvolume.c:293: fs->dirbase = ld_dword(fs->win + BPB_RootClus32);	/* Root directory start cluster */
	ld	a, -27 (ix)
	add	a, #0x1c
	ld	-2 (ix), a
	ld	a, -26 (ix)
	adc	a, #0x00
	ld	-1 (ix), a
;fatFS/ff_findvolume.c:286: if (fmt == FS_FAT32) {
	ld	a, -7 (ix)
	sub	a, #0x03
	jr	NZ,00160$
;fatFS/ff_findvolume.c:287: if (ld_word(fs->win + BPB_FSVer32) != 0) {
	ld	c, -21 (ix)
	ld	b, -20 (ix)
	ld	l, -21 (ix)
	ld	h, -20 (ix)
	ld	de, #0x002b
	add	hl, de
	ld	d, (hl)
	ld	e, #0x00
	ld	l, c
	ld	h, b
	ld	bc, #0x002a
	add	hl, bc
	ld	c, (hl)
	ld	b, #0x00
	ld	a, e
	or	a, c
	ld	c, a
	ld	a, d
	or	a, b
	or	a, c
	jr	Z,00154$
;fatFS/ff_findvolume.c:288: return FR_NO_FILESYSTEM;	/* (Must be FAT32 revision 0.0) */
	ld	l, #0x0d
	jp	00166$
00154$:
;fatFS/ff_findvolume.c:290: if (fs->n_rootdir != 0) {
	ld	l, -13 (ix)
	ld	h, -12 (ix)
	ld	a, (hl)
	inc	hl
	or	a, (hl)
	jr	Z,00156$
;fatFS/ff_findvolume.c:291: return FR_NO_FILESYSTEM;	/* (BPB_RootEntCnt must be 0) */
	ld	l, #0x0d
	jp	00166$
00156$:
;fatFS/ff_findvolume.c:293: fs->dirbase = ld_dword(fs->win + BPB_RootClus32);	/* Root directory start cluster */
	ld	a, -21 (ix)
	add	a, #0x2c
	ld	c, a
	ld	a, -20 (ix)
	adc	a, #0x00
	ld	b, a
	push	bc
	call	_ld_dword
	pop	af
	ld	c, l
	ld	b, h
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
	inc	hl
	ld	(hl), e
	inc	hl
	ld	(hl), d
;fatFS/ff_findvolume.c:294: szbfat = fs->n_fatent * 4;					/* (Needed FAT size) */
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	inc	hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	a, #0x02
00352$:
	sla	c
	rl	b
	rl	e
	rl	d
	dec	a
	jr	NZ,00352$
	jr	00161$
00160$:
;fatFS/ff_findvolume.c:296: if (fs->n_rootdir == 0)	{
	ld	l, -13 (ix)
	ld	h, -12 (ix)
	ld	a, (hl)
	inc	hl
	or	a, (hl)
	jr	NZ,00158$
;fatFS/ff_findvolume.c:297: return FR_NO_FILESYSTEM;	/* (BPB_RootEntCnt must not be 0) */
	ld	l, #0x0d
	jp	00166$
00158$:
;fatFS/ff_findvolume.c:299: fs->dirbase = fs->fatbase + fasize;			/* Root directory start sector */
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	inc	hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	a, c
	add	a, -17 (ix)
	ld	c, a
	ld	a, b
	adc	a, -16 (ix)
	ld	b, a
	ld	a, e
	adc	a, -15 (ix)
	ld	e, a
	ld	a, d
	adc	a, -14 (ix)
	ld	d, a
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
	inc	hl
	ld	(hl), e
	inc	hl
	ld	(hl), d
;fatFS/ff_findvolume.c:305: szbfat = fs->n_fatent * 2;				/* (Needed FAT size) */
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	inc	hl
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	sla	c
	rl	b
	rl	e
	rl	d
00161$:
;fatFS/ff_findvolume.c:309: if (fs->fsize < (szbfat + (SS(fs) - 1)) / SS(fs)) {
	push	de
	push	bc
	ld	e, -19 (ix)
	ld	d, -18 (ix)
	ld	hl, #0x0033
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	pop	de
	ld	a, c
	add	a, #0xff
	ld	l, a
	ld	a, b
	adc	a, #0x01
	ld	h, a
	jr	NC,00356$
	inc	de
00356$:
	ld	b, #0x09
00357$:
	srl	d
	rr	e
	rr	h
	rr	l
	djnz	00357$
	ld	a, -4 (ix)
	sub	a, l
	ld	a, -3 (ix)
	sbc	a, h
	ld	a, -2 (ix)
	sbc	a, e
	ld	a, -1 (ix)
	sbc	a, d
	jr	NC,00163$
;fatFS/ff_findvolume.c:310: return FR_NO_FILESYSTEM;	/* (BPB_FATSz must not be less than the size needed) */
	ld	l, #0x0d
	jr	00166$
00163$:
;fatFS/ff_findvolume.c:339: fs->fs_type = fmt;		/* FAT sub-type */
	ld	l, -27 (ix)
	ld	h, -26 (ix)
	ld	a, -7 (ix)
	ld	(hl), a
;fatFS/ff_findvolume.c:340: fs->id = ++Fsid;		/* Volume mount ID */
	ld	a, -27 (ix)
	add	a, #0x04
	ld	c, a
	ld	a, -26 (ix)
	adc	a, #0x00
	ld	b, a
	ld	hl, (_Fsid)
	inc	hl
	ld	(_Fsid), hl
	ld	iy, #_Fsid
	ld	a, 0 (iy)
	ld	(bc), a
	inc	bc
	ld	a, 1 (iy)
	ld	(bc), a
;fatFS/ff_findvolume.c:342: fs->lfnbuf = LfnBuf;	/* LFN working buffer */
	ld	a, -27 (ix)
	add	a, #0x0a
	ld	c, a
	ld	a, -26 (ix)
	adc	a, #0x00
	ld	b, a
	ld	a, #<(_LfnBuf)
	ld	(bc), a
	inc	bc
	ld	a, #>(_LfnBuf)
	ld	(bc), a
;fatFS/ff_findvolume.c:354: return FR_OK;
	ld	l, #0x00
00166$:
;fatFS/ff_findvolume.c:355: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
