;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module diskio_sendcmd
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _select
	.globl _deselect
	.globl _rcvr_mmc
	.globl _xmit_mmc
	.globl _send_cmd
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_sgmPSGAddressWrite	=	0x0050
_sgmPSGDataWrite	=	0x0051
_sgmPSGDataRead	=	0x0052
_sgmConfig	=	0x0053
_phRAMBankSelect	=	0x0054
_phBankingScheme	=	0x0055
_phSDControl	=	0x0056
_phSDData	=	0x0057
_phMachineID	=	0x0058
_phCartMask	=	0x0059
_sgmBIOSMap	=	0x007f
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\diskio_sendcmd.c:27: BYTE send_cmd (		/* Returns command response (bit7==1:Send failed)*/
;	---------------------------------
; Function send_cmd
; ---------------------------------
_send_cmd::
	call	___sdcc_enter_ix
	ld	hl, #-13
	add	hl, sp
	ld	sp, hl
;fatFs\diskio_sendcmd.c:34: if (cmd & 0x80) {	/* ACMD<n> is the command sequense of CMD55-CMD<n> */
	ld	a, 4 (ix)
	bit	7, a
	jr	Z,00104$
;fatFs\diskio_sendcmd.c:35: cmd &= 0x7F;
	and	a, #0x7f
	ld	4 (ix), a
;fatFs\diskio_sendcmd.c:36: n = send_cmd(CMD55, 0);
	ld	hl, #0x0000
	push	hl
	ld	hl, #0x0000
	push	hl
	ld	a, #0x37
	push	af
	inc	sp
	call	_send_cmd
	pop	af
	pop	af
	inc	sp
;fatFs\diskio_sendcmd.c:37: if (n > 1) return n;
	ld	a, #0x01
	sub	a, l
	jp	C,00119$
00104$:
;fatFs\diskio_sendcmd.c:41: if (cmd != CMD12) {
	ld	a, 4 (ix)
	sub	a, #0x0c
	ld	a, #0x01
	jr	Z,00169$
	xor	a, a
00169$:
	ld	c, a
	bit	0, c
	jr	NZ,00108$
;fatFs\diskio_sendcmd.c:42: deselect();
	push	bc
	call	_deselect
	call	_select
	pop	bc
	ld	a, h
	or	a, l
	jr	NZ,00108$
	ld	l, #0xff
	jp	00119$
00108$:
;fatFs\diskio_sendcmd.c:47: buf[0] = 0x40 | cmd;			/* Start + Command index */
	ld	hl, #1
	add	hl, sp
	ld	-6 (ix), l
	ld	-5 (ix), h
	ld	b, 4 (ix)
	ld	a, b
	set	6, a
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	(hl), a
;fatFs\diskio_sendcmd.c:48: buf[1] = (BYTE)(arg >> 24);		/* Argument[31..24] */
	ld	e, -6 (ix)
	ld	d, -5 (ix)
	inc	de
	ld	a, 8 (ix)
	ld	-4 (ix), a
	xor	a, a
	ld	-3 (ix), a
	ld	-2 (ix), a
	ld	-1 (ix), a
	ld	a, -4 (ix)
	ld	(de), a
;fatFs\diskio_sendcmd.c:49: buf[2] = (BYTE)(arg >> 16);		/* Argument[23..16] */
	ld	e, -6 (ix)
	ld	d, -5 (ix)
	inc	de
	inc	de
	ld	a, 7 (ix)
	ld	-4 (ix), a
	ld	a, 8 (ix)
	ld	-3 (ix), a
	xor	a, a
	ld	-2 (ix), a
	ld	-1 (ix), a
	ld	a, -4 (ix)
	ld	(de), a
;fatFs\diskio_sendcmd.c:50: buf[3] = (BYTE)(arg >> 8);		/* Argument[15..8] */
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	inc	hl
	inc	hl
	inc	hl
	ld	e, 6 (ix)
	ld	(hl), e
;fatFs\diskio_sendcmd.c:51: buf[4] = (BYTE)arg;				/* Argument[7..0] */
	ld	a, -6 (ix)
	add	a, #0x04
	ld	e, a
	ld	a, -5 (ix)
	adc	a, #0x00
	ld	d, a
	ld	a, 5 (ix)
	ld	(de), a
;fatFs\diskio_sendcmd.c:52: n = 0x01;						/* Dummy CRC + Stop */
	ld	e, #0x01
;fatFs\diskio_sendcmd.c:53: if (cmd == CMD0) n = 0x95;		/* (valid CRC for CMD0(0)) */
	ld	a, b
	or	a, a
	jr	NZ,00110$
	ld	e, #0x95
00110$:
;fatFs\diskio_sendcmd.c:54: if (cmd == CMD8) n = 0x87;		/* (valid CRC for CMD8(0x1AA)) */
	ld	a, 4 (ix)
	sub	a, #0x08
	jr	NZ,00112$
	ld	e, #0x87
00112$:
;fatFs\diskio_sendcmd.c:55: buf[5] = n;
	ld	a, -6 (ix)
	add	a, #0x05
	ld	l, a
	ld	a, -5 (ix)
	adc	a, #0x00
	ld	h, a
	ld	(hl), e
;fatFs\diskio_sendcmd.c:56: xmit_mmc(buf, 6);
	ld	e, -6 (ix)
	ld	d, -5 (ix)
	push	bc
	ld	hl, #0x0006
	push	hl
	push	de
	call	_xmit_mmc
	pop	af
	pop	af
	pop	bc
;fatFs\diskio_sendcmd.c:59: if (cmd == CMD12) rcvr_mmc(&d, 1);	/* Skip a stuff byte when stop reading */
	ld	a, c
	or	a, a
	jr	Z,00129$
	ld	hl, #0
	add	hl, sp
	ld	bc, #0x0001
	push	bc
	push	hl
	call	_rcvr_mmc
	pop	af
	pop	af
;fatFs\diskio_sendcmd.c:61: do {
00129$:
	ld	c, #0x0a
00116$:
;fatFs\diskio_sendcmd.c:62: rcvr_mmc(&d, 1);
	ld	hl, #0
	add	hl, sp
	push	bc
	ld	de, #0x0001
	push	de
	push	hl
	call	_rcvr_mmc
	pop	af
	pop	af
	pop	bc
;fatFs\diskio_sendcmd.c:63: } while ((d & 0x80) && --n);
	ld	l, -13 (ix)
	bit	7, l
	jr	Z,00118$
	dec	c
	jr	NZ,00116$
00118$:
;fatFs\diskio_sendcmd.c:65: return d;			/* Return with the response value */
00119$:
;fatFs\diskio_sendcmd.c:66: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
