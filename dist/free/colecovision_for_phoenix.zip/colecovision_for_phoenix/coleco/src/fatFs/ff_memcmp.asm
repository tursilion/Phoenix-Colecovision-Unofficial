;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_memcmp
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _mem_cmp
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_memcmp.c:39: int mem_cmp (const void* dst, const void* src, UINT cnt)	/* ZR:same, NZ:different */
;	---------------------------------
; Function mem_cmp
; ---------------------------------
_mem_cmp::
	call	___sdcc_enter_ix
	push	af
	push	af
;fatFs\ff_memcmp.c:41: const BYTE *d = (const BYTE *)dst, *s = (const BYTE *)src;
	ld	c, 4 (ix)
	ld	b, 5 (ix)
	ld	a, 6 (ix)
	ld	-2 (ix), a
	ld	a, 7 (ix)
	ld	-1 (ix), a
;fatFs\ff_memcmp.c:44: do {
	ld	e, 8 (ix)
	ld	d, 9 (ix)
00102$:
;fatFs\ff_memcmp.c:45: r = *d++ - *s++;
	ld	a, (bc)
	inc	bc
	ld	-4 (ix), a
	xor	a, a
	ld	-3 (ix), a
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	l, (hl)
	inc	-2 (ix)
	jr	NZ,00118$
	inc	-1 (ix)
00118$:
	ld	h, #0x00
	ld	a, -4 (ix)
	sub	a, l
	ld	l, a
	ld	a, -3 (ix)
	sbc	a, h
	ld	h, a
;fatFs\ff_memcmp.c:46: } while (--cnt && r == 0);
	dec	de
	ld	a, d
	or	a, e
	jr	Z,00104$
	ld	a, h
	or	a, l
	jr	Z,00102$
00104$:
;fatFs\ff_memcmp.c:48: return r;
;fatFs\ff_memcmp.c:49: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
