;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module diskio_waitready
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _dly_50us
	.globl _rcvr_mmc
	.globl _wait_ready
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_sgmPSGAddressWrite	=	0x0050
_sgmPSGDataWrite	=	0x0051
_sgmPSGDataRead	=	0x0052
_sgmConfig	=	0x0053
_phRAMBankSelect	=	0x0054
_phBankingScheme	=	0x0055
_phSDControl	=	0x0056
_phSDData	=	0x0057
_phMachineID	=	0x0058
_phCartMask	=	0x0059
_sgmBIOSMap	=	0x007f
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\diskio_waitready.c:27: int wait_ready (void)	/* 1:OK, 0:Timeout */
;	---------------------------------
; Function wait_ready
; ---------------------------------
_wait_ready::
	call	___sdcc_enter_ix
	dec	sp
;fatFs\diskio_waitready.c:32: for (tmr = 5000; tmr; tmr--) {	/* Wait for ready in timeout of 500ms */
	ld	bc, #0x1388
00104$:
;fatFs\diskio_waitready.c:33: rcvr_mmc(&d, 1);
	ld	hl, #0
	add	hl, sp
	push	bc
	ld	de, #0x0001
	push	de
	push	hl
	call	_rcvr_mmc
	pop	af
	pop	af
	pop	bc
;fatFs\diskio_waitready.c:34: if (d == 0xFF) break;
	ld	a, -1 (ix)
	inc	a
	jr	Z,00103$
;fatFs\diskio_waitready.c:35: dly_50us(2);
	push	bc
	ld	a, #0x02
	push	af
	inc	sp
	call	_dly_50us
	inc	sp
	pop	bc
;fatFs\diskio_waitready.c:32: for (tmr = 5000; tmr; tmr--) {	/* Wait for ready in timeout of 500ms */
	dec	bc
	ld	a, b
	or	a, c
	jr	NZ,00104$
00103$:
;fatFs\diskio_waitready.c:38: return tmr ? 1 : 0;
	ld	a, b
	or	a, c
	jr	Z,00108$
	ld	hl, #0x0001
	jr	00109$
00108$:
	ld	hl, #0x0000
00109$:
;fatFs\diskio_waitready.c:39: }
	inc	sp
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
