;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_createname
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _memset
	.globl _chk_chr
	.globl _create_name
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_createname.c:42: FRESULT create_name (	    /* FR_OK: successful, FR_INVALID_NAME: could not create */
;	---------------------------------
; Function create_name
; ---------------------------------
_create_name::
	call	___sdcc_enter_ix
	ld	hl, #-17
	add	hl, sp
	ld	sp, hl
;fatFs\ff_createname.c:56: p = *path; lfn = dp->obj.fs->lfnbuf; di = 0;
	ld	a, 6 (ix)
	ld	-17 (ix), a
	ld	a, 7 (ix)
	ld	-16 (ix), a
	pop	hl
	push	hl
	ld	a, (hl)
	ld	-4 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-3 (ix), a
	ld	a, 4 (ix)
	ld	-15 (ix), a
	ld	a, 5 (ix)
	ld	-14 (ix), a
	ld	l, -15 (ix)
	ld	h, -14 (ix)
	ld	c, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, c
	ld	de, #0x000a
	add	hl, de
	ld	a, (hl)
	ld	-13 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-12 (ix), a
	xor	a, a
	ld	-2 (ix), a
	xor	a, a
	ld	-1 (ix), a
00172$:
;fatFs\ff_createname.c:59: uc = *(p++);                /* get an ASCII character */
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	c, (hl)
	inc	-4 (ix)
	jr	NZ,00375$
	inc	-3 (ix)
00375$:
	ld	a, -4 (ix)
	ld	-11 (ix), a
	ld	a, -3 (ix)
	ld	-10 (ix), a
	ld	a, c
	ld	-9 (ix), a
	rla
	sbc	a, a
	ld	-8 (ix), a
;fatFs\ff_createname.c:67: if (wc < ' ' || wc == '/') break;	/* Break if end of the path or a separator is found */
	ld	a, -9 (ix)
	ld	-7 (ix), a
	ld	a, -8 (ix)
	ld	-6 (ix), a
	ld	a, -7 (ix)
	sub	a, #0x20
	ld	a, -6 (ix)
	sbc	a, #0x00
	ld	a, #0x00
	rla
	ld	-5 (ix), a
	or	a, a
	jr	NZ,00106$
	ld	a, -7 (ix)
	sub	a, #0x2f
	or	a, -6 (ix)
	jr	Z,00106$
;fatFs\ff_createname.c:72: if (di >= FF_MAX_LFN) return FR_INVALID_NAME;	/* Reject too long name */
	ld	a, -1 (ix)
	sub	a, #0x7f
	jr	C,00105$
	ld	l, #0x06
	jp	00178$
00105$:
;fatFs\ff_createname.c:73: lfn[di++] = wc;					/* Store the Unicode character */
	ld	l, -1 (ix)
	inc	-1 (ix)
	ld	a, -1 (ix)
	ld	-2 (ix), a
	ld	h, #0x00
	add	hl, hl
	ld	e, -13 (ix)
	ld	d, -12 (ix)
	add	hl, de
	ld	a, -9 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -8 (ix)
	ld	(hl), a
	jr	00172$
00106$:
;fatFs\ff_createname.c:78: *path = p;							/* Return pointer to the next segment */
	pop	hl
	push	hl
	ld	a, -11 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -10 (ix)
	ld	(hl), a
;fatFs\ff_createname.c:79: cf = (wc < ' ') ? NS_LAST : 0;		/* Set last segment flag if end of the path */
	ld	a, -5 (ix)
	or	a, a
	jr	Z,00180$
	ld	-4 (ix), #0x04
	xor	a, a
	ld	-3 (ix), a
	jr	00181$
00180$:
	xor	a, a
	ld	-4 (ix), a
	ld	-3 (ix), a
00181$:
	ld	a, -4 (ix)
	ld	-3 (ix), a
;fatFs\ff_createname.c:92: while (di) {						/* Snip off trailing spaces and dots if exist */
	ld	b, -2 (ix)
00110$:
;fatFs\ff_createname.c:93: wc = lfn[di - 1];
	ld	-2 (ix), b
	xor	a, a
	ld	-1 (ix), a
;fatFs\ff_createname.c:92: while (di) {						/* Snip off trailing spaces and dots if exist */
	ld	a, b
	or	a, a
	jr	Z,00220$
;fatFs\ff_createname.c:93: wc = lfn[di - 1];
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	dec	hl
	add	hl, hl
	ld	e, -13 (ix)
	ld	d, -12 (ix)
	add	hl, de
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
;fatFs\ff_createname.c:94: if (wc != ' ' && wc != '.') break;
	ld	a, e
	sub	a, #0x20
	or	a, d
	jr	Z,00108$
	ld	a, e
	sub	a, #0x2e
	or	a, d
	jr	NZ,00220$
00108$:
;fatFs\ff_createname.c:95: di--;
	dec	b
	jr	00110$
00220$:
	ld	-6 (ix), b
;fatFs\ff_createname.c:97: lfn[di] = 0;							/* LFN is created into the working buffer */
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	add	hl, hl
	ld	e, -13 (ix)
	ld	d, -12 (ix)
	add	hl, de
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
;fatFs\ff_createname.c:98: if (di == 0) return FR_INVALID_NAME;	/* Reject null name */
	ld	a, b
	or	a, a
	jr	NZ,00114$
	ld	l, #0x06
	jp	00178$
00114$:
;fatFs\ff_createname.c:101: for (si = 0; lfn[si] == ' '; si++) ;	/* Remove leading spaces */
	xor	a, a
	ld	-1 (ix), a
00175$:
	ld	a, -1 (ix)
	ld	-5 (ix), a
	xor	a, a
	ld	-4 (ix), a
	ld	a, -5 (ix)
	ld	-8 (ix), a
	ld	a, -4 (ix)
	ld	-7 (ix), a
	sla	-8 (ix)
	rl	-7 (ix)
	ld	a, -13 (ix)
	add	a, -8 (ix)
	ld	-5 (ix), a
	ld	a, -12 (ix)
	adc	a, -7 (ix)
	ld	-4 (ix), a
	ld	l, -5 (ix)
	ld	h, -4 (ix)
	ld	a, (hl)
	ld	-5 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-4 (ix), a
	ld	a, -5 (ix)
	sub	a, #0x20
	or	a, -4 (ix)
	jr	NZ,00221$
	inc	-1 (ix)
	jr	00175$
00221$:
	ld	a, -1 (ix)
	ld	-2 (ix), a
;fatFs\ff_createname.c:102: if (si > 0 || lfn[si] == '.') cf |= NS_LOSS | NS_LFN;	/* Is there any leading space or dot? */
	ld	a, -1 (ix)
	or	a, a
	jr	NZ,00116$
	ld	a, -5 (ix)
	sub	a, #0x2e
	or	a, -4 (ix)
	jr	NZ,00196$
00116$:
	ld	a, -3 (ix)
	or	a, #0x03
	ld	-3 (ix), a
;fatFs\ff_createname.c:103: while (di > 0 && lfn[di - 1] != '.') di--;	/* Find last dot (di<=si: no extension) */
00196$:
	ld	b, -6 (ix)
00120$:
	ld	a, b
	or	a, a
	jr	Z,00222$
	ld	l, b
	ld	h, #0x00
	dec	hl
	add	hl, hl
	ld	e, -13 (ix)
	ld	d, -12 (ix)
	add	hl, de
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	a, e
	sub	a, #0x2e
	or	a, d
	jr	Z,00222$
	dec	b
	jr	00120$
00222$:
	ld	-11 (ix), b
;fatFs\ff_createname.c:105: memset(dp->fn, ' ', 11);
	ld	a, -15 (ix)
	add	a, #0x1c
	ld	-10 (ix), a
	ld	a, -14 (ix)
	adc	a, #0x00
	ld	-9 (ix), a
	ld	c, -10 (ix)
	ld	b, -9 (ix)
	ld	hl, #0x000b
	push	hl
	ld	l, #0x20
	push	hl
	push	bc
	call	_memset
	pop	af
	pop	af
	pop	af
;fatFs\ff_createname.c:106: i = b = 0; ni = 8;
	ld	e, #0x00
	xor	a, a
	ld	-1 (ix), a
	ld	-8 (ix), #0x08
00177$:
;fatFs\ff_createname.c:108: wc = lfn[si++];					/* Get an LFN character */
	ld	l, -2 (ix)
	inc	-2 (ix)
	ld	h, #0x00
	add	hl, hl
	ld	c, -13 (ix)
	ld	b, -12 (ix)
	add	hl, bc
	ld	b, (hl)
	inc	hl
	ld	d, (hl)
;fatFs\ff_createname.c:122: si = di; i = 8; ni = 11; b <<= 2;		/* Enter name extension */
	ld	a, e
	add	a, a
	add	a, a
	ld	-7 (ix), a
;fatFs\ff_createname.c:109: if (wc == 0) break;				/* Break on end of the LFN */
	ld	a, d
	or	a, b
	jp	Z, 00158$
;fatFs\ff_createname.c:67: if (wc < ' ' || wc == '/') break;	/* Break if end of the path or a separator is found */
	ld	-6 (ix), b
	ld	-5 (ix), d
;fatFs\ff_createname.c:102: if (si > 0 || lfn[si] == '.') cf |= NS_LOSS | NS_LFN;	/* Is there any leading space or dot? */
	ld	a, -3 (ix)
	or	a, #0x03
	ld	c, a
;fatFs\ff_createname.c:110: if (wc == ' ' || (wc == '.' && si != di)) {	/* Remove embedded spaces and dots */
	ld	a, -6 (ix)
	sub	a, #0x20
	or	a, -5 (ix)
	jr	Z,00125$
	ld	a, -2 (ix)
	sub	a, -11 (ix)
	ld	a, #0x01
	jr	Z,00389$
	xor	a, a
00389$:
	ld	-4 (ix), a
	ld	a, -6 (ix)
	sub	a, #0x2e
	or	a, -5 (ix)
	jr	NZ,00126$
	bit	0, -4 (ix)
	jr	NZ,00126$
00125$:
;fatFs\ff_createname.c:111: cf |= NS_LOSS | NS_LFN;
	ld	-3 (ix), c
;fatFs\ff_createname.c:112: continue;
	jr	00177$
00126$:
;fatFs\ff_createname.c:115: if (i >= ni || si == di) {		/* End of field? */
	ld	a, -1 (ix)
	sub	a, -8 (ix)
	jr	NC,00135$
	ld	a, -4 (ix)
	or	a, a
	jr	Z,00136$
00135$:
;fatFs\ff_createname.c:116: if (ni == 11) {				/* Name extension overflow? */
	ld	a, -8 (ix)
	sub	a, #0x0b
	jr	NZ,00130$
;fatFs\ff_createname.c:117: cf |= NS_LOSS | NS_LFN;
	ld	-3 (ix), c
;fatFs\ff_createname.c:118: break;
	jp	00158$
00130$:
;fatFs\ff_createname.c:120: if (si != di) cf |= NS_LOSS | NS_LFN;	/* Name body overflow? */
	bit	0, -4 (ix)
	jr	NZ,00132$
	ld	-3 (ix), c
00132$:
;fatFs\ff_createname.c:121: if (si > di) break;						/* No name extension? */
	ld	a, -11 (ix)
	sub	a, -2 (ix)
	jp	C, 00158$
;fatFs\ff_createname.c:122: si = di; i = 8; ni = 11; b <<= 2;		/* Enter name extension */
	ld	a, -11 (ix)
	ld	-2 (ix), a
	ld	-1 (ix), #0x08
	ld	-8 (ix), #0x0b
	ld	e, -7 (ix)
;fatFs\ff_createname.c:123: continue;
	jp	00177$
00136$:
;fatFs\ff_createname.c:126: if (wc >= 0x80) {	/* Is this a non-ASCII character? */
	ld	a, -6 (ix)
	sub	a, #0x80
	ld	a, -5 (ix)
	sbc	a, #0x00
	jr	C,00141$
;fatFs\ff_createname.c:127: cf |= NS_LFN;	/* LFN entry needs to be created */
	ld	a, -3 (ix)
	or	a, #0x02
	ld	-3 (ix), a
;fatFs\ff_createname.c:137: if (wc & 0x80) wc = ExCvt[wc & 0x7F];	/* Convert extended character to upper (SBCS) */
	bit	7, b
	jr	Z,00141$
	ld	c, -6 (ix)
	res	7, c
	ld	b, #0x00
	ld	hl, #_ExCvt
	add	hl, bc
	ld	b, (hl)
	ld	d, #0x00
00141$:
;fatFs\ff_createname.c:67: if (wc < ' ' || wc == '/') break;	/* Break if end of the path or a separator is found */
	ld	-5 (ix), b
	ld	-4 (ix), d
;fatFs\ff_createname.c:102: if (si > 0 || lfn[si] == '.') cf |= NS_LOSS | NS_LFN;	/* Is there any leading space or dot? */
	ld	a, -3 (ix)
	or	a, #0x03
	ld	-6 (ix), a
;fatFs\ff_createname.c:143: if (wc >= 0x100) {				/* Is this a DBC? */
	ld	a, -4 (ix)
	sub	a, #0x01
	jr	C,00155$
;fatFs\ff_createname.c:144: if (i >= ni - 1) {			/* Field overflow? */
	ld	l, -8 (ix)
	ld	h, #0x00
	dec	hl
	ld	a, -1 (ix)
	ld	-5 (ix), a
	xor	a, a
	ld	-4 (ix), a
	ld	a, -5 (ix)
	sub	a, l
	ld	a, -4 (ix)
	sbc	a, h
	jp	PO, 00395$
	xor	a, #0x80
00395$:
	jp	M, 00143$
;fatFs\ff_createname.c:145: cf |= NS_LOSS | NS_LFN;
	ld	a, -6 (ix)
	ld	-3 (ix), a
;fatFs\ff_createname.c:146: i = ni; continue;		/* Next field */
	ld	a, -8 (ix)
	ld	-1 (ix), a
	jp	00177$
00143$:
;fatFs\ff_createname.c:148: dp->fn[i++] = (BYTE)(wc >> 8);	/* Put 1st byte */
	ld	a, -1 (ix)
	inc	-1 (ix)
	add	a, -10 (ix)
	ld	l, a
	ld	a, #0x00
	adc	a, -9 (ix)
	ld	h, a
	ld	-5 (ix), d
	ld	-4 (ix), #0x00
	ld	a, -5 (ix)
	ld	(hl), a
	jr	00156$
00155$:
;fatFs\ff_createname.c:150: if (wc == 0 || chk_chr("+,;=[]", wc)) {	/* Replace illegal characters for SFN if needed */
	ld	a, d
	or	a, b
	jr	Z,00150$
	ld	l, b
	ld	h, d
	push	bc
	push	de
	push	hl
	ld	hl, #___str_0
	push	hl
	call	_chk_chr
	pop	af
	pop	af
	pop	de
	pop	bc
	ld	a, h
	or	a, l
	jr	Z,00151$
00150$:
;fatFs\ff_createname.c:151: wc = '_'; cf |= NS_LOSS | NS_LFN;/* Lossy conversion */
	ld	b, #0x5f
	ld	a, -6 (ix)
	ld	-3 (ix), a
	jr	00156$
00151$:
;fatFs\ff_createname.c:153: if (IsUpper(wc)) {		/* ASCII upper case? */
	ld	a, -5 (ix)
	sub	a, #0x41
	ld	a, -4 (ix)
	sbc	a, #0x00
	jr	C,00145$
	ld	a, #0x5a
	cp	a, -5 (ix)
	ld	a, #0x00
	sbc	a, -4 (ix)
	jr	C,00145$
;fatFs\ff_createname.c:154: b |= 2;
	set	1, e
00145$:
;fatFs\ff_createname.c:156: if (IsLower(wc)) {		/* ASCII lower case? */
	ld	a, -5 (ix)
	sub	a, #0x61
	ld	a, -4 (ix)
	sbc	a, #0x00
	jr	C,00156$
	ld	a, #0x7a
	cp	a, -5 (ix)
	ld	a, #0x00
	sbc	a, -4 (ix)
	jr	C,00156$
;fatFs\ff_createname.c:157: b |= 1; 
	set	0, e
00156$:
;fatFs\ff_createname.c:164: dp->fn[i++] = (BYTE)wc;
	ld	a, -1 (ix)
	inc	-1 (ix)
	add	a, -10 (ix)
	ld	l, a
	ld	a, #0x00
	adc	a, -9 (ix)
	ld	h, a
	ld	(hl), b
	jp	00177$
00158$:
;fatFs\ff_createname.c:167: if (dp->fn[0] == DDEM) dp->fn[0] = RDDEM;	/* If the first character collides with DDEM, replace it with RDDEM */
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	ld	a, (hl)
	sub	a, #0xe5
	jr	NZ,00160$
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	ld	(hl), #0x05
00160$:
;fatFs\ff_createname.c:169: if (ni == 8) b <<= 2;				/* Shift capital flags if no extension */
	ld	a, -8 (ix)
	sub	a, #0x08
	jr	NZ,00162$
	ld	e, -7 (ix)
00162$:
;fatFs\ff_createname.c:170: if ((b & 0x0C) == 0x0C || (b & 0x03) == 0x03) cf |= NS_LFN;	/* LFN entry needs to be created if composite capitals */
	ld	-2 (ix), e
	xor	a, a
	ld	-1 (ix), a
	ld	a, -2 (ix)
	and	a, #0x0c
	ld	c, a
	ld	b, #0x00
	ld	a, c
	sub	a, #0x0c
	or	a, b
	jr	Z,00163$
	ld	a, -2 (ix)
	and	a, #0x03
	ld	c, a
	ld	b, #0x00
	ld	a, c
	sub	a, #0x03
	or	a, b
	jr	NZ,00164$
00163$:
	ld	a, -3 (ix)
	or	a, #0x02
	ld	-3 (ix), a
00164$:
;fatFs\ff_createname.c:171: if (!(cf & NS_LFN)) {				/* When LFN is in 8.3 format without extended character, NT flags are created */
	bit	1, -3 (ix)
	jr	NZ,00171$
;fatFs\ff_createname.c:172: if (b & 0x01) cf |= NS_EXT;		/* NT flag (Extension has small capital letters only) */
	bit	0, e
	jr	Z,00167$
	ld	a, -3 (ix)
	or	a, #0x10
	ld	-3 (ix), a
00167$:
;fatFs\ff_createname.c:173: if (b & 0x04) cf |= NS_BODY;	/* NT flag (Body has small capital letters only) */
	bit	2, e
	jr	Z,00171$
	ld	a, -3 (ix)
	or	a, #0x08
	ld	-3 (ix), a
00171$:
;fatFs\ff_createname.c:176: dp->fn[NSFLAG] = cf;	/* SFN is created into dp->fn[] */
	ld	a, -15 (ix)
	add	a, #0x27
	ld	-2 (ix), a
	ld	a, -14 (ix)
	adc	a, #0x00
	ld	-1 (ix), a
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	a, -3 (ix)
	ld	(hl), a
;fatFs\ff_createname.c:178: return FR_OK;
	ld	l, #0x00
00178$:
;fatFs\ff_createname.c:245: }
	ld	sp, ix
	pop	ix
	ret
___str_0:
	.ascii "+,;=[]"
	.db 0x00
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
