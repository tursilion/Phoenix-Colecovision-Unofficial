;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_sumsfn
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _sum_sfn
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_sumsfn.c:43: BYTE sum_sfn (
;	---------------------------------
; Function sum_sfn
; ---------------------------------
_sum_sfn::
	call	___sdcc_enter_ix
	dec	sp
;fatFs\ff_sumsfn.c:47: BYTE sum = 0;
	xor	a, a
	ld	-1 (ix), a
;fatFs\ff_sumsfn.c:48: UINT n = 11;
	ld	bc, #0x000b
;fatFs\ff_sumsfn.c:50: do {
	ld	l, 4 (ix)
	ld	h, 5 (ix)
00101$:
;fatFs\ff_sumsfn.c:51: sum = (sum >> 1) + (sum << 7) + *dir++;
	ld	e, -1 (ix)
	srl	e
	ld	a, -1 (ix)
	rrca
	and	a, #0x80
	add	a, e
	ld	e, (hl)
	inc	hl
	add	a, e
	ld	-1 (ix), a
;fatFs\ff_sumsfn.c:52: } while (--n);
	ld	e, c
	ld	d, b
	dec	de
	ld	c, e
	ld	a,d
	ld	b,a
	or	a, e
	jr	NZ,00101$
;fatFs\ff_sumsfn.c:53: return sum;
	ld	l, -1 (ix)
;fatFs\ff_sumsfn.c:54: }
	inc	sp
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
