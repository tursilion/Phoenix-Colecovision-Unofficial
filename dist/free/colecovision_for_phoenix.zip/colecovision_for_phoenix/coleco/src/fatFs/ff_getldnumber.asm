;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_getldnumber
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _get_ldnumber_unused
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_getldnumber.c:47: int get_ldnumber (	/* Returns logical drive number (-1:invalid drive number or null pointer) */
;	---------------------------------
; Function get_ldnumber_unused
; ---------------------------------
_get_ldnumber_unused::
	call	___sdcc_enter_ix
	ld	hl, #-11
	add	hl, sp
	ld	sp, hl
;fatFs\ff_getldnumber.c:53: int i, vol = -1;
	ld	hl, #0xffff
	ex	(sp), hl
;fatFs\ff_getldnumber.c:59: tt = tp = *path;
	ld	a, 4 (ix)
	ld	-9 (ix), a
	ld	a, 5 (ix)
	ld	-8 (ix), a
	ld	l, -9 (ix)
	ld	h, -8 (ix)
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	-7 (ix), e
;fatFs\ff_getldnumber.c:60: if (!tp) return vol;	/* Invalid path name? */
	ld	-6 (ix), d
	ld	a, d
	or	a, -7 (ix)
	jr	NZ,00119$
	ld	hl, #0xffff
	jp	00115$
;fatFs\ff_getldnumber.c:61: do tc = *tt++; while ((UINT)tc >= (FF_USE_LFN ? ' ' : '!') && tc != ':');	/* Find a colon in the path */
00119$:
00104$:
	ld	a, (de)
	inc	de
	push	af
	ld	b, a
	rla
	sbc	a, a
	ld	l, a
	pop	af
	sub	a, #0x3a
	ld	a, #0x01
	jr	Z,00159$
	xor	a, a
00159$:
	ld	c, a
	ld	a, b
	sub	a, #0x20
	ld	a, l
	sbc	a, #0x00
	jr	C,00125$
	bit	0, c
	jr	Z,00104$
00125$:
	ld	-5 (ix), e
	ld	-4 (ix), d
;fatFs\ff_getldnumber.c:63: if (tc == ':') {	/* DOS/Windows style volume ID? */
	ld	a, c
	or	a, a
	jr	Z,00114$
;fatFs\ff_getldnumber.c:64: i = FF_VOLUMES;
	ld	bc, #0x0001
;fatFs\ff_getldnumber.c:65: if (IsDigit(*tp) && tp + 2 == tt) {	/* Is there a numeric volume ID + colon? */
	ld	l, -7 (ix)
	ld	h, -6 (ix)
	ld	a, (hl)
	ld	-3 (ix), a
	xor	a, #0x80
	sub	a, #0xb0
	jr	C,00108$
	ld	a, #0x39
	sub	a, -3 (ix)
	jp	PO, 00160$
	xor	a, #0x80
00160$:
	jp	M, 00108$
	ld	a, -7 (ix)
	add	a, #0x02
	ld	-2 (ix), a
	ld	a, -6 (ix)
	adc	a, #0x00
	ld	-1 (ix), a
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	cp	a, a
	sbc	hl, de
	jr	NZ,00108$
;fatFs\ff_getldnumber.c:66: i = (int)*tp - '0';	/* Get the LD number */
	ld	a, -3 (ix)
	ld	c, a
	rla
	sbc	a, a
	ld	b, a
	ld	a, c
	add	a, #0xd0
	ld	c, a
	ld	a, b
	adc	a, #0xff
	ld	b, a
00108$:
;fatFs\ff_getldnumber.c:83: if (i < FF_VOLUMES) {	/* If a volume ID is found, get the drive number and strip it */
	ld	a, c
	sub	a, #0x01
	ld	a, b
	rla
	ccf
	rra
	sbc	a, #0x80
	jr	NC,00112$
;fatFs\ff_getldnumber.c:84: vol = i;		/* Drive number */
	inc	sp
	inc	sp
	push	bc
;fatFs\ff_getldnumber.c:85: *path = tt;		/* Snip the drive prefix off */
	pop	bc
	pop	hl
	push	hl
	push	bc
	ld	a, -5 (ix)
	ld	(hl), a
	inc	hl
	ld	a, -4 (ix)
	ld	(hl), a
00112$:
;fatFs\ff_getldnumber.c:87: return vol;
	pop	hl
	push	hl
	jr	00115$
00114$:
;fatFs\ff_getldnumber.c:115: return vol;		/* Return the default drive */
	ld	hl, #0x0000
00115$:
;fatFs\ff_getldnumber.c:116: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
