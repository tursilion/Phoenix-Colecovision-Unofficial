;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_dirread
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _sum_sfn
	.globl _pick_lfn
	.globl _dir_next
	.globl _move_window
	.globl _dir_read
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_dirread.c:46: FRESULT dir_read (
;	---------------------------------
; Function dir_read
; ---------------------------------
_dir_read::
	call	___sdcc_enter_ix
	ld	hl, #-18
	add	hl, sp
	ld	sp, hl
;fatFs\ff_dirread.c:51: FRESULT res = FR_NO_FILE;
	ld	-15 (ix), #0x04
;fatFs\ff_dirread.c:52: FATFS *fs = dp->obj.fs;
	ld	c, 4 (ix)
	ld	b, 5 (ix)
	ld	a, (bc)
	ld	-14 (ix), a
	inc	bc
	ld	a, (bc)
	ld	-13 (ix), a
	dec	bc
;fatFs\ff_dirread.c:55: BYTE ord = 0xFF, sum = 0xFF;
	ld	-12 (ix), #0xff
	ld	-11 (ix), #0xff
;fatFs\ff_dirread.c:58: while (dp->sect) {
	ld	-10 (ix), c
	ld	-9 (ix), b
	ld	a, -14 (ix)
	ld	-8 (ix), a
	ld	a, -13 (ix)
	ld	-7 (ix), a
	ld	hl, #0x0016
	add	hl, bc
	ld	-6 (ix), l
	ld	-5 (ix), h
00120$:
	push	bc
	ld	e, -6 (ix)
	ld	d, -5 (ix)
	ld	hl, #0x0010
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	ld	a, -1 (ix)
	or	a, -2 (ix)
	or	a, -3 (ix)
	or	a, -4 (ix)
	jp	Z, 00122$
;fatFs\ff_dirread.c:59: res = move_window(fs, dp->sect);
	push	bc
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	push	hl
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	push	hl
	ld	l, -14 (ix)
	ld	h, -13 (ix)
	push	hl
	call	_move_window
	pop	af
	pop	af
	pop	af
	pop	bc
;fatFs\ff_dirread.c:60: if (res != FR_OK) {
	ld	-15 (ix), l
	ld	a, l
	or	a, a
	jp	NZ, 00122$
;fatFs\ff_dirread.c:63: b = dp->dir[DIR_Name];	/* Test for the entry type */
	ld	hl, #0x001a
	add	hl, bc
	ld	-4 (ix), l
	ld	-3 (ix), h
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	ld	a, (hl)
;fatFs\ff_dirread.c:64: if (b == 0) {
	ld	-1 (ix), a
	or	a, a
	jr	NZ,00104$
;fatFs\ff_dirread.c:65: res = FR_NO_FILE; 
	ld	-15 (ix), #0x04
;fatFs\ff_dirread.c:66: break; /* Reached to end of the directory */
	jp	00122$
00104$:
;fatFs\ff_dirread.c:86: dp->obj.attr = attr = dp->dir[DIR_Attr] & AM_MASK;	/* Get attribute */
	ld	a, c
	add	a, #0x04
	ld	e, a
	ld	a, b
	adc	a, #0x00
	ld	d, a
	push	bc
	ld	bc, #0x000b
	add	hl, bc
	pop	bc
	ld	a, (hl)
	and	a, #0x3f
	ld	-2 (ix), a
	ld	(de), a
;fatFs\ff_dirread.c:88: if (b == DDEM || b == '.' || (int)((attr & ~AM_ARC) == AM_VOL) != vol) {	/* An entry without valid data */
	ld	a, -1 (ix)
	sub	a, #0xe5
	jr	Z,00113$
	ld	a, -1 (ix)
	sub	a, #0x2e
	jr	Z,00113$
	ld	e, -2 (ix)
	ld	d, #0x00
	res	5, e
	ld	a, e
	sub	a, #0x08
	or	a, d
	ld	a, #0x01
	jr	Z,00201$
	xor	a, a
00201$:
	ld	e, a
	ld	d, #0x00
	ld	l, 6 (ix)
	ld	h, 7 (ix)
	cp	a, a
	sbc	hl, de
	jr	Z,00114$
00113$:
;fatFs\ff_dirread.c:89: ord = 0xFF;
	ld	-12 (ix), #0xff
	jp	00115$
00114$:
;fatFs\ff_dirread.c:95: dp->blk_ofs = dp->dptr;
	ld	hl, #0x0028
	add	hl, bc
	ex	de, hl
;fatFs\ff_dirread.c:91: if (attr == AM_LFN) {			/* An LFN entry is found */
	ld	a, -2 (ix)
	sub	a, #0x0f
	jp	NZ,00111$
;fatFs\ff_dirread.c:92: if (b & LLEF) {			/* Is it start of an LFN sequence? */
	bit	6, -1 (ix)
	jr	Z,00106$
;fatFs\ff_dirread.c:93: sum = dp->dir[LDIR_Chksum];
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	push	bc
	ld	bc, #0x000d
	add	hl, bc
	pop	bc
	ld	a, (hl)
	ld	-11 (ix), a
;fatFs\ff_dirread.c:94: b &= (BYTE)~LLEF; ord = b;
	ld	a, -1 (ix)
	and	a, #0xbf
	ld	-1 (ix), a
	ld	-12 (ix), a
;fatFs\ff_dirread.c:95: dp->blk_ofs = dp->dptr;
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	push	bc
	ld	bc, #0x000e
	add	hl, bc
	pop	bc
	ld	a, (hl)
	ld	-18 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-17 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-16 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-15 (ix), a
	push	bc
	ld	hl, #0x0002
	add	hl, sp
	ld	bc, #0x0004
	ldir
	pop	bc
00106$:
;fatFs\ff_dirread.c:98: ord = (b == ord && sum == dp->dir[LDIR_Chksum] && pick_lfn(fs->lfnbuf, dp->dir)) ? ord - 1 : 0xFF;
	ld	a, -12 (ix)
	sub	a, -1 (ix)
	jr	NZ,00127$
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
	ld	l, e
	ld	h, d
	push	bc
	ld	bc, #0x000d
	add	hl, bc
	pop	bc
	ld	a, (hl)
	ld	-1 (ix), a
	ld	a, -11 (ix)
	sub	a, -1 (ix)
	jr	NZ,00127$
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	push	bc
	ld	bc, #0x000a
	add	hl, bc
	pop	bc
	ld	a, (hl)
	inc	hl
	ld	h, (hl)
	ld	l, a
	push	bc
	push	de
	push	hl
	call	_pick_lfn
	pop	af
	pop	af
	pop	bc
	ld	a, h
	or	a, l
	jr	Z,00127$
	ld	a, -12 (ix)
	dec	a
	ld	e, a
	rla
	sbc	a, a
	jr	00128$
00127$:
	ld	de, #0x00ff
00128$:
	ld	-12 (ix), e
	jr	00115$
00111$:
;fatFs\ff_dirread.c:100: if (ord != 0 || sum != sum_sfn(dp->dir)) {	/* Is there a valid LFN? */
	ld	a, -12 (ix)
	or	a, a
	jr	NZ,00107$
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	push	de
	push	bc
	call	_sum_sfn
	pop	af
	ld	c, l
	pop	de
	ld	a, -11 (ix)
	sub	a, c
	jr	Z,00122$
00107$:
;fatFs\ff_dirread.c:101: dp->blk_ofs = 0xFFFFFFFF;			/* It has no LFN. */
	ld	a, #0xff
	ld	(de), a
	inc	de
	ld	a, #0xff
	ld	(de), a
	inc	de
	ld	a, #0xff
	ld	(de), a
	inc	de
	ld	a, #0xff
	ld	(de), a
;fatFs\ff_dirread.c:103: break;
	jr	00122$
00115$:
;fatFs\ff_dirread.c:112: res = dir_next(dp, 0);		/* Next entry */
	push	bc
	ld	hl, #0x0000
	push	hl
	push	bc
	call	_dir_next
	pop	af
	pop	af
	pop	bc
;fatFs\ff_dirread.c:113: if (res != FR_OK) {
	ld	-15 (ix), l
	ld	a, l
	or	a, a
	jp	Z, 00120$
;fatFs\ff_dirread.c:114: break;
00122$:
;fatFs\ff_dirread.c:118: if (res != FR_OK) {
	ld	a, -15 (ix)
	or	a, a
	jr	Z,00124$
;fatFs\ff_dirread.c:119: dp->sect = 0;		/* Terminate the read operation on error or EOT */
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	ld	(hl), a
00124$:
;fatFs\ff_dirread.c:121: return res;
	ld	l, -15 (ix)
;fatFs\ff_dirread.c:122: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
