;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_picklfn
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _pick_lfn
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_picklfn.c:45: int pick_lfn (	/* 1:succeeded, 0:buffer overflow or invalid LFN entry */
;	---------------------------------
; Function pick_lfn
; ---------------------------------
_pick_lfn::
	call	___sdcc_enter_ix
	ld	hl, #-10
	add	hl, sp
	ld	sp, hl
;fatFs\ff_picklfn.c:54: if (ld_word(dir + LDIR_FstClusLO) != 0) return 0;	/* Check LDIR_FstClusLO is 0 */
	ld	a, 6 (ix)
	add	a, #0x1a
	ld	e, a
	ld	a, 7 (ix)
	adc	a, #0x00
	ld	d, a
	ld	l, e
	ld	h, d
	inc	hl
	ld	b, (hl)
	ld	c, #0x00
	ld	a, (de)
	ld	e, a
	ld	d, #0x00
	ld	a, c
	or	a, e
	ld	c, a
	ld	a, b
	or	a, d
	or	a, c
	jr	Z,00102$
	ld	hl, #0x0000
	jp	00118$
00102$:
;fatFs\ff_picklfn.c:56: i = ((dir[LDIR_Ord] & ~LLEF) - 1) * 13;	/* Offset in the LFN buffer */
	ld	a, 6 (ix)
	ld	-10 (ix), a
	ld	a, 7 (ix)
	ld	-9 (ix), a
	pop	hl
	push	hl
	ld	c, (hl)
	ld	b, #0x00
	res	6, c
	dec	bc
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, bc
	add	hl, hl
	add	hl, hl
	add	hl, bc
	ld	-8 (ix), l
	ld	-7 (ix), h
;fatFs\ff_picklfn.c:58: for (wc = 1, s = 0; s < 13; s++) {		/* Process all characters in the entry */
	ld	-6 (ix), #0x01
	xor	a, a
	ld	-5 (ix), a
	ld	a, -8 (ix)
	ld	-2 (ix), a
	ld	a, -7 (ix)
	ld	-1 (ix), a
	ld	bc, #0x0000
00116$:
	ld	a, c
	sub	a, #0x0d
	ld	a, b
	sbc	a, #0x00
	jp	NC, 00110$
;fatFs\ff_picklfn.c:59: uc = ld_word(dir + LfnOfs[s]);		/* Pick an LFN character */
	ld	hl, #_LfnOfs
	add	hl, bc
	ld	a, (hl)
	add	a, -10 (ix)
	ld	e, a
	ld	a, #0x00
	adc	a, -9 (ix)
	ld	d, a
	ld	l, e
	ld	h, d
	inc	hl
	ld	l, (hl)
	ld	-3 (ix), l
	ld	-4 (ix), #0x00
	ld	a, (de)
	ld	e, a
	ld	d, #0x00
	ld	a, -4 (ix)
	or	a, e
	ld	e, a
	ld	a, -3 (ix)
	or	a, d
	ld	d, a
;fatFs\ff_picklfn.c:60: if (wc != 0) {
	ld	a, -5 (ix)
	or	a, -6 (ix)
	jr	Z,00108$
;fatFs\ff_picklfn.c:61: if (i >= FF_MAX_LFN) return 0;	/* Buffer overflow? */
	ld	a, -2 (ix)
	sub	a, #0x7f
	ld	a, -1 (ix)
	sbc	a, #0x00
	jr	C,00104$
	ld	hl, #0x0000
	jr	00118$
00104$:
;fatFs\ff_picklfn.c:62: lfnbuf[i++] = wc = uc;			/* Store it */
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	inc	-2 (ix)
	jr	NZ,00160$
	inc	-1 (ix)
00160$:
	ld	a, -2 (ix)
	ld	-8 (ix), a
	ld	a, -1 (ix)
	ld	-7 (ix), a
	add	hl, hl
	ld	-4 (ix), l
	ld	-3 (ix), h
	ld	a, 4 (ix)
	add	a, -4 (ix)
	ld	l, a
	ld	a, 5 (ix)
	adc	a, -3 (ix)
	ld	h, a
	ld	-6 (ix), e
	ld	-5 (ix), d
	ld	(hl), e
	inc	hl
	ld	(hl), d
	jr	00117$
00108$:
;fatFs\ff_picklfn.c:64: if (uc != 0xFFFF) return 0;		/* Check filler */
	ld	a, e
	and	a, d
	inc	a
	jr	Z,00117$
	ld	hl, #0x0000
	jr	00118$
00117$:
;fatFs\ff_picklfn.c:58: for (wc = 1, s = 0; s < 13; s++) {		/* Process all characters in the entry */
	inc	bc
	jp	00116$
00110$:
;fatFs\ff_picklfn.c:68: if (dir[LDIR_Ord] & LLEF) {				/* Put terminator if it is the last LFN part */
	pop	hl
	push	hl
	bit	6, (hl)
	jr	Z,00114$
;fatFs\ff_picklfn.c:69: if (i >= FF_MAX_LFN) return 0;		/* Buffer overflow? */
	ld	a, -8 (ix)
	sub	a, #0x7f
	ld	a, -7 (ix)
	sbc	a, #0x00
	jr	C,00112$
	ld	hl, #0x0000
	jr	00118$
00112$:
;fatFs\ff_picklfn.c:70: lfnbuf[i] = 0;
	pop	de
	pop	bc
	push	bc
	push	de
	sla	c
	rl	b
	ld	l, 4 (ix)
	ld	h, 5 (ix)
	add	hl, bc
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
00114$:
;fatFs\ff_picklfn.c:73: return 1;		/* The part of LFN is valid */
	ld	hl, #0x0001
00118$:
;fatFs\ff_picklfn.c:74: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
