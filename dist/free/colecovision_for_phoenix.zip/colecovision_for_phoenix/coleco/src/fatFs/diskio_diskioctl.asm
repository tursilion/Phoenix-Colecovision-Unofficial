;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module diskio_diskioctl
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _send_cmd
	.globl _rcvr_datablock
	.globl _select
	.globl _deselect
	.globl _disk_status
	.globl _disk_ioctl
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_sgmPSGAddressWrite	=	0x0050
_sgmPSGDataWrite	=	0x0051
_sgmPSGDataRead	=	0x0052
_sgmConfig	=	0x0053
_phRAMBankSelect	=	0x0054
_phBankingScheme	=	0x0055
_phSDControl	=	0x0056
_phSDData	=	0x0057
_phMachineID	=	0x0058
_phCartMask	=	0x0059
_sgmBIOSMap	=	0x007f
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\diskio_diskioctl.c:34: DRESULT disk_ioctl (
;	---------------------------------
; Function disk_ioctl
; ---------------------------------
_disk_ioctl::
	call	___sdcc_enter_ix
	ld	hl, #-22
	add	hl, sp
	ld	sp, hl
;fatFs\diskio_diskioctl.c:48: if (disk_status() & STA_NOINIT) return RES_NOTRDY;	/* Check if card is in the socket */
	call	_disk_status
	ld	a, l
	rrca
	jr	NC,00102$
	ld	l, #0x03
	jp	00116$
00102$:
;fatFs\diskio_diskioctl.c:51: res = RES_ERROR;
	ld	-1 (ix), #0x01
;fatFs\diskio_diskioctl.c:52: switch (ctrl) {
	ld	a, 4 (ix)
	or	a, a
	jr	Z,00103$
;fatFs\diskio_diskioctl.c:61: *(DWORD*)buff = cs << 10;
	ld	a, 5 (ix)
	ld	-6 (ix), a
	ld	a, 6 (ix)
	ld	-5 (ix), a
;fatFs\diskio_diskioctl.c:52: switch (ctrl) {
	ld	a, 4 (ix)
	dec	a
	jr	Z,00106$
	ld	a, 4 (ix)
	sub	a, #0x03
	jp	Z,00113$
	jp	00114$
;fatFs\diskio_diskioctl.c:53: case CTRL_SYNC :		/* Make sure that no pending write process */
00103$:
;fatFs\diskio_diskioctl.c:54: if (select()) res = RES_OK;
	call	_select
	ld	a, h
	or	a, l
	jp	Z, 00115$
	xor	a, a
	ld	-1 (ix), a
;fatFs\diskio_diskioctl.c:55: break;
	jp	00115$
;fatFs\diskio_diskioctl.c:57: case GET_SECTOR_COUNT :	/* Get number of sectors on the disk (DWORD) */
00106$:
;fatFs\diskio_diskioctl.c:58: if ((send_cmd(CMD9, 0) == 0) && rcvr_datablock(csd, 16)) {
	ld	hl, #0x0000
	push	hl
	ld	hl, #0x0000
	push	hl
	ld	a, #0x09
	push	af
	inc	sp
	call	_send_cmd
	pop	af
	pop	af
	inc	sp
	ld	a, l
	or	a, a
	jp	NZ, 00115$
	ld	hl, #0
	add	hl, sp
	ex	de, hl
	ld	c, e
	ld	b, d
	push	de
	ld	hl, #0x0010
	push	hl
	push	bc
	call	_rcvr_datablock
	pop	af
	pop	af
	pop	de
	ld	a, h
	or	a, l
	jp	Z, 00115$
;fatFs\diskio_diskioctl.c:59: if ((csd[0] >> 6) == 1) {	/* SDC ver 2.00 */
	ld	a, (de)
	rlca
	rlca
	and	a, #0x03
	ld	-4 (ix), a
;fatFs\diskio_diskioctl.c:60: cs = csd[9] + ((WORD)csd[8] << 8) + ((DWORD)(csd[7] & 63) << 16) + 1;
	ld	l, e
	ld	h, d
	ld	c, e
	ld	b, d
	ld	-3 (ix), e
	ld	-2 (ix), d
	push	bc
	ld	bc, #0x0009
	add	hl, bc
	pop	bc
	ld	a, (hl)
	ld	-1 (ix), a
	ld	l, c
	ld	h, b
	ld	bc, #0x0008
	add	hl, bc
	ld	c, (hl)
	ld	l, -3 (ix)
	ld	h, -2 (ix)
	push	bc
	ld	bc, #0x0007
	add	hl, bc
	pop	bc
	ld	b, (hl)
;fatFs\diskio_diskioctl.c:59: if ((csd[0] >> 6) == 1) {	/* SDC ver 2.00 */
	ld	a, -4 (ix)
	dec	a
	jr	NZ,00108$
;fatFs\diskio_diskioctl.c:60: cs = csd[9] + ((WORD)csd[8] << 8) + ((DWORD)(csd[7] & 63) << 16) + 1;
	ld	l, -1 (ix)
	ld	h, #0x00
	ld	e, #0x00
	ld	d, c
	add	hl, de
	ld	a, b
	and	a, #0x3f
	ld	d, #0x00
	ld	e, a
	ld	a, d
	rla
	sbc	a, a
	ld	bc, #0x0000
	ld	-4 (ix), l
	ld	-3 (ix), h
	xor	a, a
	ld	-2 (ix), a
	ld	-1 (ix), a
	ld	a, -4 (ix)
	add	a, c
	ld	c, a
	ld	a, -3 (ix)
	adc	a, b
	ld	b, a
	ld	a, -2 (ix)
	adc	a, e
	ld	e, a
	ld	a, -1 (ix)
	adc	a, d
	ld	d, a
	inc	c
	jr	NZ,00166$
	inc	b
	jr	NZ,00166$
	inc	de
00166$:
;fatFs\diskio_diskioctl.c:61: *(DWORD*)buff = cs << 10;
	ld	a, #0x0a
00167$:
	sla	c
	rl	b
	rl	e
	rl	d
	dec	a
	jr	NZ,00167$
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	(hl), c
	inc	hl
	ld	(hl), b
	inc	hl
	ld	(hl), e
	inc	hl
	ld	(hl), d
	jp	00109$
00108$:
;fatFs\diskio_diskioctl.c:63: n = (csd[5] & 15) + ((csd[10] & 128) >> 7) + ((csd[9] & 3) << 1) + 2;
	ld	l, e
	ld	h, d
	inc	hl
	inc	hl
	inc	hl
	inc	hl
	inc	hl
	ld	a, (hl)
	and	a, #0x0f
	ld	-2 (ix), a
	ld	l, e
	ld	h, d
	push	bc
	ld	bc, #0x000a
	add	hl, bc
	pop	bc
	ld	a, (hl)
	and	a, #0x80
	ld	l, a
	ld	h, #0x00
	ld	a, #0x07
00169$:
	sra	h
	rr	l
	dec	a
	jr	NZ,00169$
	ld	a, l
	add	a, -2 (ix)
	ld	l, a
	ld	a, -1 (ix)
	and	a, #0x03
	add	a, a
	add	a, l
	add	a, #0x02
	ld	-1 (ix), a
;fatFs\diskio_diskioctl.c:64: cs = (csd[8] >> 6) + ((WORD)csd[7] << 2) + ((WORD)(csd[6] & 3) << 10) + 1;
	ld	a, c
	rlca
	rlca
	and	a, #0x03
	ld	c, a
	ld	hl, #0x0000
	sla	b
	rl	h
	sla	b
	rl	h
	ld	a, c
	add	a, b
	ld	c, a
	ld	a, l
	adc	a, h
	ld	b, a
	ex	de,hl
	ld	de, #0x0006
	add	hl, de
	ld	a, (hl)
	and	a, #0x03
	ld	d, #0x00
	ld	e, a
	add	a, a
	add	a, a
	ld	h, a
	ld	l, #0x00
	add	hl, bc
	ex	de, hl
	inc	de
	ld	bc, #0x0000
;fatFs\diskio_diskioctl.c:65: *(DWORD*)buff = cs << (n - 9);
	ld	a, -1 (ix)
	add	a, #0xf7
	inc	a
	jr	00173$
00172$:
	sla	e
	rl	d
	rl	c
	rl	b
00173$:
	dec	a
	jr	NZ,00172$
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	(hl), e
	inc	hl
	ld	(hl), d
	inc	hl
	ld	(hl), c
	inc	hl
	ld	(hl), b
00109$:
;fatFs\diskio_diskioctl.c:67: res = RES_OK;
	xor	a, a
	ld	-1 (ix), a
;fatFs\diskio_diskioctl.c:69: break;
	jr	00115$
;fatFs\diskio_diskioctl.c:71: case GET_BLOCK_SIZE :	/* Get erase block size in unit of sector (DWORD) */
00113$:
;fatFs\diskio_diskioctl.c:72: *(DWORD*)buff = 128;
	ld	l, -6 (ix)
	ld	h, -5 (ix)
	ld	(hl), #0x80
	inc	hl
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	ld	(hl), a
;fatFs\diskio_diskioctl.c:73: res = RES_OK;
	xor	a, a
	ld	-1 (ix), a
;fatFs\diskio_diskioctl.c:74: break;
	jr	00115$
;fatFs\diskio_diskioctl.c:76: default:
00114$:
;fatFs\diskio_diskioctl.c:77: res = RES_PARERR;
	ld	-1 (ix), #0x04
;fatFs\diskio_diskioctl.c:78: }
00115$:
;fatFs\diskio_diskioctl.c:80: deselect();
	call	_deselect
;fatFs\diskio_diskioctl.c:82: return res;
	ld	l, -1 (ix)
00116$:
;fatFs\diskio_diskioctl.c:83: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
