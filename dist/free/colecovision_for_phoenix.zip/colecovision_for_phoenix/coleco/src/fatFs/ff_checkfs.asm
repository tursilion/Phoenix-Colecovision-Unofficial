;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_checkfs
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _move_window
	.globl _mem_cmp
	.globl _check_fs
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_checkfs.c:42: BYTE check_fs (	/* 0:FAT, 1:exFAT, 2:Valid BS but not FAT, 3:Not a BS, 4:Disk error */
;	---------------------------------
; Function check_fs
; ---------------------------------
_check_fs::
	call	___sdcc_enter_ix
	push	af
	push	af
;fatFs\ff_checkfs.c:47: fs->wflag = 0; fs->winsect = 0xFFFFFFFF;		/* Invaidate window */
	ld	c, 4 (ix)
	ld	b, 5 (ix)
	ld	e, c
	ld	d, b
	inc	de
	inc	de
	xor	a, a
	ld	(de), a
	ld	hl, #0x0024
	add	hl, bc
	ld	(hl), #0xff
	inc	hl
	ld	(hl), #0xff
	inc	hl
	ld	(hl), #0xff
	inc	hl
	ld	(hl), #0xff
;fatFs\ff_checkfs.c:48: if (move_window(fs, sect) != FR_OK) {
	push	bc
	ld	l, 8 (ix)
	ld	h, 9 (ix)
	push	hl
	ld	l, 6 (ix)
	ld	h, 7 (ix)
	push	hl
	push	bc
	call	_move_window
	pop	af
	pop	af
	pop	af
	ld	a, l
	pop	bc
	or	a, a
	jr	Z,00102$
;fatFs\ff_checkfs.c:49: return 4;	/* Load boot record */
	ld	l, #0x04
	jp	00113$
00102$:
;fatFs\ff_checkfs.c:52: if (ld_word(fs->win + BS_55AA) != 0xAA55) {
	inc	sp
	inc	sp
	push	bc
	ld	-2 (ix), c
	ld	-1 (ix), b
	ld	l, c
	ld	h, b
	ld	de, #0x0227
	add	hl, de
	ld	d, (hl)
	ld	e, #0x00
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	push	bc
	ld	bc, #0x0226
	add	hl, bc
	pop	bc
	ld	l, (hl)
	ld	h, #0x00
	ld	a, e
	or	a, l
	ld	e, a
	ld	a, d
	or	a, h
	ld	d, a
	ld	a, e
	sub	a, #0x55
	jr	NZ,00145$
	ld	a, d
	sub	a, #0xaa
	jr	Z,00104$
00145$:
;fatFs\ff_checkfs.c:53: return 3;	/* Check boot record signature (always here regardless of the sector size) */
	ld	l, #0x03
	jr	00113$
00104$:
;fatFs\ff_checkfs.c:59: if (fs->win[BS_JmpBoot] == 0xE9 || fs->win[BS_JmpBoot] == 0xEB || fs->win[BS_JmpBoot] == 0xE8) {	/* Valid JumpBoot code? */
	pop	hl
	push	hl
	ld	de, #0x0028
	add	hl, de
	ld	a, (hl)
	cp	a, #0xe9
	jr	Z,00109$
	cp	a, #0xeb
	jr	Z,00109$
	sub	a, #0xe8
	jr	NZ,00110$
00109$:
;fatFs\ff_checkfs.c:60: if (!mem_cmp(fs->win + BS_FilSysType, "FAT", 3)) {
	ld	hl, #0x005e
	add	hl, bc
	push	bc
	ld	de, #0x0003
	push	de
	ld	de, #___str_0
	push	de
	push	hl
	call	_mem_cmp
	pop	af
	pop	af
	pop	af
	pop	bc
	ld	a, h
;fatFs\ff_checkfs.c:61: return 0;		/* Is it an FAT VBR? */
	or	a,l
	jr	NZ,00106$
	ld	l,a
	jr	00113$
00106$:
;fatFs\ff_checkfs.c:63: if (!mem_cmp(fs->win + BS_FilSysType32, "FAT32", 5)) {
	ld	hl, #0x007a
	add	hl, bc
	ld	bc, #0x0005
	push	bc
	ld	bc, #___str_1
	push	bc
	push	hl
	call	_mem_cmp
	pop	af
	pop	af
	pop	af
	ld	a, h
;fatFs\ff_checkfs.c:64: return 0;	/* Is it an FAT32 VBR? */
	or	a,l
	jr	NZ,00110$
	ld	l,a
	jr	00113$
00110$:
;fatFs\ff_checkfs.c:67: return 2;	/* Valid BS but not FAT */
	ld	l, #0x02
00113$:
;fatFs\ff_checkfs.c:68: }
	ld	sp, ix
	pop	ix
	ret
___str_0:
	.ascii "FAT"
	.db 0x00
___str_1:
	.ascii "FAT32"
	.db 0x00
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
