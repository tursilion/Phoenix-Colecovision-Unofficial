;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_lddword
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ld_dword
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_lddword.c:42: DWORD ld_dword (const BYTE* ptr)	/* Load a 4-byte little-endian word */
;	---------------------------------
; Function ld_dword
; ---------------------------------
_ld_dword::
	call	___sdcc_enter_ix
	push	af
	push	af
;fatFs\ff_lddword.c:46: rv = ptr[3];
	ld	l, 4 (ix)
	ld	h, 5 (ix)
	inc	hl
	inc	hl
	inc	hl
	ld	c, (hl)
	ld	b, #0x00
	ld	e, #0x00
;fatFs\ff_lddword.c:47: rv = rv << 8 | ptr[2];
	ld	-3 (ix), c
	ld	-2 (ix), b
	ld	-1 (ix), e
	xor	a, a
	ld	-4 (ix), a
	ld	l, 4 (ix)
	ld	h, 5 (ix)
	inc	hl
	inc	hl
	ld	c, (hl)
	ld	b, #0x00
	ld	de, #0x0000
	ld	a, c
	or	a, -4 (ix)
	ld	c, a
	ld	a, b
	or	a, -3 (ix)
	ld	b, a
	ld	a, e
	or	a, -2 (ix)
	ld	e, a
	ld	a, d
	or	a, -1 (ix)
;fatFs\ff_lddword.c:48: rv = rv << 8 | ptr[1];
	ld	-3 (ix), c
	ld	-2 (ix), b
	ld	-1 (ix), e
	xor	a, a
	ld	-4 (ix), a
	ld	l, 4 (ix)
	ld	h, 5 (ix)
	inc	hl
	ld	c, (hl)
	ld	b, #0x00
	ld	de, #0x0000
	ld	a, c
	or	a, -4 (ix)
	ld	c, a
	ld	a, b
	or	a, -3 (ix)
	ld	b, a
	ld	a, e
	or	a, -2 (ix)
	ld	e, a
	ld	a, d
	or	a, -1 (ix)
;fatFs\ff_lddword.c:49: rv = rv << 8 | ptr[0];
	ld	-3 (ix), c
	ld	-2 (ix), b
	ld	-1 (ix), e
	xor	a, a
	ld	-4 (ix), a
	ld	l, 4 (ix)
	ld	h, 5 (ix)
	ld	c, (hl)
	ld	b, #0x00
	ld	de, #0x0000
	ld	a, -4 (ix)
	or	a, c
	ld	l, a
	ld	a, -3 (ix)
	or	a, b
	ld	h, a
	ld	a, -2 (ix)
	or	a, e
	ld	e, a
	ld	a, -1 (ix)
	or	a, d
	ld	d, a
;fatFs\ff_lddword.c:50: return rv;
;fatFs\ff_lddword.c:51: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
