;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_ldclust
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _ld_clust
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_ldclust.c:42: DWORD ld_clust (	/* Returns the top cluster value of the SFN entry */
;	---------------------------------
; Function ld_clust
; ---------------------------------
_ld_clust::
	call	___sdcc_enter_ix
	push	af
	push	af
;fatFs\ff_ldclust.c:49: cl = ld_word(dir + DIR_FstClusLO);
	ld	a, 6 (ix)
	add	a, #0x1a
	ld	e, a
	ld	a, 7 (ix)
	adc	a, #0x00
	ld	d, a
	ld	l, e
	ld	h, d
	inc	hl
	ld	b, (hl)
	ld	c, #0x00
	ld	a, (de)
	ld	e, a
	ld	d, #0x00
	ld	a, c
	or	a, e
	ld	c, a
	ld	a, b
	or	a, d
	ld	b, a
	ld	-4 (ix), c
	ld	a, b
	ld	-3 (ix), a
	rla
	sbc	a, a
	ld	-2 (ix), a
	ld	-1 (ix), a
;fatFs\ff_ldclust.c:50: if (fs->fs_type == FS_FAT32) {
	ld	c, 4 (ix)
	ld	b, 5 (ix)
	ld	a, (bc)
	sub	a, #0x03
	jr	NZ,00102$
;fatFs\ff_ldclust.c:51: cl |= (DWORD)ld_word(dir + DIR_FstClusHI) << 16;
	ld	a, 6 (ix)
	add	a, #0x14
	ld	e, a
	ld	a, 7 (ix)
	adc	a, #0x00
	ld	d, a
	ld	l, e
	ld	h, d
	inc	hl
	ld	b, (hl)
	ld	c, #0x00
	ld	a, (de)
	ld	e, a
	ld	d, #0x00
	ld	a, c
	or	a, e
	ld	e, a
	ld	a, b
	or	a, d
	ld	d, a
	rla
	sbc	a, a
	ld	bc, #0x0000
	ld	a, -4 (ix)
	or	a, c
	ld	-4 (ix), a
	ld	a, -3 (ix)
	or	a, b
	ld	-3 (ix), a
	ld	a, -2 (ix)
	or	a, e
	ld	-2 (ix), a
	ld	a, -1 (ix)
	or	a, d
	ld	-1 (ix), a
00102$:
;fatFs\ff_ldclust.c:54: return cl;
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	ld	e, -2 (ix)
	ld	d, -1 (ix)
;fatFs\ff_ldclust.c:55: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
