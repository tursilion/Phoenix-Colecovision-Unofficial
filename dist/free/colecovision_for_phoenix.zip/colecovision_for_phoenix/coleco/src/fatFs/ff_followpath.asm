;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module ff_followpath
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _create_name
	.globl _dir_find
	.globl _ld_clust
	.globl _dir_sdi
	.globl _follow_path
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;fatFs\ff_followpath.c:42: FRESULT follow_path (	/* FR_OK(0): successful, !=0: error code */
;	---------------------------------
; Function follow_path
; ---------------------------------
_follow_path::
	call	___sdcc_enter_ix
	ld	hl, #-10
	add	hl, sp
	ld	sp, hl
;fatFs\ff_followpath.c:49: FATFS *fs = dp->obj.fs;
	ld	a, 4 (ix)
	ld	-10 (ix), a
	ld	a, 5 (ix)
	ld	-9 (ix), a
	pop	bc
	push	bc
	pop	hl
	push	hl
	ld	a, (hl)
	ld	-8 (ix), a
	inc	hl
	ld	a, (hl)
	ld	-7 (ix), a
;fatFs\ff_followpath.c:59: while (*path == '/') path++;	/* Strip heading separator */
	ld	e, 6 (ix)
	ld	d, 7 (ix)
00101$:
	ld	a, (de)
	sub	a, #0x2f
	jr	NZ,00140$
	inc	de
	ld	6 (ix), e
	ld	7 (ix), d
	jr	00101$
00140$:
	ld	6 (ix), e
	ld	7 (ix), d
;fatFs\ff_followpath.c:63: dp->obj.sclust = 0;					/* Start from root directory */
	ld	hl, #0x0006
	add	hl, bc
	xor	a, a
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	ld	(hl), a
	inc	hl
	ld	(hl), a
;fatFs\ff_followpath.c:82: if ((UINT)*path < ' ') {				/* Null path name is the origin directory itself */
	ld	e, 6 (ix)
	ld	d, 7 (ix)
	ld	a, (de)
	ld	e, a
	rla
	sbc	a, a
	ld	d, a
	ld	a, e
	sub	a, #0x20
	ld	a, d
	sbc	a, #0x00
	jr	NC,00127$
;fatFs\ff_followpath.c:83: dp->fn[NSFLAG] = NS_NONAME;
	ld	hl, #0x0027
	add	hl, bc
	ld	(hl), #0x80
;fatFs\ff_followpath.c:84: res = dir_sdi(dp, 0);
	ld	hl, #0x0000
	push	hl
	ld	hl, #0x0000
	push	hl
	push	bc
	call	_dir_sdi
	pop	af
	pop	af
	pop	af
	ld	e, l
	jp	00126$
00127$:
;fatFs\ff_followpath.c:88: res = create_name(dp, &path);	/* Get a segment name of the path */
	ld	hl, #16
	add	hl, sp
	push	bc
	push	hl
	push	bc
	call	_create_name
	pop	af
	pop	af
	ld	a, l
	pop	bc
;fatFs\ff_followpath.c:89: if (res != FR_OK) break;
	ld	e, a
	or	a, a
	jp	NZ, 00126$
;fatFs\ff_followpath.c:90: res = dir_find(dp);				/* Find an object with the segment name */
	push	bc
	push	bc
	call	_dir_find
	pop	af
	ld	a, l
	pop	bc
	ld	e, a
;fatFs\ff_followpath.c:91: ns = dp->fn[NSFLAG];
	pop	hl
	push	hl
	push	bc
	ld	bc, #0x0027
	add	hl, bc
	pop	bc
	ld	a, (hl)
;fatFs\ff_followpath.c:99: if (!(ns & NS_LAST)) res = FR_NO_PATH;	/* Adjust error code if not last segment */
	and	a, #0x04
	ld	d, a
	ld	l, #0x00
;fatFs\ff_followpath.c:92: if (res != FR_OK) {				/* Failed to find the object */
	ld	a, e
	or	a, a
	jr	Z,00117$
;fatFs\ff_followpath.c:93: if (res == FR_NO_FILE) {	/* Object is not found */
	ld	a, e
	sub	a, #0x04
	jp	NZ,00126$
;fatFs\ff_followpath.c:99: if (!(ns & NS_LAST)) res = FR_NO_PATH;	/* Adjust error code if not last segment */
	ld	a, l
	or	a, d
	jr	NZ,00126$
	ld	e, #0x05
;fatFs\ff_followpath.c:102: break;
	jr	00126$
00117$:
;fatFs\ff_followpath.c:104: if (ns & NS_LAST) break;			/* Last segment matched. Function completed. */
	ld	a, l
	or	a, d
	jr	NZ,00126$
;fatFs\ff_followpath.c:106: if (!(dp->obj.attr & AM_DIR)) {		/* It is not a sub-directory and cannot follow */
	pop	hl
	push	hl
	ld	de, #0x0004
	add	hl, de
	bit	4, (hl)
	jr	NZ,00121$
;fatFs\ff_followpath.c:107: res = FR_NO_PATH; break;
	ld	e, #0x05
	jr	00126$
00121$:
;fatFs\ff_followpath.c:118: dp->obj.sclust = ld_clust(fs, fs->win + dp->dptr % SS(fs));	/* Open next directory */
	ld	a, -10 (ix)
	add	a, #0x06
	ld	-6 (ix), a
	ld	a, -9 (ix)
	adc	a, #0x00
	ld	-5 (ix), a
	ld	a, -8 (ix)
	add	a, #0x28
	ld	-2 (ix), a
	ld	a, -7 (ix)
	adc	a, #0x00
	ld	-1 (ix), a
	pop	hl
	push	hl
	ld	de, #0x000e
	add	hl, de
	ld	e, (hl)
	inc	hl
	ld	a, (hl)
	and	a, #0x01
	ld	d, a
	ld	a, e
	add	a, -2 (ix)
	ld	e, a
	ld	a, d
	adc	a, -1 (ix)
	ld	d, a
	push	bc
	push	de
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	push	hl
	call	_ld_clust
	pop	af
	pop	af
	ld	-4 (ix), l
	ld	-3 (ix), h
	ld	-2 (ix), e
	ld	-1 (ix), d
	ld	e, -6 (ix)
	ld	d, -5 (ix)
	ld	hl, #0x0008
	add	hl, sp
	ld	bc, #0x0004
	ldir
	pop	bc
	jp	00127$
00126$:
;fatFs\ff_followpath.c:123: return res;
	ld	l, e
;fatFs\ff_followpath.c:124: }
	ld	sp, ix
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
