;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module f18a
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _useScanlines
	.globl _DEFAULT_PALETTE
	.globl _unlock_f18a
	.globl _reset_f18a
	.globl _lock_f18a
	.globl _prepare_f18a
	.globl _loadpal_f18a
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_VDPRD	=	0x00be
_VDPST	=	0x00bf
_VDPWA	=	0x00bf
_VDPWD	=	0x00be
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
_useScanlines::
	.ds 1
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;f18a.c:24: void unlock_f18a() {
;	---------------------------------
; Function unlock_f18a
; ---------------------------------
_unlock_f18a::
;../libti99coleco/vdp.h:72: inline void VDP_SET_REGISTER(unsigned char r, unsigned char v)		{	VDPWA=(v); VDPWA=(0x80|(r)); }
	ld	a, #0x1c
	out	(_VDPWA), a
	ld	a, #0xb9
	out	(_VDPWA), a
	ld	a, #0x1c
	out	(_VDPWA), a
	ld	a, #0xb9
	out	(_VDPWA), a
;f18a.c:26: VDP_SET_REGISTER(0x39, 0x1c);	// write again (unlocks enhanced mode)
;f18a.c:27: }
	ret
_DEFAULT_PALETTE:
	.dw #0x0000
	.dw #0x0000
	.dw #0x02c3
	.dw #0x05d6
	.dw #0x054f
	.dw #0x076f
	.dw #0x0d54
	.dw #0x04ef
	.dw #0x0f54
	.dw #0x0f76
	.dw #0x0dc3
	.dw #0x0ed6
	.dw #0x02b2
	.dw #0x0c5c
	.dw #0x0ccc
	.dw #0x0fff
;f18a.c:30: void reset_f18a() {
;	---------------------------------
; Function reset_f18a
; ---------------------------------
_reset_f18a::
;../libti99coleco/vdp.h:72: inline void VDP_SET_REGISTER(unsigned char r, unsigned char v)		{	VDPWA=(v); VDPWA=(0x80|(r)); }
	ld	a, #0x80
	out	(_VDPWA), a
	ld	a, #0xb2
	out	(_VDPWA), a
	ld	a, #0x00
	out	(_VDPWA), a
	ld	a, #0x87
	out	(_VDPWA), a
	ld	a, #0x80
	out	(_VDPWA), a
	ld	a, #0x81
	out	(_VDPWA), a
;f18a.c:37: VDP_SET_REGISTER(VDP_REG_MODE1, VDP_MODE1_16K);
;f18a.c:38: }
	ret
;f18a.c:41: void lock_f18a() {
;	---------------------------------
; Function lock_f18a
; ---------------------------------
_lock_f18a::
;../libti99coleco/vdp.h:72: inline void VDP_SET_REGISTER(unsigned char r, unsigned char v)		{	VDPWA=(v); VDPWA=(0x80|(r)); }
	ld	a, #0x00
	out	(_VDPWA), a
	ld	a, #0xb9
	out	(_VDPWA), a
;f18a.c:42: VDP_SET_REGISTER(0x39, 0x00);	// VR1/57, value 00000000 (corrupts VDPR1 if already locked)
;f18a.c:43: }
	ret
;f18a.c:49: void prepare_f18a() {
;	---------------------------------
; Function prepare_f18a
; ---------------------------------
_prepare_f18a::
;f18a.c:51: reset_f18a();
	call	_reset_f18a
;f18a.c:54: unlock_f18a();
	call	_unlock_f18a
;../libti99coleco/vdp.h:72: inline void VDP_SET_REGISTER(unsigned char r, unsigned char v)		{	VDPWA=(v); VDPWA=(0x80|(r)); }
	ld	a, #0x00
	out	(_VDPWA), a
	ld	a, #0xb8
	out	(_VDPWA), a
	ld	a, #0x00
	out	(_VDPWA), a
	ld	a, #0x98
	out	(_VDPWA), a
;f18a.c:63: loadpal_f18a(DEFAULT_PALETTE, 16);
	ld	a, #0x10
	push	af
	inc	sp
	ld	hl, #_DEFAULT_PALETTE
	push	hl
	call	_loadpal_f18a
	pop	af
	inc	sp
;../libti99coleco/vdp.h:72: inline void VDP_SET_REGISTER(unsigned char r, unsigned char v)		{	VDPWA=(v); VDPWA=(0x80|(r)); }
	ld	a, #0x00
	out	(_VDPWA), a
	ld	a, #0x8f
	out	(_VDPWA), a
;f18a.c:69: if (useFlicker) {
	ld	a,(#_useFlicker + 0)
	or	a, a
	jr	Z,00102$
;../libti99coleco/vdp.h:72: inline void VDP_SET_REGISTER(unsigned char r, unsigned char v)		{	VDPWA=(v); VDPWA=(0x80|(r)); }
	ld	a, #0x04
	out	(_VDPWA), a
	ld	a, #0x9e
	out	(_VDPWA), a
;f18a.c:70: VDP_SET_REGISTER(0x1e, 4); // stop sprite is #4
	jr	00103$
00102$:
;../libti99coleco/vdp.h:72: inline void VDP_SET_REGISTER(unsigned char r, unsigned char v)		{	VDPWA=(v); VDPWA=(0x80|(r)); }
	ld	a, #0x20
	out	(_VDPWA), a
	ld	a, #0x9e
	out	(_VDPWA), a
00103$:
;f18a.c:78: VDP_SET_REGISTER(0x32, useScanlines);
	ld	iy, #_useScanlines
	ld	a, 0 (iy)
	out	(_VDPWA), a
;../libti99coleco/vdp.h:72: inline void VDP_SET_REGISTER(unsigned char r, unsigned char v)		{	VDPWA=(v); VDPWA=(0x80|(r)); }
	ld	a, #0xb2
	out	(_VDPWA), a
;f18a.c:81: while (VDPST & 0x80) {
00104$:
	in	a, (_VDPST)
	rlca
	jp	NC,_lock_f18a
;../libti99coleco/vdp.h:43: __endasm;
	nop
	nop
	nop
	nop
	nop
;f18a.c:82: VDP_SAFE_DELAY();
	jr	00104$
;f18a.c:86: lock_f18a();
;f18a.c:87: }
	jp	_lock_f18a
;f18a.c:91: void loadpal_f18a(const unsigned int *ptr, unsigned char cnt) {
;	---------------------------------
; Function loadpal_f18a
; ---------------------------------
_loadpal_f18a::
	call	___sdcc_enter_ix
;../libti99coleco/vdp.h:72: inline void VDP_SET_REGISTER(unsigned char r, unsigned char v)		{	VDPWA=(v); VDPWA=(0x80|(r)); }
	ld	a, #0xc0
	out	(_VDPWA), a
	ld	a, #0xaf
	out	(_VDPWA), a
;f18a.c:94: while (cnt-- > 0) {
	ld	c, 4 (ix)
	ld	b, 5 (ix)
	ld	e, 6 (ix)
00101$:
	ld	a, e
	dec	e
	or	a, a
	jr	Z,00103$
;f18a.c:95: VDPWD = ptr[0]>>8;
	ld	l, c
	ld	h, b
	ld	d, (hl)
	inc	hl
	ld	a, (hl)
	out	(_VDPWD), a
;f18a.c:96: VDPWD = ptr[0]&0xff;
	ld	a, (bc)
	out	(_VDPWD), a
;f18a.c:97: ptr++;
	inc	bc
	inc	bc
	jr	00101$
00103$:
;../libti99coleco/vdp.h:72: inline void VDP_SET_REGISTER(unsigned char r, unsigned char v)		{	VDPWA=(v); VDPWA=(0x80|(r)); }
	ld	a, #0x00
	out	(_VDPWA), a
	ld	a, #0xaf
	out	(_VDPWA), a
;f18a.c:100: VDP_SET_REGISTER(0x2f, 0x00);	// Turn off the DPM mode
;f18a.c:101: }
	pop	ix
	ret
	.area _CODE
	.area _INITIALIZER
__xinit__useScanlines:
	.db #0x00	; 0
	.area _CABS (ABS)
