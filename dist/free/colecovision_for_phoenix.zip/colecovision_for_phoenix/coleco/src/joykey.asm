;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module joykey
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _MY_JOYX
	.globl _MY_JOYY
	.globl _MY_KEY
	.globl _keys
	.globl _readinputs
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_port0	=	0x00fc
_port1	=	0x00ff
_port2	=	0x0080
_port3	=	0x00c0
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_MY_KEY::
	.ds 1
_MY_JOYY::
	.ds 1
_MY_JOYX::
	.ds 1
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;joykey.c:32: void readinputs(unsigned char mode) {
;	---------------------------------
; Function readinputs
; ---------------------------------
_readinputs::
	call	___sdcc_enter_ix
;joykey.c:35: port2 = SELECT;		// select keypad
	ld	a, #0x2a
	out	(_port2), a
;joykey.c:37: if (mode == 2) {
	ld	a, 4 (ix)
	sub	a, #0x02
	ld	a, #0x01
	jr	Z,00163$
	xor	a, a
00163$:
	ld	c, a
	or	a, a
	jr	Z,00102$
;joykey.c:38: key = port1;
	in	a, (_port1)
	ld	e, a
	jr	00103$
00102$:
;joykey.c:40: key = port0;
	in	a, (_port0)
	ld	e, a
00103$:
;joykey.c:47: if ((key&0x40) == 0) {
	bit	6, e
	jr	NZ,00105$
;joykey.c:48: MY_KEY = JOY_FIRE;
	ld	hl,#_MY_KEY + 0
	ld	(hl), #0x12
	jr	00106$
00105$:
;joykey.c:50: MY_KEY = keys[key & 0xf];
	ld	a, e
	and	a, #0x0f
	ld	e, a
	ld	d, #0x00
	ld	hl, #_keys
	add	hl, de
	ex	de, hl
	ld	a, (de)
	ld	(_MY_KEY+0), a
00106$:
;joykey.c:53: MY_JOYX = 0;
	ld	hl,#_MY_JOYX + 0
	ld	(hl), #0x00
;joykey.c:54: MY_JOYY = 0;
	ld	hl,#_MY_JOYY + 0
	ld	(hl), #0x00
;joykey.c:56: port3 = SELECT;		// select joystick
	ld	a, #0x2a
	out	(_port3), a
;joykey.c:57: if (mode == 2) {
	ld	a, c
	or	a, a
	jr	Z,00108$
;joykey.c:58: key = port1;
	in	a, (_port1)
	ld	c, a
	jr	00109$
00108$:
;joykey.c:60: key = port0;
	in	a, (_port0)
	ld	c, a
00109$:
;joykey.c:64: if ((key&0x40) == 0) {
	bit	6, c
	jr	NZ,00111$
;joykey.c:65: MY_KEY = JOY_FIRE;
	ld	hl,#_MY_KEY + 0
	ld	(hl), #0x12
00111$:
;joykey.c:67: if ((key&0x08) == 0) {
	bit	3, c
	jr	NZ,00113$
;joykey.c:68: MY_JOYX = JOY_LEFT;
	ld	hl,#_MY_JOYX + 0
	ld	(hl), #0xfc
00113$:
;joykey.c:70: if ((key&0x04) == 0) {
	bit	2, c
	jr	NZ,00115$
;joykey.c:71: MY_JOYY = JOY_DOWN;
	ld	hl,#_MY_JOYY + 0
	ld	(hl), #0xfc
00115$:
;joykey.c:73: if ((key&0x02) == 0) {
	bit	1, c
	jr	NZ,00117$
;joykey.c:74: MY_JOYX = JOY_RIGHT;
	ld	hl,#_MY_JOYX + 0
	ld	(hl), #0x04
00117$:
;joykey.c:76: if ((key&0x01) == 0) {
	bit	0, c
	jr	NZ,00120$
;joykey.c:77: MY_JOYY = JOY_UP;
	ld	hl,#_MY_JOYY + 0
	ld	(hl), #0x04
00120$:
;joykey.c:80: }
	pop	ix
	ret
_keys:
	.db #0xff	; 255
	.db #0x38	; 56	'8'
	.db #0x34	; 52	'4'
	.db #0x35	; 53	'5'
	.db #0xff	; 255
	.db #0x37	; 55	'7'
	.db #0x23	; 35
	.db #0x32	; 50	'2'
	.db #0xff	; 255
	.db #0x2a	; 42
	.db #0x30	; 48	'0'
	.db #0x39	; 57	'9'
	.db #0x33	; 51	'3'
	.db #0x31	; 49	'1'
	.db #0x36	; 54	'6'
	.db #0xff	; 255
	.area _CODE
	.area _INITIALIZER
	.area _CABS (ABS)
