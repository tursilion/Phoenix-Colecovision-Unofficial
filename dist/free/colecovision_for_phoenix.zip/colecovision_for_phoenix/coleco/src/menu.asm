;--------------------------------------------------------
; File Created by SDCC : free open source ANSI-C Compiler
; Version 4.0.0 #11528 (MINGW64)
;--------------------------------------------------------
	.module menu
	.optsdcc -mz80
	
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _menu
	.globl _inc_palette
	.globl _load_palette
	.globl _getUserSelection
	.globl _undrawSelect
	.globl _drawSelect
	.globl _loadMegacartRom
	.globl _copyPage
	.globl _loadCartridgeRom
	.globl _waitSDCard
	.globl _sortDir
	.globl _drawTitles
	.globl _waitRelease
	.globl _readDir
	.globl _mystrcmp
	.globl _displayErrorString
	.globl _waitAnyFirePressed
	.globl _waitBothFireClear
	.globl _mystrcpy
	.globl _vdpStrOut
	.globl _clrscrbottom
	.globl _clrscr
	.globl _cleartextout
	.globl _centerString
	.globl _textout
	.globl _startTitle
	.globl _waitVblanks
	.globl _readkeypad
	.globl _vdpmemcpyfast
	.globl _disk_status
	.globl _f_mount
	.globl _f_readdir
	.globl _f_closedir
	.globl _f_opendir
	.globl _f_lseek
	.globl _f_read
	.globl _f_close
	.globl _f_open
	.globl _loadpal_f18a
	.globl _vdpreadchar
	.globl _vdpmemset
	.globl _memmove
	.globl _memcpy
	.globl _memset
	.globl _MENU_COLOR_SETS
	.globl _showExt
	.globl _firstDir
	.globl _firstScan
	.globl _listSelect
	.globl _listOffset
	.globl _listSize
	.globl _lastFilename
	.globl _currentPalette
	.globl _finfo
	.globl _dir
	.globl _fil
	.globl _fatFs
	.globl _repeatTimeout
	.globl _sortedList
	.globl _path2
	.globl _path
	.globl _hex
	.globl _MENU_INVERT
	.globl _MENU_CONTRAST
	.globl _MENU_PALETTE
	.globl _FolderNameLen
	.globl _FolderName
	.globl _dly_50us
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
_VDPRD	=	0x00be
_VDPST	=	0x00bf
_VDPWA	=	0x00bf
_VDPWD	=	0x00be
_sgmPSGAddressWrite	=	0x0050
_sgmPSGDataWrite	=	0x0051
_sgmPSGDataRead	=	0x0052
_sgmConfig	=	0x0053
_phRAMBankSelect	=	0x0054
_phBankingScheme	=	0x0055
_phSDControl	=	0x0056
_phSDData	=	0x0057
_phMachineID	=	0x0058
_phCartMask	=	0x0059
_phCachePage	=	0x005c
_phCacheCheck	=	0x005d
_phCacheStatus	=	0x005e
_sgmBIOSMap	=	0x007f
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _DATA
_path::
	.ds 512
_path2::
	.ds 512
_sortedList::
	.ds 512
_repeatTimeout::
	.ds 1
_fatFs::
	.ds 552
_fil::
	.ds 540
_dir::
	.ds 44
_finfo::
	.ds 260
_currentPalette::
	.ds 1
;--------------------------------------------------------
; ram data
;--------------------------------------------------------
	.area _INITIALIZED
_lastFilename::
	.ds 2
_listSize::
	.ds 1
_listOffset::
	.ds 1
_listSelect::
	.ds 1
_firstScan::
	.ds 1
_firstDir::
	.ds 1
_showExt::
	.ds 1
_MENU_COLOR_SETS::
	.ds 6
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area _DABS (ABS)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area _HOME
	.area _GSINIT
	.area _GSFINAL
	.area _GSINIT
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area _HOME
	.area _HOME
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area _CODE
;menu.c:182: void dly_50us(unsigned char n)
;	---------------------------------
; Function dly_50us
; ---------------------------------
_dly_50us::
;menu.c:187: while (n--) {
	ld	iy, #2
	add	iy, sp
	ld	c, 0 (iy)
00101$:
	ld	a, c
	dec	c
	or	a, a
	ret	Z
;menu.c:197: __endasm;
	ex	(sp),hl ; 19 t-states
	ex	(sp),hl ; 19 t-states
	ex	(sp),hl ; 19 t-states
	ex	(sp),hl ; 19 t-states
	ex	(sp),hl ; 19 t-states
	ex	(sp),hl ; 19 t-states
	ex	(sp),hl ; 19 t-states
	ex	(sp),hl ; *8 = 152 t-states =~ 42.4uS, plus loop overhead
;menu.c:199: }
	jr	00101$
_FolderName:
	.ascii "COLECO"
	.db 0x00
_FolderNameLen:
	.db #0x07	; 7
_MENU_PALETTE:
	.dw #0x0000
	.dw #0x0000
	.dw #0x0000
	.dw #0x0010
	.dw #0x0eee
	.dw #0x044e
	.dw #0x0000
	.dw #0x0900
_MENU_CONTRAST:
	.dw #0x0000
	.dw #0x0000
	.dw #0x0000
	.dw #0x0000
	.dw #0x0eee
	.dw #0x0aaa
	.dw #0x0000
	.dw #0x0222
_MENU_INVERT:
	.dw #0x0eee
	.dw #0x0eee
	.dw #0x0eee
	.dw #0x0eee
	.dw #0x0000
	.dw #0x0444
	.dw #0x0eee
	.dw #0x0aaa
_hex:
	.db #0x30	;  48	'0'
	.db #0x31	;  49	'1'
	.db #0x32	;  50	'2'
	.db #0x33	;  51	'3'
	.db #0x34	;  52	'4'
	.db #0x35	;  53	'5'
	.db #0x36	;  54	'6'
	.db #0x37	;  55	'7'
	.db #0x38	;  56	'8'
	.db #0x39	;  57	'9'
	.db #0x41	;  65	'A'
	.db #0x42	;  66	'B'
	.db #0x43	;  67	'C'
	.db #0x44	;  68	'D'
	.db #0x45	;  69	'E'
	.db #0x46	;  70	'F'
;menu.c:202: void cleartextout() {
;	---------------------------------
; Function cleartextout
; ---------------------------------
_cleartextout::
;menu.c:203: vdpmemset(GSPRITEPAT, 0, 16*4*8);
	ld	hl, #0x0200
	push	hl
	xor	a, a
	push	af
	inc	sp
	ld	h, #0x18
	push	hl
	call	_vdpmemset
	pop	af
	pop	af
	inc	sp
;menu.c:204: }
	ret
;menu.c:207: void clrscr() {
;	---------------------------------
; Function clrscr
; ---------------------------------
_clrscr::
;menu.c:208: vdpmemset(GIMAGE, ' ', 960);
	ld	hl, #0x03c0
	push	hl
	ld	a, #0x20
	push	af
	inc	sp
	ld	hl, #0x0000
	push	hl
	call	_vdpmemset
	pop	af
	pop	af
	inc	sp
;menu.c:209: }
	ret
;menu.c:212: void clrscrbottom() {
;	---------------------------------
; Function clrscrbottom
; ---------------------------------
_clrscrbottom::
;menu.c:213: vdpmemset(GIMAGE+(40*21), ' ', (40*3));
	ld	hl, #0x0078
	push	hl
	ld	a, #0x20
	push	af
	inc	sp
	ld	hl, #0x0348
	push	hl
	call	_vdpmemset
	pop	af
	pop	af
	inc	sp
;menu.c:214: cleartextout();
;menu.c:215: }
	jp	_cleartextout
;menu.c:218: void vdpStrOut(const char *p, unsigned char cnt) {
;	---------------------------------
; Function vdpStrOut
; ---------------------------------
_vdpStrOut::
;menu.c:219: ++cnt;  // account for pre-decrement so we stop at 0
	ld	iy, #4
	add	iy, sp
	inc	0 (iy)
;menu.c:220: while ((*p >= ' ') && (--cnt)) {
	ld	c, 0 (iy)
	dec	iy
	dec	iy
	ld	e, 0 (iy)
	ld	d, 1 (iy)
00105$:
	ld	a, (de)
	ld	b, a
	xor	a, #0x80
	sub	a, #0xa0
	jr	C,00107$
	dec	c
	jr	Z,00107$
;menu.c:221: VDPWD = *(p++);
	ld	a, b
	out	(_VDPWD), a
	inc	de
;menu.c:222: if ((*p=='.')&&(!showExt)) break;   // make sure we always show at least 1 character
	ld	a, (de)
	sub	a, #0x2e
	jr	NZ,00105$
	ld	a,(#_showExt + 0)
	or	a, a
	jr	NZ,00105$
00107$:
;menu.c:224: if (cnt) {
	ld	a, c
	or	a, a
	ret	Z
;menu.c:225: while (--cnt) {
00108$:
	dec	c
	ret	Z
;menu.c:226: VDPWD = ' ';
	ld	a, #0x20
	out	(_VDPWD), a
;menu.c:229: }
	jr	00108$
;menu.c:232: void mystrcpy(char *pDest, char *pSrc) {
;	---------------------------------
; Function mystrcpy
; ---------------------------------
_mystrcpy::
	call	___sdcc_enter_ix
	dec	sp
;menu.c:234: while ((*pSrc) && (cnt--)) {
	ld	-1 (ix), #0x7e
	ld	e, 6 (ix)
	ld	d, 7 (ix)
	ld	c, 4 (ix)
	ld	b, 5 (ix)
00102$:
	ld	a, (de)
	ld	l, a
	or	a, a
	jr	Z,00104$
	ld	h, -1 (ix)
	dec	-1 (ix)
	ld	a, h
	or	a, a
	jr	Z,00104$
;menu.c:235: *(pDest++)=*(pSrc++);
	ld	a, l
	inc	de
	ld	(bc), a
	inc	bc
	jr	00102$
00104$:
;menu.c:237: *(pDest) = 0;
	xor	a, a
	ld	(bc), a
;menu.c:238: }
	inc	sp
	pop	ix
	ret
;menu.c:242: void waitBothFireClear() {
;	---------------------------------
; Function waitBothFireClear
; ---------------------------------
_waitBothFireClear::
00104$:
;menu.c:244: readkeypad();
	call	_readkeypad
;menu.c:245: if (MY_KEY == 0xff) break;
	ld	a,(#_MY_KEY + 0)
	inc	a
	jr	NZ,00104$
;menu.c:247: }
	ret
;menu.c:251: void waitAnyFirePressed() {
;	---------------------------------
; Function waitAnyFirePressed
; ---------------------------------
_waitAnyFirePressed::
00104$:
;menu.c:253: readkeypad();
	call	_readkeypad
;menu.c:254: if (MY_KEY == JOY_FIRE) break;
	ld	a,(#_MY_KEY + 0)
	sub	a, #0x12
	jr	NZ,00104$
;menu.c:256: }
	ret
;menu.c:259: void displayErrorString(char *pstr, unsigned char x) {
;	---------------------------------
; Function displayErrorString
; ---------------------------------
_displayErrorString::
	call	___sdcc_enter_ix
;menu.c:261: clrscrbottom();
	call	_clrscrbottom
;menu.c:262: centerString(0, pstr);
	ld	l, 4 (ix)
	ld	h, 5 (ix)
	push	hl
	xor	a, a
	push	af
	inc	sp
	call	_centerString
;menu.c:263: centerString(1, "Press fire...");
	inc	sp
	ld	hl,#___str_1
	ex	(sp),hl
	ld	a, #0x01
	push	af
	inc	sp
	call	_centerString
	pop	af
	inc	sp
;menu.c:268: VDPWD = x>>4;
	ld	c, 6 (ix)
	srl	c
	srl	c
	srl	c
	srl	c
;menu.c:266: if (firstDir) {
	ld	a,(#_firstDir + 0)
	or	a, a
	jr	Z,00102$
;../libti99coleco/vdp.h:65: inline void VDP_SET_ADDRESS_WRITE(unsigned int x)					{	VDPWA=((x)&0xff); VDPWA=(((x)>>8)|0x40); }
	ld	a, #0x1e
	out	(_VDPWA), a
	xor	a, a
	or	a, #0x40
	out	(_VDPWA), a
;menu.c:268: VDPWD = x>>4;
	ld	a, c
	out	(_VDPWD), a
;menu.c:269: VDPWD = x&0x0f;
	ld	a, 6 (ix)
	and	a, #0x0f
	out	(_VDPWD), a
	jr	00103$
00102$:
;../libti99coleco/vdp.h:65: inline void VDP_SET_ADDRESS_WRITE(unsigned int x)					{	VDPWA=((x)&0xff); VDPWA=(((x)>>8)|0x40); }
	ld	a, #0x26
	out	(_VDPWA), a
	xor	a, a
	or	a, #0x40
	out	(_VDPWA), a
;menu.c:272: VDPWD = hex[(x>>4)];
	ld	de, #_hex+0
	ld	l, c
	ld	h, #0x00
	add	hl, de
	ld	a, (hl)
	out	(_VDPWD), a
;menu.c:273: VDPWD = hex[(x&0xf)];
	ld	a, 6 (ix)
	and	a, #0x0f
	ld	h, #0x00
	ld	l, a
	add	hl, de
	ld	a, (hl)
	out	(_VDPWD), a
00103$:
;menu.c:277: waitBothFireClear();
	call	_waitBothFireClear
;menu.c:280: waitAnyFirePressed();
	call	_waitAnyFirePressed
;menu.c:283: cleartextout();
	call	_cleartextout
;menu.c:286: waitBothFireClear();
;menu.c:287: }
	pop	ix
	jp	_waitBothFireClear
___str_1:
	.ascii "Press fire..."
	.db 0x00
;menu.c:291: char mystrcmp(const char *s1, const char *s2) {
;	---------------------------------
; Function mystrcmp
; ---------------------------------
_mystrcmp::
	call	___sdcc_enter_ix
	push	af
;menu.c:320: return (c1-c2);
	ld	c, 4 (ix)
	ld	b, 5 (ix)
	ld	a, 6 (ix)
	ld	-2 (ix), a
	ld	a, 7 (ix)
	ld	-1 (ix), a
00116$:
;menu.c:294: c1 = *s1;
	ld	a, (bc)
	ld	e, a
;menu.c:295: c2 = *s2;
	pop	hl
	push	hl
	ld	d, (hl)
;menu.c:300: if (c1&0x40) {
	bit	6, e
	jr	Z,00104$
;menu.c:301: c1&=0xdf;
	res	5, e
	jr	00105$
00104$:
;menu.c:302: } else if (c1 == '_') { // if it's a letter, it can't be an underscore, so 'else'
	ld	a, e
	sub	a, #0x5f
	jr	NZ,00105$
;menu.c:303: c1=' ';
	ld	e, #0x20
00105$:
;menu.c:306: if (c2&0x40) {
	bit	6, d
	jr	Z,00109$
;menu.c:307: c2&=0xdf;
	res	5, d
	jr	00110$
00109$:
;menu.c:308: } else if (c2 == '_') {
	ld	a, d
	sub	a, #0x5f
	jr	NZ,00110$
;menu.c:309: c2=' ';
	ld	d, #0x20
00110$:
;menu.c:313: if (c1 != c2) break;
;menu.c:314: if (c1 == 0) break;  // only need this test if they are BOTH NUL
	ld	a,e
	cp	a,d
	jr	NZ,00115$
	or	a, a
	jr	Z,00115$
;menu.c:317: ++s1; 
	inc	bc
;menu.c:318: ++s2; 
	inc	-2 (ix)
	jr	NZ,00116$
	inc	-1 (ix)
	jr	00116$
00115$:
;menu.c:320: return (c1-c2);
	ld	a, e
	sub	a, d
	ld	l, a
;menu.c:321: }
	pop	af
	pop	ix
	ret
;menu.c:330: void readDir() {
;	---------------------------------
; Function readDir
; ---------------------------------
_readDir::
	call	___sdcc_enter_ix
	push	af
	push	af
;menu.c:331: repeatDir:
00101$:
;menu.c:332: lastFilename = (unsigned char*)0x8000;  // no files loaded yet
	ld	hl, #0x8000
	ld	(_lastFilename), hl
;menu.c:337: if (FR_OK == f_opendir(&dir, path)) {
	ld	hl, #_path
	push	hl
	ld	hl, #_dir
	push	hl
	call	_f_opendir
	pop	af
	pop	af
	ld	a, l
	or	a, a
	jp	NZ, 00127$
;menu.c:340: mystrcpy(path2, path);
	ld	hl, #_path
	push	hl
	ld	hl, #_path2
	push	hl
	call	_mystrcpy
	pop	af
;menu.c:341: centerString(1, path2);
	ld	hl, #_path2
	ex	(sp),hl
	ld	a, #0x01
	push	af
	inc	sp
	call	_centerString
	pop	af
	inc	sp
;menu.c:343: if (path[1] != 0) {
	ld	a, (#(_path + 0x0001) + 0)
	or	a, a
	jr	Z,00133$
;menu.c:345: memset(lastFilename, 0, 128);
	ld	hl, (_lastFilename)
	ld	-2 (ix), l
	ld	-1 (ix), h
	ld	hl, #0x0080
	push	hl
	ld	l, #0x00
	push	hl
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	push	hl
	call	_memset
	pop	af
	pop	af
	pop	af
;menu.c:346: lastFilename[0]='.';
	ld	hl, (_lastFilename)
	ld	(hl), #0x2e
;menu.c:347: lastFilename[1]='.';
	ld	hl, (_lastFilename)
	inc	hl
	ld	(hl), #0x2e
;menu.c:349: lastFilename+=128;
	ld	hl, #_lastFilename
	ld	a, (hl)
	add	a, #0x80
	ld	(hl), a
	jr	NC,00199$
	inc	hl
	inc	(hl)
00199$:
;menu.c:352: while (FR_OK == f_readdir(&dir, &finfo)) {
00133$:
00122$:
	ld	de, #_finfo
	ld	bc, #_dir
	push	de
	push	bc
	call	_f_readdir
	pop	af
	pop	af
	ld	a, l
	or	a, a
	jp	NZ, 00124$
;menu.c:354: if (disk_status() == STA_NODISK) {
	call	_disk_status
	ld	a, l
	sub	a, #0x02
	jr	NZ,00105$
;menu.c:355: f_closedir(&dir);
	ld	bc, #_dir
	push	bc
	call	_f_closedir
	pop	af
;menu.c:356: return;
	jp	00127$
00105$:
;menu.c:362: if (finfo.fname[0] == '.') {
	ld	a, (#(_finfo + 0x0005) + 0)
	cp	a, #0x2e
	jr	Z,00122$
;menu.c:366: if (finfo.fname[0] == '\0') {
	or	a, a
	jp	Z, 00124$
;menu.c:371: if ((firstScan) && (finfo.fattrib & AM_DIR)) {
	ld	a,(#_firstScan + 0)
	or	a, a
	jr	Z,00113$
	ld	a, (#(_finfo + 0x0004) + 0)
	bit	4, a
	jr	Z,00113$
;menu.c:377: if (0 == mystrcmp(finfo.fname, FolderName)) {
	ld	hl, #_FolderName
	push	hl
	ld	hl, #(_finfo + 0x0005)
	push	hl
	call	_mystrcmp
	pop	af
	pop	af
	ld	a, l
	or	a, a
	jr	NZ,00113$
;menu.c:378: f_closedir(&dir);
	ld	hl, #_dir
	push	hl
	call	_f_closedir
	pop	af
;menu.c:379: memcpy(&path[1], FolderName, FolderNameLen);
	ld	hl,#_FolderNameLen + 0
	ld	c, (hl)
	ld	b, #0x00
	push	bc
	ld	hl, #_FolderName
	push	hl
	ld	hl, #(_path + 0x0001)
	push	hl
	call	_memcpy
	pop	af
	pop	af
	pop	af
;menu.c:380: firstScan = 0;
	ld	hl,#_firstScan + 0
	ld	(hl), #0x00
;menu.c:381: goto repeatDir;
	jp	00101$
00113$:
;menu.c:386: mystrcpy(lastFilename, finfo.fname);    // will truncate to 126 characters
	ld	hl, #(_finfo + 0x0005)
	push	hl
	ld	hl, (_lastFilename)
	push	hl
	call	_mystrcpy
	pop	af
	pop	af
;menu.c:387: if (finfo.fattrib & AM_DIR) {
	ld	hl, #(_finfo + 0x0004) + 0
	ld	e, (hl)
;menu.c:388: *(lastFilename+127) = 0;            // 0 size for directory
	ld	iy, #_lastFilename
	ld	a, 0 (iy)
	add	a, #0x7f
	ld	c, a
	ld	a, 1 (iy)
	adc	a, #0x00
	ld	b, a
;menu.c:387: if (finfo.fattrib & AM_DIR) {
	bit	4, e
	jr	Z,00118$
;menu.c:388: *(lastFilename+127) = 0;            // 0 size for directory
	xor	a, a
	ld	(bc), a
	jr	00119$
00118$:
;menu.c:393: unsigned char x = finfo.fsize >> 14;
	push	bc
	ld	de, #_finfo
	ld	hl, #0x0002
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	pop	bc
	ld	e, -3 (ix)
	ld	d, -2 (ix)
	ld	l, -1 (ix)
	ld	a, #0x06
00205$:
	srl	l
	rr	d
	rr	e
	dec	a
	jr	NZ, 00205$
;menu.c:394: if (finfo.fsize&0x3fff) ++x;
	ld	a, -4 (ix)
	or	a, a
	jr	NZ,00207$
	ld	a, -3 (ix)
	and	a, #0x3f
	jr	Z,00116$
00207$:
	inc	e
00116$:
;menu.c:395: *(lastFilename+127) = x;
	ld	a, e
	ld	(bc), a
00119$:
;menu.c:397: lastFilename += 128;
	ld	hl, #_lastFilename
	ld	a, (hl)
	add	a, #0x80
	ld	(hl), a
	jr	NC,00208$
	inc	hl
	inc	(hl)
00208$:
;menu.c:400: if (lastFilename >= (unsigned char*)0xff80) {
	ld	iy, #_lastFilename
	ld	a, 0 (iy)
	sub	a, #0x80
	ld	a, 1 (iy)
	sbc	a, #0xff
	jp	C, 00122$
;menu.c:401: displayErrorString("Max directory count reached", (unsigned char)(((unsigned int)lastFilename-0x8000)>>7));
	ld	bc, (_lastFilename)
	ld	e, c
	ld	a,b
	add	a,#0x80
	ld	d, a
	ld	b, #0x07
00209$:
	srl	d
	rr	e
	djnz	00209$
	ld	a, e
	push	af
	inc	sp
	ld	hl, #___str_2
	push	hl
	call	_displayErrorString
	pop	af
	inc	sp
;menu.c:402: break;
00124$:
;menu.c:406: f_closedir(&dir);
	ld	hl, #_dir
	push	hl
	call	_f_closedir
	pop	af
;menu.c:407: firstScan = 0;
	ld	hl,#_firstScan + 0
	ld	(hl), #0x00
00127$:
;menu.c:409: }
	ld	sp, ix
	pop	ix
	ret
___str_2:
	.ascii "Max directory count reached"
	.db 0x00
;menu.c:413: void waitRelease() {
;	---------------------------------
; Function waitRelease
; ---------------------------------
_waitRelease::
00108$:
;menu.c:415: readkeypad();
	call	_readkeypad
;menu.c:416: if ((MY_JOYY == 0) && (MY_JOYX == 0)) {
	ld	a,(#_MY_JOYY + 0)
	or	a, a
	jr	NZ,00104$
	ld	a,(#_MY_JOYX + 0)
	or	a, a
	jr	NZ,00104$
;menu.c:417: repeatTimeout = 45;     // hold this long before next repeat starts
	ld	hl,#_repeatTimeout + 0
	ld	(hl), #0x2d
;menu.c:418: break;
	ret
00104$:
;menu.c:420: --repeatTimeout;
	ld	iy, #_repeatTimeout
	dec	0 (iy)
;menu.c:421: if (repeatTimeout == 0) {
	ld	a, 0 (iy)
	or	a, a
	jr	NZ,00102$
;menu.c:422: repeatTimeout = 5;  // faster repeat if you keep holding
	ld	0 (iy), #0x05
;menu.c:423: break;
	ret
00102$:
;menu.c:426: waitVblanks(1);
	ld	a, #0x01
	push	af
	inc	sp
	call	_waitVblanks
	inc	sp
;menu.c:429: }
	jr	00108$
;menu.c:432: void drawTitles() {
;	---------------------------------
; Function drawTitles
; ---------------------------------
_drawTitles::
	call	___sdcc_enter_ix
	ld	hl, #-9
	add	hl, sp
	ld	sp, hl
;menu.c:437: for (idx = listOffset; idx < listOffset+24; ++idx) {
	ld	a,(#_listOffset + 0)
	ld	-5 (ix), a
	ld	-4 (ix), #0x00
	ld	-3 (ix), #0x10
	xor	a, a
	ld	-2 (ix), a
	ld	-1 (ix), a
00120$:
	ld	hl,#_listOffset + 0
	ld	c, (hl)
	ld	b, #0x00
	ld	hl, #0x0018
	add	hl, bc
	ld	a, -5 (ix)
	ld	-9 (ix), a
	xor	a, a
	ld	-8 (ix), a
	ld	a, -9 (ix)
	sub	a, l
	ld	a, -8 (ix)
	sbc	a, h
	jp	PO, 00165$
	xor	a, #0x80
00165$:
	jp	P, 00122$
;menu.c:441: if (idx&1) {
	ld	a, -5 (ix)
	and	a, #0x01
	ld	-7 (ix), a
	ld	-6 (ix), #0x00
	ld	a, #0x00
	or	a, -7 (ix)
	jr	Z,00102$
;menu.c:442: vdpmemset(atvdp , (COLORTEXT<<4) | COLORLINE2, 40);
	ld	hl, #0x0028
	push	hl
	ld	a, #0x43
	push	af
	inc	sp
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	push	hl
	call	_vdpmemset
	pop	af
	pop	af
	inc	sp
	jr	00103$
00102$:
;menu.c:444: vdpmemset(atvdp , (COLORTEXT<<4) | COLORLINE1, 40);
	ld	hl, #0x0028
	push	hl
	ld	a, #0x42
	push	af
	inc	sp
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	push	hl
	call	_vdpmemset
	pop	af
	pop	af
	inc	sp
00103$:
;../libti99coleco/vdp.h:65: inline void VDP_SET_ADDRESS_WRITE(unsigned int x)					{	VDPWA=((x)&0xff); VDPWA=(((x)>>8)|0x40); }
	ld	b, -1 (ix)
	ld	c, -2 (ix)
	set	6, b
;menu.c:447: if (idx >= listSize) {
	ld	hl, #_listSize
	ld	a, -5 (ix)
	sub	a, (hl)
	jr	C,00114$
;../libti99coleco/vdp.h:65: inline void VDP_SET_ADDRESS_WRITE(unsigned int x)					{	VDPWA=((x)&0xff); VDPWA=(((x)>>8)|0x40); }
	ld	a, c
	out	(_VDPWA), a
	ld	a, b
	out	(_VDPWA), a
;menu.c:450: vdpStrOut("", 40);  // to erase the line
	ld	a, #0x28
	push	af
	inc	sp
	ld	hl, #___str_3
	push	hl
	call	_vdpStrOut
	pop	af
	inc	sp
;menu.c:453: if (idx == 0xff) {
	ld	a, -5 (ix)
	inc	a
	jr	NZ,00115$
;menu.c:454: idx--;      // so the loop doesn't wrap around
	dec	-5 (ix)
;menu.c:455: if (vdp == 23*40) break;
	ld	a, -2 (ix)
	sub	a, #0x98
	jr	NZ,00115$
	ld	a, -1 (ix)
	sub	a, #0x03
	jp	Z,00122$
	jr	00115$
00114$:
;menu.c:458: ptr = sortedList[idx];
	pop	hl
	push	hl
	add	hl, hl
	ld	de, #_sortedList
	add	hl, de
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
;menu.c:461: if (ptr[127] == 0) {
	ld	l, e
	ld	h, d
	push	bc
	ld	bc, #0x007f
	add	hl, bc
	pop	bc
	ld	a, (hl)
	or	a, a
	jr	NZ,00112$
;menu.c:463: if (idx&1) {
	ld	a, -6 (ix)
	or	a, -7 (ix)
	jr	Z,00109$
;menu.c:464: vdpmemset(atvdp , (COLORDIRECTORY<<4) | COLORLINE2, 40);
	push	bc
	push	de
	ld	hl, #0x0028
	push	hl
	ld	a, #0x53
	push	af
	inc	sp
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	push	hl
	call	_vdpmemset
	pop	af
	pop	af
	inc	sp
	pop	de
	pop	bc
	jr	00112$
00109$:
;menu.c:466: vdpmemset(atvdp , (COLORDIRECTORY<<4) | COLORLINE1, 40);
	push	bc
	push	de
	ld	hl, #0x0028
	push	hl
	ld	a, #0x52
	push	af
	inc	sp
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	push	hl
	call	_vdpmemset
	pop	af
	pop	af
	inc	sp
	pop	de
	pop	bc
00112$:
;../libti99coleco/vdp.h:65: inline void VDP_SET_ADDRESS_WRITE(unsigned int x)					{	VDPWA=((x)&0xff); VDPWA=(((x)>>8)|0x40); }
	ld	a, c
	out	(_VDPWA), a
	ld	a, b
	out	(_VDPWA), a
;menu.c:473: vdpStrOut(ptr, 40);
	ld	a, #0x28
	push	af
	inc	sp
	push	de
	call	_vdpStrOut
	pop	af
	inc	sp
00115$:
;menu.c:475: atvdp+=40;
	ld	a, -4 (ix)
	add	a, #0x28
	ld	-4 (ix), a
	jr	NC,00169$
	inc	-3 (ix)
00169$:
;menu.c:476: vdp+=40;
	ld	a, -2 (ix)
	add	a, #0x28
	ld	-2 (ix), a
	jr	NC,00170$
	inc	-1 (ix)
00170$:
;menu.c:437: for (idx = listOffset; idx < listOffset+24; ++idx) {
	inc	-5 (ix)
	jp	00120$
00122$:
;menu.c:478: }
	ld	sp, ix
	pop	ix
	ret
___str_3:
	.db 0x00
;menu.c:481: void sortDir() {
;	---------------------------------
; Function sortDir
; ---------------------------------
_sortDir::
	call	___sdcc_enter_ix
	push	af
	push	af
;menu.c:488: listSize = 0;
	ld	hl,#_listSize + 0
	ld	(hl), #0x00
;menu.c:490: while (ptr < lastFilename) {
	ld	-2 (ix), #0x00
	ld	-1 (ix), #0x80
00117$:
	ld	hl, #_lastFilename
	ld	a, -2 (ix)
	sub	a, (hl)
	ld	a, -1 (ix)
	inc	hl
	sbc	a, (hl)
	jp	NC, 00125$
;menu.c:499: if (*(ptr+127) == 0) {
	pop	bc
	pop	hl
	push	hl
	push	bc
	ld	de, #0x007f
	add	hl, de
	ld	a, (hl)
;menu.c:501: for (idx = 0; idx < listSize; ++idx) {
	or	a,a
	jr	NZ,00113$
	ld	c,a
00121$:
	ld	hl, #_listSize
	ld	a, c
	sub	a, (hl)
	jr	NC,00139$
;menu.c:505: ptr2 = sortedList[idx];
	ld	l, c
	ld	h, #0x00
	add	hl, hl
	ld	de, #_sortedList
	add	hl, de
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
;menu.c:508: if ((*(ptr2+127)) != 0) break;
	ld	l, e
	ld	h, d
	push	bc
	ld	bc, #0x007f
	add	hl, bc
	pop	bc
	ld	a, (hl)
	or	a, a
	jr	NZ,00139$
;menu.c:512: if (mystrcmp(ptr, ptr2) < 0) break;
	push	bc
	push	de
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	push	hl
	call	_mystrcmp
	pop	af
	pop	af
	pop	bc
	bit	7, l
	jr	NZ,00139$
;menu.c:501: for (idx = 0; idx < listSize; ++idx) {
	inc	c
	jr	00121$
00113$:
;menu.c:516: for (idx = listSize-1; idx != 255; --idx) {
	ld	hl,#_listSize + 0
	ld	c, (hl)
	dec	c
	ld	b, c
00124$:
	ld	a, b
	inc	a
	jr	Z,00114$
;menu.c:520: ptr2 = sortedList[idx];
	ld	l, b
	ld	h, #0x00
	add	hl, hl
	ld	de, #_sortedList
	add	hl, de
	ld	e, (hl)
	inc	hl
	ld	d, (hl)
;menu.c:523: if ((*(ptr2+127)) == 0) {
	ld	l, e
	ld	h, d
	push	bc
	ld	bc, #0x007f
	add	hl, bc
	pop	bc
	ld	a, (hl)
;menu.c:524: ++idx;
	inc	c
;menu.c:523: if ((*(ptr2+127)) == 0) {
	or	a, a
;menu.c:524: ++idx;
;menu.c:525: break;
	jr	Z,00114$
;menu.c:530: if (mystrcmp(ptr, ptr2) < 0) {
	push	bc
	push	de
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	push	hl
	call	_mystrcmp
	pop	af
	pop	af
	pop	bc
	bit	7, l
;menu.c:535: ++idx;
;menu.c:536: break;
	jr	Z,00114$
;menu.c:516: for (idx = listSize-1; idx != 255; --idx) {
	dec	b
	ld	c, b
	jr	00124$
00139$:
00114$:
;menu.c:542: memmove(&sortedList[idx+1], &sortedList[idx], (listSize-idx)*2);
	ld	e, c
	ld	d, #0x00
	ld	-4 (ix), e
	ld	-3 (ix), d
	sla	-4 (ix)
	rl	-3 (ix)
;menu.c:541: if (idx < listSize) {
	ld	hl, #_listSize
	ld	a, c
	sub	a, (hl)
	jr	NC,00116$
;menu.c:542: memmove(&sortedList[idx+1], &sortedList[idx], (listSize-idx)*2);
	ld	iy, #_listSize
	ld	l, 0 (iy)
	ld	h, #0x00
	cp	a, a
	sbc	hl, de
	add	hl, hl
	ld	a, #<(_sortedList)
	add	a, -4 (ix)
	ld	c, a
	ld	a, #>(_sortedList)
	adc	a, -3 (ix)
	ld	b, a
	inc	de
	sla	e
	rl	d
	ld	a, e
	add	a, #<(_sortedList)
	ld	e, a
	ld	a, d
	adc	a, #>(_sortedList)
	ld	d, a
	push	hl
	push	bc
	push	de
	call	_memmove
	pop	af
	pop	af
	pop	af
00116$:
;menu.c:546: sortedList[idx] = ptr;
	ld	a, -4 (ix)
	add	a, #<(_sortedList)
	ld	c, a
	ld	a, -3 (ix)
	adc	a, #>(_sortedList)
	ld	b, a
	ld	a, -2 (ix)
	ld	(bc), a
	inc	bc
	ld	a, -1 (ix)
	ld	(bc), a
;menu.c:549: ++listSize;
	ld	hl, #_listSize+0
	inc	(hl)
;menu.c:552: ptr += 0x80;
	ld	a, -2 (ix)
	add	a, #0x80
	ld	-2 (ix), a
	jp	NC,00117$
	inc	-1 (ix)
	jp	00117$
00125$:
;menu.c:554: }
	ld	sp, ix
	pop	ix
	ret
;menu.c:557: void waitSDCard() {
;	---------------------------------
; Function waitSDCard
; ---------------------------------
_waitSDCard::
;menu.c:564: cleartextout();
	call	_cleartextout
;menu.c:565: textout(GSPRITEPAT+(0*8)+(4*16), "Insert SD or turn system");
	ld	hl, #___str_4
	push	hl
	ld	hl, #0x1840
	push	hl
	call	_textout
	pop	af
;menu.c:566: textout(GSPRITEPAT+(1*8)+(1*16), "off before inserting cartridge");
	ld	hl, #___str_5
	ex	(sp),hl
	ld	hl, #0x1818
	push	hl
	call	_textout
	pop	af
	pop	af
;menu.c:568: debounce = 0;
	ld	c, #0x00
;menu.c:569: while (debounce < 2) {
00104$:
	ld	a, c
	sub	a, #0x02
	ret	NC
;menu.c:572: waitVblanks(2);
	push	bc
	ld	a, #0x02
	push	af
	inc	sp
	call	_waitVblanks
	inc	sp
	call	_disk_status
	ld	a, l
	pop	bc
;menu.c:576: debounce = 0;
	sub	a,#0x02
	jr	NZ,00102$
	ld	c,a
	jr	00103$
00102$:
;menu.c:578: ++debounce;
	inc	c
00103$:
;menu.c:582: readkeypad();
	push	bc
	call	_readkeypad
	pop	bc
;menu.c:584: }
	jr	00104$
___str_4:
	.ascii "Insert SD or turn system"
	.db 0x00
___str_5:
	.ascii "off before inserting cartridge"
	.db 0x00
;menu.c:588: void loadCartridgeRom() {
;	---------------------------------
; Function loadCartridgeRom
; ---------------------------------
_loadCartridgeRom::
	call	___sdcc_enter_ix
	push	af
	push	af
	push	af
;menu.c:592: clrscrbottom();
	call	_clrscrbottom
;menu.c:593: centerString(0, "reading cart...");
	ld	hl, #___str_6
	push	hl
	xor	a, a
	push	af
	inc	sp
	call	_centerString
	pop	af
	inc	sp
	ld	de, #0x8200
00111$:
;menu.c:599: res = f_read(&fil, p, 512, &br);
	ld	hl, #0
	add	hl, sp
	ld	c, e
	ld	b, d
	push	de
	push	hl
	ld	hl, #0x0200
	push	hl
	push	bc
	ld	hl, #_fil
	push	hl
	call	_f_read
	pop	af
	pop	af
	pop	af
	pop	af
	ld	a, l
	pop	de
	ld	b, a
;menu.c:600: if (res != FR_OK) {
	or	a, a
	jr	Z,00102$
;menu.c:601: f_close(&fil);
	push	bc
	ld	hl, #_fil
	push	hl
	call	_f_close
	inc	sp
	ld	hl,#___str_7
	ex	(sp),hl
	call	_displayErrorString
	pop	af
	inc	sp
;menu.c:603: return;
	jr	00113$
00102$:
;menu.c:605: if (br < 512) {
	ld	a, -5 (ix)
	sub	a, #0x02
	jr	C,00110$
;menu.c:610: p+=512;
	ld	hl, #0x0200
	add	hl, de
	ex	de, hl
;menu.c:611: if (p < (unsigned char*)0x8000) {
	ld	a, d
	sub	a, #0x80
	jr	NC,00111$
;menu.c:613: if (f_eof(&fil)) {
	ld	de, #_fil + 16
	ld	hl, #0x0002
	add	hl, sp
	ex	de, hl
	ld	bc, #0x0004
	ldir
	ld	bc, (#_fil + 10)
	ld	de, (#_fil + 12)
	ld	a, -4 (ix)
	sub	a, c
	jr	NZ,00140$
	ld	a, -3 (ix)
	sub	a, b
	jr	NZ,00140$
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	cp	a, a
	sbc	hl, de
	jr	Z,00110$
00140$:
;menu.c:616: f_close(&fil);
	ld	hl, #_fil
	push	hl
	call	_f_close
;menu.c:617: displayErrorString("Unrecognized >32k Cart", 1);
	ld	h,#0x01
	ex	(sp),hl
	inc	sp
	ld	hl, #___str_8
	push	hl
	call	_displayErrorString
	pop	af
	inc	sp
;menu.c:618: return;
	jr	00113$
00110$:
;menu.c:622: f_close(&fil);
	ld	hl, #_fil
	push	hl
	call	_f_close
	pop	af
;menu.c:625: phBankingScheme = PH_BANK_MEGACART | PH_UPPER_CART;     // the megacart banking is ignored for upper type cart
	ld	a, #0x31
	out	(_phBankingScheme), a
;menu.c:628: startTitle();   // never returns
	call	_startTitle
00113$:
;menu.c:629: }
	ld	sp, ix
	pop	ix
	ret
___str_6:
	.ascii "reading cart..."
	.db 0x00
___str_7:
	.ascii "Cartridge load failed."
	.db 0x00
___str_8:
	.ascii "Unrecognized >32k Cart"
	.db 0x00
;menu.c:632: void copyPage(unsigned char a, unsigned char b) {
;	---------------------------------
; Function copyPage
; ---------------------------------
_copyPage::
	call	___sdcc_enter_ix
;menu.c:636: while (off > 0) {   // watch for wrap around
	ld	bc, #0x0080
00101$:
	ld	a, c
	or	a, b
	jr	Z,00104$
;menu.c:637: phRAMBankSelect = a;
	ld	a, 4 (ix)
	out	(_phRAMBankSelect), a
;menu.c:638: memcpy(path2, off, 512);
	ld	e, b
	ld	d, c
	push	bc
	push	de
	ld	hl, #0x0200
	push	hl
	push	de
	ld	hl, #_path2
	push	hl
	call	_memcpy
	pop	af
	pop	af
	pop	af
	pop	de
	pop	bc
;menu.c:639: phRAMBankSelect = b;
	ld	a, 5 (ix)
	out	(_phRAMBankSelect), a
;menu.c:640: memcpy(off, path2, 512);
	push	bc
	ld	hl, #0x0200
	push	hl
	ld	hl, #_path2
	push	hl
	push	de
	call	_memcpy
	pop	af
	pop	af
	pop	af
	pop	bc
;menu.c:641: off += 512;
	ld	a, c
	add	a, #0x02
	ld	c, a
	jr	00101$
00104$:
;menu.c:643: }
	pop	ix
	ret
;menu.c:650: unsigned char loadMegacartRom(unsigned char fsize, unsigned char isSGM) {
;	---------------------------------
; Function loadMegacartRom
; ---------------------------------
_loadMegacartRom::
	call	___sdcc_enter_ix
	ld	hl, #-15
	add	hl, sp
	ld	sp, hl
;menu.c:656: clrscrbottom();
	call	_clrscrbottom
;menu.c:657: if (!isSGM) {
	ld	a, 5 (ix)
	or	a, a
	jr	NZ,00102$
;menu.c:658: centerString(0, "reading megacart...");
	ld	hl, #___str_9
	push	hl
	xor	a, a
	push	af
	inc	sp
	call	_centerString
	pop	af
	inc	sp
	jr	00103$
00102$:
;menu.c:660: centerString(0, "reading sgm...");
	ld	hl, #___str_10
	push	hl
	xor	a, a
	push	af
	inc	sp
	call	_centerString
	pop	af
	inc	sp
00103$:
;menu.c:666: ofs = 0;
	ld	bc, #0x0000
	ld	de, #0x0000
;menu.c:667: n = fsize;
	ld	a, 4 (ix)
	ld	-1 (ix), a
	ld	-2 (ix), a
;menu.c:668: if (n > 30) {
	ld	a, #0x1e
	sub	a, -1 (ix)
	jr	NC,00105$
;menu.c:669: ofs = (FSIZE_t)(n - 30) << 14;
	ld	a, -1 (ix)
	ld	b, #0x00
	add	a, #0xe2
	ld	c, a
	ld	a, b
	adc	a, #0xff
	ld	b, a
	rla
	sbc	a, a
	ld	e, a
	ld	d, a
	ld	a, #0x0e
00212$:
	sla	c
	rl	b
	rl	e
	rl	d
	dec	a
	jr	NZ,00212$
;menu.c:670: n = 30;
	ld	-2 (ix), #0x1e
00105$:
;menu.c:674: page = CART_LAST_PAGE - ((n-1)>>1);
	ld	l, -2 (ix)
	ld	h, #0x00
	dec	hl
	sra	h
	rr	l
	ld	a, #0x0f
	sub	a, l
;menu.c:675: phRAMBankSelect = page;
	ld	-11 (ix), a
	out	(_phRAMBankSelect), a
;menu.c:679: p = (unsigned char*)0x8000 + ((n&1)?0x4000:0);
	bit	0, -2 (ix)
	jr	Z,00132$
	ld	hl, #0x4000
	jr	00133$
00132$:
	ld	hl, #0x0000
00133$:
	ld	-4 (ix), l
	ld	a, h
	add	a, #0x80
	ld	-3 (ix), a
;menu.c:682: if (FR_OK != f_lseek(&fil, ofs)) {
	push	de
	push	bc
	ld	hl, #_fil
	push	hl
	call	_f_lseek
	pop	af
	pop	af
	pop	af
	ld	-2 (ix), l
	ld	a, l
	or	a, a
	jr	Z,00142$
;menu.c:683: f_close(&fil);
	ld	hl, #_fil
	push	hl
	call	_f_close
;menu.c:684: displayErrorString("Failed to seek file.", 2);
	ld	h,#0x02
	ex	(sp),hl
	inc	sp
	ld	hl, #___str_11
	push	hl
	call	_displayErrorString
	pop	af
	inc	sp
;menu.c:685: return page;
	ld	l, -11 (ix)
	jp	00130$
00142$:
	ld	a, -11 (ix)
	ld	-2 (ix), a
00128$:
;menu.c:692: res = f_read(&fil, p, 512, &br);
	ld	hl, #2
	add	hl, sp
	ex	(sp), hl
	pop	de
	push	de
	ld	c, -4 (ix)
	ld	b, -3 (ix)
	push	de
	ld	hl, #0x0200
	push	hl
	push	bc
	ld	hl, #_fil
	push	hl
	call	_f_read
	pop	af
	pop	af
	pop	af
	pop	af
	ld	a, l
	ld	b, a
;menu.c:693: if (res != FR_OK) {
	or	a, a
	jr	Z,00109$
;menu.c:694: f_close(&fil);
	push	bc
	ld	hl, #_fil
	push	hl
	call	_f_close
	inc	sp
	ld	hl,#___str_12
	ex	(sp),hl
	call	_displayErrorString
	pop	af
	inc	sp
;menu.c:696: return page;
	ld	l, -11 (ix)
	jp	00130$
00109$:
;menu.c:698: if (br < 512) {
	ld	a, -12 (ix)
	sub	a, #0x02
	jr	C,00116$
;menu.c:703: p+=512;
	ld	a, -4 (ix)
	ld	-4 (ix), a
	ld	a, -3 (ix)
	add	a, #0x02
;menu.c:704: if (p < (unsigned char*)0x8000) {
	ld	-3 (ix), a
	sub	a, #0x80
	jr	NC,00128$
;menu.c:706: ++page;
	inc	-2 (ix)
	ld	a, -2 (ix)
	ld	-11 (ix), a
;menu.c:707: if (page > CART_LAST_PAGE) {
	ld	a, #0x0f
	sub	a, -2 (ix)
	jr	C,00116$
;menu.c:712: p = (unsigned char*)0x8000;
	ld	-4 (ix), #0x00
	ld	-3 (ix), #0x80
;menu.c:713: phRAMBankSelect = page;
	ld	a, -2 (ix)
	out	(_phRAMBankSelect), a
	jr	00128$
00116$:
;menu.c:719: if (fsize > 30) {
	ld	a, #0x1e
	sub	a, 4 (ix)
	jp	NC, 00121$
;menu.c:721: ofs = 0;
	xor	a, a
	ld	-10 (ix), a
	ld	-9 (ix), a
	ld	-8 (ix), a
	ld	-7 (ix), a
;menu.c:724: do {
	ld	a, -15 (ix)
	ld	-6 (ix), a
	ld	a, -14 (ix)
	ld	-5 (ix), a
	ld	a, -15 (ix)
	ld	-4 (ix), a
	ld	a, -14 (ix)
	ld	-3 (ix), a
	ld	a, -1 (ix)
	add	a, a
	ld	-2 (ix), a
	xor	a, a
	ld	-1 (ix), a
00117$:
;menu.c:725: phCachePage = n;
	ld	a, -1 (ix)
	out	(_phCachePage), a
;menu.c:726: f_lseek(&fil, ofs);
	ld	l, -8 (ix)
	ld	h, -7 (ix)
	push	hl
	ld	l, -10 (ix)
	ld	h, -9 (ix)
	push	hl
	ld	hl, #_fil
	push	hl
	call	_f_lseek
	pop	af
	pop	af
	pop	af
;menu.c:727: f_read(&fil, path2, 1, &br);
	ld	c, -6 (ix)
	ld	b, -5 (ix)
	push	bc
	ld	hl, #0x0001
	push	hl
	ld	hl, #_path2
	push	hl
	ld	hl, #_fil
	push	hl
	call	_f_read
	pop	af
	pop	af
	pop	af
	pop	af
;menu.c:728: ofs += 8191;
	ld	a, -10 (ix)
	add	a, #0xff
	ld	c, a
	ld	a, -9 (ix)
	adc	a, #0x1f
	ld	b, a
	ld	a, -8 (ix)
	adc	a, #0x00
	ld	e, a
	ld	a, -7 (ix)
	adc	a, #0x00
	ld	d, a
;menu.c:729: phCacheCheck = n;
	ld	a, -1 (ix)
	out	(_phCacheCheck), a
;menu.c:730: f_lseek(&fil, ofs);
	push	bc
	push	de
	push	de
	push	bc
	ld	hl, #_fil
	push	hl
	call	_f_lseek
	pop	af
	pop	af
	pop	af
	pop	de
	pop	bc
;menu.c:731: f_read(&fil, path2, 1, &br);
	ld	l, -4 (ix)
	ld	h, -3 (ix)
	push	bc
	push	de
	push	hl
	ld	hl, #0x0001
	push	hl
	ld	hl, #_path2
	push	hl
	ld	hl, #_fil
	push	hl
	call	_f_read
	pop	af
	pop	af
	pop	af
	pop	af
	pop	de
	pop	bc
;menu.c:732: ++ofs;
	ld	a, c
	add	a, #0x01
	ld	-10 (ix), a
	ld	a, b
	adc	a, #0x00
	ld	-9 (ix), a
	ld	a, e
	adc	a, #0x00
	ld	-8 (ix), a
	ld	a, d
	adc	a, #0x00
	ld	-7 (ix), a
;menu.c:733: } while (++n != (unsigned char)(fsize * 2));
	inc	-1 (ix)
	ld	a, -2 (ix)
	sub	a, -1 (ix)
	jp	NZ,00117$
;menu.c:734: phCacheStatus = 0;
	ld	a, #0x00
	out	(_phCacheStatus), a
00121$:
;menu.c:736: f_close(&fil);
	ld	hl, #_fil
	push	hl
	call	_f_close
	pop	af
;menu.c:740: if ((fsize & (fsize - 1)) || (phCacheStatus & 1)) {
	ld	a, 4 (ix)
	ld	-6 (ix), a
	xor	a, a
	ld	-5 (ix), a
	ld	a, -6 (ix)
	add	a, #0xff
	ld	-4 (ix), a
	ld	a, -5 (ix)
	adc	a, #0xff
	ld	-3 (ix), a
	ld	a, -6 (ix)
	and	a, -4 (ix)
	ld	-2 (ix), a
	ld	a, -5 (ix)
	and	a, -3 (ix)
	ld	-1 (ix), a
	or	a, -2 (ix)
	jr	NZ,00122$
	in	a, (_phCacheStatus)
	ld	-1 (ix), a
	bit	0, -1 (ix)
	jr	Z,00123$
00122$:
;menu.c:741: displayErrorString("Unpadded or fragmented", fsize);
	ld	a, 4 (ix)
	push	af
	inc	sp
	ld	hl, #___str_13
	push	hl
	call	_displayErrorString
	pop	af
	inc	sp
;menu.c:742: return page;
	ld	l, -11 (ix)
	jr	00130$
00123$:
;menu.c:744: phCartMask = isSGM ? fsize * 2 - 1 : fsize - 1;
	ld	a, 5 (ix)
	or	a, a
	jr	Z,00134$
	ld	a, 4 (ix)
	add	a, a
	dec	a
	jr	00135$
00134$:
	ld	a, 4 (ix)
	dec	a
00135$:
	out	(_phCartMask), a
;menu.c:747: if (isSGM) {
	ld	a, 5 (ix)
	or	a, a
	jr	Z,00126$
;menu.c:748: phBankingScheme = PH_BANK_SGM | PH_UPPER_EXPROM;
	ld	a, #0x12
	out	(_phBankingScheme), a
	jr	00127$
00126$:
;menu.c:750: phBankingScheme = PH_BANK_MEGACART | PH_UPPER_EXPROM;
	ld	a, #0x11
	out	(_phBankingScheme), a
00127$:
;menu.c:752: phRAMBankSelect = CART_FIRST_PAGE;  // this is not necessarily enforced on real megacarts
	ld	a, #0x01
	out	(_phRAMBankSelect), a
;menu.c:755: startTitle();   // never returns
	call	_startTitle
;menu.c:758: return 0;
	ld	l, #0x00
00130$:
;menu.c:759: }
	ld	sp, ix
	pop	ix
	ret
___str_9:
	.ascii "reading megacart..."
	.db 0x00
___str_10:
	.ascii "reading sgm..."
	.db 0x00
___str_11:
	.ascii "Failed to seek file."
	.db 0x00
___str_12:
	.ascii "Cartridge load failed."
	.db 0x00
___str_13:
	.ascii "Unpadded or fragmented"
	.db 0x00
;menu.c:762: void drawSelect() {
;	---------------------------------
; Function drawSelect
; ---------------------------------
_drawSelect::
;menu.c:766: if (listSelect > listSize-1) {
	ld	hl,#_listSize + 0
	ld	c, (hl)
	ld	b, #0x00
	dec	bc
	ld	hl,#_listSelect + 0
	ld	e, (hl)
	ld	d, #0x00
	ld	a, c
	sub	a, e
	ld	a, b
	sbc	a, d
	jp	PO, 00110$
	xor	a, #0x80
00110$:
	jp	P, 00102$
;menu.c:767: listSelect = listSize-1;
	ld	a,(#_listSize + 0)
	ld	hl, #_listSelect
	add	a, #0xff
	ld	(hl), a
00102$:
;menu.c:770: adr = listSelect - listOffset;     // row on screen
	ld	hl,#_listSelect + 0
	ld	c, (hl)
	ld	b, #0x00
	ld	hl,#_listOffset + 0
	ld	e, (hl)
	ld	d, #0x00
	ld	a, c
	sub	a, e
	ld	c, a
	ld	a, b
	sbc	a, d
	ld	b, a
;menu.c:771: adr *= 40;      // multiply for offset
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, hl
	add	hl, bc
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	c, l
;menu.c:772: adr += GCOLOR;  // index into attribute table
	ld	a, h
	add	a, #0x10
	ld	b, a
;menu.c:774: attr = vdpreadchar(adr);            // get the current attribute (for text color)
	push	bc
	push	bc
	call	_vdpreadchar
	pop	af
	ld	a, l
	pop	bc
;menu.c:775: attr = (attr&0xf0) | COLORHILITE;    // highlight the background
	and	a, #0xf0
	or	a, #0x07
	ld	d, a
;menu.c:777: vdpmemset(adr, attr, 40);           // write out the whole line the same
	ld	hl, #0x0028
	push	hl
	push	de
	inc	sp
	push	bc
	call	_vdpmemset
	pop	af
	pop	af
	inc	sp
;menu.c:778: }
	ret
;menu.c:781: void undrawSelect() {
;	---------------------------------
; Function undrawSelect
; ---------------------------------
_undrawSelect::
;menu.c:786: adr = listSelect - listOffset;     // row on screen
	ld	hl,#_listSelect + 0
	ld	c, (hl)
	ld	b, #0x00
	ld	hl,#_listOffset + 0
	ld	e, (hl)
	ld	d, #0x00
	ld	a, c
	sub	a, e
	ld	c, a
	ld	a, b
	sbc	a, d
	ld	b, a
;menu.c:788: if (adr & 1) {
	bit	0, c
;menu.c:790: bg = COLORLINE2;
;menu.c:792: bg = COLORLINE1;
	ld	e, #0x03
	jr	NZ,00103$
	ld	e, #0x02
00103$:
;menu.c:794: adr *= 40;      // multiply for offset
	ld	l, c
	ld	h, b
	add	hl, hl
	add	hl, hl
	add	hl, bc
	add	hl, hl
	add	hl, hl
	add	hl, hl
	ld	c, l
;menu.c:795: adr += GCOLOR;  // index into attribute table
	ld	a, h
	add	a, #0x10
	ld	b, a
;menu.c:797: attr = vdpreadchar(adr);   // get the current attribute (for text color)
	push	bc
	push	de
	push	bc
	call	_vdpreadchar
	pop	af
	ld	a, l
	pop	de
	pop	bc
;menu.c:798: attr = (attr&0xf0) | bg;    // highlight the background
	and	a, #0xf0
	or	a, e
	ld	d, a
;menu.c:799: vdpmemset(adr, attr, 40);  // write out the whole line the same
	ld	hl, #0x0028
	push	hl
	push	de
	inc	sp
	push	bc
	call	_vdpmemset
	pop	af
	pop	af
	inc	sp
;menu.c:800: }
	ret
;menu.c:807: char getUserSelection() {
;	---------------------------------
; Function getUserSelection
; ---------------------------------
_getUserSelection::
	call	___sdcc_enter_ix
	push	af
;menu.c:809: drawSelect();
	call	_drawSelect
00143$:
;menu.c:814: if (disk_status() == STA_NODISK) {
	call	_disk_status
	ld	a, l
;menu.c:815: return 0;
	sub	a,#0x02
	jr	NZ,00102$
	ld	l,a
	jp	00144$
00102$:
;menu.c:819: waitVblanks(1);
	ld	a, #0x01
	push	af
	inc	sp
	call	_waitVblanks
	inc	sp
;menu.c:822: readkeypad();
	call	_readkeypad
;menu.c:824: if (MY_JOYX | MY_JOYY) {
	ld	a,(#_MY_JOYX + 0)
	ld	hl,#_MY_JOYY + 0
	or	a,(hl)
	or	a, a
	jp	Z, 00137$
;menu.c:825: undrawSelect();     // clear the highlight
	call	_undrawSelect
;menu.c:827: if (MY_JOYX == 0x80) {
	ld	a,(#_MY_JOYX + 0)
	sub	a, #0x80
	jr	NZ,00104$
;menu.c:829: return -1;
	ld	l, #0xff
	jp	00144$
00104$:
;menu.c:832: if (MY_JOYY == JOY_UP) {
	ld	a,(#_MY_JOYY + 0)
	sub	a, #0x04
	jr	NZ,00134$
;menu.c:833: if (listSelect > 0) {
	ld	iy, #_listSelect
	ld	a, 0 (iy)
	or	a, a
	jp	Z, 00135$
;menu.c:834: --listSelect;       // count down
	dec	0 (iy)
;menu.c:835: if (listSelect < listOffset) {
	ld	hl, #_listOffset
	ld	a, 0 (iy)
	sub	a, (hl)
	jp	NC, 00135$
;menu.c:836: listOffset--;
	ld	hl, #_listOffset+0
	dec	(hl)
;menu.c:837: return -1;      // request redraw
	ld	l, #0xff
	jp	00144$
00134$:
;menu.c:841: if (listSelect < listSize-1) {
	ld	hl,#_listSize + 0
	ld	e, (hl)
	ld	d, #0x00
;menu.c:843: if (listSelect > listOffset+23) {
	ld	hl,#_listOffset + 0
	ld	c, (hl)
	ld	b, #0x00
;menu.c:841: if (listSelect < listSize-1) {
	dec	de
;menu.c:843: if (listSelect > listOffset+23) {
	ld	hl, #0x0017
	add	hl, bc
	ex	(sp), hl
;menu.c:840: } else if (MY_JOYY == JOY_DOWN) {
	ld	a,(#_MY_JOYY + 0)
	sub	a, #0xfc
	jr	NZ,00131$
;menu.c:841: if (listSelect < listSize-1) {
	ld	a,(#_listSelect + 0)
	ld	b, #0x00
	sub	a, e
	ld	a, b
	sbc	a, d
	jp	PO, 00239$
	xor	a, #0x80
00239$:
	jp	P, 00135$
;menu.c:842: ++listSelect;
	ld	iy, #_listSelect
	inc	0 (iy)
;menu.c:843: if (listSelect > listOffset+23) {
	ld	c, 0 (iy)
	ld	b, #0x00
	ld	a, -2 (ix)
	sub	a, c
	ld	a, -1 (ix)
	sbc	a, b
	jp	PO, 00240$
	xor	a, #0x80
00240$:
	jp	P, 00135$
;menu.c:844: listOffset++;
	ld	hl, #_listOffset+0
	inc	(hl)
;menu.c:845: return -1;      // request redraw
	ld	l, #0xff
	jp	00144$
00131$:
;menu.c:851: unsigned char add = listSize-1-listOffset;
	ld	hl,#_listOffset + 0
	ld	c, (hl)
;menu.c:857: listSelect += 24;
	ld	hl,#_listSelect + 0
	ld	b, (hl)
;menu.c:848: } else if (MY_JOYX == JOY_RIGHT) {
	ld	a,(#_MY_JOYX + 0)
	sub	a, #0x04
	jr	NZ,00128$
;menu.c:851: unsigned char add = listSize-1-listOffset;
	ld	iy, #_listSize
	ld	l, 0 (iy)
	dec	l
;menu.c:849: if (listOffset+23 < listSize-1) {
	ld	a, -2 (ix)
	sub	a, e
	ld	a, -1 (ix)
	sbc	a, d
	jp	PO, 00243$
	xor	a, #0x80
00243$:
	jp	P, 00117$
;menu.c:851: unsigned char add = listSize-1-listOffset;
	ld	a, l
	sub	a, c
;menu.c:852: if (add < 24) {
	cp	a, #0x18
	jr	NC,00114$
;menu.c:853: listOffset += add;
	ld	hl, #_listOffset
	add	a, (hl)
	ld	(hl), a
;menu.c:854: listSelect = listOffset;
	ld	a,(#_listOffset + 0)
	ld	(#_listSelect + 0),a
	jr	00115$
00114$:
;menu.c:856: listOffset += 24;
	ld	a, c
	add	a, #0x18
	ld	(_listOffset+0), a
;menu.c:857: listSelect += 24;
	ld	a, b
	add	a, #0x18
	ld	(_listSelect+0), a
00115$:
;menu.c:859: return -1;          // request redraw
	ld	l, #0xff
	jr	00144$
00117$:
;menu.c:861: listSelect = listSize-1;
	ld	iy, #_listSelect
	ld	0 (iy), l
	jr	00135$
00128$:
;menu.c:863: } else if (MY_JOYX == JOY_LEFT) {
	ld	a,(#_MY_JOYX + 0)
	sub	a, #0xfc
	jr	NZ,00135$
;menu.c:864: if (listOffset > 0) {
	ld	iy, #_listOffset
	ld	a, 0 (iy)
	or	a, a
	jr	Z,00123$
;menu.c:866: if (listOffset < 24) {
	ld	a, 0 (iy)
	sub	a, #0x18
	jr	NC,00120$
;menu.c:867: listOffset = 0;
	ld	0 (iy), #0x00
;menu.c:868: listSelect = 0;
	ld	hl,#_listSelect + 0
	ld	(hl), #0x00
	jr	00121$
00120$:
;menu.c:870: listOffset -=24;
	ld	hl, #_listOffset
	ld	a, c
	add	a, #0xe8
	ld	(hl), a
;menu.c:871: listSelect -=24;
	ld	hl, #_listSelect
	ld	a, b
	add	a, #0xe8
	ld	(hl), a
00121$:
;menu.c:873: return -1;          // request redraw
	ld	l, #0xff
	jr	00144$
00123$:
;menu.c:875: listSelect = 0;
	ld	hl,#_listSelect + 0
	ld	(hl), #0x00
00135$:
;menu.c:879: drawSelect();
	call	_drawSelect
;menu.c:880: waitRelease();
	call	_waitRelease
;menu.c:881: continue;
	jp	00143$
00137$:
;menu.c:885: repeatTimeout = 45;
	ld	hl,#_repeatTimeout + 0
	ld	(hl), #0x2d
;menu.c:889: if (MY_KEY == JOY_FIRE) {
	ld	a,(#_MY_KEY + 0)
	sub	a, #0x12
	jp	NZ,00143$
;menu.c:890: return 1;   // selected
	ld	l, #0x01
00144$:
;menu.c:895: }
	pop	af
	pop	ix
	ret
;menu.c:898: void load_palette() {
;	---------------------------------
; Function load_palette
; ---------------------------------
_load_palette::
;menu.c:899: loadpal_f18a(MENU_COLOR_SETS[currentPalette], 8);
	ld	bc, #_MENU_COLOR_SETS+0
	ld	iy, #_currentPalette
	ld	l, 0 (iy)
	ld	h, #0x00
	add	hl, hl
	add	hl, bc
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
	ld	a, #0x08
	push	af
	inc	sp
	push	bc
	call	_loadpal_f18a
	pop	af
	inc	sp
;menu.c:900: }
	ret
;menu.c:902: void inc_palette() {
;	---------------------------------
; Function inc_palette
; ---------------------------------
_inc_palette::
;menu.c:903: ++currentPalette;
	ld	iy, #_currentPalette
	inc	0 (iy)
;menu.c:904: if (currentPalette >= sizeof(MENU_COLOR_SETS)/sizeof(MENU_COLOR_SETS[0])) currentPalette = 0;
	ld	a, 0 (iy)
	sub	a, #0x03
	jp	C,_load_palette
	ld	0 (iy), #0x00
;menu.c:905: load_palette();
;menu.c:906: }
	jp	_load_palette
;menu.c:910: void menu() {
;	---------------------------------
; Function menu
; ---------------------------------
_menu::
	call	___sdcc_enter_ix
	push	af
	push	af
	push	af
	dec	sp
;menu.c:914: nocard:
00101$:
;menu.c:915: cleartextout();
	call	_cleartextout
;menu.c:917: if (disk_status() == STA_NODISK) {
	call	_disk_status
	ld	a, l
	sub	a, #0x02
	jr	NZ,00103$
;menu.c:918: waitSDCard();
	call	_waitSDCard
00103$:
;menu.c:923: path[0]='/';
	ld	hl, #_path
	ld	(hl), #0x2f
;menu.c:924: path[1]=0;
	ld	hl, #(_path + 0x0001)
	ld	(hl), #0x00
;menu.c:925: if (FR_OK != f_mount(&fatFs, "", 1)) {
	ld	a, #0x01
	push	af
	inc	sp
	ld	hl, #___str_14
	push	hl
	ld	hl, #_fatFs
	push	hl
	call	_f_mount
	pop	af
	pop	af
	inc	sp
	ld	a, l
	or	a, a
	jr	Z,00105$
;menu.c:926: displayErrorString("Failed to mount SD",0);
	xor	a, a
	push	af
	inc	sp
	ld	hl, #___str_15
	push	hl
	call	_displayErrorString
	pop	af
	inc	sp
;menu.c:927: goto nocard;
	jr	00101$
00105$:
;menu.c:929: firstScan = 1;
	ld	hl,#_firstScan + 0
	ld	(hl), #0x01
;menu.c:930: firstDir = 1;
	ld	hl,#_firstDir + 0
	ld	(hl), #0x01
;menu.c:932: dirLoop:
00106$:
;menu.c:934: cleartextout();
	call	_cleartextout
;menu.c:935: textout(GSPRITEPAT+(0*8)+(12*16), "READING");
	ld	hl, #___str_16
	push	hl
	ld	hl, #0x18c0
	push	hl
	call	_textout
	pop	af
	pop	af
;menu.c:938: phBankingScheme = PH_BANK_MEGACART | PH_UPPER_INTRAM;
	ld	a, #0x01
	out	(_phBankingScheme), a
;menu.c:940: phRAMBankSelect = DIRECTORY_PAGE;
	ld	a, #0x0e
	out	(_phRAMBankSelect), a
;menu.c:943: readDir();
	call	_readDir
;menu.c:944: if (disk_status() == STA_NODISK) goto nocard;
	call	_disk_status
	ld	a, l
	sub	a, #0x02
	jr	Z,00101$
;menu.c:945: if (lastFilename == (unsigned char*)0x8000) {
	ld	iy, #_lastFilename
	ld	a, 0 (iy)
	or	a, a
	jr	NZ,00110$
	ld	a, 1 (iy)
	sub	a, #0x80
	jr	NZ,00110$
;menu.c:947: displayErrorString("Failed to open directory", 0);
	xor	a, a
	push	af
	inc	sp
	ld	hl, #___str_17
	push	hl
	call	_displayErrorString
	pop	af
	inc	sp
;menu.c:948: goto nocard;    // start right over at the root
	jp	00101$
00110$:
;menu.c:955: sortDir();
	call	_sortDir
;menu.c:959: if (listSize == 0) {
	ld	a,(#_listSize + 0)
	or	a, a
	jr	NZ,00112$
;menu.c:960: centerString(1, "No files found");
	ld	hl, #___str_18
	push	hl
	ld	a, #0x01
	push	af
	inc	sp
	call	_centerString
	pop	af
	inc	sp
;menu.c:961: goto nocard;    // start right over at the root
	jp	00101$
00112$:
;menu.c:965: cleartextout();
	call	_cleartextout
;menu.c:968: listOffset = 0;     // top of display
	ld	hl,#_listOffset + 0
	ld	(hl), #0x00
;menu.c:969: listSelect = 0;     // user selected index
	ld	hl,#_listSelect + 0
	ld	(hl), #0x00
;menu.c:971: if (firstDir) {
	ld	iy, #_firstDir
	ld	a, 0 (iy)
	or	a, a
	jr	Z,00114$
;menu.c:972: firstDir = 0;
	ld	0 (iy), #0x00
;../libti99coleco/vdp.h:72: inline void VDP_SET_REGISTER(unsigned char r, unsigned char v)		{	VDPWA=(v); VDPWA=(0x80|(r)); }
	ld	a, #0x80
	out	(_VDPWA), a
	ld	a, #0x81
	out	(_VDPWA), a
;menu.c:978: vdpmemcpy(0x0800+29*8, FATFONT, 94*8);
	ld	hl, #0x02f0
	push	hl
	ld	hl, #_FATFONT
	push	hl
	ld	hl, #0x08e8
	push	hl
	call	_vdpmemcpyfast
	pop	af
	pop	af
	pop	af
;menu.c:982: useScanlines |= 0x02;
	ld	iy, #_useScanlines
	ld	a, 0 (iy)
	or	a, #0x02
	ld	(_useScanlines+0), a
;menu.c:983: VDP_SET_REGISTER(50,useScanlines);
	ld	a, 0 (iy)
	out	(_VDPWA), a
;../libti99coleco/vdp.h:72: inline void VDP_SET_REGISTER(unsigned char r, unsigned char v)		{	VDPWA=(v); VDPWA=(0x80|(r)); }
	ld	a, #0xb2
	out	(_VDPWA), a
	ld	a, #0x06
	out	(_VDPWA), a
	ld	a, #0x87
	out	(_VDPWA), a
;menu.c:989: clrscr();
	call	_clrscr
;menu.c:992: currentPalette = 0;
	ld	hl,#_currentPalette + 0
	ld	(hl), #0x00
;menu.c:993: load_palette();
	call	_load_palette
;../libti99coleco/vdp.h:72: inline void VDP_SET_REGISTER(unsigned char r, unsigned char v)		{	VDPWA=(v); VDPWA=(0x80|(r)); }
	ld	a, #0xf2
	out	(_VDPWA), a
	ld	a, #0x81
	out	(_VDPWA), a
;menu.c:997: text_width = 40;
	ld	hl,#_text_width + 0
	ld	(hl), #0x28
	jr	00217$
00114$:
;menu.c:999: clrscr();
	call	_clrscr
;menu.c:1002: drawLoop:
00217$:
00116$:
;menu.c:1004: phRAMBankSelect = DIRECTORY_PAGE;
	ld	a, #0x0e
	out	(_phRAMBankSelect), a
;menu.c:1007: drawTitles();
	call	_drawTitles
00190$:
;menu.c:1011: char ret = getUserSelection();
	call	_getUserSelection
;menu.c:1012: if (ret >= 0) {
	bit	7, l
	jr	Z,00119$
;menu.c:1018: drawTitles();
	call	_drawTitles
;menu.c:1021: waitRelease();
	call	_waitRelease
	jr	00190$
00119$:
;menu.c:1025: if (disk_status() == STA_NODISK) {
	call	_disk_status
	ld	a, l
	sub	a, #0x02
	jr	NZ,00121$
;menu.c:1027: clrscr();
	call	_clrscr
;menu.c:1029: goto nocard;
	jp	00101$
00121$:
;menu.c:1035: p = sortedList[listSelect];
	ld	iy, #_listSelect
	ld	l, 0 (iy)
	ld	h, #0x00
	add	hl, hl
	ld	de, #_sortedList
	add	hl, de
	ld	c, (hl)
	inc	hl
	ld	b, (hl)
;menu.c:1038: if (*(p+127) == 0) {
	ld	l, c
	ld	h, b
	ld	de, #0x007f
	add	hl, de
	ld	a, (hl)
	or	a, a
	jp	NZ, 00145$
;menu.c:1043: pp = path;
	ld	de, #_path
;menu.c:1044: while (*pp) ++pp;   // find the end of the current string
00122$:
	ld	a, (de)
	or	a, a
	jr	Z,00237$
	inc	de
	jr	00122$
00237$:
	ld	-2 (ix), e
	ld	-1 (ix), d
;menu.c:1045: originalP = pp;     // in case we need to undo it
	inc	sp
	inc	sp
	push	de
;menu.c:1048: if ((p[0]=='.')&&(p[1]=='.')) {
	ld	a, (bc)
	sub	a, #0x2e
	jr	NZ,00141$
	ld	l, c
	ld	h, b
	inc	hl
	ld	a, (hl)
	sub	a, #0x2e
	jr	NZ,00141$
;menu.c:1049: while ((*pp != '/') && (pp > path)) --pp;
	ld	c, e
	ld	b, d
00126$:
	ld	a, (bc)
	sub	a, #0x2f
	jr	Z,00238$
	ld	e, c
	ld	d, b
	ld	a, #<(_path)
	sub	a, e
	ld	a, #>(_path)
	sbc	a, d
	jr	NC,00238$
	dec	bc
	jr	00126$
00238$:
	ld	e, c
	ld	d, b
;menu.c:1050: if (pp == path) {
	ld	hl, #_path
	cp	a, a
	sbc	hl, de
	jr	NZ,00130$
;menu.c:1052: path[0]='/';
	ld	(hl), #0x2f
;menu.c:1053: path[1]=0;
	ld	hl, #(_path + 0x0001)
	ld	(hl), #0x00
	jr	00142$
00130$:
;menu.c:1056: *pp = 0;
	xor	a, a
	ld	(bc), a
	jr	00142$
00141$:
;menu.c:1060: if (pp > path+1) {
	ld	e, -2 (ix)
	ld	d, -1 (ix)
	ld	a, #<((_path + 0x0001))
	sub	a, e
	ld	a, #>((_path + 0x0001))
	sbc	a, d
	jr	NC,00215$
;menu.c:1061: *(pp++) = '/';
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	(hl), #0x2f
	inc	-2 (ix)
	jr	NZ,00432$
	inc	-1 (ix)
00432$:
;menu.c:1065: while ((*p) && (pp-path < 510)) {   // this 510 means we always have room for the '/'
00215$:
00135$:
	ld	a, (bc)
	ld	e, a
	or	a, a
	jr	Z,00137$
	ld	a, -2 (ix)
	sub	a, #<(_path)
	ld	d, a
	ld	a, -1 (ix)
	sbc	a, #>(_path)
	ld	l, a
	ld	a, d
	sub	a, #0xfe
	ld	a, l
	rla
	ccf
	rra
	sbc	a, #0x81
	jr	NC,00137$
;menu.c:1066: *(pp++) = *(p++);
	inc	bc
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	(hl), e
	inc	-2 (ix)
	jr	NZ,00135$
	inc	-1 (ix)
	jr	00135$
00137$:
;menu.c:1070: if (*p) {
	ld	a, (bc)
	or	a, a
	jr	Z,00139$
;menu.c:1073: *pp = 0;
	pop	hl
	push	hl
	ld	(hl), #0x00
;menu.c:1074: displayErrorString("Path too long...", 0);
	xor	a, a
	push	af
	inc	sp
	ld	hl, #___str_19
	push	hl
	call	_displayErrorString
	pop	af
	inc	sp
;menu.c:1075: goto drawLoop;
	jp	00116$
00139$:
;menu.c:1079: *(pp++) = 0;
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	(hl), #0x00
00142$:
;menu.c:1083: clrscr();
	call	_clrscr
;menu.c:1087: goto dirLoop;
	jp	00106$
00145$:
;menu.c:1100: unsigned char fsize = *(p+127);  // save off the size (16k chunks)
	ld	-3 (ix), a
;menu.c:1103: s1 = path2;
	ld	-2 (ix), #<(_path2)
	ld	-1 (ix), #>(_path2)
;menu.c:1104: s2 = path;
	ld	de, #_path
;menu.c:1107: while (*s2) {
00146$:
	ld	a, (de)
	or	a, a
	jr	Z,00240$
;menu.c:1108: *(s1++) = *(s2++);
	inc	de
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	(hl), a
	inc	-2 (ix)
	jr	NZ,00146$
	inc	-1 (ix)
	jr	00146$
00240$:
	ld	e, -2 (ix)
	ld	d, -1 (ix)
;menu.c:1113: if (path[1] != 0) {
	ld	a, (#(_path + 0x0001) + 0)
	or	a, a
	jr	Z,00224$
;menu.c:1114: *(s1++) = '/';
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	(hl), #0x2f
	ld	e, -2 (ix)
	ld	d, -1 (ix)
	inc	de
;menu.c:1118: while ((*p) && (s1-path2 < 127)) {
00224$:
	ld	-2 (ix), e
	ld	-1 (ix), d
00152$:
	ld	a, (bc)
	ld	e, a
	or	a, a
	jr	Z,00241$
	ld	a, -2 (ix)
	sub	a, #<(_path2)
	ld	l, a
	ld	a, -1 (ix)
	sbc	a, #>(_path2)
	ld	d, a
	ld	a, l
	sub	a, #0x7f
	ld	a, d
	rla
	ccf
	rra
	sbc	a, #0x80
	jr	NC,00241$
;menu.c:1119: *(s1++) = *(p++);
	inc	bc
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	(hl), e
	inc	-2 (ix)
	jr	NZ,00152$
	inc	-1 (ix)
	jr	00152$
00241$:
	ld	e, -2 (ix)
	ld	d, -1 (ix)
;menu.c:1121: *s1 = 0;
	ld	l, -2 (ix)
	ld	h, -1 (ix)
	ld	(hl), #0x00
;menu.c:1124: if (*p) {
	ld	a, (bc)
	or	a, a
	jr	Z,00156$
;menu.c:1125: displayErrorString("Path too long...", 1);
	ld	a, #0x01
	push	af
	inc	sp
	ld	hl, #___str_19
	push	hl
	call	_displayErrorString
	pop	af
	inc	sp
;menu.c:1126: goto drawLoop;
	jp	00116$
00156$:
;menu.c:1130: clrscrbottom();
	push	de
	call	_clrscrbottom
	ld	hl, #___str_20
	push	hl
	xor	a, a
	push	af
	inc	sp
	call	_centerString
	inc	sp
	ld	hl,#_path2
	ex	(sp),hl
	ld	hl, #_fil
	push	hl
	call	_f_open
	pop	af
	pop	af
	ld	a, l
	pop	de
;menu.c:1135: if (FR_OK != res) {
	ld	b, a
	or	a, a
	jr	Z,00158$
;menu.c:1136: displayErrorString("Failed to open file.", res);
	push	bc
	inc	sp
	ld	hl, #___str_21
	push	hl
	call	_displayErrorString
	pop	af
	inc	sp
;menu.c:1137: goto drawLoop;
	jp	00116$
00158$:
;menu.c:1141: phRAMBankSelect = CART_FIRST_PAGE;
	ld	a, #0x01
	out	(_phRAMBankSelect), a
;menu.c:1143: res = f_read(&fil, (unsigned char*)0x8000, 512, &br);
	ld	hl, #2
	add	hl, sp
	push	hl
	push	de
	push	hl
	ld	hl, #0x0200
	push	hl
	ld	h, #0x80
	push	hl
	ld	hl, #_fil
	push	hl
	call	_f_read
	pop	af
	pop	af
	pop	af
	pop	af
	pop	de
	pop	bc
;menu.c:1144: if ((res != FR_OK) || (br != 512)) {
	ld	-1 (ix), l
	ld	a, l
	or	a, a
	jr	NZ,00159$
	ld	a, -5 (ix)
	or	a, a
	jr	NZ,00436$
	ld	a, -4 (ix)
	sub	a, #0x02
	jr	Z,00160$
00436$:
00159$:
;menu.c:1145: f_close(&fil);
	ld	hl, #_fil
	push	hl
	call	_f_close
	pop	af
;menu.c:1146: displayErrorString("Unrecognized file type.", res);
	ld	a, -1 (ix)
	push	af
	inc	sp
	ld	hl, #___str_22
	push	hl
	call	_displayErrorString
	pop	af
	inc	sp
;menu.c:1147: goto drawLoop;
	jp	00116$
00160$:
;menu.c:1151: if ( ((pRom(0x8000) == 0xaa) && (pRom(0x8001) == 0x55)) ||
	ld	a, (#0x8000)
	sub	a, #0xaa
	jr	NZ,00172$
	ld	a, (#0x8001)
	sub	a, #0x55
	jr	Z,00168$
00172$:
;menu.c:1152: ((pRom(0x8000) == 0x55) && (pRom(0x8001) == 0xaa)) ) {
	ld	a, (#0x8000)
	sub	a, #0x55
	jr	NZ,00169$
	ld	a, (#0x8001)
	sub	a, #0xaa
	jr	NZ,00169$
00168$:
;menu.c:1153: if (0 == mystrcmp(s1-4, ".sgm")) {
	ld	hl, #___str_23
	ld	a, e
	add	a, #0xfc
	ld	c, a
	ld	a, d
	adc	a, #0xff
	ld	b, a
	push	hl
	push	bc
	call	_mystrcmp
	pop	af
	pop	af
	ld	a, l
	or	a, a
	jr	NZ,00166$
;menu.c:1155: if (loadMegacartRom(fsize, 1) >= DIRECTORY_PAGE) {
	ld	a, #0x01
	push	af
	inc	sp
	ld	a, -3 (ix)
	push	af
	inc	sp
	call	_loadMegacartRom
	pop	af
	ld	a, l
	sub	a, #0x0e
	jp	C, 00116$
;menu.c:1157: goto dirLoop;
	jp	00106$
;menu.c:1160: goto drawLoop;
00166$:
;menu.c:1163: loadCartridgeRom();
	call	_loadCartridgeRom
;menu.c:1166: goto drawLoop;
	jp	00116$
00169$:
;menu.c:1176: ofs = fsize - 1;    // get the size in blocks, minus 1
	ld	l, -3 (ix)
	ld	h, #0x00
	dec	hl
	ld	a, h
	rla
	sbc	a, a
	ld	e, a
	ld	d, a
;menu.c:1177: ofs <<= 14;         // times 16384 for offset
	ld	a, #0x0e
00444$:
	add	hl, hl
	rl	e
	rl	d
	dec	a
	jr	NZ,00444$
;menu.c:1178: if (FR_OK != f_lseek(&fil, ofs)) {
	push	bc
	push	de
	push	hl
	ld	hl, #_fil
	push	hl
	call	_f_lseek
	pop	af
	pop	af
	pop	af
	ld	a, l
	pop	bc
	or	a, a
	jr	Z,00174$
;menu.c:1179: f_close(&fil);
	ld	hl, #_fil
	push	hl
	call	_f_close
	pop	af
;menu.c:1180: displayErrorString("Failed to identify file.", res);
	ld	a, -1 (ix)
	push	af
	inc	sp
	ld	hl, #___str_24
	push	hl
	call	_displayErrorString
	pop	af
	inc	sp
;menu.c:1181: goto drawLoop;
	jp	00116$
00174$:
;menu.c:1185: res = f_read(&fil, (unsigned char*)0x8200, 512, &br);
	push	bc
	ld	hl, #0x0200
	push	hl
	ld	h, #0x82
	push	hl
	ld	hl, #_fil
	push	hl
	call	_f_read
	pop	af
	pop	af
	pop	af
	pop	af
	ld	c, l
;menu.c:1186: if ((res != FR_OK) || (br != 512)) {
	ld	a, c
	or	a, a
	jr	NZ,00175$
	ld	a, -5 (ix)
	or	a, a
	jr	NZ,00446$
	ld	a, -4 (ix)
	sub	a, #0x02
	jr	Z,00176$
00446$:
00175$:
;menu.c:1188: f_close(&fil);
	push	bc
	ld	hl, #_fil
	push	hl
	call	_f_close
	pop	af
	pop	bc
;menu.c:1189: displayErrorString("Failed to read block.", res);
	ld	a, c
	push	af
	inc	sp
	ld	hl, #___str_25
	push	hl
	call	_displayErrorString
	pop	af
	inc	sp
;menu.c:1190: goto drawLoop;
	jp	00116$
00176$:
;menu.c:1194: if ( ((pRom(0x8200) == 0xaa) && (pRom(0x8201) == 0x55)) ||
	ld	a, (#0x8200)
	sub	a, #0xaa
	jr	NZ,00185$
	ld	a, (#0x8201)
	sub	a, #0x55
	jr	Z,00181$
00185$:
;menu.c:1195: ((pRom(0x8200) == 0x55) && (pRom(0x8201) == 0xaa)) ) {
	ld	a, (#0x8200)
	sub	a, #0x55
	jr	NZ,00182$
	ld	a, (#0x8201)
	sub	a, #0xaa
	jr	NZ,00182$
00181$:
;menu.c:1198: if (loadMegacartRom(fsize, 0) >= DIRECTORY_PAGE) {
	xor	a, a
	push	af
	inc	sp
	ld	a, -3 (ix)
	push	af
	inc	sp
	call	_loadMegacartRom
	pop	af
	ld	a, l
	sub	a, #0x0e
	jp	C, 00116$
;menu.c:1200: goto dirLoop;
	jp	00106$
;menu.c:1203: goto drawLoop;
00182$:
;menu.c:1209: f_close(&fil);
	ld	hl, #_fil
	push	hl
	call	_f_close
	pop	af
;menu.c:1210: displayErrorString("Unrecognized file type.", 0);
	xor	a, a
	push	af
	inc	sp
	ld	hl, #___str_22
	push	hl
	call	_displayErrorString
	pop	af
	inc	sp
;menu.c:1211: goto drawLoop;
;menu.c:1213: }
	jp	00116$
___str_14:
	.db 0x00
___str_15:
	.ascii "Failed to mount SD"
	.db 0x00
___str_16:
	.ascii "READING"
	.db 0x00
___str_17:
	.ascii "Failed to open directory"
	.db 0x00
___str_18:
	.ascii "No files found"
	.db 0x00
___str_19:
	.ascii "Path too long..."
	.db 0x00
___str_20:
	.ascii "checking..."
	.db 0x00
___str_21:
	.ascii "Failed to open file."
	.db 0x00
___str_22:
	.ascii "Unrecognized file type."
	.db 0x00
___str_23:
	.ascii ".sgm"
	.db 0x00
___str_24:
	.ascii "Failed to identify file."
	.db 0x00
___str_25:
	.ascii "Failed to read block."
	.db 0x00
	.area _CODE
	.area _INITIALIZER
__xinit__lastFilename:
	.dw #0x0000
__xinit__listSize:
	.db #0x00	; 0
__xinit__listOffset:
	.db #0x00	; 0
__xinit__listSelect:
	.db #0x00	; 0
__xinit__firstScan:
	.db #0x00	; 0
__xinit__firstDir:
	.db #0x00	; 0
__xinit__showExt:
	.db #0x00	; 0
__xinit__MENU_COLOR_SETS:
	.dw _MENU_PALETTE
	.dw _MENU_INVERT
	.dw _MENU_CONTRAST
	.area _CABS (ABS)
