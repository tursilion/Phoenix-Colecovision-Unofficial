This is the DEMO core for NES - it will only say NES on the core screen.
It will automatically boot the first NES core in the root of the card - no selection.
Coleco pads do not work properly, you have to use a SNES pad.

All that is fixed in the full core.
